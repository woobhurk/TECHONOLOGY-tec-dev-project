package com.tyfanch.testjavaee.test07_mysql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Main {
    public static final String DB_DRIVER = "com.mysql.cj.jdbc.Driver";
    public static final String DB_URL = "jdbc:mysql://localhost:3306/test_db";
    public static final String DB_USER = "root";
    public static final String DB_PASSWORD = "root";

    public static void main(String[] args) {
        Main mainTester = new Main();

        mainTester.testMySql();
    }

    private void testMySql() {
        Connection connection = null;
        Statement statement = null;
        String sqlQueryStr = "select * from `websites`;";

        try {
            Class.forName(Main.DB_DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            statement = connection.createStatement();
            // Show table
            System.out.println(queryTable(statement, sqlQueryStr));
            // Update table
            updateTable(statement);
            System.out.println("---- UPDATED");
            // Show table again
            System.out.println(queryTable(statement, sqlQueryStr));

            statement.close();
            connection.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    private String queryTable(Statement statement, String sqlQueryStr) {
        ResultSet resultSet;
        StringBuilder resultStrBuilder = new StringBuilder();

        try {
            resultSet = statement.executeQuery(sqlQueryStr);

            while (resultSet.next()) {
                resultStrBuilder.append(String.format("id=%-2d, name=%-10s, url=%-50s, alexa=%-6d, country=%-5s%n",
                        resultSet.getInt("id"), resultSet.getString("name"),
                        resultSet.getString("url"), resultSet.getInt("alexa"),
                        resultSet.getString("country")));
            }

            resultSet.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return resultStrBuilder.toString();
    }

    private void updateTable(Statement statement) {
        Scanner scanner = new Scanner(System.in);
        String sqlUpdateStr;
        int id;
        String name;
        String url;
        int alexa;
        String country;

        System.out.print("New line.id = ");
        id = scanner.nextInt();
        scanner.nextLine();
        System.out.print("New line.name = ");
        name = scanner.nextLine();
        System.out.print("New line.url = ");
        url = scanner.nextLine();
        System.out.print("New line.alexa = ");
        alexa = scanner.nextInt();
        scanner.nextLine();
        System.out.print("New line.country = ");
        country = scanner.nextLine();
        sqlUpdateStr = String.format("insert into `websites` values ('%d', '%s', '%s', '%d', '%s');",
                id, name, url, alexa, country);
        System.out.println("sqlUpdateStr = " + sqlUpdateStr);

        try {
            statement.executeUpdate(sqlUpdateStr);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
