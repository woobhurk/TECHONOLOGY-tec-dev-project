package com.tyfanch.testjavaee.test01_thread;

public class BalanceRunnable implements Runnable {
    private static int  balance = 100;

    @Override
    public void run() {
        while (balance > 0) {
            synchronized (Object.class) {
                System.out.println(Thread.currentThread().getName() + ", balance = " + balance);
                balance--;
            }

            try {
                Thread.sleep(200);
            } catch (InterruptedException e) {
                e.printStackTrace();
                Thread.currentThread().interrupt();
            }
        }
    }
}
