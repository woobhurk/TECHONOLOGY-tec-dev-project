package com.tyfanch.testjavaee.test06_jdk8newfeature;

public interface TestDefaultInterface1 {
    default void printName(String name) {
        System.out.println("name1 = " + name);
    }
}
