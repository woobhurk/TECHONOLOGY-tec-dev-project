package com.tyfanch.testjavaee.test09_threadpool;

import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;

public class Main {
    public static void main(String[] args) {
        ThreadPoolExecutor threadPoolExecutor = (ThreadPoolExecutor) Executors.newFixedThreadPool(20);

        for (int i = 0; i < 10; i++) {
            DemoTask demoTask = new DemoTask();

            threadPoolExecutor.execute(demoTask);
            System.out.println("线程数：" + threadPoolExecutor.getPoolSize() +
                                "，队列大小：" + threadPoolExecutor.getQueue().size() +
                                "，已完成：" + threadPoolExecutor.getCompletedTaskCount());
        }

        threadPoolExecutor.shutdown();
    }
}
