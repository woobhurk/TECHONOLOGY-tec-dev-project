package com.tyfanch.testjavaee.test05_stream;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        File file = new File("./test.txt");
        OutputStreamWriter outputStreamWriter;
        InputStreamReader inputStreamReader;
        Scanner scanner = new Scanner(System.in);
        String fileContentStr;
        char[] fileContentChars;

        try {
            outputStreamWriter = new OutputStreamWriter(new FileOutputStream(file), "utf-8");
            inputStreamReader = new InputStreamReader(new FileInputStream(file), "utf-8");

            System.out.print("Input str: \t");
            fileContentStr = scanner.nextLine();
            scanner.close();
            outputStreamWriter.write(new StringBuilder(fileContentStr).reverse().toString().toCharArray());
            outputStreamWriter.close();
            fileContentChars = new char[(int) file.length()];
            inputStreamReader.read(fileContentChars);
            inputStreamReader.close();
            System.out.println("File content: \t" + new String(fileContentChars));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
