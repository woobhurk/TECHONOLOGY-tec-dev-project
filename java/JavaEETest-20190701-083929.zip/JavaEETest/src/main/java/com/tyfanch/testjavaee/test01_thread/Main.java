package com.tyfanch.testjavaee.test01_thread;

public class Main {
    public static void main(String[] args) {
        Main main = new Main();

        main.testSyncThread();
        main.testThreadDie();
    }

    private void testSyncThread() {
        System.out.println("---- testSyncThread");

        BalanceRunnable balanceRunnable = new BalanceRunnable();

        for (int i = 0; i < 10; i++) {
            new Thread(balanceRunnable, "Balance " + i).start();
        }
    }

    private void testThreadDie() {
        System.out.println("---- testThreadDie");

        Thread thread = new Thread(() -> {
            for (int i = 0; i < 100; i++) {
                System.out.println("i = " + i);
            }
        });

        thread.start();

        try {
            thread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
            Thread.currentThread().interrupt();
        }

        System.out.println(thread.getName() + " died.");
    }
}
