package com.tyfanch.testjavaee.test08_gson;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class Main {

    public static void main(String[] args) {
        Main mainTester = new Main();
        Gson gson = new Gson();

        mainTester.testConvBasic(gson);
        mainTester.testConvPojo(gson);
        mainTester.testConvList(gson);
    }

    private void testConvBasic(Gson gson) {
        int varA = 10;
        boolean varB = false;
        float varC = 23.3404F;
        double varD = 32.20329;
        String varE = "Hello";
        String jsonStr;

        jsonStr = gson.toJson(varA);
        System.out.println("---- " + varA);
        System.out.println("varA = " + gson.fromJson(jsonStr, int.class));
        jsonStr = gson.toJson(varB);
        System.out.println("---- " + varB);
        System.out.println("varB = " + gson.fromJson(jsonStr, boolean.class));
        jsonStr = gson.toJson(varC);
        System.out.println("---- " + varC);
        System.out.println("varC = " + gson.fromJson(jsonStr, float.class));
        jsonStr = gson.toJson(varD);
        System.out.println("---- " + varD);
        System.out.println("varD = " + gson.fromJson(jsonStr, double.class));
        jsonStr = gson.toJson(varE);
        System.out.println("---- " + varE);
        System.out.println("varE = " + gson.fromJson(jsonStr, String.class));
    }

    private void testConvPojo(Gson gson) {
        PojoTest pojoTest = new PojoTest();
        String jsonStr;

        pojoTest.setName("tyfanch");
        pojoTest.setSex(0);
        pojoTest.setAge(22);
        pojoTest.setBirthday(LocalDateTime.of(1997, 2, 24, 11, 24));
        jsonStr = gson.toJson(pojoTest);
        System.out.println("---- " + jsonStr);
        System.out.println("pojoTest = " + gson.fromJson(jsonStr, PojoTest.class));
    }

    private void testConvList(Gson gson) {
        List<PojoTest> pojoTests = new ArrayList<>();
        String jsonStr;

        for (int i = 0; i < 5; i++) {
            PojoTest pojoTest = new PojoTest();
            Random random = new Random();

            pojoTest.setName("sfhje vjsojv");
            pojoTest.setSex(random.nextInt(1));
            pojoTest.setAge(random.nextInt(100));
            pojoTest.setBirthday(LocalDateTime.of(random.nextInt(2000), random.nextInt(11) + 1,
                                    random.nextInt(31), random.nextInt(23), random.nextInt(59),
                                    random.nextInt(59)));
            pojoTests.add(pojoTest);
        }

        jsonStr = gson.toJson(pojoTests);
        System.out.println("---- " + jsonStr);
        System.out.println("pojoTests = " + gson.fromJson(jsonStr, new TypeToken<List<PojoTest>>(){}.getType()));
    }
}
