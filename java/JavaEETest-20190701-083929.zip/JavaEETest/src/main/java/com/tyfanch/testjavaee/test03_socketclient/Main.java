package com.tyfanch.testjavaee.test03_socketclient;

public class Main {
    public static void main(String[] args) {
        new SocketClientTest().start();
    }
}
