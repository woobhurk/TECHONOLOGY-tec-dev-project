package com.tyfanch.testjavaee.test02_socketserver;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class SocketServerTest {
    public static final String SERVER = "localhost";
    public static final int PORT = 8888;
    public static final int BUFFER_SIZE = 1024;

    public void start() {
        ServerSocket serverSocket;
        Socket socket;

        try {
            serverSocket = new ServerSocket(PORT);
            System.out.println("Server listening to port " + PORT);

            while (true) {
                try {
                    socket = serverSocket.accept();
                    System.out.println("Connected with " + socket.getInetAddress() + ":" + socket.getPort() + "...");
                    retriveRequestStr(socket);
                    postResponseStr(socket);
                    socket.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String retriveRequestStr(Socket socket) throws Exception {
        InputStream socketInputStream = socket.getInputStream();
        String requestStr = "";
        byte[] buffer = new byte[BUFFER_SIZE];

        socketInputStream.read(buffer);
        requestStr = new String(buffer, "utf-8");
        System.out.println("Client> " + requestStr);

        return requestStr;
    }

    private String postResponseStr(Socket socket) throws Exception {
        Scanner scanner = new Scanner(System.in);
        OutputStream socketOutputStream = socket.getOutputStream();
        String responseStr = "";

        System.out.print("Server> ");
        responseStr = scanner.nextLine();
        scanner.close();
        socketOutputStream.write(responseStr.getBytes("utf-8"));

        return responseStr;
    }
}
