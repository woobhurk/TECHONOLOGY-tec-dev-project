package com.tyfanch.testjavaee.test03_socketclient;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.Scanner;

public class SocketClientTest {
    public static final String SERVER = "localhost";
    public static final int PORT = 8888;
    public static final int BUFFER_SIZE = 1024;

    public void start() {
        Socket socket = null;

        while (true) {
            System.out.println("Connecting to server...");

            try {
                socket = new Socket(SERVER, PORT);
            } catch (Exception e) {
                e.printStackTrace();
            }

            System.out.println("Connected to " + socket.getInetAddress() + ":" + socket.getPort());

            try {
                postRequestStr(socket);
                retriveResponseStr(socket);
                socket.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private String postRequestStr(Socket socket) throws Exception {
        OutputStream socketOutputStream = socket.getOutputStream();
        Scanner scanner = new Scanner(System.in);
        String requestStr = "";

        scanner.reset();
        System.out.print("Client> ");
        requestStr = scanner.nextLine();
        scanner.close();
        socketOutputStream.write(requestStr.getBytes("utf-8"));

        return requestStr;
    }

    private String retriveResponseStr(Socket socket) throws Exception {
        InputStream socketInputStream = socket.getInputStream();
        String responseStr = "";
        byte[] buffer = new byte[socketInputStream.available()];

        socketInputStream.read(buffer);
        responseStr = new String(buffer, "utf-8");
        System.out.println("Server> " + responseStr);

        return responseStr;
    }
}
