package com.tyfanch.testjavaee.test06_jdk8newfeature;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

public class Main {
    public static void main(String[] args) {
        Main mainTester = new Main();

        try {
            mainTester.testLambda();
            mainTester.testFunctionalInterface();
            mainTester.testFunctionRef();
            mainTester.testDefaultInterface();
            mainTester.testStream();
            mainTester.testNewDate();
            mainTester.testBase64();
            mainTester.testNashorn();
        } catch (NoSuchAlgorithmException | InterruptedException e) {
            e.printStackTrace();
        }
    }

    private void testLambda() {
        System.out.println("---- testLambda");

        TestLambdaInterface testLambdaInterface = (message) -> {
            System.out.println(message);
        };

        testLambdaInterface.showMessage("hello");
    }

    private void testFunctionalInterface() {
        // Already tested in `testLambda`
    }

    private void testFunctionRef() throws NoSuchAlgorithmException {
        System.out.println("---- testFunctionRef");

        List<Integer> userIntegers = new ArrayList<>();

        for (int i = 0; i < 10; i++) {
            userIntegers.add(SecureRandom.getInstanceStrong().nextInt(100));
        }

        userIntegers.forEach(System.out::println);
    }

    private void testDefaultInterface() {
        System.out.println("---- testDefaultInterface");

        new TestDefaultInterfaceImpl().printName("nullName");
    }

    private void testStream() {
        System.out.println("---- testStream");

        Random random = new Random(System.currentTimeMillis());

        random.ints().limit(10).map(x -> x * x).sorted().forEach(System.out::println);
    }

    private void testNewDate() {
        System.out.println("---- testNewDate");

        LocalDateTime localDateTime = LocalDateTime.now();

        System.out.printf("现在时间：%d年%d月%d日 %d时%d分%d秒%n", localDateTime.getYear(),
                localDateTime.getMonth().getValue(), localDateTime.getDayOfMonth(), localDateTime.getHour(),
                localDateTime.getMinute(), localDateTime.getSecond());
    }

    private void testBase64() {
        System.out.println("---- testBase64");

        Scanner scanner = new Scanner(System.in);
        String decodeStr;
        String encodedStr;

        System.out.print("String to be encoded: ");
        scanner.reset();
        decodeStr = scanner.nextLine();

        try {
            encodedStr = Base64.getEncoder().encodeToString(decodeStr.getBytes("utf-8"));
            System.out.println("Encoded str: " + encodedStr);
            System.out.println("Decoded str: " + new String(Base64.getDecoder().decode(encodedStr)));

            encodedStr = Base64.getUrlEncoder().encodeToString(decodeStr.getBytes("utf-8"));
            System.out.println("Encoded URL str: " + encodedStr);
            System.out.println("Decoded URL str: " + new String(Base64.getUrlDecoder().decode(encodedStr)));

            encodedStr = Base64.getMimeEncoder().encodeToString(decodeStr.getBytes("utf-8"));
            System.out.println("Encoded MIME str: " + encodedStr);
            System.out.println("Decoded MIME str: " + new String(Base64.getMimeDecoder().decode(encodedStr)));
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
    }

    private void testNashorn() throws InterruptedException {
        System.out.println("---- testNashorn");

        ScriptEngineManager scriptEngineManager = new ScriptEngineManager();
        ScriptEngine scriptEngine = scriptEngineManager.getEngineByName("nashorn");
        Scanner scanner = new Scanner(System.in);
        String scriptLine = "";
        Object scriptResult;

        do {
            try {
                System.out.print("Nashorn> ");
                scriptLine = scanner.nextLine();
                scriptResult = scriptEngine.eval(scriptLine);

                if (scriptResult != null) {
                    System.out.println("[I] " + scriptResult.toString());
                    scriptEngine.getContext().getWriter().flush();
                }
            } catch (ScriptException | IOException e) {
                System.err.println("[E] " + e.getMessage());
                //e.printStackTrace();
            }

            Thread.sleep(200);
        } while (!scriptLine.trim().equalsIgnoreCase("exit"));

        System.out.println("Goodbye.");
    }
}
