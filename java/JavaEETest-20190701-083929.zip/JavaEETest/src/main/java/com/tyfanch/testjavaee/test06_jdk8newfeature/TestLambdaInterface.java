package com.tyfanch.testjavaee.test06_jdk8newfeature;

@FunctionalInterface
public interface TestLambdaInterface {
    void showMessage(String message);
}
