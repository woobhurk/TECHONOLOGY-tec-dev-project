package com.tyfanch.testjavaee.test02_socketserver;

public class Main {
    public static void main(String[] args) {
        new SocketServerTest().start();
    }
}

