package com.tyfanch.testjavaee.test04_date;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Date date = new Date();
        Scanner scanner;
        String dateStr;
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        System.out.println(simpleDateFormat.format(date));
        System.out.printf("%1$tF %1$tT%n", date);
        System.out.print("Input date: ");

        try {
            scanner = new Scanner(System.in);
            dateStr = scanner.nextLine();
            scanner.close();
            date = simpleDateFormat.parse(dateStr);
            System.out.println("Your input: " + date.toString());
        } catch (Exception e) {
            System.err.println("Error when parsing dateStr:");
            e.printStackTrace();
        }
    }
}
