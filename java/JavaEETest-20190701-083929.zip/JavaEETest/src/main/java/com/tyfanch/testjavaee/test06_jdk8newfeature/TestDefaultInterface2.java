package com.tyfanch.testjavaee.test06_jdk8newfeature;

public interface TestDefaultInterface2 {
    default void printName(String name) {
        System.out.println("name2 = " + name);
    }
}
