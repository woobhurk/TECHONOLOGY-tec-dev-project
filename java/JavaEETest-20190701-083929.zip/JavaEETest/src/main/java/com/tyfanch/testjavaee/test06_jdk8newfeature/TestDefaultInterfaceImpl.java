package com.tyfanch.testjavaee.test06_jdk8newfeature;

public class TestDefaultInterfaceImpl implements TestDefaultInterface1, TestDefaultInterface2 {
    @Override
    public void printName(String name) {
        TestDefaultInterface1.super.printName(name);
        TestDefaultInterface2.super.printName(name);
        System.out.println("name = " + name);
    }
}
