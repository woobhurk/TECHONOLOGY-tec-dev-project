package com.tyfanch.testjavaee.test08_gson;

import java.time.LocalDateTime;

/**
 * @author tyfanch
 */
public class PojoTest {
    private String name;
    private int sex;
    private int age;
    private LocalDateTime birthday = LocalDateTime.of(1997, 4, 4, 21, 23);

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getSex() {
        return sex;
    }

    public void setSex(int sex) {
        this.sex = sex;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public LocalDateTime getBirthday() {
        return birthday;
    }

    public void setBirthday(LocalDateTime birthday) {
        this.birthday = birthday;
    }
}
