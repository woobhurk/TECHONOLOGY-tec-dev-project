package com.tyfanch.electivehelper.ui;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

import com.google.android.material.tabs.TabLayout;
import com.tyfanch.electivehelper.R;
import com.tyfanch.electivehelper.databinding.ActivityMainBinding;
import com.tyfanch.electivehelper.ui.adapters.FragmentVpAdapter;
import com.tyfanch.electivehelper.view.vc.MainVc;

@SuppressWarnings("ConstantConditions")
public class MainActivity extends AppCompatActivity {
    public static final int ID = 0x000000;

    private ActivityMainBinding mainBinding;
    private int currentPageIndex;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        this.mainBinding = DataBindingUtil.setContentView(this, R.layout.activity_main);
        this.setContentView(this.mainBinding.getRoot());
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // 如果用户未登录则直接退出应用
        if (requestCode == AccountActivity.ID && resultCode != Activity.RESULT_OK) {
            this.finish();
        } else {
            TabLayout tvMain = this.mainBinding.tabMain;
            int tabCount = tvMain.getTabCount();

            tvMain.getTabAt(tabCount - 1).select();
        }
    }

    @Override
    protected void onStart() {
        super.onStart();

        MainVc mainVc;
        FragmentVpAdapter fragmentVpAdapter;

        fragmentVpAdapter = new FragmentVpAdapter(this.getSupportFragmentManager());
        fragmentVpAdapter.addFragment(new OnlineCourseListFrag(),
            this.getString(R.string.online_course));
        fragmentVpAdapter.addFragment(new CourseListFrag(),
            this.getString(R.string.course_list));
        fragmentVpAdapter.addFragment(new MsgListFrag(),
            this.getString(R.string.msg_list));
        fragmentVpAdapter.addFragment(new UserCenterFrag(),
            this.getString(R.string.user_center));
        this.mainBinding.vpMain.setAdapter(fragmentVpAdapter);
        this.mainBinding.tabMain.setupWithViewPager(this.mainBinding.vpMain);
        // 恢复之前离开时标签页位置
        this.mainBinding.tabMain.getTabAt(this.currentPageIndex).select();

        mainVc = new MainVc(this, this.getSupportFragmentManager());
        this.mainBinding.setMainVc(mainVc);
    }

    @Override
    protected void onPause() {
        super.onPause();

        // 保存当前离开时的标签页位置
        this.currentPageIndex = this.mainBinding.tabMain.getSelectedTabPosition();
    }
}
