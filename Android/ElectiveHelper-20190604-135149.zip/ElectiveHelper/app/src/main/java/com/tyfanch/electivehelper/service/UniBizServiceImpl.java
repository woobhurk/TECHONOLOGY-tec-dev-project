package com.tyfanch.electivehelper.service;

import com.tyfanch.electivehelper.bean.StudentCourseConst;
import com.tyfanch.electivehelper.constant.ServerConfig;
import com.tyfanch.electivehelper.interfaces.ResultCallback;
import com.tyfanch.electivehelper.utils.HttpUtils;

import java.util.HashMap;
import java.util.Map;

public class UniBizServiceImpl extends BaseCommonService implements UniBizService {
    @Override
    public void findStudentsOfCourse(String studentCourseJson, ResultCallback callback) {
        Map<String, String> postBody = new HashMap<>();

        postBody.put(ServerConfig.REQUEST_ACTION, "findStudentsOfCourse");
        postBody.put(StudentCourseConst.NAME, studentCourseJson);
        HttpUtils.post(ServerConfig.STUDENT_URL, postBody,
            result -> this.requestSuccess((String) result, callback),
            result -> this.requestFail(callback));
    }

    @Override
    public void hasSelected(String studentCourseJson, ResultCallback callback) {
        Map<String, String> postBody = new HashMap<>();

        postBody.put(ServerConfig.REQUEST_ACTION, "hasSelected");
        postBody.put(StudentCourseConst.NAME, studentCourseJson);
        HttpUtils.post(ServerConfig.STUDENT_URL, postBody,
            result -> this.requestSuccess((String) result, callback),
            result -> this.requestFail(callback));
    }

    @Override
    public void selectCourse(String studentCourseJson, ResultCallback callback) {
        Map<String, String> postBody = new HashMap<>();

        postBody.put(ServerConfig.REQUEST_ACTION, "selectCourse");
        postBody.put(StudentCourseConst.NAME, studentCourseJson);
        HttpUtils.post(ServerConfig.STUDENT_URL, postBody,
            result -> this.requestSuccess((String) result, callback),
            result -> this.requestFail(callback));
    }

    @Override
    public void deselectCourse(String studentCourseJson, ResultCallback callback) {
        Map<String, String> postBody = new HashMap<>();

        postBody.put(ServerConfig.REQUEST_ACTION, "deselectCourse");
        postBody.put(StudentCourseConst.NAME, studentCourseJson);
        HttpUtils.post(ServerConfig.STUDENT_URL, postBody,
            result -> this.requestSuccess((String) result, callback),
            result -> this.requestFail(callback));
    }
}
