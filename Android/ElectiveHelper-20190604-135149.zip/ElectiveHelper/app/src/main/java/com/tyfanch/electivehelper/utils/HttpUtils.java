package com.tyfanch.electivehelper.utils;

import android.util.Log;

import com.tyfanch.electivehelper.interfaces.ResultCallback;

import java.io.IOException;
import java.util.Map;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class HttpUtils {
    private HttpUtils() {}

    public static void post(String url, Map<String, String> body,
        final ResultCallback onSuccess, final ResultCallback onFail) {
        FormBody.Builder builder = new FormBody.Builder();
        RequestBody requestBody;

        for (Map.Entry<String, String> entry : body.entrySet()) {
            builder.add(entry.getKey(), entry.getValue());
        }

        requestBody = builder.build();
        final Request request = new Request.Builder()
            .url(url)
            .post(requestBody)
            .build();
        OkHttpClient httpClient = new OkHttpClient();

        httpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.d("HttpUtils", e.getMessage());
                onFail.onResult(e.getMessage());
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.body() != null) {
                    onSuccess.onResult(response.body().string());
                } else {
                    onSuccess.onResult("");
                }
            }
        });
    }

    //public static void post(String url, String body,
    //    final ResultCallback onSuccess, final ResultCallback onFail) {
    //    MediaType mediaType = MediaType.parse("text/plain; charset=utf-8");
    //    Request request = new Request.Builder()
    //        .url(url)
    //        .post(RequestBody.create(mediaType, body))
    //        .build();
    //    OkHttpClient httpClient = new OkHttpClient();
    //
    //    httpClient.newCall(request).enqueue(new Callback() {
    //        @Override
    //        public void onFailure(Call call, IOException e) {
    //            onFail.onResult(e.getMessage());
    //        }
    //
    //        @Override
    //        public void onResponse(Call call, Response response) throws IOException {
    //            if (response.body() != null) {
    //                onSuccess.onResult(response.body().string());
    //            } else {
    //                onSuccess.onResult("");
    //            }
    //        }
    //    });
    //}
}
