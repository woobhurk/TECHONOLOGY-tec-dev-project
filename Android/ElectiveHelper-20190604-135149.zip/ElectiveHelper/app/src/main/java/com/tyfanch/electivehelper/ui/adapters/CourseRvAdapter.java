package com.tyfanch.electivehelper.ui.adapters;


import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.tyfanch.electivehelper.R;
import com.tyfanch.electivehelper.databinding.ItemCourseBinding;
import com.tyfanch.electivehelper.view.vc.CourseItemVc;
import com.tyfanch.electivehelper.view.vc.CourseListVc;
import com.tyfanch.electivehelper.view.vo.CourseVo;

import java.util.List;

public class CourseRvAdapter extends RecyclerView.Adapter<CourseRvAdapter.CourseRvHolder> {
    private FragmentActivity activity;
    private CourseListVc courseListVc;
    private List<CourseVo> courseVoList;

    public CourseRvAdapter(FragmentActivity activity, CourseListVc courseListVc,
        List<CourseVo> courseVoList) {
        this.activity = activity;
        this.courseListVc = courseListVc;
        this.courseVoList = courseVoList;
    }

    @Override
    public CourseRvHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(this.activity);
        //View itemView = layoutInflater.inflate(
        //    R.layout.item_course, parent, false);

        ItemCourseBinding courseBinding = DataBindingUtil.inflate(
            layoutInflater, R.layout.item_course, parent, false);

        return new CourseRvHolder(courseBinding);
    }

    @Override
    public void onBindViewHolder(CourseRvHolder holder, int position) {
        CourseVo courseVo = this.courseVoList.get(position);
        CourseItemVc courseItemVc;

        courseItemVc = new CourseItemVc(this.activity, courseVo);
        holder.getCourseBinding().setCourseListVc(this.courseListVc);
        holder.getCourseBinding().setCourseItemVc(courseItemVc);
    }

    @Override
    public int getItemCount() {
        return this.courseVoList.size();
    }

    public List<CourseVo> getCourseVoList() {
        return this.courseVoList;
    }

    public void setCourseVoList(List<CourseVo> courseVoList) {
        this.courseVoList = courseVoList;
    }

    /**
     * CourseRvHolder
     */
    public static class CourseRvHolder extends RecyclerView.ViewHolder {
        private ItemCourseBinding courseBinding;

        public CourseRvHolder(ItemCourseBinding courseBinding) {
            super(courseBinding.getRoot());

            this.courseBinding = courseBinding;
        }

        public ItemCourseBinding getCourseBinding() {
            return this.courseBinding;
        }

        public void setCourseBinding(ItemCourseBinding courseBinding) {
            this.courseBinding = courseBinding;
        }
    }
}
