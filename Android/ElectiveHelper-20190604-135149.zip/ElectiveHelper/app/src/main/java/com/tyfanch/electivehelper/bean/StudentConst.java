package com.tyfanch.electivehelper.bean;

public class StudentConst extends UniUserConst {
    private StudentConst() {}

    public static final String NAME = "student";
}
