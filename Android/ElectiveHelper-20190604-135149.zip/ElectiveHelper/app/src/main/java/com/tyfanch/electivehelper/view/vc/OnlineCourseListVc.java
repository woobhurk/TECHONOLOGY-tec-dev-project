package com.tyfanch.electivehelper.view.vc;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.view.View;

import androidx.databinding.BaseObservable;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;

import com.fasterxml.jackson.core.type.TypeReference;
import com.tyfanch.electivehelper.bean.UniUserConst;
import com.tyfanch.electivehelper.service.OnlineCourseService;
import com.tyfanch.electivehelper.service.OnlineCourseServiceImpl;
import com.tyfanch.electivehelper.ui.OnlineCourseActivity;
import com.tyfanch.electivehelper.ui.adapters.OnlineCourseRvAdapter;
import com.tyfanch.electivehelper.ui_utils.PreferenceUtil;
import com.tyfanch.electivehelper.ui_utils.PromptUtil;
import com.tyfanch.electivehelper.utils.JsonUtils;
import com.tyfanch.electivehelper.view.vo.OnlineCourseVo;
import com.tyfanch.electivehelper.view.vo.OnlineCourseVoConst;
import com.tyfanch.electivehelper.view.vo.ResultInfo;

import java.io.IOException;
import java.util.List;

public class OnlineCourseListVc extends BaseObservable {
    private FragmentActivity activity;
    private FragmentManager fragmentManager;
    private RecyclerView rvOnlineCourseList;
    private OnlineCourseService onlineCourseService = new OnlineCourseServiceImpl();

    public OnlineCourseListVc(FragmentActivity activity,
        FragmentManager fragmentManager, RecyclerView rvOnlineCourseList) {
        this.activity = activity;
        this.fragmentManager = fragmentManager;
        this.rvOnlineCourseList = rvOnlineCourseList;

        this.initVc();
    }

    @SuppressLint("DefaultLocale")
    public void onOnlineCourseClick(View view, OnlineCourseVo onlineCourseVo) {
        //PromptUtil.showToast(this.activity, onlineCourseVo.getName());
        //Intent intent = new Intent();
        //Uri uri = Uri.parse(String.format(OnlineCourseConfig.COURSE_URL,
        //    onlineCourseVo.getCourseId()));
        //
        //intent.setAction(Intent.ACTION_VIEW);
        //intent.setData(uri);
        //this.activity.startActivity(intent);
        Intent intent = new Intent(this.activity, OnlineCourseActivity.class);

        try {
            intent.putExtra(OnlineCourseVoConst.NAME, JsonUtils.toJson(onlineCourseVo));
            this.activity.startActivityForResult(intent, OnlineCourseActivity.ID);
        } catch (IOException e) {
            e.printStackTrace();
            PromptUtil.showToast(this.activity, e.getMessage());
        }
    }

    private void initVc() {
        this.fetchOnlineCourse();
    }

    private void fetchOnlineCourse() {
        String uniUserJson = PreferenceUtil.getString(
            this.activity, UniUserConst.NAME, "");

        this.onlineCourseService.findByInterest(uniUserJson,
            result -> this.proceedFetchOnlineCourseResult((ResultInfo) result));
    }

    private void proceedFetchOnlineCourseResult(ResultInfo resultInfo) {
        try {
            if (resultInfo.getSuccess()) {
                String onlineCourseListJson = (String) resultInfo.getResultData();
                List<OnlineCourseVo> onlineCourseVoList = JsonUtils.fromJson(onlineCourseListJson,
                    new TypeReference<List<OnlineCourseVo>>() {});

                this.updateOnlineCourseList(onlineCourseVoList);
            } else {
                this.activity.runOnUiThread(
                    () -> PromptUtil.showToast(this.activity, resultInfo.getResultMsg()));
            }
        } catch (IOException e) {
            e.printStackTrace();
            this.activity.runOnUiThread(
                () -> PromptUtil.showToast(this.activity, e.getMessage()));
        }
    }

    private void updateOnlineCourseList(List<OnlineCourseVo> onlineCourseVoList) {
        OnlineCourseRvAdapter onlineCourseRvAdapter;

        if (this.rvOnlineCourseList.getAdapter() != null) {
            onlineCourseRvAdapter = (OnlineCourseRvAdapter) this.rvOnlineCourseList.getAdapter();
            onlineCourseRvAdapter.setOnlineCourseVoList(onlineCourseVoList);
            this.activity.runOnUiThread(onlineCourseRvAdapter::notifyDataSetChanged);
        } else {
            onlineCourseRvAdapter = new OnlineCourseRvAdapter(this.activity,
                this, onlineCourseVoList);
            this.activity.runOnUiThread(
                () -> this.rvOnlineCourseList.setAdapter(onlineCourseRvAdapter));
        }
    }
}
