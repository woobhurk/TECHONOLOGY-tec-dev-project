package com.tyfanch.electivehelper.service;

import android.content.Context;

import com.tyfanch.electivehelper.bean.UniUserConst;
import com.tyfanch.electivehelper.bean.UserConst;
import com.tyfanch.electivehelper.constant.ServerConfig;
import com.tyfanch.electivehelper.interfaces.ResultCallback;
import com.tyfanch.electivehelper.ui_utils.PreferenceUtil;
import com.tyfanch.electivehelper.utils.Base64Utils;
import com.tyfanch.electivehelper.utils.HttpUtils;
import com.tyfanch.electivehelper.view.vo.UserVoConst;

import java.util.HashMap;
import java.util.Map;

public class AccountServiceImpl extends BaseCommonService implements AccountService {
    @Override
    public void login(String userVoJson, ResultCallback callback) {
        Map<String, String> postBody = new HashMap<>();

        postBody.put(ServerConfig.REQUEST_ACTION, "login");
        postBody.put(UserVoConst.NAME, userVoJson);
        HttpUtils.post(ServerConfig.USER_URL, postBody,
            resultInfoJson -> this.requestSuccess((String) resultInfoJson, callback),
            result -> this.requestFail(callback));
    }

    @Override
    public void loginByIdAndPassword(String userJson, ResultCallback callback) {
        Map<String, String> postBody = new HashMap<>();

        postBody.put(ServerConfig.REQUEST_ACTION, "loginByIdAndPassword");
        postBody.put(UserConst.NAME, Base64Utils.encode(userJson));
        HttpUtils.post(ServerConfig.USER_URL, postBody,
            resultInfoJson -> this.requestSuccess((String) resultInfoJson, callback),
            result -> this.requestFail(callback));
    }

    @Override
    public void reg(String userVoJson, ResultCallback callback) {
        Map<String, String> postBody = new HashMap<>();

        postBody.put(ServerConfig.REQUEST_ACTION, "reg");
        postBody.put(UserVoConst.NAME, userVoJson);
        HttpUtils.post(ServerConfig.USER_URL, postBody,
            resultInfoJson -> this.requestSuccess((String) resultInfoJson, callback),
            result -> this.requestFail(callback));
    }

    @Override
    public void update(String userJson, ResultCallback callback) {
        Map<String, String> postBody = new HashMap<>();

        postBody.put(ServerConfig.REQUEST_ACTION, "update");
        postBody.put(UserConst.NAME, userJson);
        HttpUtils.post(ServerConfig.USER_URL, postBody,
            resultInfoJson -> this.requestSuccess((String) resultInfoJson, callback),
            result -> this.requestFail(callback));
    }

    @Override
    public void isUsernameExist(String userJson, ResultCallback callback) {
        Map<String, String> postBody = new HashMap<>();

        postBody.put(ServerConfig.REQUEST_ACTION, "isUsernameExist");
        postBody.put(UserConst.NAME, Base64Utils.encode(userJson));
        HttpUtils.post(ServerConfig.USER_URL, postBody,
            resultInfoJson -> this.requestSuccess((String) resultInfoJson, callback),
            result -> this.requestFail(callback));
    }

    @Override
    public void isEmailExist(String userJson, ResultCallback callback) {
        Map<String, String> postBody = new HashMap<>();

        postBody.put(ServerConfig.REQUEST_ACTION, "isEmailExist");
        postBody.put(UserConst.NAME, Base64Utils.encode(userJson));
        HttpUtils.post(ServerConfig.USER_URL, postBody,
            resultInfoJson -> this.requestSuccess((String) resultInfoJson, callback),
            result -> this.requestFail(callback));
    }

    @Override
    public void hasLogin(String userJson, ResultCallback callback) {
        Map<String, String> postBody = new HashMap<>();

        postBody.put(ServerConfig.REQUEST_ACTION, "hasLogin");
        postBody.put(UserConst.NAME, userJson);
        HttpUtils.post(ServerConfig.USER_URL, postBody,
            resultInfoJson -> this.requestSuccess((String) resultInfoJson, callback),
            result -> this.requestFail(callback));
    }

    @Override
    public void logout(Context ctx, ResultCallback callback) {
        PreferenceUtil.remove(ctx, UserConst.NAME);
        PreferenceUtil.remove(ctx, UniUserConst.NAME);
        callback.onResult(null);
    }
}
