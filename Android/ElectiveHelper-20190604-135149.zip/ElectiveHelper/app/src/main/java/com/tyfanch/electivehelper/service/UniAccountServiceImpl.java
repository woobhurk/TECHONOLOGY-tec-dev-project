package com.tyfanch.electivehelper.service;

import android.content.Context;

import com.tyfanch.electivehelper.bean.UniUser;
import com.tyfanch.electivehelper.bean.UniUserConst;
import com.tyfanch.electivehelper.bean.UserConst;
import com.tyfanch.electivehelper.bean.UserTypeConst;
import com.tyfanch.electivehelper.constant.ServerConfig;
import com.tyfanch.electivehelper.interfaces.ResultCallback;
import com.tyfanch.electivehelper.ui_utils.PreferenceUtil;
import com.tyfanch.electivehelper.utils.Base64Utils;
import com.tyfanch.electivehelper.utils.HttpUtils;
import com.tyfanch.electivehelper.utils.JsonUtils;
import com.tyfanch.electivehelper.view.vo.UniUserVo;
import com.tyfanch.electivehelper.view.vo.UniUserVoConst;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class UniAccountServiceImpl extends BaseCommonService implements UniAccountService {
    @Override
    public void login(String userJson, String uniUserVoJson, ResultCallback callback) {
        Map<String, String> postBody = new HashMap<>();
        UniUserVo uniUserVo;
        String url;

        try {
            uniUserVo = JsonUtils.fromJson(Base64Utils.decode(uniUserVoJson), UniUserVo.class);
            url = this.getUrl(uniUserVo.getType());
            postBody.put(ServerConfig.REQUEST_ACTION, "login");
            postBody.put(UserConst.NAME, userJson);
            postBody.put(UniUserVoConst.NAME, uniUserVoJson);
            HttpUtils.post(url, postBody,
                result -> this.requestSuccess((String) result, callback),
                result -> this.requestFail(callback));
        } catch (IOException e) {
            e.printStackTrace();
            this.requestFail(callback);
        }
    }

    @Override
    public void findUserByUniUserId(String uniUserJson, ResultCallback callback) {
        Map<String, String> postBody = new HashMap<>();
        UniUser uniUser;
        String url;

        try {
            uniUser = JsonUtils.fromJson(Base64Utils.decode(uniUserJson), UniUser.class);
            url = this.getUrl(uniUser.getType());
            postBody.put(ServerConfig.REQUEST_ACTION, "findUserByUniUserId");
            postBody.put(UniUserConst.NAME, uniUserJson);
            HttpUtils.post(url, postBody,
                result -> this.requestSuccess((String) result, callback),
                result -> this.requestFail(callback));
        } catch (IOException e) {
            e.printStackTrace();
            this.requestFail(callback);
        }
    }

    @Override
    public void findUniUserByUserId(String userJson, ResultCallback callback) {
        Map<String, String> postBody = new HashMap<>();

        postBody.put(ServerConfig.REQUEST_ACTION, "findUniUserByUserId");
        postBody.put(UniUserConst.NAME, userJson);
        HttpUtils.post(ServerConfig.TEACHER_URL, postBody,
            result -> this.requestSuccess((String) result, callback),
            result -> this.requestFail(callback));
    }

    @Override
    public void hasLogin(String uniUserJson, ResultCallback callback) {
        Map<String, String> postBody = new HashMap<>();
        UniUser uniUser;
        String url;

        try {
            uniUser = JsonUtils.fromJson(Base64Utils.decode(uniUserJson), UniUser.class);
            url = this.getUrl(uniUser.getType());
            postBody.put(ServerConfig.REQUEST_ACTION, "hasLogin");
            postBody.put(UniUserConst.NAME, uniUserJson);
            HttpUtils.post(url, postBody,
                result -> this.requestSuccess((String) result, callback),
                result -> this.requestFail(callback));
        } catch (IOException e) {
            e.printStackTrace();
            this.requestFail(callback);
        }
    }

    @Override
    public void logout(Context ctx, ResultCallback callback) {
        PreferenceUtil.remove(ctx, UniUserConst.NAME);
        callback.onResult(null);
    }

    private String getUrl(int type) {
        return (type == UserTypeConst.TYPE_PRIMARY)
            ? ServerConfig.STUDENT_URL
            : ServerConfig.TEACHER_URL;
    }
}
