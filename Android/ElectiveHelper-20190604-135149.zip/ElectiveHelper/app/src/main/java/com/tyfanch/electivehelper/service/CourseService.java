package com.tyfanch.electivehelper.service;

import com.tyfanch.electivehelper.interfaces.ResultCallback;

public interface CourseService {
    void findAll(ResultCallback callback);

    void findByColumn(String courseVoJson, ResultCallback callback);

    void findByTeacherAndColumn(String uniUserJson, String courseVoJson,
        ResultCallback callback);

    void findByStudentAndColumn(String uniUserJson, String courseVoJson,
        ResultCallback callback);

    void save(String courseJson, ResultCallback callback);

    void update(String courseJson, ResultCallback callback);

    void deleteById(String courseJson, ResultCallback callback);
}
