package com.tyfanch.electivehelper.ui.adapters;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.tyfanch.electivehelper.R;
import com.tyfanch.electivehelper.bean.UniUser;
import com.tyfanch.electivehelper.databinding.ItemStudentBinding;
import com.tyfanch.electivehelper.view.vc.StudentItemVc;
import com.tyfanch.electivehelper.view.vc.StudentListVc;

import java.util.List;

public class StudentRvAdapter extends RecyclerView.Adapter<StudentRvAdapter.StudentRvHolder> {
    private FragmentActivity activity;
    private StudentListVc studentListVc;
    private List<UniUser> studentList;

    public StudentRvAdapter(FragmentActivity activity, StudentListVc studentListVc,
        List<UniUser> studentList) {
        this.activity = activity;
        this.studentListVc = studentListVc;
        this.studentList = studentList;
    }

    @Override
    public StudentRvHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(this.activity);
        ItemStudentBinding studentBinding = DataBindingUtil.inflate(
            layoutInflater, R.layout.item_student, parent, false);

        return new StudentRvHolder(studentBinding);
    }

    @Override
    public void onBindViewHolder(StudentRvHolder holder, int position) {
        StudentItemVc studentItemVc;

        studentItemVc = new StudentItemVc(this.activity, this.studentList.get(position));
        holder.getStudentBinding().setStudentListVc(this.studentListVc);
        holder.getStudentBinding().setStudentItemVc(studentItemVc);
    }

    @Override
    public int getItemCount() {
        return this.studentList.size();
    }

    public List<UniUser> getStudentList() {
        return this.studentList;
    }

    public void setStudentList(List<UniUser> studentList) {
        this.studentList = studentList;
    }

    public static class StudentRvHolder extends RecyclerView.ViewHolder {
        private ItemStudentBinding studentBinding;

        public StudentRvHolder(ItemStudentBinding studentBinding) {
            super(studentBinding.getRoot());

            this.studentBinding = studentBinding;
        }

        public ItemStudentBinding getStudentBinding() {
            return this.studentBinding;
        }

        public void setStudentBinding(ItemStudentBinding studentBinding) {
            this.studentBinding = studentBinding;
        }
    }
}
