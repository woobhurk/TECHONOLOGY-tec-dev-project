package com.tyfanch.electivehelper.view.vc;

import android.content.Intent;

import androidx.databinding.BaseObservable;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;

import com.tyfanch.electivehelper.R;
import com.tyfanch.electivehelper.bean.UserConst;
import com.tyfanch.electivehelper.service.AccountService;
import com.tyfanch.electivehelper.service.AccountServiceImpl;
import com.tyfanch.electivehelper.ui.AccountActivity;
import com.tyfanch.electivehelper.ui_utils.PreferenceUtil;
import com.tyfanch.electivehelper.ui_utils.PromptUtil;
import com.tyfanch.electivehelper.view.vo.ResultInfo;

public class MainVc extends BaseObservable {
    private FragmentActivity activity;
    private FragmentManager fragmentManager;

    public MainVc(FragmentActivity activity, FragmentManager fragmentManager) {
        this.activity = activity;
        this.fragmentManager = fragmentManager;

        this.initVc();
    }

    private void initVc() {
        this.checkLogin();
    }

    /**
     * 检测用户是否登录，未登录则跳转到登录界面
     */
    private void checkLogin() {
        AccountService accountService = new AccountServiceImpl();
        String userJson = PreferenceUtil.getString(this.activity, UserConst.NAME, "");

        //accountService.hasLogin(userJson, result -> {
        //    boolean loggedIn = (boolean) ((ResultInfo) result).getResultData();
        //
        //    // 未登录则提示登录，跳转到登录页面
        //    if (!loggedIn) {
        //        this.activity.runOnUiThread(
        //            () -> PromptUtil.showToast(this.activity, R.string.login_first));
        //        this.activity.finish();
        //        this.activity.startActivityForResult(
        //            new Intent(this.activity, AccountActivity.class),
        //            AccountActivity.ID);
        //    }
        //});

        accountService.login(userJson, result -> {
            ResultInfo resultInfo = (ResultInfo) result;
            String currentUserJson;

            if (resultInfo.getSuccess()) {
                // 登录则更新用户信息
                currentUserJson = (String) resultInfo.getResultData();
                PreferenceUtil.putString(this.activity, UserConst.NAME, currentUserJson);
            } else {
                // 未登录则提示登录，跳转到登录页面
                this.activity.runOnUiThread(
                    () -> PromptUtil.showToast(this.activity, R.string.login_first));
                this.activity.finish();
                this.activity.startActivityForResult(
                    new Intent(this.activity, AccountActivity.class),
                    AccountActivity.ID);
            }
        });
    }
}
