package com.tyfanch.electivehelper.view.vc;

import android.app.Activity;
import android.content.Intent;
import android.view.View;

import androidx.databinding.BaseObservable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;

import com.tyfanch.electivehelper.R;
import com.tyfanch.electivehelper.bean.UserConst;
import com.tyfanch.electivehelper.bean.UserTypeConst;
import com.tyfanch.electivehelper.service.AccountService;
import com.tyfanch.electivehelper.service.AccountServiceImpl;
import com.tyfanch.electivehelper.ui.MainActivity;
import com.tyfanch.electivehelper.ui.UserLoginFrag;
import com.tyfanch.electivehelper.ui.UserRegFrag;
import com.tyfanch.electivehelper.ui_utils.PreferenceUtil;
import com.tyfanch.electivehelper.ui_utils.PromptUtil;
import com.tyfanch.electivehelper.utils.Base64Utils;
import com.tyfanch.electivehelper.utils.JsonUtils;
import com.tyfanch.electivehelper.utils.Md5Utils;
import com.tyfanch.electivehelper.view.vo.ResultInfo;
import com.tyfanch.electivehelper.view.vo.UserVo;

import java.io.IOException;

/**
 * 用户账号界面控制器
 */
public class AccountVc extends BaseObservable {
    private FragmentActivity activity;
    private FragmentManager fragmentManager;
    private AccountService accountService = new AccountServiceImpl();
    private UserVo userVo = new UserVo();

    public AccountVc(FragmentActivity activity, FragmentManager fragmentManager) {
        this.activity = activity;
        this.fragmentManager = fragmentManager;

        this.initVc();
    }

    public void onLoginClick(View view) {
        try {
            this.userVo.setType(UserTypeConst.TYPE_PRIMARY);
            this.userVo.setPassword(Md5Utils.toMd5(this.userVo.getPassword()));
            this.accountService.login(Base64Utils.encode(JsonUtils.toJson(this.userVo)),
                result -> this.proceedResult((ResultInfo) result));
        } catch (IOException e) {
            e.printStackTrace();
            PromptUtil.showToast(this.activity, e.getMessage());
        }
    }

    public void onRegNowClick(View view) {
        Fragment currentFrag = this.fragmentManager.findFragmentByTag(UserLoginFrag.TAG);

        if (currentFrag != null) {
            currentFrag.onDestroy();
            this.fragmentManager.beginTransaction()
                .detach(currentFrag)
                .add(R.id.layCommon, new UserRegFrag(), UserRegFrag.TAG)
                .commit();
        }
    }

    public void onRegClick(View view) {
        try {
            this.userVo.setType(UserTypeConst.TYPE_PRIMARY);
            this.userVo.setPassword(Md5Utils.toMd5(this.userVo.getPassword()));
            this.userVo.setConfPassword(Md5Utils.toMd5(this.userVo.getConfPassword()));
            this.accountService.reg(Base64Utils.encode(JsonUtils.toJson(this.userVo)),
                result -> this.proceedResult((ResultInfo) result));
        } catch (IOException e) {
            e.printStackTrace();
            PromptUtil.showToast(this.activity, e.getMessage());
        }
    }

    public void onLoginNowClick(View view) {
        Fragment currentFrag = this.fragmentManager.findFragmentByTag(UserRegFrag.TAG);

        if (currentFrag != null) {
            currentFrag.onDestroy();
            this.fragmentManager.beginTransaction()
                .detach(currentFrag)
                .add(R.id.layCommon, new UserLoginFrag(), UserLoginFrag.TAG)
                .commit();
        }
    }

    public void initVc() {

    }

    private void proceedResult(ResultInfo resultInfo) {
        if (resultInfo.getSuccess()) {
            PreferenceUtil.putString(this.activity, UserConst.NAME,
                (String) resultInfo.getResultData());
            this.activity.setResult(Activity.RESULT_OK);
            this.activity.finish();
            this.activity.startActivity(new Intent(this.activity, MainActivity.class));
        } else {
            this.activity.runOnUiThread(
                () -> PromptUtil.showToast(this.activity, resultInfo.getResultMsg()));
        }
    }

    public FragmentActivity getActivity() {
        return this.activity;
    }

    public void setActivity(FragmentActivity activity) {
        this.activity = activity;
    }

    public FragmentManager getFragmentManager() {
        return this.fragmentManager;
    }

    public void setFragmentManager(FragmentManager fragmentManager) {
        this.fragmentManager = fragmentManager;
    }

    public UserVo getUserVo() {
        return this.userVo;
    }

    public void setUserVo(UserVo userVo) {
        this.userVo = userVo;
    }
}
