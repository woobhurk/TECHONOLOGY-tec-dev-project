package com.tyfanch.electivehelper.bean;

import java.io.Serializable;

public class Teacher extends UniUser implements Serializable {
}
