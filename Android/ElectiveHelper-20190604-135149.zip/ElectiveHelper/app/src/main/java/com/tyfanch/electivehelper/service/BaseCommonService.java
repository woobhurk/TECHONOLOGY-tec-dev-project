package com.tyfanch.electivehelper.service;

import com.tyfanch.electivehelper.interfaces.ResultCallback;
import com.tyfanch.electivehelper.utils.JsonUtils;
import com.tyfanch.electivehelper.view.vo.ResultInfo;
import com.tyfanch.electivehelper.view.vo.ResultInfoConst;

import java.io.IOException;

public abstract class BaseCommonService {
    protected void requestSuccess(String resultInfoJson, ResultCallback callback) {
        ResultInfo resultInfo;

        try {
            resultInfo = JsonUtils.fromJson(resultInfoJson, ResultInfo.class);
            callback.onResult(resultInfo);
        } catch (IOException e) {
            e.printStackTrace();
            this.requestFail(callback);
        }
    }

    protected void requestFail(ResultCallback callback) {
        ResultInfo resultInfo = new ResultInfo();

        resultInfo.setSuccess(false);
        resultInfo.setResultCode(-1);
        resultInfo.setResultMsg(ResultInfoConst.REQUEST_FAIL);
        resultInfo.setResultData(false);
        callback.onResult(resultInfo);
    }
}
