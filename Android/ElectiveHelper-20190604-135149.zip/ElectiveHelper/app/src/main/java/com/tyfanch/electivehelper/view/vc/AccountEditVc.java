package com.tyfanch.electivehelper.view.vc;

import android.app.Activity;
import android.view.View;

import androidx.databinding.BaseObservable;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;

import com.tyfanch.electivehelper.bean.User;
import com.tyfanch.electivehelper.bean.UserConst;
import com.tyfanch.electivehelper.service.AccountService;
import com.tyfanch.electivehelper.service.AccountServiceImpl;
import com.tyfanch.electivehelper.ui_utils.PreferenceUtil;
import com.tyfanch.electivehelper.ui_utils.PromptUtil;
import com.tyfanch.electivehelper.utils.Base64Utils;
import com.tyfanch.electivehelper.utils.JsonUtils;
import com.tyfanch.electivehelper.utils.Md5Utils;
import com.tyfanch.electivehelper.view.vo.ResultInfo;
import com.tyfanch.electivehelper.view.vo.ResultInfoConst;

import java.io.IOException;

public class AccountEditVc extends BaseObservable {
    private FragmentActivity activity;
    private FragmentManager fragmentManager;
    private AccountService accountService = new AccountServiceImpl();
    private User user;
    private String newPassword;

    public AccountEditVc(FragmentActivity activity, FragmentManager fragmentManager) {
        this.activity = activity;
        this.fragmentManager = fragmentManager;

        this.initVc();
    }

    private void initVc() {
        String userJson;

        try {
            userJson = PreferenceUtil.getString(this.activity, UserConst.NAME, "");
            this.user = JsonUtils.fromJson(Base64Utils.decode(userJson), User.class);
            this.user.setPassword("");
            this.newPassword = "";
        } catch (IOException e) {
            e.printStackTrace();
        }

        this.notifyChange();
    }

    public void onUpdateClick(View view) {
        String userJson;

        try {
            if (!this.user.getUsername().isEmpty()
                && !this.user.getEmail().isEmpty()
                && !this.user.getPassword().isEmpty()) {
                this.user.setPassword(Md5Utils.toMd5(this.user.getPassword()));
                userJson = JsonUtils.toJson(this.user);
                this.accountService.loginByIdAndPassword(userJson,
                    result -> this.proceedLoginResult((ResultInfo) result));
            } else {
                PromptUtil.showToast(this.activity, ResultInfoConst.INVALID_PARAMETER);
            }
        } catch (IOException e) {
            e.printStackTrace();
            PromptUtil.showToast(this.activity, e.getMessage());
        }
    }

    private void proceedLoginResult(ResultInfo resultInfo) {
        try {
            if (resultInfo.getSuccess()) {
                if (!this.newPassword.isEmpty()) {
                    this.user.setPassword(Md5Utils.toMd5(this.newPassword));
                }

                this.accountService.update(Base64Utils.encode(JsonUtils.toJson(this.user)),
                    updateResult -> this.proceedUpdateResult((ResultInfo) updateResult));
            } else {
                this.activity.runOnUiThread(
                    () -> PromptUtil.showToast(this.activity, resultInfo.getResultMsg()));
            }
        } catch (IOException e) {
            e.printStackTrace();
            this.activity.runOnUiThread(
                () -> PromptUtil.showToast(this.activity, e.getMessage()));
        }
    }

    private void proceedUpdateResult(ResultInfo resultInfo) {
        if (resultInfo.getSuccess()) {
            String userJson = (String) resultInfo.getResultData();

            PreferenceUtil.putString(this.activity, UserConst.NAME, userJson);
            this.activity.setResult(Activity.RESULT_OK);
            this.activity.finish();
        } else {
            this.activity.runOnUiThread(
                () -> PromptUtil.showToast(this.activity, resultInfo.getResultMsg()));
        }
    }

    public FragmentActivity getActivity() {
        return this.activity;
    }

    public void setActivity(FragmentActivity activity) {
        this.activity = activity;
    }

    public FragmentManager getFragmentManager() {
        return this.fragmentManager;
    }

    public void setFragmentManager(FragmentManager fragmentManager) {
        this.fragmentManager = fragmentManager;
    }

    public User getUser() {
        return this.user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String getNewPassword() {
        return this.newPassword;
    }

    public void setNewPassword(String newPassword) {
        this.newPassword = newPassword;
    }
}
