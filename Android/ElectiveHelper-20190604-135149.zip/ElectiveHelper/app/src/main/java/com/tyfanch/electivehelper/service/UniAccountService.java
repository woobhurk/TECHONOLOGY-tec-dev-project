package com.tyfanch.electivehelper.service;

import android.content.Context;

import com.tyfanch.electivehelper.interfaces.ResultCallback;

public interface UniAccountService {
    void login(String userJson, String uniUserVoJson, ResultCallback callback);

    void findUserByUniUserId(String uniUserJson, ResultCallback callback);

    void findUniUserByUserId(String userJson, ResultCallback callback);

    void hasLogin(String uniUserJson, ResultCallback callback);

    void logout(Context ctx, ResultCallback callback);
}
