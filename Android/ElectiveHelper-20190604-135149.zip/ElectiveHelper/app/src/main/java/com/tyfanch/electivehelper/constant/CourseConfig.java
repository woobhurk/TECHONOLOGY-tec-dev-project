package com.tyfanch.electivehelper.constant;

public class CourseConfig {
    private CourseConfig() {}

    public static final String[] dayOfWeekList = {
        "星期一", "星期二", "星期三", "星期四",
        "星期五", "星期六", "星期天"
    };
}
