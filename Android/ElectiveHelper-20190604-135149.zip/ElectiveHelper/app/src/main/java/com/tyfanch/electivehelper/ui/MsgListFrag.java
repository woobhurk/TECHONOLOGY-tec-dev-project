package com.tyfanch.electivehelper.ui;


import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.tyfanch.electivehelper.R;
import com.tyfanch.electivehelper.databinding.FragMsgListBinding;
import com.tyfanch.electivehelper.view.vc.MsgListVc;

public class MsgListFrag extends Fragment {
    public static final String TAG = "MsgListFrag";

    private FragMsgListBinding msgListBinding;

    public MsgListFrag() {}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
        Bundle savedInstanceState) {
        this.msgListBinding = DataBindingUtil.inflate(
            inflater, R.layout.frag_msg_list, container, false);

        return this.msgListBinding.getRoot();
    }

    @Override
    public void onStart() {
        super.onStart();

        MsgListVc msgListVc;
        RecyclerView rvMsgList = this.msgListBinding.rvMsgList;

        rvMsgList.setLayoutManager(new LinearLayoutManager(this.getContext()));
        msgListVc = new MsgListVc(this.getActivity(), this.getFragmentManager(), rvMsgList);
        this.msgListBinding.setMsgListVc(msgListVc);

        //if (this.getActivity() != null) {
        //    this.getActivity().setTitle(R.string.msg_list);
        //}

        Log.d(TAG, TAG + " onStart");
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);

        if (isVisibleToUser && this.getActivity() != null) {
            this.getActivity().setTitle(R.string.msg_list);
        }

        Log.d(TAG, "" + isVisibleToUser);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG, TAG + " Destroyed");
    }
}
