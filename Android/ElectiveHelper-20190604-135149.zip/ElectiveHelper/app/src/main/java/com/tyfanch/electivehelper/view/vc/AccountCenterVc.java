package com.tyfanch.electivehelper.view.vc;

import android.content.Intent;
import android.view.View;

import androidx.databinding.BaseObservable;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;

import com.tyfanch.electivehelper.R;
import com.tyfanch.electivehelper.bean.UniUser;
import com.tyfanch.electivehelper.bean.UniUserConst;
import com.tyfanch.electivehelper.bean.User;
import com.tyfanch.electivehelper.bean.UserConst;
import com.tyfanch.electivehelper.bean.UserTypeConst;
import com.tyfanch.electivehelper.service.AccountService;
import com.tyfanch.electivehelper.service.AccountServiceImpl;
import com.tyfanch.electivehelper.service.UniAccountService;
import com.tyfanch.electivehelper.service.UniAccountServiceImpl;
import com.tyfanch.electivehelper.ui.AccountActivity;
import com.tyfanch.electivehelper.ui.AccountEditActivity;
import com.tyfanch.electivehelper.ui.MyCourseListActivity;
import com.tyfanch.electivehelper.ui.UniAccountActivity;
import com.tyfanch.electivehelper.ui_utils.PreferenceUtil;
import com.tyfanch.electivehelper.ui_utils.PromptUtil;
import com.tyfanch.electivehelper.utils.Base64Utils;
import com.tyfanch.electivehelper.utils.JsonUtils;
import com.tyfanch.electivehelper.utils.ScheduledTaskUtil;
import com.tyfanch.electivehelper.view.vo.ResultInfo;

import java.io.IOException;

public class AccountCenterVc extends BaseObservable {
    private FragmentActivity activity;
    private FragmentManager fragmentManager;
    private AccountService accountService = new AccountServiceImpl();
    private UniAccountService uniAccountService = new UniAccountServiceImpl();
    private User user;
    private UniUser uniUser;
    private String uniUserTypeStr;
    private boolean showUniUser = false;

    public AccountCenterVc(FragmentActivity activity, FragmentManager fragmentManager) {
        this.activity = activity;
        this.fragmentManager = fragmentManager;

        this.initVc();
    }

    public void onEditClick(View view) {
        Intent intent = new Intent(this.activity, AccountEditActivity.class);

        this.activity.startActivityForResult(intent, AccountEditActivity.ID);
    }

    public void onLogoutClick(View view) {
        Intent intent = new Intent(this.activity, AccountActivity.class);

        PromptUtil.showDialog(this.activity, "退出登录",
            "确定退出账号'" + this.user.getUsername() + "'？",
            "确定", "取消", () -> {
                this.accountService.logout(this.activity,
                    result -> this.proceedLogoutResult((ResultInfo) result));
                this.activity.finish();
                this.activity.startActivityForResult(intent, AccountActivity.ID);
            });
    }

    public void onBindClick(View view) {
        Intent intent = new Intent(this.activity, UniAccountActivity.class);

        this.activity.startActivityForResult(intent, UniAccountActivity.ID);
    }

    public void onMyCourseClick(View view) {
        String uniUserJson = PreferenceUtil.getString(
            this.activity, UniUserConst.NAME, "");
        Intent intent = new Intent(this.activity, MyCourseListActivity.class);

        intent.putExtra(UniUserConst.NAME, uniUserJson);
        this.activity.startActivityForResult(intent, MyCourseListActivity.ID);
    }

    public void onUnbindClick(View view) {
        PromptUtil.showDialog(this.activity, "解绑",
            "确定解绑'" + this.uniUser.getAccount() + "'？",
            "确定", "取消", () -> {
                this.uniAccountService.logout(this.activity,
                    result -> this.proceedUnbindResult((ResultInfo) result));
                this.showUniUser = false;
                this.notifyChange();
            });
    }

    private void initVc() {
        // 获取用户账号
        String userJson = PreferenceUtil.getString(this.activity,
            UserConst.NAME, "");
        // 获取教务系统账号
        String uniUserJson = PreferenceUtil.getString(this.activity,
            UniUserConst.NAME, "");

        // 验证登录，同时更新用户信息
        this.accountService.login(userJson,
            result -> this.proceedLoginResult((ResultInfo) result));
        // 判断教务系统是否登录
        this.uniAccountService.login(userJson, uniUserJson,
            result -> this.proceedLoginUniResult((ResultInfo) result));
    }

    private void proceedLoginResult(ResultInfo resultInfo) {
        String currentUserJson;

        try {
            if (resultInfo.getSuccess()) {
                currentUserJson = (String) resultInfo.getResultData();
                PreferenceUtil.putString(this.activity, UserConst.NAME, currentUserJson);
                this.user = JsonUtils.fromJson(
                    Base64Utils.decode(currentUserJson), User.class);
            }
        } catch (IOException e) {
            e.printStackTrace();
            this.activity.runOnUiThread(
                () -> PromptUtil.showToast(this.activity, e.getMessage()));
        }

        this.notifyChange();
    }

    private void proceedLoginUniResult(ResultInfo resultInfo) {
        String currentUniUserJson;

        try {
            if (resultInfo.getSuccess()) {
                currentUniUserJson = (String) resultInfo.getResultData();
                PreferenceUtil.putString(
                    this.activity, UniUserConst.NAME, currentUniUserJson);
                this.uniUser = JsonUtils.fromJson(
                    Base64Utils.decode(currentUniUserJson), UniUser.class);
                this.uniUserTypeStr = (this.uniUser.getType() == UserTypeConst.TYPE_PRIMARY)
                    ? "学生" : "老师";
                this.showUniUser = true;
            } else {
                this.showUniUser = false;
            }
        } catch (IOException e) {
            e.printStackTrace();
            this.activity.runOnUiThread(
                () -> PromptUtil.showToast(this.activity, e.getMessage()));
        }

        this.notifyChange();
    }

    private void proceedLogoutResult(ResultInfo resultInfo) {
        ScheduledTaskUtil.shutdownAll();
        this.activity.runOnUiThread(
            () -> PromptUtil.showToast(this.activity, R.string.logged_out));
    }

    private void proceedUnbindResult(ResultInfo resultInfo) {
        ScheduledTaskUtil.shutdownAll();
        this.activity.runOnUiThread(
            () -> PromptUtil.showToast(this.activity, R.string.uni_unbounded));
    }

    public FragmentActivity getActivity() {
        return this.activity;
    }

    public void setActivity(FragmentActivity activity) {
        this.activity = activity;
    }

    public FragmentManager getFragmentManager() {
        return this.fragmentManager;
    }

    public void setFragmentManager(FragmentManager fragmentManager) {
        this.fragmentManager = fragmentManager;
    }

    public User getUser() {
        return this.user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public UniUser getUniUser() {
        return this.uniUser;
    }

    public void setUniUser(UniUser uniUser) {
        this.uniUser = uniUser;
    }

    public String getUniUserTypeStr() {
        return this.uniUserTypeStr;
    }

    public void setUniUserTypeStr(String uniUserTypeStr) {
        this.uniUserTypeStr = uniUserTypeStr;
    }

    public boolean isShowUniUser() {
        return this.showUniUser;
    }

    public void setShowUniUser(boolean showUniUser) {
        this.showUniUser = showUniUser;
    }
}
