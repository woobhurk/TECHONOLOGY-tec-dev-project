package com.tyfanch.electivehelper.ui;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;

import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;

import com.tyfanch.electivehelper.R;
import com.tyfanch.electivehelper.databinding.FragOnlineCourseBinding;
import com.tyfanch.electivehelper.utils.JsonUtils;
import com.tyfanch.electivehelper.view.vc.OnlineCourseVc;
import com.tyfanch.electivehelper.view.vo.OnlineCourseVo;
import com.tyfanch.electivehelper.view.vo.OnlineCourseVoConst;

import java.io.IOException;

public class OnlineCourseFrag extends Fragment {
    public static final String TAG = "OnlineCourseFrag";

    private FragOnlineCourseBinding onlineCourseBinding;

    public OnlineCourseFrag() {}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
        Bundle savedInstanceState) {
        this.onlineCourseBinding = DataBindingUtil.inflate(
            inflater, R.layout.frag_online_course, container, false);

        return this.onlineCourseBinding.getRoot();
    }

    @Override
    public void onStart() {
        super.onStart();

        OnlineCourseVc onlineCourseVc;
        WebView wvOnlineCourse = this.onlineCourseBinding.wvOnlineCourse;
        OnlineCourseVo onlineCourseVo;
        String onlineCourseVoJson;

        onlineCourseVc = new OnlineCourseVc(this.getActivity(), this.getFragmentManager(),
            wvOnlineCourse);
        this.onlineCourseBinding.setOnlineCourseVc(onlineCourseVc);

        try {

            if (this.getActivity() != null) {
                onlineCourseVoJson = this.getActivity().getIntent().getStringExtra(
                    OnlineCourseVoConst.NAME);
                onlineCourseVo = JsonUtils.fromJson(onlineCourseVoJson, OnlineCourseVo.class);
                this.getActivity().setTitle(onlineCourseVo.getName());
            }
        } catch (IOException e) {
            e.printStackTrace();
            if (this.getActivity() != null) {
                this.getActivity().setTitle(R.string.course_detail);
            }
        }
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);

        //if (isVisibleToUser && this.getActivity() != null) {
        //    this.getActivity().setTitle(R.string.user_edit);
        //}
    }

    @Override
    public void onDestroy() {
        Log.d(TAG, TAG + " Destroyed");
        super.onDestroy();
    }
}
