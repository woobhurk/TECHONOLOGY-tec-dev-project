package com.tyfanch.electivehelper.view.vc;

import androidx.databinding.BaseObservable;
import androidx.fragment.app.FragmentActivity;

import com.fasterxml.jackson.core.type.TypeReference;
import com.tyfanch.electivehelper.bean.UniUser;
import com.tyfanch.electivehelper.bean.User;
import com.tyfanch.electivehelper.bean.UserConst;
import com.tyfanch.electivehelper.service.UniAccountService;
import com.tyfanch.electivehelper.service.UniAccountServiceImpl;
import com.tyfanch.electivehelper.ui_utils.PreferenceUtil;
import com.tyfanch.electivehelper.ui_utils.PromptUtil;
import com.tyfanch.electivehelper.utils.Base64Utils;
import com.tyfanch.electivehelper.utils.JsonUtils;
import com.tyfanch.electivehelper.view.vo.ReplyVo;
import com.tyfanch.electivehelper.view.vo.ResultInfo;

import java.io.IOException;
import java.util.List;

public class ReplyItemVc extends BaseObservable {
    private FragmentActivity activity;
    private UniAccountService uniAccountService = new UniAccountServiceImpl();
    private User user;
    private UniUser uniUser;
    private UniUser innerUniUser;
    private ReplyVo replyVo;
    private ReplyVo innerReplyVo;
    private boolean replySentByCurrentUser;
    private boolean innerReplyVisible;

    public ReplyItemVc(FragmentActivity activity, ReplyVo replyVo) {
        this.activity = activity;
        this.replyVo = replyVo;

        this.initVc();
    }

    private void initVc() {
        String userJson;

        try {
            userJson = PreferenceUtil.getString(this.activity, UserConst.NAME, "");
            this.user = JsonUtils.fromJson(Base64Utils.decode(userJson), User.class);
            this.fetchUniUser();
            this.fetchInnerUniUser();
            this.innerReplyVo = this.replyVo.getReplyTo();
            this.replySentByCurrentUser = this.user.getId().equals(
                this.replyVo.getSender().getId());
            this.innerReplyVisible = (this.innerReplyVo != null);
        } catch (IOException e) {
            e.printStackTrace();
            PromptUtil.showToast(this.activity, e.getMessage());
        }

        this.notifyChange();
    }

    private void fetchUniUser() {
        String userJson;

        try {
            userJson = Base64Utils.encode(JsonUtils.toJson(this.replyVo.getSender()));
            this.uniAccountService.findUniUserByUserId(userJson,
                result -> this.proceedFetchUniUser((ResultInfo) result));
        } catch (IOException e) {
            e.printStackTrace();
            PromptUtil.showToast(this.activity, e.getMessage());
        }
    }

    private void fetchInnerUniUser() {
        String innerUserJson;

        try {
            if (this.replyVo.getReplyTo() != null) {
                innerUserJson = Base64Utils.encode(
                    JsonUtils.toJson(this.replyVo.getReplyTo().getSender()));
                this.uniAccountService.findUniUserByUserId(innerUserJson,
                    result -> this.proceedFetchInnerUniUser((ResultInfo) result));
            }
        } catch (IOException e) {
            e.printStackTrace();
            PromptUtil.showToast(this.activity, e.getMessage());
        }
    }

    private void proceedFetchUniUser(ResultInfo resultInfo) {
        try {
            if (resultInfo.getSuccess()) {
                String uniUserListJson = (String) resultInfo.getResultData();
                List<UniUser> uniUserList;

                uniUserList = JsonUtils.fromJson(uniUserListJson,
                    new TypeReference<List<UniUser>>() {});

                if (!uniUserList.isEmpty()) {
                    this.uniUser = uniUserList.get(0);
                } else {
                    this.uniUser = new UniUser();
                    this.uniUser.setName("无");
                }
            } else {
                this.uniUser = new UniUser();
                this.uniUser.setName("无");
            }
        } catch (IOException e) {
            e.printStackTrace();
            this.activity.runOnUiThread(
                () -> PromptUtil.showToast(this.activity, e.getMessage()));
        }

        this.notifyChange();
    }

    private void proceedFetchInnerUniUser(ResultInfo resultInfo) {
        try {
            if (resultInfo.getSuccess()) {
                String innerUniUserListJson = (String) resultInfo.getResultData();
                List<UniUser> innerUniUserList;

                innerUniUserList = JsonUtils.fromJson(innerUniUserListJson,
                    new TypeReference<List<UniUser>>() {});

                if (!innerUniUserList.isEmpty()) {
                    this.innerUniUser = innerUniUserList.get(0);
                } else {
                    this.innerUniUser = new UniUser();
                    this.innerUniUser.setName("无");
                }
            } else {
                this.innerUniUser = new UniUser();
                this.innerUniUser.setName("无");
            }
        } catch (IOException e) {
            e.printStackTrace();
            this.activity.runOnUiThread(
                () -> PromptUtil.showToast(this.activity, e.getMessage()));
        }

        this.notifyChange();
    }

    public User getUser() {
        return this.user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public UniUser getUniUser() {
        return this.uniUser;
    }

    public void setUniUser(UniUser uniUser) {
        this.uniUser = uniUser;
    }

    public UniUser getInnerUniUser() {
        return this.innerUniUser;
    }

    public void setInnerUniUser(UniUser innerUniUser) {
        this.innerUniUser = innerUniUser;
    }

    public ReplyVo getReplyVo() {
        return this.replyVo;
    }

    public void setReplyVo(ReplyVo replyVo) {
        this.replyVo = replyVo;
    }

    public ReplyVo getInnerReplyVo() {
        return this.innerReplyVo;
    }

    public void setInnerReplyVo(ReplyVo innerReplyVo) {
        this.innerReplyVo = innerReplyVo;
    }

    public boolean isReplySentByCurrentUser() {
        return this.replySentByCurrentUser;
    }

    public void setReplySentByCurrentUser(boolean replySentByCurrentUser) {
        this.replySentByCurrentUser = replySentByCurrentUser;
    }

    public boolean isInnerReplyVisible() {
        return this.innerReplyVisible;
    }

    public void setInnerReplyVisible(boolean innerReplyVisible) {
        this.innerReplyVisible = innerReplyVisible;
    }
}
