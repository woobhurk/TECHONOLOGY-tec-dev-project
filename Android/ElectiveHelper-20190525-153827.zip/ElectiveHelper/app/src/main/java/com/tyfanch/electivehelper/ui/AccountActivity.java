package com.tyfanch.electivehelper.ui;

import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import com.tyfanch.electivehelper.R;

public class AccountActivity extends AppCompatActivity {
    public static final int ID = 0x000001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        this.setContentView(R.layout.activity_common);
    }

    @Override
    protected void onStart() {
        super.onStart();

        FragmentManager fragmentManager = this.getSupportFragmentManager();
        UserLoginFrag userLoginFrag = new UserLoginFrag();

        fragmentManager.beginTransaction()
            .add(R.id.layCommon, userLoginFrag, UserLoginFrag.TAG)
            .commit();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        Log.d("----", "AccountActivity Destroyed");
    }
}
