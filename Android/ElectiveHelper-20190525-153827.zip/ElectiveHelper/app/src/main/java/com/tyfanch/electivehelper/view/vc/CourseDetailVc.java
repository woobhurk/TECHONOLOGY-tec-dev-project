package com.tyfanch.electivehelper.view.vc;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.util.Log;
import android.view.View;

import androidx.appcompat.widget.AppCompatRatingBar;
import androidx.databinding.BaseObservable;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;

import com.fasterxml.jackson.core.type.TypeReference;
import com.tyfanch.electivehelper.bean.Course;
import com.tyfanch.electivehelper.bean.StudentCourse;
import com.tyfanch.electivehelper.bean.UniUser;
import com.tyfanch.electivehelper.bean.UniUserConst;
import com.tyfanch.electivehelper.bean.User;
import com.tyfanch.electivehelper.bean.UserConst;
import com.tyfanch.electivehelper.bean.UserTypeConst;
import com.tyfanch.electivehelper.constant.CourseConfig;
import com.tyfanch.electivehelper.service.CourseService;
import com.tyfanch.electivehelper.service.CourseServiceImpl;
import com.tyfanch.electivehelper.service.UniAccountService;
import com.tyfanch.electivehelper.service.UniAccountServiceImpl;
import com.tyfanch.electivehelper.service.UniBizService;
import com.tyfanch.electivehelper.service.UniBizServiceImpl;
import com.tyfanch.electivehelper.ui.MsgContentListActivity;
import com.tyfanch.electivehelper.ui.StudentListActivity;
import com.tyfanch.electivehelper.ui_utils.PreferenceUtil;
import com.tyfanch.electivehelper.ui_utils.PromptUtil;
import com.tyfanch.electivehelper.utils.Base64Utils;
import com.tyfanch.electivehelper.utils.JsonUtils;
import com.tyfanch.electivehelper.utils.TyBeanUtils;
import com.tyfanch.electivehelper.view.vo.CourseVo;
import com.tyfanch.electivehelper.view.vo.CourseVoConst;
import com.tyfanch.electivehelper.view.vo.ResultInfo;

import java.io.IOException;
import java.util.List;

public class CourseDetailVc extends BaseObservable {
    private FragmentActivity activity;
    private FragmentManager fragmentManager;
    private UniAccountService uniAccountService = new UniAccountServiceImpl();
    private UniBizService uniBizService = new UniBizServiceImpl();
    private CourseService courseService = new CourseServiceImpl();
    private AppCompatRatingBar rbCourseRate;
    private UniUser uniUser;
    private CourseVo courseVo;
    private User teacherUser;
    private boolean teacherNameClickable;
    private boolean typeTeacher;
    private boolean ownerTeacher;
    private String classroomStr;
    private String dayOfWeekStr;
    private String classOfDayStr;
    private String rateCountStr;
    private String rateStr;
    private boolean courseSelected;

    public CourseDetailVc(FragmentActivity activity, FragmentManager fragmentManager,
        AppCompatRatingBar rbCourseRate) {
        this.activity = activity;
        this.fragmentManager = fragmentManager;
        this.rbCourseRate = rbCourseRate;

        this.initVc();
    }

    public void onTeacherNameClick(View view) {
        Intent intent = new Intent(this.activity, MsgContentListActivity.class);

        try {
            intent.putExtra(UserConst.NAME, JsonUtils.toJson(this.teacherUser));
            this.activity.startActivityForResult(intent, MsgContentListActivity.ID);
        } catch (IOException e) {
            e.printStackTrace();
            PromptUtil.showToast(this.activity, e.getMessage());
        }
    }

    public void onRateClick(View view) {
        Course course = new Course();
        String courseJson;
        int rateCount = this.courseVo.getRateCount() == null ? 0
            : this.courseVo.getRateCount();
        int rateTotal = this.courseVo.getRateTotal() == null ? 0
            : this.courseVo.getRateTotal();

        this.courseVo.setRateCount(rateCount + 1);
        this.courseVo.setRateTotal(rateTotal + (int) this.rbCourseRate.getRating());
        //course.setId(this.courseVo.getId());
        course.setTeacherId(this.courseVo.getTeacher().getId());
        //course.setName(this.courseVo.getName());
        //course.setDescription(this.courseVo.getDescription());
        //course.setKeywords(this.courseVo.getKeywords());
        //course.setStartTime(this.courseVo.getStartTime());
        //course.setEndTime(this.courseVo.getEndTime());
        course.setClassroomId(this.courseVo.getClassroom().getId());
        //course.setDayOfWeek(this.courseVo.getDayOfWeek());
        //course.setClassOfDay(this.courseVo.getClassOfDay());
        //course.setRateCount(this.courseVo.getRateCount());
        //course.setRateTotal(this.courseVo.getRateTotal());
        TyBeanUtils.copyObject(course, this.courseVo);

        try {
            courseJson = JsonUtils.toJson(course);
            this.courseService.update(courseJson,
                result -> this.proceedRateResult((ResultInfo) result));
        } catch (Exception e) {
            e.printStackTrace();
            PromptUtil.showToast(this.activity, e.getMessage());
        }

        this.notifyChange();
    }

    public void onSelectCourseClick(View view) {
        StudentCourse studentCourse = new StudentCourse();
        String studentCourseJson;

        try {
            studentCourse.setStudentId(this.uniUser.getId());
            studentCourse.setCourseId(this.courseVo.getId());
            studentCourseJson = JsonUtils.toJson(studentCourse);

            if (this.courseSelected) {
                this.uniBizService.selectCourse(studentCourseJson,
                    result -> this.proceedSelectResult((ResultInfo) result));
            } else {
                this.uniBizService.deselectCourse(studentCourseJson,
                    result -> this.proceedSelectResult((ResultInfo) result));
            }
        } catch (IOException e) {
            e.printStackTrace();
            PromptUtil.showToast(this.activity, e.getMessage());
        }
    }

    public void onShowStudentsClick(View view) {
        Intent intent = new Intent(this.activity, StudentListActivity.class);
        String courseVoJson;

        try {
            courseVoJson = JsonUtils.toJson(this.courseVo);
            intent.putExtra(CourseVoConst.NAME, courseVoJson);
            this.activity.startActivityForResult(intent, StudentListActivity.ID);
        } catch (IOException e) {
            e.printStackTrace();
            PromptUtil.showToast(this.activity, e.getMessage());
        }
    }

    @SuppressLint("DefaultLocale")
    private void initVc() {
        String uniUserJson;
        String courseVoJson;
        StudentCourse studentCourse = new StudentCourse();
        String studentCourseJson;
        Integer rateCount;
        Integer rateTotal;

        try {
            uniUserJson = PreferenceUtil.getString(
                this.activity, UniUserConst.NAME, "");
            courseVoJson = this.activity.getIntent().getStringExtra(CourseVoConst.NAME);
            this.uniUser = JsonUtils.fromJson(Base64Utils.decode(uniUserJson), UniUser.class);
            this.courseVo = JsonUtils.fromJson(courseVoJson, CourseVo.class);
            this.findTeacherUser();
            this.typeTeacher = (this.uniUser.getType() == UserTypeConst.TYPE_SENIOR);
            this.ownerTeacher = this.typeTeacher
                && (this.courseVo.getTeacher().getId().equals(this.uniUser.getId()));

            if (!this.typeTeacher) {
                studentCourse.setStudentId(this.uniUser.getId());
                studentCourse.setCourseId(this.courseVo.getId());
                studentCourseJson = JsonUtils.toJson(studentCourse);
                this.uniBizService.hasSelected(studentCourseJson, result -> {
                    this.courseSelected = (Boolean) ((ResultInfo) result).getResultData();
                    this.notifyChange();
                });
            }

            this.classroomStr = String.format("%d-%s-%s",
                this.courseVo.getClassroom().getId(),
                this.courseVo.getClassroom().getBuilding(),
                this.courseVo.getClassroom().getRoom());
            this.dayOfWeekStr = CourseConfig.dayOfWeekList[this.courseVo.getDayOfWeek() - 1];
            this.classOfDayStr = String.format("第%d, %d节课",
                this.courseVo.getClassOfDay() * 2 - 1,
                this.courseVo.getClassOfDay() * 2);
            rateCount = this.courseVo.getRateCount();
            rateTotal = this.courseVo.getRateTotal();

            if (rateCount != null && rateCount > 0 && rateTotal != null && rateTotal > 0) {
                this.rateCountStr = rateCount + "人评";
                this.rateStr = String.format("%.1f分", (double) rateTotal / rateCount);
            } else {
                this.rateCountStr = "";
                this.rateStr = "无评分";
            }

            this.rbCourseRate.setRating(0.0F);
            // 需要在初始化评分控件之后再绑定监听器，否则一打开页面就会自动评分
            this.rbCourseRate.setOnRatingBarChangeListener(
                (ratingBar, rating, fromUser) -> this.onRateClick(ratingBar));

            this.notifyChange();
        } catch (IOException e) {
            e.printStackTrace();
            this.activity.runOnUiThread(
                () -> PromptUtil.showToast(this.activity, e.getMessage()));
        }
    }

    private void findTeacherUser() {
        String uniUserJson;

        try {
            uniUserJson = JsonUtils.toJson(this.courseVo.getTeacher());
            this.uniAccountService.findUserByUniUserId(Base64Utils.encode(uniUserJson),
                result -> this.proceedFindTeacherUserResult((ResultInfo) result));
        } catch (IOException e) {
            e.printStackTrace();
            PromptUtil.showToast(this.activity, e.getMessage());
        }
    }

    private void proceedFindTeacherUserResult(ResultInfo resultInfo) {
        String teacherUserListJson;
        List<User> teacherUserList;
        String currentUserJson = PreferenceUtil.getString(
            this.activity, UserConst.NAME, "");
        User currentUser;

        try {
            if (resultInfo.getSuccess()) {
                currentUser = JsonUtils.fromJson(
                    Base64Utils.decode(currentUserJson), User.class);
                teacherUserListJson = (String) resultInfo.getResultData();
                teacherUserList = JsonUtils.fromJson(teacherUserListJson,
                    new TypeReference<List<User>>() {});

                if (!teacherUserList.isEmpty()) {
                    this.teacherUser = teacherUserList.get(0);
                    this.teacherNameClickable = !currentUser.getId().equals(
                        this.teacherUser.getId());
                    this.notifyChange();
                }
            } else {
                this.activity.runOnUiThread(
                    () -> PromptUtil.showToast(this.activity, resultInfo.getResultMsg()));
            }
        } catch (IOException e) {
            e.printStackTrace();
            this.activity.runOnUiThread(
                () -> PromptUtil.showToast(this.activity, e.getMessage()));
        }
    }

    @SuppressLint("DefaultLocale")
    private void proceedRateResult(ResultInfo resultInfo) {
        Integer rateCount;
        Integer rateTotal;

        rateCount = this.courseVo.getRateCount();
        rateTotal = this.courseVo.getRateTotal();
        this.rateCountStr = rateCount + "人评";
        this.rateStr = String.format("%.1f分", (double) rateTotal / rateCount);
        this.notifyChange();
        this.activity.runOnUiThread(
            () -> PromptUtil.showToast(this.activity, resultInfo.getResultMsg()));
    }

    private void proceedSelectResult(ResultInfo resultInfo) {
        this.activity.runOnUiThread(
            () -> PromptUtil.showToast(this.activity, resultInfo.getResultMsg()));

        Log.d("----", resultInfo.toString());

        if (!resultInfo.getSuccess()) {
            this.courseSelected = !this.courseSelected;
            this.notifyChange();
        }
    }

    public CourseVo getCourseVo() {
        return this.courseVo;
    }

    public void setCourseVo(CourseVo courseVo) {
        this.courseVo = courseVo;
    }

    public boolean isTeacherNameClickable() {
        return this.teacherNameClickable;
    }

    public void setTeacherNameClickable(boolean teacherNameClickable) {
        this.teacherNameClickable = teacherNameClickable;
    }

    public boolean isTypeTeacher() {
        return this.typeTeacher;
    }

    public void setTypeTeacher(boolean typeTeacher) {
        this.typeTeacher = typeTeacher;
    }

    public boolean isOwnerTeacher() {
        return this.ownerTeacher;
    }

    public void setOwnerTeacher(boolean ownerTeacher) {
        this.ownerTeacher = ownerTeacher;
    }

    public String getClassroomStr() {
        return this.classroomStr;
    }

    public void setClassroomStr(String classroomStr) {
        this.classroomStr = classroomStr;
    }

    public String getDayOfWeekStr() {
        return this.dayOfWeekStr;
    }

    public void setDayOfWeekStr(String dayOfWeekStr) {
        this.dayOfWeekStr = dayOfWeekStr;
    }

    public String getClassOfDayStr() {
        return this.classOfDayStr;
    }

    public void setClassOfDayStr(String classOfDayStr) {
        this.classOfDayStr = classOfDayStr;
    }

    public String getRateCountStr() {
        return this.rateCountStr;
    }

    public void setRateCountStr(String rateCountStr) {
        this.rateCountStr = rateCountStr;
    }

    public String getRateStr() {
        return this.rateStr;
    }

    public void setRateStr(String rateStr) {
        this.rateStr = rateStr;
    }

    public boolean isCourseSelected() {
        return this.courseSelected;
    }

    public void setCourseSelected(boolean courseSelected) {
        this.courseSelected = courseSelected;
    }
}
