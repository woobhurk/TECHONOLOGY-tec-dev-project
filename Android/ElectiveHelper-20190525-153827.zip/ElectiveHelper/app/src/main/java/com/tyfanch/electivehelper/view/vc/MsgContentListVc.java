package com.tyfanch.electivehelper.view.vc;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.util.Log;
import android.view.View;

import androidx.databinding.BaseObservable;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;

import com.fasterxml.jackson.core.type.TypeReference;
import com.tyfanch.electivehelper.bean.Msg;
import com.tyfanch.electivehelper.bean.User;
import com.tyfanch.electivehelper.bean.UserConst;
import com.tyfanch.electivehelper.constant.ScheduledTaskConfig;
import com.tyfanch.electivehelper.service.MsgService;
import com.tyfanch.electivehelper.service.MsgServiceImpl;
import com.tyfanch.electivehelper.ui.MsgContentListActivity;
import com.tyfanch.electivehelper.ui.adapters.MsgContentRvAdapter;
import com.tyfanch.electivehelper.ui_utils.PreferenceUtil;
import com.tyfanch.electivehelper.ui_utils.PromptUtil;
import com.tyfanch.electivehelper.utils.Base64Utils;
import com.tyfanch.electivehelper.utils.JsonUtils;
import com.tyfanch.electivehelper.utils.ScheduledTaskUtil;
import com.tyfanch.electivehelper.view.vo.MsgVo;
import com.tyfanch.electivehelper.view.vo.ResultInfo;
import com.tyfanch.electivehelper.view.vo.ResultInfoConst;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

public class MsgContentListVc extends BaseObservable {
    private FragmentActivity activity;
    private FragmentManager fragmentManager;
    private RecyclerView rvMsgContentList;
    private MsgService msgService = new MsgServiceImpl();
    private User sender;
    private User receiver;
    private Msg newMsg = new Msg();
    private List<MsgVo> prevMsgVoList = new ArrayList<>();
    private static int prevMsgVoListSize = 0;

    public MsgContentListVc(FragmentActivity activity, FragmentManager fragmentManager,
        RecyclerView rvMsgContentList) {
        this.activity = activity;
        this.fragmentManager = fragmentManager;
        this.rvMsgContentList = rvMsgContentList;

        this.initVc();
    }

    @SuppressLint("SimpleDateFormat")
    public void onSendMsgClick(View view) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String newMsgJson;

        try {
            if (!this.newMsg.getMsgText().isEmpty()) {
                this.newMsg.setSenderId(this.sender.getId());
                this.newMsg.setReceiverId(this.receiver.getId());
                this.newMsg.setMsgTime(sdf.format(new Date()));
                newMsgJson = JsonUtils.toJson(this.newMsg);
                this.msgService.save(newMsgJson,
                    result -> this.proceedSendMsgResult((ResultInfo) result));
            } else {
                PromptUtil.showToast(this.activity, ResultInfoConst.INVALID_PARAMETER);
            }
        } catch (IOException e) {
            e.printStackTrace();
            PromptUtil.showToast(this.activity, e.getMessage());
        }
    }

    private void initVc() {
        String senderJson = PreferenceUtil.getString(
            this.activity, UserConst.NAME, "");
        String receiverJson = this.activity.getIntent().getStringExtra(UserConst.NAME);

        try {
            this.sender = JsonUtils.fromJson(Base64Utils.decode(senderJson), User.class);
            this.receiver = JsonUtils.fromJson(receiverJson, User.class);
            // 定时获取任务，因为都是获取消息列表，所以覆盖联系人列表里的任务
            ScheduledTaskUtil.newScheduledTask(ScheduledTaskConfig.MSG_TASK,
                ScheduledTaskConfig.MSG_FETCH_DELAY, this::fetchMsgContentList);
        } catch (IOException e) {
            e.printStackTrace();
            this.activity.runOnUiThread(
                () -> PromptUtil.showToast(this.activity, e.getMessage()));
        }
    }

    private void fetchMsgContentList() {
        Msg tmpMsg = new Msg();
        String tmpMsgJson;

        Log.d("----", "MsgContentListVc.fetchMsgContentList..."
            + System.currentTimeMillis());

        try {
            tmpMsg.setSenderId(this.sender.getId());
            tmpMsg.setReceiverId(this.receiver.getId());
            tmpMsgJson = JsonUtils.toJson(tmpMsg);
            this.msgService.findByPaired(tmpMsgJson,
                result -> this.proceedFetchMsgContentResult((ResultInfo) result));
        } catch (IOException e) {
            e.printStackTrace();
            this.activity.runOnUiThread(
                () -> PromptUtil.showToast(this.activity, e.getMessage()));
        }
    }

    private void proceedFetchMsgContentResult(ResultInfo resultInfo) {
        try {
            if (resultInfo.getSuccess()) {
                String msgVoListJson = (String) resultInfo.getResultData();
                List<MsgVo> msgVoList = JsonUtils.fromJson(msgVoListJson,
                    new TypeReference<List<MsgVo>>() {});

                if (msgVoList.size() != this.prevMsgVoList.size()) {
                    this.sendMessageNotification(msgVoList);
                    this.updateMsgContentList(msgVoList);
                    this.prevMsgVoList = msgVoList;
                }
            } else {
                this.activity.runOnUiThread(
                    () -> PromptUtil.showToast(this.activity, resultInfo.getResultMsg()));
            }
        } catch (IOException e) {
            e.printStackTrace();
            this.activity.runOnUiThread(
                () -> PromptUtil.showToast(this.activity, e.getMessage()));
        }
    }

    private void proceedSendMsgResult(ResultInfo resultInfo) {
        if (resultInfo.getSuccess()) {
            this.newMsg = new Msg();
            this.fetchMsgContentList();
            this.notifyChange();
        } else {
            this.activity.runOnUiThread(
                () -> PromptUtil.showToast(this.activity, resultInfo.getResultMsg()));
        }
    }

    private void updateMsgContentList(List<MsgVo> msgVoList) {
        MsgContentRvAdapter msgContentRvAdapter;

        Log.d("----", "MsgContentListVc.updateMsgContentList..."
            + System.currentTimeMillis());

        // 按时间顺序排列，因为在消息内容控件上消息是从下往上排列的
        Collections.sort(msgVoList,
            (o1, o2) -> o1.getMsgTime().compareTo(o2.getMsgTime()));

        if (this.rvMsgContentList.getAdapter() != null) {
            msgContentRvAdapter = (MsgContentRvAdapter) this.rvMsgContentList.getAdapter();
            msgContentRvAdapter.setMsgVoList(msgVoList);
            this.activity.runOnUiThread(msgContentRvAdapter::notifyDataSetChanged);
        } else {
            msgContentRvAdapter = new MsgContentRvAdapter(
                this.activity, this, msgVoList);
            this.activity.runOnUiThread(
                () -> this.rvMsgContentList.setAdapter(msgContentRvAdapter));
        }

        // 滚动到最底部
        this.activity.runOnUiThread(
            () -> this.rvMsgContentList.smoothScrollToPosition(
                msgContentRvAdapter.getItemCount()));
    }

    private void sendMessageNotification(List<MsgVo> msgVoList) {
        MsgVo msgVo;
        String senderName;
        String msgText;
        Intent intent = new Intent(this.activity, MsgContentListActivity.class);

        // 按时间倒序排列，这样去取出的第一条消息就是最新的
        Collections.sort(msgVoList,
            (o1, o2) -> o2.getMsgTime().compareTo(o1.getMsgTime()));

        try {
            if (!msgVoList.isEmpty() && msgVoList.size() != prevMsgVoListSize) {
                msgVo = msgVoList.get(0);
                senderName = msgVo.getSender().getUsername();
                msgText = msgVo.getMsgText();
                intent.putExtra(UserConst.NAME, JsonUtils.toJson(msgVo.getSender()));

                // receiver为当前聊天对象，sender为当前用户
                // 如果消息的发送者和接收者都不是当前聊天对象则发送通知
                if (!msgVo.getSender().getId().equals(this.receiver.getId())
                    && !msgVo.getReceiver().getId().equals(this.receiver.getId())) {
                    this.activity.runOnUiThread(
                        () -> PromptUtil.showNotification(
                            this.activity, intent, senderName, msgText));
                    prevMsgVoListSize = msgVoList.size();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
            this.activity.runOnUiThread(
                () -> PromptUtil.showToast(this.activity, e.getMessage()));
        }
    }

    public Msg getNewMsg() {
        return this.newMsg;
    }

    public void setNewMsg(Msg newMsg) {
        this.newMsg = newMsg;
    }
}
