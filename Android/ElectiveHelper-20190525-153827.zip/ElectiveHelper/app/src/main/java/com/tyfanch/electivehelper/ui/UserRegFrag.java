package com.tyfanch.electivehelper.ui;


import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;

import com.tyfanch.electivehelper.R;
import com.tyfanch.electivehelper.databinding.FragUserRegBinding;
import com.tyfanch.electivehelper.view.vc.AccountVc;

public class UserRegFrag extends Fragment {
    public static final String TAG = "UserRegFrag";

    private FragUserRegBinding userRegBinding;

    public UserRegFrag() {}

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
        Bundle savedInstanceState) {
        this.userRegBinding = DataBindingUtil.inflate(
            inflater, R.layout.frag_user_reg, container, false);

        return this.userRegBinding.getRoot();
    }

    @Override
    public void onStart() {
        super.onStart();

        AccountVc accountVc;

        accountVc = new AccountVc(this.getActivity(),
            this.getFragmentManager());
        this.userRegBinding.setAccountVc(accountVc);

        if (this.getActivity() != null) {
            this.getActivity().setTitle(R.string.register);
        }
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);

        //if (isVisibleToUser && this.getActivity() != null) {
        //    this.getActivity().setTitle(R.string.register);
        //}
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG, TAG + " Destroyed");
    }
}
