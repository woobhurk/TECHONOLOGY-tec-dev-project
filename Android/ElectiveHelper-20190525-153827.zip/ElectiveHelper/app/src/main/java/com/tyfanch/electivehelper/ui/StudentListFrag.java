package com.tyfanch.electivehelper.ui;


import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.tyfanch.electivehelper.R;
import com.tyfanch.electivehelper.databinding.FragStudentListBinding;
import com.tyfanch.electivehelper.view.vc.StudentListVc;

public class StudentListFrag extends Fragment {
    public static final String TAG = "StudentListFrag";

    private FragStudentListBinding studentListBinding;

    public StudentListFrag() {}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
        Bundle savedInstanceState) {
        this.studentListBinding = DataBindingUtil.inflate(
            inflater, R.layout.frag_student_list, container, false);

        return this.studentListBinding.getRoot();
    }

    @Override
    public void onStart() {
        super.onStart();

        StudentListVc studentListVc;
        RecyclerView rvStudentList = this.studentListBinding.rvStudentList;

        rvStudentList.setLayoutManager(new LinearLayoutManager(this.getContext()));
        studentListVc = new StudentListVc(this.getActivity(), this.getFragmentManager(), rvStudentList);
        this.studentListBinding.setStudentListVc(studentListVc);

        if (this.getActivity() != null) {
            this.getActivity().setTitle(R.string.student_list);
        }

        Log.d(TAG, TAG + " onStart");
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);

        //if (isVisibleToUser && this.getActivity() != null) {
        //    this.getActivity().setTitle(R.string.student_list);
        //}

        Log.d(TAG, "" + isVisibleToUser);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG, TAG + " Destroyed");
    }
}
