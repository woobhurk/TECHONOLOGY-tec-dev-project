package com.tyfanch.electivehelper.ui.adapters;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.tyfanch.electivehelper.R;
import com.tyfanch.electivehelper.databinding.ItemMsgBinding;
import com.tyfanch.electivehelper.view.vc.MsgItemVc;
import com.tyfanch.electivehelper.view.vc.MsgListVc;
import com.tyfanch.electivehelper.view.vo.MsgVo;

import java.util.List;

public class MsgRvAdapter extends RecyclerView.Adapter<MsgRvAdapter.MsgRvHolder> {
    private FragmentActivity activity;
    private MsgListVc msgListVc;
    private List<MsgVo> msgVoList;

    public MsgRvAdapter(FragmentActivity activity, MsgListVc msgListVc, List<MsgVo> msgVoList) {
        this.activity = activity;
        this.msgListVc = msgListVc;
        this.msgVoList = msgVoList;
    }

    @Override
    public MsgRvHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(this.activity);
        ItemMsgBinding msgBinding = DataBindingUtil.inflate(
            layoutInflater, R.layout.item_msg, parent, false);

        return new MsgRvHolder(msgBinding);
    }

    @Override
    public void onBindViewHolder(MsgRvHolder holder, int position) {
        MsgItemVc msgItemVc = new MsgItemVc(this.activity, this.msgVoList.get(position));

        holder.getMsgBinding().setMsgItemVc(msgItemVc);
        holder.getMsgBinding().setMsgListVc(this.msgListVc);
    }

    @Override
    public int getItemCount() {
        return this.msgVoList.size();
    }

    public List<MsgVo> getMsgVoList() {
        return this.msgVoList;
    }

    public void setMsgVoList(List<MsgVo> msgVoList) {
        this.msgVoList = msgVoList;
    }

    public static class MsgRvHolder extends RecyclerView.ViewHolder {
        private ItemMsgBinding msgBinding;

        public MsgRvHolder(ItemMsgBinding msgBinding) {
            super(msgBinding.getRoot());

            this.msgBinding = msgBinding;
        }

        public ItemMsgBinding getMsgBinding() {
            return this.msgBinding;
        }

        public void setMsgBinding(ItemMsgBinding msgBinding) {
            this.msgBinding = msgBinding;
        }
    }
}
