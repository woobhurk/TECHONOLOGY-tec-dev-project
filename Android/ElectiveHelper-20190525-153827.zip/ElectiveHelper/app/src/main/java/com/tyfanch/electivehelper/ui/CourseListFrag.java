package com.tyfanch.electivehelper.ui;


import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.appcompat.widget.AppCompatSpinner;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.tyfanch.electivehelper.R;
import com.tyfanch.electivehelper.databinding.FragCourseListBinding;
import com.tyfanch.electivehelper.view.vc.CourseListVc;

public class CourseListFrag extends Fragment {
    public static final String TAG = "CourseListFrag";

    private FragCourseListBinding courseListBinding;

    public CourseListFrag() {}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
        Bundle savedInstanceState) {
        this.courseListBinding = DataBindingUtil.inflate(
            inflater, R.layout.frag_course_list, container, false);

        return this.courseListBinding.getRoot();
    }

    @Override
    public void onStart() {
        super.onStart();

        CourseListVc courseListVc;
        AppCompatSpinner spDayOfWeek = this.courseListBinding.spDayOfWeek;
        AppCompatSpinner spClassOfDay = this.courseListBinding.spClassOfDay;
        RecyclerView rvCourseList = this.courseListBinding.rvCourseList;

        rvCourseList.setLayoutManager(new LinearLayoutManager(this.getActivity()));
        courseListVc = new CourseListVc(this.getActivity(), this.getFragmentManager(),
            spDayOfWeek, spClassOfDay, rvCourseList);
        this.courseListBinding.setCourseListVc(courseListVc);

        //if (this.getActivity() != null) {
        //    this.getActivity().setTitle(R.string.course_list);
        //}
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);

        if (isVisibleToUser && this.getActivity() != null) {
            this.getActivity().setTitle(R.string.course_list);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG, TAG + " Destroyed");
    }
}
