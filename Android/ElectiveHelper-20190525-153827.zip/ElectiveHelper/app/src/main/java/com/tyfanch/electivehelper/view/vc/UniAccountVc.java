package com.tyfanch.electivehelper.view.vc;

import android.app.Activity;
import android.view.View;

import androidx.databinding.BaseObservable;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;

import com.tyfanch.electivehelper.bean.UniUserConst;
import com.tyfanch.electivehelper.bean.UserConst;
import com.tyfanch.electivehelper.bean.UserTypeConst;
import com.tyfanch.electivehelper.service.UniAccountService;
import com.tyfanch.electivehelper.service.UniAccountServiceImpl;
import com.tyfanch.electivehelper.ui_utils.PreferenceUtil;
import com.tyfanch.electivehelper.ui_utils.PromptUtil;
import com.tyfanch.electivehelper.utils.Base64Utils;
import com.tyfanch.electivehelper.utils.JsonUtils;
import com.tyfanch.electivehelper.utils.Md5Utils;
import com.tyfanch.electivehelper.view.vo.ResultInfo;
import com.tyfanch.electivehelper.view.vo.UniUserVo;

import java.io.IOException;

public class UniAccountVc extends BaseObservable {
    private FragmentActivity activity;
    private FragmentManager fragmentManager;
    private UniAccountService uniAccountService = new UniAccountServiceImpl();
    private UniUserVo uniUserVo = new UniUserVo();

    public UniAccountVc(FragmentActivity activity, FragmentManager fragmentManager) {
        this.activity = activity;
        this.fragmentManager = fragmentManager;

        this.initVc();
    }

    public void onUniTypeChange(View view, int type) {
        this.uniUserVo.setType(type);
    }

    public void onUniLoginClick(View view) {
        String userJson = PreferenceUtil.getString(this.activity.getApplicationContext(),
            UserConst.NAME, "");
        String uniUserVoJson;

        try {
            this.uniUserVo.setPassword(Md5Utils.toMd5(this.uniUserVo.getPassword()));
            this.uniUserVo.setPasswordEncrypted(true);
            uniUserVoJson = Base64Utils.encode(JsonUtils.toJson(this.uniUserVo));
            this.uniAccountService.login(userJson, uniUserVoJson,
                result -> this.proceedResult((ResultInfo) result));
        } catch (IOException e) {
            e.printStackTrace();
            PromptUtil.showToast(this.activity, e.getMessage());
        }
    }

    private void initVc() {
        this.uniUserVo.setType(UserTypeConst.TYPE_PRIMARY);
    }

    private void proceedResult(ResultInfo resultInfo) {
        if (resultInfo.getSuccess()) {
            PreferenceUtil.putString(this.activity, UniUserConst.NAME,
                (String) resultInfo.getResultData());
            this.activity.setResult(Activity.RESULT_OK);
            this.activity.finish();
        } else {
            this.activity.runOnUiThread(
                () -> PromptUtil.showToast(this.activity, resultInfo.getResultMsg()));
        }
    }

    public FragmentActivity getActivity() {
        return this.activity;
    }

    public void setActivity(FragmentActivity activity) {
        this.activity = activity;
    }

    public FragmentManager getFragmentManager() {
        return this.fragmentManager;
    }

    public void setFragmentManager(FragmentManager fragmentManager) {
        this.fragmentManager = fragmentManager;
    }

    public UniUserVo getUniUserVo() {
        return this.uniUserVo;
    }

    public void setUniUserVo(UniUserVo uniUserVo) {
        this.uniUserVo = uniUserVo;
    }
}
