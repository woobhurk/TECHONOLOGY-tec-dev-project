package com.tyfanch.electivehelper.view.vc;

import android.content.Intent;
import android.util.Log;
import android.view.View;

import androidx.databinding.BaseObservable;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;

import com.fasterxml.jackson.core.type.TypeReference;
import com.tyfanch.electivehelper.bean.StudentCourse;
import com.tyfanch.electivehelper.bean.UniUser;
import com.tyfanch.electivehelper.bean.User;
import com.tyfanch.electivehelper.bean.UserConst;
import com.tyfanch.electivehelper.service.UniBizService;
import com.tyfanch.electivehelper.service.UniBizServiceImpl;
import com.tyfanch.electivehelper.ui.MsgContentListActivity;
import com.tyfanch.electivehelper.ui.adapters.StudentRvAdapter;
import com.tyfanch.electivehelper.ui_utils.PromptUtil;
import com.tyfanch.electivehelper.utils.JsonUtils;
import com.tyfanch.electivehelper.view.vo.CourseVo;
import com.tyfanch.electivehelper.view.vo.CourseVoConst;
import com.tyfanch.electivehelper.view.vo.ResultInfo;

import java.io.IOException;
import java.util.List;

public class StudentListVc extends BaseObservable {
    private FragmentActivity activity;
    private FragmentManager fragmentManager;
    private RecyclerView rvStudentList;
    private UniBizService uniBizService = new UniBizServiceImpl();

    public StudentListVc(FragmentActivity activity, FragmentManager fragmentManager,
        RecyclerView rvStudentList) {
        this.activity = activity;
        this.fragmentManager = fragmentManager;
        this.rvStudentList = rvStudentList;

        this.initVc();
    }

    public void onStudentClick(View view, User studentUser) {
        Intent intent = new Intent(this.activity, MsgContentListActivity.class);
        String studentUserJson;

        try {
            studentUserJson = JsonUtils.toJson(studentUser);
            intent.putExtra(UserConst.NAME, studentUserJson);
            Log.d("----", studentUser.toString());
            this.activity.startActivityForResult(intent, MsgContentListActivity.ID);
        } catch (IOException e) {
            e.printStackTrace();
            PromptUtil.showToast(this.activity, e.getMessage());
        }
    }

    private void initVc() {
        this.findStudentsOfCourse();
    }

    private void findStudentsOfCourse() {
        String courseVoJson;
        CourseVo courseVo;
        StudentCourse studentCourse = new StudentCourse();

        try {
            courseVoJson = this.activity.getIntent().getStringExtra(CourseVoConst.NAME);
            courseVo = JsonUtils.fromJson(courseVoJson, CourseVo.class);
            studentCourse.setCourseId(courseVo.getId());
            this.uniBizService.findStudentsOfCourse(JsonUtils.toJson(studentCourse),
                result -> this.proceedFindStudents((ResultInfo) result));
        } catch (IOException e) {
            e.printStackTrace();
            PromptUtil.showToast(this.activity, e.getMessage());
        }
    }

    private void proceedFindStudents(ResultInfo resultInfo) {
        String studentListJson;
        List<UniUser> studentList;

        try {
            if (resultInfo.getSuccess()) {
                studentListJson = (String) resultInfo.getResultData();
                studentList = JsonUtils.fromJson(studentListJson,
                    new TypeReference<List<UniUser>>() {});
                this.updateStudentList(studentList);
            } else {
                this.activity.runOnUiThread(
                    () -> PromptUtil.showToast(this.activity, resultInfo.getResultMsg()));
            }
        } catch (IOException e) {
            e.printStackTrace();
            this.activity.runOnUiThread(
                () -> PromptUtil.showToast(this.activity, e.getMessage()));
        }
    }

    private void updateStudentList(List<UniUser> studentList) {
        StudentRvAdapter studentRvAdapter;

        if (this.rvStudentList.getAdapter() != null) {
            studentRvAdapter = (StudentRvAdapter) this.rvStudentList.getAdapter();
            studentRvAdapter.setStudentList(studentList);
            this.activity.runOnUiThread(studentRvAdapter::notifyDataSetChanged);
        } else {
            studentRvAdapter = new StudentRvAdapter(
                this.activity, this, studentList);
            this.activity.runOnUiThread(
                () -> this.rvStudentList.setAdapter(studentRvAdapter));
        }
    }
}
