package com.tyfanch.electivehelper.ui.adapters;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.tyfanch.electivehelper.R;
import com.tyfanch.electivehelper.databinding.ItemOnlineCourseBinding;
import com.tyfanch.electivehelper.view.vc.OnlineCourseItemVc;
import com.tyfanch.electivehelper.view.vc.OnlineCourseListVc;
import com.tyfanch.electivehelper.view.vo.OnlineCourseVo;

import java.util.List;

public class OnlineCourseRvAdapter
    extends RecyclerView.Adapter<OnlineCourseRvAdapter.OnlineCourseRvHolder> {
    private FragmentActivity activity;
    private OnlineCourseListVc onlineCourseListVc;
    private List<OnlineCourseVo> onlineCourseVoList;

    public OnlineCourseRvAdapter(FragmentActivity activity,
        OnlineCourseListVc onlineCourseListVc,
        List<OnlineCourseVo> onlineCourseVoList) {
        this.activity = activity;
        this.onlineCourseListVc = onlineCourseListVc;
        this.onlineCourseVoList = onlineCourseVoList;
    }

    @Override
    public OnlineCourseRvHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(this.activity);
        ItemOnlineCourseBinding courseBinding = DataBindingUtil.inflate(layoutInflater,
            R.layout.item_online_course, parent, false);

        return new OnlineCourseRvHolder(courseBinding);
    }

    @Override
    public void onBindViewHolder(OnlineCourseRvHolder holder, int position) {
        ItemOnlineCourseBinding courseBinding = holder.getOnlineCourseBinding();
        OnlineCourseItemVc onlineCourseItemVc = new OnlineCourseItemVc(
            this.activity, courseBinding.ivCourseImage, this.onlineCourseVoList.get(position));

        courseBinding.setOnlineCourseItemVc(onlineCourseItemVc);
        courseBinding.setOnlineCourseListVc(this.onlineCourseListVc);
    }

    @Override
    public int getItemCount() {
        return this.onlineCourseVoList.size();
    }

    public List<OnlineCourseVo> getOnlineCourseVoList() {
        return this.onlineCourseVoList;
    }

    public void setOnlineCourseVoList(
        List<OnlineCourseVo> onlineCourseVoList) {
        this.onlineCourseVoList = onlineCourseVoList;
    }

    public static class OnlineCourseRvHolder extends RecyclerView.ViewHolder {
        private ItemOnlineCourseBinding onlineCourseBinding;

        public OnlineCourseRvHolder(ItemOnlineCourseBinding onlineCourseBinding) {
            super(onlineCourseBinding.getRoot());

            this.onlineCourseBinding = onlineCourseBinding;
        }

        public ItemOnlineCourseBinding getOnlineCourseBinding() {
            return this.onlineCourseBinding;
        }

        public void setOnlineCourseBinding(
            ItemOnlineCourseBinding onlineCourseBinding) {
            this.onlineCourseBinding = onlineCourseBinding;
        }
    }
}
