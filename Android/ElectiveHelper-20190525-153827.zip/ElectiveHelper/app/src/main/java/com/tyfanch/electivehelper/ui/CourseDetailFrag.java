package com.tyfanch.electivehelper.ui;


import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;

import com.tyfanch.electivehelper.R;
import com.tyfanch.electivehelper.databinding.FragCourseDetailBinding;
import com.tyfanch.electivehelper.view.vc.CourseDetailVc;

public class CourseDetailFrag extends Fragment {
    public static final String TAG = "CourseDetailFrag";

    private FragCourseDetailBinding courseDetailBinding;

    public CourseDetailFrag() {}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
        Bundle savedInstanceState) {
        this.courseDetailBinding = DataBindingUtil.inflate(
            inflater, R.layout.frag_course_detail, container, false);

        return this.courseDetailBinding.getRoot();
    }

    @Override
    public void onStart() {
        super.onStart();

        CourseDetailVc courseDetailVc;

        courseDetailVc = new CourseDetailVc(this.getActivity(), this.getFragmentManager(),
            this.courseDetailBinding.rbCourseRate);
        this.courseDetailBinding.setCourseDetailVc(courseDetailVc);

        //if (this.getActivity() != null) {
        //    this.getActivity().setTitle(R.string.msg_list);
        //}
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);

        if (isVisibleToUser && this.getActivity() != null) {
            this.getActivity().setTitle(R.string.course_detail);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG, TAG + " Destroyed");
    }
}
