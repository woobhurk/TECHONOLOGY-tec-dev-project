package com.tyfanch.electivehelper.utils;

import android.util.Log;
import android.util.SparseArray;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * 定时任务
 */
public class ScheduledTaskUtil {
    private static SparseArray<ScheduledExecutorService> taskPool = new SparseArray<>();

    private ScheduledTaskUtil() {}

    /**
     * 执行新的定时任务
     *
     * @param taskId 任务的ID，如果任务池中已经有相同ID的任务则先停止之前的任务再开启新的任务
     * @param delay 延迟时间
     * @param runnable 运行的任务
     */
    public static void newScheduledTask(int taskId, int delay, Runnable runnable) {
        ScheduledExecutorService currentTask = Executors.newSingleThreadScheduledExecutor();
        ScheduledExecutorService prevTask = taskPool.get(taskId);

        if (prevTask != null) {
            Log.d("ScheduledTaskUtil", "Shutting down previous task...");
            prevTask.shutdown();
            taskPool.put(taskId, currentTask);
        } else {
            taskPool.put(taskId, currentTask);
        }

        currentTask.scheduleWithFixedDelay(runnable, 0, delay, TimeUnit.SECONDS);
    }

    public static void shutdownTask(int taskId) {
        taskPool.get(taskId).shutdown();
    }

    public static void shutdownAll() {
        for (int i = taskPool.size() - 1; i >= 0; i--) {
            taskPool.valueAt(i).shutdown();
            taskPool.removeAt(i);
        }
    }
}
