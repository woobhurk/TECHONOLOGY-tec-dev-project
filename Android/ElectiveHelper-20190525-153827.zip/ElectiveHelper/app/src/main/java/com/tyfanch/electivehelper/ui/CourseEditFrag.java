package com.tyfanch.electivehelper.ui;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.appcompat.widget.AppCompatSpinner;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;

import com.tyfanch.electivehelper.R;
import com.tyfanch.electivehelper.databinding.FragCourseEditBinding;
import com.tyfanch.electivehelper.view.vc.CourseEditVc;

public class CourseEditFrag extends Fragment {
    public static final String TAG = "CourseEditFrag";

    private FragCourseEditBinding courseEditBinding;

    public CourseEditFrag() {}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
        Bundle savedInstanceState) {
        this.courseEditBinding = DataBindingUtil.inflate(
            inflater, R.layout.frag_course_edit, container, false);

        return this.courseEditBinding.getRoot();
    }

    @Override
    public void onStart() {
        super.onStart();

        CourseEditVc courseEditVc;
        AppCompatSpinner spClassroom = this.courseEditBinding.spClassroom;
        AppCompatSpinner spDayOfWeek = this.courseEditBinding.spDayOfWeek;
        AppCompatSpinner spClassOfDay = this.courseEditBinding.spClassOfDay;

        courseEditVc = new CourseEditVc(this.getActivity(), this.getFragmentManager(),
            spClassroom, spDayOfWeek, spClassOfDay);
        this.courseEditBinding.setCourseEditVc(courseEditVc);

        if (this.getActivity() != null) {
            this.getActivity().setTitle(R.string.course_edit);
        }
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);

        //if (isVisibleToUser && this.getActivity() != null) {
        //    this.getActivity().setTitle(R.string.course_edit);
        //}
    }

    @Override
    public void onDestroy() {
        Log.d(TAG, TAG + " Destroyed");
        super.onDestroy();
    }
}
