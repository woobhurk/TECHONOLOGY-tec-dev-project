package com.tyfanch.electivehelper.service;

import com.tyfanch.electivehelper.interfaces.ResultCallback;

public interface UniBizService {
    void findStudentsOfCourse(String studentCourseJson, ResultCallback callback);

    void hasSelected(String studentCourseJson, ResultCallback callback);

    void selectCourse(String studentCourseJson, ResultCallback callback);

    void deselectCourse(String studentCourseJson, ResultCallback callback);
}
