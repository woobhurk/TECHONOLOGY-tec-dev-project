package com.tyfanch.electivehelper.ui;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;

import com.tyfanch.electivehelper.R;
import com.tyfanch.electivehelper.databinding.FragUserLoginBinding;
import com.tyfanch.electivehelper.view.vc.AccountVc;

public class UserLoginFrag extends Fragment {
    public static final String TAG = "UserLoginFrag";

    private FragUserLoginBinding userLoginBinding;

    public UserLoginFrag() {}

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
        Bundle savedInstanceState) {
        this.userLoginBinding = DataBindingUtil.inflate(
            inflater, R.layout.frag_user_login, container, false);

        return this.userLoginBinding.getRoot();
    }

    @Override
    public void onStart() {
        super.onStart();

        AccountVc accountVc;

        accountVc = new AccountVc(this.getActivity(),
            this.getFragmentManager());
        this.userLoginBinding.setAccountVc(accountVc);

        if (this.getActivity() != null) {
            this.getActivity().setTitle(R.string.login);
        }
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);

        //if (isVisibleToUser && this.getActivity() != null) {
        //    this.getActivity().setTitle(R.string.login);
        //}
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG, TAG + " Destroyed");
    }
}
