package com.tyfanch.electivehelper.ui;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.tyfanch.electivehelper.R;

public class MsgContentListActivity extends AppCompatActivity {
    public static final int ID = 0x000006;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        this.setContentView(R.layout.activity_common);
    }

    @Override
    protected void onStart() {
        super.onStart();

        FragmentManager fragmentManager = this.getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        MsgContentListFrag msgContentListFrag;

        for (Fragment fragment : fragmentManager.getFragments()) {
            fragmentTransaction.remove(fragment);
        }

        msgContentListFrag = new MsgContentListFrag();
        fragmentTransaction
            .add(R.id.layCommon, msgContentListFrag, MsgContentListFrag.TAG)
            .commit();
    }
}
