package com.tyfanch.electivehelper.service;

import com.tyfanch.electivehelper.bean.MsgConst;
import com.tyfanch.electivehelper.constant.ServerConfig;
import com.tyfanch.electivehelper.interfaces.ResultCallback;
import com.tyfanch.electivehelper.utils.HttpUtils;

import java.util.HashMap;
import java.util.Map;

public class MsgServiceImpl extends BaseCommonService implements MsgService {
    @Override
    public void findBySingle(String msgJson, ResultCallback callback) {
        Map<String, String> postBody = new HashMap<>();

        postBody.put(ServerConfig.REQUEST_ACTION, "findBySingle");
        postBody.put(MsgConst.NAME, msgJson);
        HttpUtils.post(ServerConfig.MSG_VO_URL, postBody,
            result -> this.requestSuccess((String) result, callback),
            result -> this.requestFail(callback));
    }

    @Override
    public void findByPaired(String msgJson, ResultCallback callback) {
        Map<String, String> postBody = new HashMap<>();

        postBody.put(ServerConfig.REQUEST_ACTION, "findByPaired");
        postBody.put(MsgConst.NAME, msgJson);
        HttpUtils.post(ServerConfig.MSG_VO_URL, postBody,
            result -> this.requestSuccess((String) result, callback),
            result -> this.requestFail(callback));
    }

    @Override
    public void save(String msgJson, ResultCallback callback) {
        Map<String, String> postBody = new HashMap<>();

        postBody.put(ServerConfig.REQUEST_ACTION, "save");
        postBody.put(MsgConst.NAME, msgJson);
        HttpUtils.post(ServerConfig.MSG_URL, postBody,
            result -> this.requestSuccess((String) result, callback),
            result -> this.requestFail(callback));
    }
}
