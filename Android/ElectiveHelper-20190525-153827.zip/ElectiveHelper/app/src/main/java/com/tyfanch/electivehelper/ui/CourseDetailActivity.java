package com.tyfanch.electivehelper.ui;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

import com.tyfanch.electivehelper.R;
import com.tyfanch.electivehelper.databinding.ActivityCourseDetailBinding;
import com.tyfanch.electivehelper.ui.adapters.FragmentVpAdapter;

public class CourseDetailActivity extends AppCompatActivity {
    public static final int ID = 0x000005;

    private ActivityCourseDetailBinding courseDetailBinding;
    private int currentPageIndex;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        this.courseDetailBinding = DataBindingUtil.setContentView(
            this, R.layout.activity_course_detail);
        this.setContentView(this.courseDetailBinding.getRoot());
    }

    @Override
    protected void onStart() {
        super.onStart();

        FragmentVpAdapter fragmentVpAdapter;

        fragmentVpAdapter = new FragmentVpAdapter(this.getSupportFragmentManager());
        fragmentVpAdapter.addFragment(new CourseDetailFrag(), "");
        fragmentVpAdapter.addFragment(new ReplyListFrag(), "");
        this.courseDetailBinding.vpCourseDetail.setAdapter(fragmentVpAdapter);
        this.courseDetailBinding.vpCourseDetail.setCurrentItem(
            this.currentPageIndex, false);
    }

    @Override
    protected void onPause() {
        super.onPause();

        this.currentPageIndex = this.courseDetailBinding.vpCourseDetail.getCurrentItem();
    }
}
