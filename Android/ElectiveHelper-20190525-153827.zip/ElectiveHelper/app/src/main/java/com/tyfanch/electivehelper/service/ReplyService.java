package com.tyfanch.electivehelper.service;

import com.tyfanch.electivehelper.interfaces.ResultCallback;

public interface ReplyService {
    void findByCourse(String replyJson, ResultCallback callback);

    void save(String replyJson, ResultCallback callback);

    void deleteById(String replyJson, ResultCallback callback);
}
