package com.tyfanch.electivehelper.view.vc;

import android.widget.ImageView;

import androidx.databinding.BaseObservable;
import androidx.fragment.app.FragmentActivity;

import com.bumptech.glide.Glide;
import com.tyfanch.electivehelper.view.vo.OnlineCourseVo;

public class OnlineCourseItemVc extends BaseObservable {
    private FragmentActivity activity;
    private ImageView ivCourseImage;
    private OnlineCourseVo onlineCourseVo;
    private String description;
    private String provider;
    private String scoreStr;

    public OnlineCourseItemVc(FragmentActivity activity, ImageView ivCourseImage,
        OnlineCourseVo onlineCourseVo) {
        this.activity = activity;
        this.ivCourseImage = ivCourseImage;
        this.onlineCourseVo = onlineCourseVo;

        this.initVc();
    }

    private void initVc() {
        String tmpImageUrl = this.onlineCourseVo.getImageUrl();
        String tmpDescription = this.onlineCourseVo.getDescription();
        String tmpProvider = this.onlineCourseVo.getProvider();
        Double tmpScore = this.onlineCourseVo.getScore();

        if (tmpImageUrl!= null && !tmpImageUrl.equals("null")) {
            Glide.with(this.activity).load(tmpImageUrl)
                .skipMemoryCache(false)
                .into(this.ivCourseImage);
        }

        this.description = (tmpDescription == null || tmpDescription.equals("null")) ? "暂无介绍"
            : this.onlineCourseVo.getDescription();
        this.provider = (tmpProvider == null || tmpProvider.equals("null")) ? "未知"
            : this.onlineCourseVo.getProvider();
        this.scoreStr = (tmpScore == null || tmpScore == 0.0) ? "无"
            : String.valueOf(this.onlineCourseVo.getScore());
        this.notifyChange();
    }

    public OnlineCourseVo getOnlineCourseVo() {
        return this.onlineCourseVo;
    }

    public void setOnlineCourseVo(OnlineCourseVo onlineCourseVo) {
        this.onlineCourseVo = onlineCourseVo;
    }

    public String getDescription() {
        return this.description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getProvider() {
        return this.provider;
    }

    public void setProvider(String provider) {
        this.provider = provider;
    }

    public String getScoreStr() {
        return this.scoreStr;
    }

    public void setScoreStr(String scoreStr) {
        this.scoreStr = scoreStr;
    }
}
