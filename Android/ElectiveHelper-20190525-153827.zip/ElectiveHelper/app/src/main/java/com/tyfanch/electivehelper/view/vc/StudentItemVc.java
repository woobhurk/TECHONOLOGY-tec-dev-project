package com.tyfanch.electivehelper.view.vc;

import androidx.databinding.BaseObservable;
import androidx.fragment.app.FragmentActivity;

import com.fasterxml.jackson.core.type.TypeReference;
import com.tyfanch.electivehelper.bean.UniUser;
import com.tyfanch.electivehelper.bean.User;
import com.tyfanch.electivehelper.service.UniAccountService;
import com.tyfanch.electivehelper.service.UniAccountServiceImpl;
import com.tyfanch.electivehelper.ui_utils.PromptUtil;
import com.tyfanch.electivehelper.utils.Base64Utils;
import com.tyfanch.electivehelper.utils.JsonUtils;
import com.tyfanch.electivehelper.view.vo.ResultInfo;

import java.io.IOException;
import java.util.List;

public class StudentItemVc extends BaseObservable {
    private FragmentActivity activity;
    private UniAccountService uniAccountService = new UniAccountServiceImpl();
    private UniUser student;
    private User studentUser;
    private boolean studentClickable;

    public StudentItemVc(FragmentActivity activity, UniUser student) {
        this.activity = activity;
        this.student = student;

        this.initVc();
    }

    private void initVc() {
        String uniUserJson;

        try {
            uniUserJson = JsonUtils.toJson(this.student);
            this.uniAccountService.findUserByUniUserId(Base64Utils.encode(uniUserJson),
                result -> this.proceedFindUserResult((ResultInfo) result));
        } catch (IOException e) {
            e.printStackTrace();
            PromptUtil.showToast(this.activity, e.getMessage());
        }
    }

    private void proceedFindUserResult(ResultInfo resultInfo) {
        String studentUserListJson;
        List<User> studentUserList;

        try {
            if (resultInfo.getSuccess()) {
                studentUserListJson = (String) resultInfo.getResultData();
                studentUserList = JsonUtils.fromJson(studentUserListJson,
                    new TypeReference<List<User>>() {});

                if (!studentUserList.isEmpty()) {
                    this.studentUser = studentUserList.get(0);
                    this.studentClickable = true;
                    this.notifyChange();
                }
            } else {
                this.activity.runOnUiThread(
                    () -> PromptUtil.showToast(this.activity, resultInfo.getResultMsg()));
            }
        } catch (IOException e) {
            e.printStackTrace();
            this.activity.runOnUiThread(
                () -> PromptUtil.showToast(this.activity, e.getMessage()));
        }
    }

    public UniUser getStudent() {
        return this.student;
    }

    public void setStudent(UniUser student) {
        this.student = student;
    }

    public User getStudentUser() {
        return this.studentUser;
    }

    public void setStudentUser(User studentUser) {
        this.studentUser = studentUser;
    }

    public boolean isStudentClickable() {
        return this.studentClickable;
    }

    public void setStudentClickable(boolean studentClickable) {
        this.studentClickable = studentClickable;
    }
}
