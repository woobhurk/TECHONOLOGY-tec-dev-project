package com.tyfanch.electivehelper.service;

import com.tyfanch.electivehelper.interfaces.ResultCallback;

public interface MsgService {
    void findBySingle(String msgJson, ResultCallback callback);

    void findByPaired(String msgJson, ResultCallback callback);

    void save(String msgJson, ResultCallback callback);
}
