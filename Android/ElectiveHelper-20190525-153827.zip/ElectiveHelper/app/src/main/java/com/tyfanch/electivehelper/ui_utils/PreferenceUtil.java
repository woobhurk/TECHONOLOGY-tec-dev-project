package com.tyfanch.electivehelper.ui_utils;

import android.content.Context;
import android.preference.PreferenceManager;

import java.util.Map;

public class PreferenceUtil {
    private PreferenceUtil() {}

    public static String getString(Context ctx, String key, String defValue) {
        return PreferenceManager.getDefaultSharedPreferences(ctx)
            .getString(key, defValue);
    }

    public static Map<String, ?> getAll(Context ctx) {
        return PreferenceManager.getDefaultSharedPreferences(ctx)
            .getAll();
    }

    public static void putString(Context ctx, String key, String value) {
        PreferenceManager.getDefaultSharedPreferences(ctx)
            .edit()
            .putString(key, value)
            .apply();
    }

    public static void remove(Context ctx, String key) {
        PreferenceManager.getDefaultSharedPreferences(ctx)
            .edit()
            .remove(key)
            .apply();
    }
}
