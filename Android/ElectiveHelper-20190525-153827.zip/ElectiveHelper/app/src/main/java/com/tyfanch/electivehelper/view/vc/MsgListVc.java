package com.tyfanch.electivehelper.view.vc;

import android.content.Intent;
import android.util.Log;
import android.util.SparseArray;
import android.view.View;

import androidx.databinding.BaseObservable;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;

import com.fasterxml.jackson.core.type.TypeReference;
import com.tyfanch.electivehelper.bean.Msg;
import com.tyfanch.electivehelper.bean.User;
import com.tyfanch.electivehelper.bean.UserConst;
import com.tyfanch.electivehelper.constant.ScheduledTaskConfig;
import com.tyfanch.electivehelper.service.MsgService;
import com.tyfanch.electivehelper.service.MsgServiceImpl;
import com.tyfanch.electivehelper.ui.MsgContentListActivity;
import com.tyfanch.electivehelper.ui.adapters.MsgRvAdapter;
import com.tyfanch.electivehelper.ui_utils.PreferenceUtil;
import com.tyfanch.electivehelper.ui_utils.PromptUtil;
import com.tyfanch.electivehelper.utils.Base64Utils;
import com.tyfanch.electivehelper.utils.JsonUtils;
import com.tyfanch.electivehelper.utils.ScheduledTaskUtil;
import com.tyfanch.electivehelper.view.vo.MsgVo;
import com.tyfanch.electivehelper.view.vo.ResultInfo;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MsgListVc extends BaseObservable {
    private FragmentActivity activity;
    private FragmentManager fragmentManager;
    private RecyclerView rvMsgList;
    private MsgService msgService = new MsgServiceImpl();
    private User user;
    private List<MsgVo> prevMsgVoList = new ArrayList<>();
    private static int prevMsgVoListSize = 0;

    public MsgListVc(FragmentActivity activity, FragmentManager fragmentManager,
        RecyclerView rvMsgList) {
        this.activity = activity;
        this.fragmentManager = fragmentManager;
        this.rvMsgList = rvMsgList;

        this.initVc();
    }

    public void onMsgClick(View view, MsgVo msgVo) {
        Intent intent = new Intent(this.activity, MsgContentListActivity.class);
        String receiverJson;

        try {
            if (msgVo.getSender().getId().equals(this.user.getId())) {
                receiverJson = JsonUtils.toJson(msgVo.getReceiver());
            } else {
                receiverJson = JsonUtils.toJson(msgVo.getSender());
            }

            intent.putExtra(UserConst.NAME, receiverJson);
            this.activity.startActivityForResult(intent, MsgContentListActivity.ID);
        } catch (IOException e) {
            e.printStackTrace();
            this.activity.runOnUiThread(
                () -> PromptUtil.showToast(this.activity, e.getMessage()));
        }
    }

    private void initVc() {
        Log.d("----", "MsgListVc.msgFetchTask initialized " + System.currentTimeMillis());
        // 定时获取任务，因为都是获取消息列表，所以覆盖聊天列表里的任务
        ScheduledTaskUtil.newScheduledTask(ScheduledTaskConfig.MSG_TASK,
            ScheduledTaskConfig.MSG_FETCH_DELAY, this::fetchMsgList);
    }

    private void fetchMsgList() {
        String userJson = PreferenceUtil.getString(this.activity, UserConst.NAME, "");
        Msg msg = new Msg();
        String msgJson;

        Log.d("----", "MsgListVc.fetchMsgList..." + System.currentTimeMillis());

        try {
            this.user = JsonUtils.fromJson(Base64Utils.decode(userJson), User.class);
            msg.setSenderId(this.user.getId());
            msgJson = JsonUtils.toJson(msg);
            this.msgService.findBySingle(msgJson,
                result -> this.proceedFetchResult((ResultInfo) result));
        } catch (IOException e) {
            e.printStackTrace();
            this.activity.runOnUiThread(
                () -> PromptUtil.showToast(this.activity, e.getMessage()));
        }
    }

    private void proceedFetchResult(ResultInfo resultInfo) {
        try {
            if (resultInfo.getSuccess()) {
                String msgVoListJson = (String) resultInfo.getResultData();
                List<MsgVo> msgVoList = JsonUtils.fromJson(msgVoListJson,
                    new TypeReference<List<MsgVo>>() {});

                if (msgVoList.size() != this.prevMsgVoList.size()) {
                    this.updateMsgList(msgVoList);
                    this.sendMessageNotification(msgVoList);
                    this.prevMsgVoList = msgVoList;
                }
            } else {
                this.activity.runOnUiThread(
                    () -> PromptUtil.showToast(this.activity, resultInfo.getResultMsg()));
            }
        } catch (IOException e) {
            e.printStackTrace();
            this.activity.runOnUiThread(
                () -> PromptUtil.showToast(this.activity, e.getMessage()));
        }
    }

    private void updateMsgList(List<MsgVo> msgVoList) {
        SparseArray<MsgVo> msgVoSparseArray = new SparseArray<>();
        List<MsgVo> mergedMsgVoList = new ArrayList<>();
        MsgRvAdapter msgRvAdapter;

        Log.d("----", "MsgListVc.fetchMsgList Updating..."
            + System.currentTimeMillis());

        // 顺序排序，这样合并消息的时候更新的消息会覆盖更旧的消息
        Collections.sort(msgVoList,
            (o1, o2) -> o1.getMsgTime().compareTo(o2.getMsgTime()));

        // 将发送方和接收方都为自己的消息内容合并成一条，用来显示成消息列表
        for (MsgVo msgVo : msgVoList) {
            if (msgVo.getSender().getId().equals(this.user.getId())) {
                msgVoSparseArray.put(msgVo.getReceiver().getId(), msgVo);
            } else {
                msgVoSparseArray.put(msgVo.getSender().getId(), msgVo);
            }
        }

        for (int i = 0; i < msgVoSparseArray.size(); i++) {
            mergedMsgVoList.add(msgVoSparseArray.valueAt(i));
        }

        // 按照时间倒序排序
        Collections.sort(mergedMsgVoList,
            (o1, o2) -> o2.getMsgTime().compareTo(o1.getMsgTime()));
        // 仅支持API-24以上
        //mergedMsgVoList.sort((o1, o2) -> o2.getMsgTime().compareTo(o1.getMsgTime()));

        if (this.rvMsgList.getAdapter() != null) {
            msgRvAdapter = (MsgRvAdapter) this.rvMsgList.getAdapter();

            msgRvAdapter.setMsgVoList(mergedMsgVoList);
            this.activity.runOnUiThread(msgRvAdapter::notifyDataSetChanged);
        } else {
            msgRvAdapter = new MsgRvAdapter(
                this.activity, this, mergedMsgVoList);
            this.activity.runOnUiThread(
                () -> this.rvMsgList.setAdapter(msgRvAdapter));
        }

        this.notifyChange();
    }

    private void sendMessageNotification(List<MsgVo> msgVoList) {
        MsgVo msgVo;
        String senderName;
        String msgText;
        Intent intent = new Intent(this.activity, MsgContentListActivity.class);

        // 按时间倒序排序
        Collections.sort(msgVoList,
            (o1, o2) -> o2.getMsgTime().compareTo(o1.getMsgTime()));

        try {
            if (!msgVoList.isEmpty() && msgVoList.size() != prevMsgVoListSize) {
                msgVo = msgVoList.get(0);
                senderName = msgVo.getSender().getUsername();
                msgText = msgVo.getMsgText();
                intent.putExtra(UserConst.NAME, JsonUtils.toJson(msgVo.getSender()));

                // user为当前用户
                // 如果消息发送者不是当前用户则发送通知
                if (!msgVo.getSender().getId().equals(this.user.getId())) {
                    this.activity.runOnUiThread(
                        () -> PromptUtil.showNotification(
                            this.activity, intent, senderName, msgText));
                    prevMsgVoListSize = msgVoList.size();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
            this.activity.runOnUiThread(
                () -> PromptUtil.showToast(this.activity, e.getMessage()));
        }
    }

    public FragmentActivity getActivity() {
        return this.activity;
    }

    public void setActivity(FragmentActivity activity) {
        this.activity = activity;
    }

    public FragmentManager getFragmentManager() {
        return this.fragmentManager;
    }

    public void setFragmentManager(FragmentManager fragmentManager) {
        this.fragmentManager = fragmentManager;
    }
}
