package com.tyfanch.electivehelper.constant;

public class ScheduledTaskConfig {
    private ScheduledTaskConfig() {}

    public static final int MSG_TASK = 0x000001;
    public static final int MSG_FETCH_DELAY = 5;
}
