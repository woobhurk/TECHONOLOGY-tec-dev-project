package com.tyfanch.electivehelper.view.vc;

import android.annotation.SuppressLint;

import androidx.databinding.BaseObservable;
import androidx.fragment.app.FragmentActivity;

import com.tyfanch.electivehelper.bean.StudentCourse;
import com.tyfanch.electivehelper.bean.UniUser;
import com.tyfanch.electivehelper.bean.UniUserConst;
import com.tyfanch.electivehelper.bean.UserTypeConst;
import com.tyfanch.electivehelper.constant.CourseConfig;
import com.tyfanch.electivehelper.service.UniBizService;
import com.tyfanch.electivehelper.service.UniBizServiceImpl;
import com.tyfanch.electivehelper.ui_utils.PreferenceUtil;
import com.tyfanch.electivehelper.ui_utils.PromptUtil;
import com.tyfanch.electivehelper.utils.Base64Utils;
import com.tyfanch.electivehelper.utils.JsonUtils;
import com.tyfanch.electivehelper.view.vo.CourseVo;
import com.tyfanch.electivehelper.view.vo.ResultInfo;

import java.io.IOException;

public class CourseItemVc extends BaseObservable {
    private FragmentActivity activity;
    private UniBizService uniBizService = new UniBizServiceImpl();
    private CourseVo courseVo;
    private boolean ownerTeacher;
    private boolean ownerStudent;
    private String classroomStr;
    private String dayOfWeekStr;
    private String classOfDayStr;
    private String rateStr;

    public CourseItemVc(FragmentActivity activity, CourseVo courseVo) {
        this.activity = activity;
        this.courseVo = courseVo;

        this.initVc();
    }

    @SuppressLint("DefaultLocale")
    private void initVc() {
        String uniUserJson;
        UniUser uniUser;
        StudentCourse studentCourse = new StudentCourse();
        String studentCourseJson;
        Integer rateCount = this.courseVo.getRateCount();
        Integer rateTotal = this.courseVo.getRateTotal();

        try {
            uniUserJson = PreferenceUtil.getString(
                this.activity, UniUserConst.NAME, "");
            uniUser = JsonUtils.fromJson(Base64Utils.decode(uniUserJson), UniUser.class);

            if (uniUser.getType().equals(UserTypeConst.TYPE_SENIOR)) {
                this.ownerTeacher = uniUser.getType().equals(UserTypeConst.TYPE_SENIOR)
                    && (uniUser.getId().equals(this.courseVo.getTeacher().getId()));
            } else {
                studentCourse.setStudentId(uniUser.getId());
                studentCourse.setCourseId(this.courseVo.getId());
                studentCourseJson = JsonUtils.toJson(studentCourse);
                this.uniBizService.hasSelected(studentCourseJson, result -> {
                    this.ownerStudent = (Boolean) ((ResultInfo) result).getResultData();
                    this.notifyChange();
                });
            }
        } catch (IOException e) {
            e.printStackTrace();
            this.activity.runOnUiThread(
                () -> PromptUtil.showToast(this.activity, e.getMessage()));
        }

        this.classroomStr = String.format("%d-%s-%s",
            this.courseVo.getClassroom().getId(),
            this.courseVo.getClassroom().getBuilding(),
            this.courseVo.getClassroom().getRoom());
        this.dayOfWeekStr = CourseConfig.dayOfWeekList[this.courseVo.getDayOfWeek() - 1];
        this.classOfDayStr = String.format("第%d, %d节课",
            this.courseVo.getClassOfDay() * 2 - 1,
            this.courseVo.getClassOfDay() * 2);

        if (rateCount != null && rateCount > 0 && rateTotal != null && rateTotal > 0) {
            this.rateStr = String.format("%.1f", (double) rateTotal / rateCount);
        } else {
            this.rateStr = "无";
        }

        this.notifyChange();
    }

    public CourseVo getCourseVo() {
        return this.courseVo;
    }

    public void setCourseVo(CourseVo courseVo) {
        this.courseVo = courseVo;
    }

    public boolean isOwnerTeacher() {
        return this.ownerTeacher;
    }

    public void setOwnerTeacher(boolean ownerTeacher) {
        this.ownerTeacher = ownerTeacher;
    }

    public boolean isOwnerStudent() {
        return this.ownerStudent;
    }

    public void setOwnerStudent(boolean ownerStudent) {
        this.ownerStudent = ownerStudent;
    }

    public String getClassroomStr() {
        return this.classroomStr;
    }

    public void setClassroomStr(String classroomStr) {
        this.classroomStr = classroomStr;
    }

    public String getDayOfWeekStr() {
        return this.dayOfWeekStr;
    }

    public void setDayOfWeekStr(String dayOfWeekStr) {
        this.dayOfWeekStr = dayOfWeekStr;
    }

    public String getClassOfDayStr() {
        return this.classOfDayStr;
    }

    public void setClassOfDayStr(String classOfDayStr) {
        this.classOfDayStr = classOfDayStr;
    }

    public String getRateStr() {
        return this.rateStr;
    }

    public void setRateStr(String rateStr) {
        this.rateStr = rateStr;
    }
}
