package com.tyfanch.electivehelper.service;

import com.tyfanch.electivehelper.bean.CourseConst;
import com.tyfanch.electivehelper.bean.UniUserConst;
import com.tyfanch.electivehelper.constant.ServerConfig;
import com.tyfanch.electivehelper.interfaces.ResultCallback;
import com.tyfanch.electivehelper.utils.HttpUtils;
import com.tyfanch.electivehelper.view.vo.CourseVoConst;

import java.util.HashMap;
import java.util.Map;

public class CourseServiceImpl extends BaseCommonService implements CourseService {
    @Override
    public void findAll(ResultCallback callback) {
        Map<String, String> postBody = new HashMap<>();

        postBody.put(ServerConfig.REQUEST_ACTION, "findAll");
        HttpUtils.post(ServerConfig.COURSE_VO_URL, postBody,
            result -> this.requestSuccess((String) result, callback),
            result -> this.requestFail(callback));
    }

    @Override
    public void findByColumn(String courseVoJson, ResultCallback callback) {
        Map<String, String> postBody = new HashMap<>();

        postBody.put(ServerConfig.REQUEST_ACTION, "findByColumn");
        postBody.put(CourseVoConst.NAME, courseVoJson);
        HttpUtils.post(ServerConfig.COURSE_VO_URL, postBody,
            result -> this.requestSuccess((String) result, callback),
            result -> this.requestFail(callback));
    }

    @Override
    public void findByTeacherAndColumn(String uniUserJson, String courseVoJson,
        ResultCallback callback) {
        Map<String, String> postBody = new HashMap<>();

        postBody.put(ServerConfig.REQUEST_ACTION, "findByTeacherAndColumn");
        postBody.put(UniUserConst.NAME, uniUserJson);
        postBody.put(CourseVoConst.NAME, courseVoJson);
        HttpUtils.post(ServerConfig.COURSE_VO_URL, postBody,
            result -> this.requestSuccess((String) result, callback),
            result -> this.requestFail(callback));
    }

    @Override
    public void findByStudentAndColumn(String uniUserJson, String courseVoJson,
        ResultCallback callback) {
        Map<String, String> postBody = new HashMap<>();

        postBody.put(ServerConfig.REQUEST_ACTION, "findByStudentAndColumn");
        postBody.put(UniUserConst.NAME, uniUserJson);
        postBody.put(CourseVoConst.NAME, courseVoJson);
        HttpUtils.post(ServerConfig.COURSE_VO_URL, postBody,
            result -> this.requestSuccess((String) result, callback),
            result -> this.requestFail(callback));
    }

    @Override
    public void save(String courseJson, ResultCallback callback) {
        Map<String, String> postBody = new HashMap<>();

        postBody.put(ServerConfig.REQUEST_ACTION, "save");
        postBody.put(CourseConst.NAME, courseJson);
        HttpUtils.post(ServerConfig.COURSE_URL, postBody,
            result -> this.requestSuccess((String) result, callback),
            result -> this.requestFail(callback));
    }

    @Override
    public void update(String courseJson, ResultCallback callback) {
        Map<String, String> postBody = new HashMap<>();

        postBody.put(ServerConfig.REQUEST_ACTION, "update");
        postBody.put(CourseConst.NAME, courseJson);
        HttpUtils.post(ServerConfig.COURSE_URL, postBody,
            result -> this.requestSuccess((String) result, callback),
            result -> this.requestFail(callback));
    }

    @Override
    public void deleteById(String courseJson, ResultCallback callback) {
        Map<String, String> postBody = new HashMap<>();

        postBody.put(ServerConfig.REQUEST_ACTION, "deleteById");
        postBody.put(CourseConst.NAME, courseJson);
        HttpUtils.post(ServerConfig.COURSE_URL, postBody,
            result -> this.requestSuccess((String) result, callback),
            result -> this.requestFail(callback));
    }
}
