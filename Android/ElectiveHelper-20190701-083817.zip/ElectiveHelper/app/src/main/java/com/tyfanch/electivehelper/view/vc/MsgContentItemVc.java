package com.tyfanch.electivehelper.view.vc;

import androidx.databinding.BaseObservable;
import androidx.fragment.app.FragmentActivity;

import com.fasterxml.jackson.core.type.TypeReference;
import com.tyfanch.electivehelper.bean.UniUser;
import com.tyfanch.electivehelper.bean.User;
import com.tyfanch.electivehelper.bean.UserConst;
import com.tyfanch.electivehelper.service.UniAccountService;
import com.tyfanch.electivehelper.service.UniAccountServiceImpl;
import com.tyfanch.electivehelper.ui_utils.PreferenceUtil;
import com.tyfanch.electivehelper.ui_utils.PromptUtil;
import com.tyfanch.electivehelper.utils.Base64Utils;
import com.tyfanch.electivehelper.utils.JsonUtils;
import com.tyfanch.electivehelper.view.vo.MsgVo;
import com.tyfanch.electivehelper.view.vo.ResultInfo;

import java.io.IOException;
import java.util.List;

public class MsgContentItemVc extends BaseObservable {
    private FragmentActivity activity;
    private UniAccountService uniAccountService = new UniAccountServiceImpl();
    private User user;
    private UniUser uniUser;
    private MsgVo msgVo;
    private boolean msgSentByCurrentUser;

    public MsgContentItemVc(FragmentActivity activity, MsgVo msgVo) {
        this.activity = activity;
        this.msgVo = msgVo;

        this.initVc();
    }

    private void initVc() {
        String userJson = PreferenceUtil.getString(this.activity, UserConst.NAME, "");

        try {
            this.user = JsonUtils.fromJson(Base64Utils.decode(userJson), User.class);
            this.msgSentByCurrentUser = this.user.getId().equals(this.msgVo.getSender().getId());
            this.fetchUniUser();
        } catch (IOException e) {
            e.printStackTrace();
            this.activity.runOnUiThread(
                () -> PromptUtil.showToast(this.activity, e.getMessage()));
        }

        this.notifyChange();
    }

    private void fetchUniUser() {
        String userJson;

        try {
            userJson = Base64Utils.encode(JsonUtils.toJson(this.msgVo.getSender()));
            this.uniAccountService.findUniUserByUserId(userJson,
                result -> this.proceedFetchUniUser((ResultInfo) result));
        } catch (IOException e) {
            e.printStackTrace();
            PromptUtil.showToast(this.activity, e.getMessage());
        }
    }

    private void proceedFetchUniUser(ResultInfo resultInfo) {
        try {
            if (resultInfo.getSuccess()) {
                String uniUserListJson = (String) resultInfo.getResultData();
                List<UniUser> uniUserList;

                uniUserList = JsonUtils.fromJson(uniUserListJson,
                    new TypeReference<List<UniUser>>() {});

                if (!uniUserList.isEmpty()) {
                    this.uniUser = uniUserList.get(0);
                } else {
                    this.uniUser = new UniUser();
                    this.uniUser.setName("无");
                }
            } else {
                this.uniUser = new UniUser();
                this.uniUser.setName("无");
            }
        } catch (IOException e) {
            e.printStackTrace();
            this.activity.runOnUiThread(
                () -> PromptUtil.showToast(this.activity, e.getMessage()));
        }

        this.notifyChange();
    }

    public User getUser() {
        return this.user;
    }

    public UniUser getUniUser() {
        return this.uniUser;
    }

    public void setUniUser(UniUser uniUser) {
        this.uniUser = uniUser;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public MsgVo getMsgVo() {
        return this.msgVo;
    }

    public void setMsgVo(MsgVo msgVo) {
        this.msgVo = msgVo;
    }

    public boolean isMsgSentByCurrentUser() {
        return this.msgSentByCurrentUser;
    }

    public void setMsgSentByCurrentUser(boolean msgSentByCurrentUser) {
        this.msgSentByCurrentUser = msgSentByCurrentUser;
    }
}
