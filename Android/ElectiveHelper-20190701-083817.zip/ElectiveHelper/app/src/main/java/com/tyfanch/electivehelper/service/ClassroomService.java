package com.tyfanch.electivehelper.service;

import com.tyfanch.electivehelper.interfaces.ResultCallback;

public interface ClassroomService {
    void findAll(ResultCallback callback);
}
