package com.tyfanch.electivehelper.ui;

import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.tyfanch.electivehelper.R;

public class CourseEditActivity extends AppCompatActivity {
    public static final int ID = 0x000004;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        this.setContentView(R.layout.activity_common);
    }

    @Override
    protected void onStart() {
        super.onStart();

        FragmentManager fragmentManager = this.getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        CourseEditFrag courseEditFrag;

        for (Fragment fragment : fragmentManager.getFragments()) {
            fragmentTransaction.remove(fragment);
        }

        courseEditFrag = new CourseEditFrag();
        fragmentTransaction
            .add(R.id.layCommon, courseEditFrag, CourseEditFrag.TAG)
            .commit();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        Log.d("----", "CourseEditActivity Destroyed");
    }
}
