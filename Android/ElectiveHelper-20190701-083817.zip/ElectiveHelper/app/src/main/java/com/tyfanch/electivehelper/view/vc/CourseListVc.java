package com.tyfanch.electivehelper.view.vc;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;

import androidx.appcompat.widget.AppCompatSpinner;
import androidx.databinding.BaseObservable;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;

import com.fasterxml.jackson.core.type.TypeReference;
import com.tyfanch.electivehelper.bean.Course;
import com.tyfanch.electivehelper.bean.Teacher;
import com.tyfanch.electivehelper.bean.UniUser;
import com.tyfanch.electivehelper.bean.UniUserConst;
import com.tyfanch.electivehelper.bean.UserConst;
import com.tyfanch.electivehelper.bean.UserTypeConst;
import com.tyfanch.electivehelper.constant.CourseConfig;
import com.tyfanch.electivehelper.interfaces.ResultCallback;
import com.tyfanch.electivehelper.service.CourseService;
import com.tyfanch.electivehelper.service.CourseServiceImpl;
import com.tyfanch.electivehelper.service.UniAccountService;
import com.tyfanch.electivehelper.service.UniAccountServiceImpl;
import com.tyfanch.electivehelper.ui.CourseDetailActivity;
import com.tyfanch.electivehelper.ui.CourseEditActivity;
import com.tyfanch.electivehelper.ui.adapters.CourseRvAdapter;
import com.tyfanch.electivehelper.ui_utils.PreferenceUtil;
import com.tyfanch.electivehelper.ui_utils.PromptUtil;
import com.tyfanch.electivehelper.utils.Base64Utils;
import com.tyfanch.electivehelper.utils.JsonUtils;
import com.tyfanch.electivehelper.view.vo.CourseVo;
import com.tyfanch.electivehelper.view.vo.CourseVoConst;
import com.tyfanch.electivehelper.view.vo.ResultInfo;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CourseListVc extends BaseObservable {
    private FragmentActivity activity;
    private FragmentManager fragmentManager;
    private AppCompatSpinner spDayOfWeek;
    private AppCompatSpinner spClassOfDay;
    private RecyclerView rvCourseList;
    private UniAccountService uniAccountService = new UniAccountServiceImpl();
    private CourseService courseService = new CourseServiceImpl();
    private UniUser uniUser;
    private boolean showCourseList;
    private boolean typeTeacher;
    private String courseName = "";
    private String teacherName = "";
    private Integer dayOfWeek = 0;
    private Integer classOfDay = 0;

    public CourseListVc(FragmentActivity activity, FragmentManager fragmentManager,
        AppCompatSpinner spDayOfWeek, AppCompatSpinner spClassOfDay, RecyclerView rvCourseList) {
        this.activity = activity;
        this.fragmentManager = fragmentManager;
        this.spDayOfWeek = spDayOfWeek;
        this.spClassOfDay = spClassOfDay;
        this.rvCourseList = rvCourseList;

        this.initVc();
    }

    public void onSearchClick(View view) {
        this.fetchCourseListByColumn();
    }

    public void onClearSearchClick(View view) {
        this.courseName = "";
        this.teacherName = "";
        this.dayOfWeek = 0;
        this.classOfDay = 0;
        this.spDayOfWeek.setSelection(0);
        this.spClassOfDay.setSelection(0);
        this.notifyChange();
        this.fetchCourseListByColumn();
    }

    public void onCourseClick(View view, CourseVo courseVo) {
        Intent intent;

        try {
            intent = new Intent(this.activity, CourseDetailActivity.class);
            intent.putExtra(CourseVoConst.NAME, JsonUtils.toJson(courseVo));
            this.activity.startActivityForResult(intent, CourseDetailActivity.ID);
        } catch (IOException e) {
            e.printStackTrace();
            PromptUtil.showToast(this.activity, e.getMessage());
        }
    }

    public void onCourseUpdateClick(View view, CourseVo courseVo) {
        Intent intent;

        try {
            intent = new Intent(this.activity, CourseEditActivity.class);
            intent.putExtra(CourseVoConst.NAME, JsonUtils.toJson(courseVo));
            this.activity.startActivityForResult(intent, CourseEditActivity.ID);
        } catch (IOException e) {
            e.printStackTrace();
            this.activity.runOnUiThread(
                () -> PromptUtil.showToast(this.activity, e.getMessage()));
        }
    }

    public void onCourseDeleteClick(View view, CourseVo courseVo) {
        Course course = new Course();
        String courseJson;

        try {
            course.setId(courseVo.getId());
            courseJson = JsonUtils.toJson(course);
            PromptUtil.showDialog(this.activity, "删除",
                "确认删除" + courseVo.getName() + "？",
                "确认", "取消",
                () -> this.courseService.deleteById(courseJson,
                    result -> this.proceedCourseDeleteResult((ResultInfo) result)));
        } catch (IOException e) {
            e.printStackTrace();
            this.activity.runOnUiThread(
                () -> PromptUtil.showToast(this.activity, e.getMessage()));
        }
    }

    public void onCourseAddClick(View view) {
        this.activity.startActivityForResult(
            new Intent(this.activity, CourseEditActivity.class), CourseEditActivity.ID);
    }

    @SuppressLint("DefaultLocale")
    private void initVc() {
        String userJson;
        String uniUserJson;
        ArrayAdapter<String> spinnerAdapter;
        List<String> dayOfWeekList = new ArrayList<>();
        List<String> classOfDayList = new ArrayList<>();

        userJson = PreferenceUtil.getString(this.activity, UserConst.NAME, "");
        uniUserJson = PreferenceUtil.getString(this.activity, UniUserConst.NAME, "");
        // 判断是否登录
        this.uniAccountService.login(userJson, uniUserJson,
            result -> this.proceedLoginResult((ResultInfo) result));

        try {
            this.uniUser = JsonUtils.fromJson(Base64Utils.decode(uniUserJson), UniUser.class);
        } catch (IOException e) {
            e.printStackTrace();
            //PromptUtil.showToast(this.activity, e.getMessage());
        }

        // 初始化下拉列表控件，第一项为空
        dayOfWeekList.add("");
        dayOfWeekList.addAll(Arrays.asList(CourseConfig.dayOfWeekList));

        classOfDayList.add("");

        for (int i = 1; i <= 4; i++) {
            classOfDayList.add(String.format("%d, %d节课", i * 2 - 1, i * 2));
        }

        // 设置星期几
        spinnerAdapter = new ArrayAdapter<>(this.activity, android.R.layout.simple_spinner_item,
            dayOfWeekList);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        this.spDayOfWeek.setAdapter(spinnerAdapter);
        this.spDayOfWeek.setOnItemSelectedListener(new OnItemSelectedListener(
            result -> this.dayOfWeek = (Integer) result));
        this.spDayOfWeek.setSelection(this.dayOfWeek);
        // 设置第几节课
        spinnerAdapter = new ArrayAdapter<>(this.activity, android.R.layout.simple_spinner_item,
            classOfDayList);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        this.spClassOfDay.setAdapter(spinnerAdapter);
        this.spClassOfDay.setOnItemSelectedListener(new OnItemSelectedListener(
            result -> this.classOfDay = (Integer) result));
        this.spClassOfDay.setSelection(this.classOfDay);
    }

    private void proceedLoginResult(ResultInfo resultInfo) {
        //boolean loggedIn = (boolean) resultInfo.getResultData();

        //if (loggedIn) {
        //    this.showCourseList = true;
        //    this.fetchCourseListByColumn();
        //} else {
        //    this.showCourseList = false;
        //}

        if (resultInfo.getSuccess()) {
            this.showCourseList = true;
            this.fetchCourseListByColumn();
        } else {
            this.showCourseList = false;
        }

        this.notifyChange();
    }

    private void fetchCourseListByColumn() {
        String uniUserJson = this.activity.getIntent().getStringExtra(UniUserConst.NAME);
        CourseVo courseVo = new CourseVo();
        String courseVoJson;

        try {
            courseVo.setTeacher(new Teacher());
            courseVo.setName(this.courseName);
            courseVo.getTeacher().setName(this.teacherName);
            courseVo.setDayOfWeek(this.dayOfWeek);
            courseVo.setClassOfDay(this.classOfDay);
            courseVoJson = JsonUtils.toJson(courseVo);

            if (uniUserJson != null) {
                if (this.uniUser.getType() == UserTypeConst.TYPE_PRIMARY) {
                    this.courseService.findByStudentAndColumn(uniUserJson, courseVoJson,
                        result -> this.proceedFetchCourseResult((ResultInfo) result));
                } else {
                    this.courseService.findByTeacherAndColumn(uniUserJson, courseVoJson,
                        result -> this.proceedFetchCourseResult((ResultInfo) result));
                }
            } else {
                this.courseService.findByColumn(courseVoJson,
                    result -> this.proceedFetchCourseResult((ResultInfo) result));
            }
        } catch (IOException e) {
            e.printStackTrace();
            this.activity.runOnUiThread(
                () -> PromptUtil.showToast(this.activity, e.getMessage()));
        }
    }

    //private void fetchAllCourseList() {
    //    String uniUserJson = this.activity.getIntent().getStringExtra(UniUserConst.NAME);
    //    CourseVo courseVo = new CourseVo();
    //    String courseVoJson;
    //
    //    try {
    //        courseVo.setTeacher(new Teacher());
    //        courseVo.setName(this.courseName);
    //        courseVo.getTeacher().setName(this.teacherName);
    //        courseVo.setDayOfWeek(this.dayOfWeek);
    //        courseVo.setClassOfDay(this.classOfDay);
    //        courseVoJson = JsonUtils.toJson(courseVo);
    //
    //        if (uniUserJson != null) {
    //            if (this.uniUser.getType() == UserTypeConst.TYPE_PRIMARY) {
    //                this.courseService.findByStudentAndColumn(uniUserJson, courseVoJson,
    //                    result -> this.proceedFetchCourseResult((ResultInfo) result));
    //            } else {
    //                this.courseService.findByTeacherAndColumn(uniUserJson, courseVoJson,
    //                    result -> this.proceedFetchCourseResult((ResultInfo) result));
    //            }
    //        } else {
    //            this.courseService.findAll(
    //                result -> this.proceedFetchCourseResult((ResultInfo) result));
    //        }
    //    } catch (IOException e) {
    //        e.printStackTrace();
    //        this.activity.runOnUiThread(
    //            () -> PromptUtil.showToast(this.activity, e.getMessage()));
    //    }
    //}

    private void proceedFetchCourseResult(ResultInfo resultInfo) {
        try {
            if (resultInfo.getSuccess()) {
                List<CourseVo> courseVoList;
                String courseVoListJson = (String) resultInfo.getResultData();

                courseVoList = JsonUtils.fromJson(courseVoListJson,
                    new TypeReference<List<CourseVo>>() {});
                this.updateCourseList(courseVoList);
            } else {
                this.activity.runOnUiThread(
                    () -> PromptUtil.showToast(this.activity, resultInfo.getResultMsg()));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void proceedCourseDeleteResult(ResultInfo resultInfo) {
        if (resultInfo.getSuccess()) {
            if (this.rvCourseList.getAdapter() != null) {
                this.activity.runOnUiThread(() -> {
                    this.fetchCourseListByColumn();
                    PromptUtil.showToast(this.activity, "已删除");
                });
            }
        } else {
            this.activity.runOnUiThread(
                () -> PromptUtil.showToast(this.activity, resultInfo.getResultMsg()));
        }
    }

    private void updateCourseList(List<CourseVo> courseVoList) {
        CourseRvAdapter courseRvAdapter;
        int scrollY = this.rvCourseList.getScrollY();

        if (this.rvCourseList.getAdapter() != null) {
            courseRvAdapter = (CourseRvAdapter) this.rvCourseList.getAdapter();
            courseRvAdapter.setCourseVoList(courseVoList);
            this.activity.runOnUiThread(courseRvAdapter::notifyDataSetChanged);
        } else {
            courseRvAdapter = new CourseRvAdapter(this.activity, this,
                courseVoList);
            this.activity.runOnUiThread(
                () -> this.rvCourseList.setAdapter(courseRvAdapter));
            this.typeTeacher = this.showCourseList
                && this.uniUser.getType().equals(UserTypeConst.TYPE_SENIOR);
        }

        this.activity.runOnUiThread(() -> this.rvCourseList.scrollTo(0, scrollY));
        this.notifyChange();
    }

    public FragmentActivity getActivity() {
        return this.activity;
    }

    public void setActivity(FragmentActivity activity) {
        this.activity = activity;
    }

    public FragmentManager getFragmentManager() {
        return this.fragmentManager;
    }

    public void setFragmentManager(FragmentManager fragmentManager) {
        this.fragmentManager = fragmentManager;
    }

    public UniUser getUniUser() {
        return this.uniUser;
    }

    public void setUniUser(UniUser uniUser) {
        this.uniUser = uniUser;
    }

    public boolean isShowCourseList() {
        return this.showCourseList;
    }

    public void setShowCourseList(boolean showCourseList) {
        this.showCourseList = showCourseList;
    }

    public boolean isTypeTeacher() {
        return this.typeTeacher;
    }

    public void setTypeTeacher(boolean typeTeacher) {
        this.typeTeacher = typeTeacher;
    }

    public String getCourseName() {
        return this.courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public String getTeacherName() {
        return this.teacherName;
    }

    public void setTeacherName(String teacherName) {
        this.teacherName = teacherName;
    }

    private class OnItemSelectedListener implements AdapterView.OnItemSelectedListener {
        private ResultCallback callback;

        public OnItemSelectedListener(ResultCallback callback) {
            this.callback = callback;
        }

        @Override
        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
            this.callback.onResult(position);
        }

        @Override
        public void onNothingSelected(AdapterView<?> parent) {
            this.callback.onResult(0);
        }
    }
}
