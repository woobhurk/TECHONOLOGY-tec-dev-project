package com.tyfanch.electivehelper.constant;

public class ServerConfig {
    private ServerConfig() {}

    // 宿舍
    //public static final String SERVER_IP = "192.168.1.15";
    // 手机联通
    public static final String SERVER_IP = "192.168.43.99";
    public static final String SERVER_URL = "http://" + SERVER_IP + ":8080/ElectiveHelper";
    public static final String USER_URL = SERVER_URL + "/User";
    public static final String MSG_URL = SERVER_URL + "/Msg";
    public static final String MSG_VO_URL = SERVER_URL + "/MsgVo";
    public static final String COURSE_URL = SERVER_URL + "/Course";
    public static final String COURSE_VO_URL = SERVER_URL + "/CourseVo";
    public static final String REPLY_URL = SERVER_URL + "/Reply";
    public static final String REPLY_VO_URL = SERVER_URL + "/ReplyVo";
    public static final String CLASSROOM_URL = SERVER_URL + "/Classroom";
    public static final String TEACHER_URL = SERVER_URL + "/Teacher";
    public static final String STUDENT_URL = SERVER_URL + "/Student";
    public static final String ONLINE_COURSE_URL = SERVER_URL + "/OnlineCourse";

    public static final String REQUEST_ACTION = "action";
}
