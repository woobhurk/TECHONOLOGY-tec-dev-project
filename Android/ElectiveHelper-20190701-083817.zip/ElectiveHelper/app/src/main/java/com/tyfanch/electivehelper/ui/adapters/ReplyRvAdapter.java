package com.tyfanch.electivehelper.ui.adapters;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.tyfanch.electivehelper.R;
import com.tyfanch.electivehelper.databinding.ItemReplyBinding;
import com.tyfanch.electivehelper.view.vc.ReplyItemVc;
import com.tyfanch.electivehelper.view.vc.ReplyListVc;
import com.tyfanch.electivehelper.view.vo.ReplyVo;

import java.util.List;

public class ReplyRvAdapter extends RecyclerView.Adapter<ReplyRvAdapter.ReplyRvHolder> {
    private FragmentActivity activity;
    private ReplyListVc replyListVc;
    private List<ReplyVo> replyVoList;

    public ReplyRvAdapter(FragmentActivity activity, ReplyListVc replyListVc,
        List<ReplyVo> replyVoList) {
        this.activity = activity;
        this.replyListVc = replyListVc;
        this.replyVoList = replyVoList;
    }

    @Override
    public ReplyRvHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(this.activity);
        ItemReplyBinding replyBinding = DataBindingUtil.inflate(
            layoutInflater, R.layout.item_reply, parent, false);

        return new ReplyRvHolder(replyBinding);
    }

    @Override
    public void onBindViewHolder(ReplyRvHolder holder, int position) {
        ReplyItemVc replyItemVc;

        replyItemVc = new ReplyItemVc(this.activity, this.replyVoList.get(position));
        holder.getReplyBinding().setReplyListVc(this.replyListVc);
        holder.getReplyBinding().setReplyItemVc(replyItemVc);
    }

    @Override
    public int getItemCount() {
        return this.replyVoList.size();
    }

    public List<ReplyVo> getReplyVoList() {
        return this.replyVoList;
    }

    public void setReplyVoList(List<ReplyVo> replyVoList) {
        this.replyVoList = replyVoList;
    }

    public static class ReplyRvHolder extends RecyclerView.ViewHolder {
        private ItemReplyBinding replyBinding;

        public ReplyRvHolder(ItemReplyBinding replyBinding) {
            super(replyBinding.getRoot());

            this.replyBinding = replyBinding;
        }

        public ItemReplyBinding getReplyBinding() {
            return this.replyBinding;
        }

        public void setReplyBinding(ItemReplyBinding replyBinding) {
            this.replyBinding = replyBinding;
        }
    }
}
