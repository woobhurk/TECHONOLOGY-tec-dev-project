package com.tyfanch.electivehelper.view.vc;

import android.annotation.SuppressLint;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.databinding.BaseObservable;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;

import com.tyfanch.electivehelper.constant.OnlineCourseConfig;
import com.tyfanch.electivehelper.ui_utils.PromptUtil;
import com.tyfanch.electivehelper.utils.JsonUtils;
import com.tyfanch.electivehelper.view.vo.OnlineCourseVo;
import com.tyfanch.electivehelper.view.vo.OnlineCourseVoConst;

import java.io.IOException;

public class OnlineCourseVc extends BaseObservable {
    private FragmentActivity activity;
    private FragmentManager fragmentManager;
    private WebView wvOnlineCourse;
    private int progress;

    public OnlineCourseVc(FragmentActivity activity, FragmentManager fragmentManager,
        WebView wvOnlineCourse) {
        this.activity = activity;
        this.fragmentManager = fragmentManager;
        this.wvOnlineCourse = wvOnlineCourse;

        this.initVc();
    }

    @SuppressLint({"DefaultLocale", "SetJavaScriptEnabled"})
    private void initVc() {
        String onlineCourseVoJson = this.activity.getIntent().getStringExtra(
            OnlineCourseVoConst.NAME);
        OnlineCourseVo onlineCourseVo;
        String onlineCourseUrl;

        try {
            onlineCourseVo = JsonUtils.fromJson(onlineCourseVoJson, OnlineCourseVo.class);
            onlineCourseUrl = String.format(OnlineCourseConfig.COURSE_URL,
                onlineCourseVo.getCourseId());
            this.wvOnlineCourse.getSettings().setDomStorageEnabled(true);
            this.wvOnlineCourse.getSettings().setAppCacheEnabled(true);
            this.wvOnlineCourse.getSettings().setCacheMode(WebSettings.LOAD_DEFAULT);
            this.wvOnlineCourse.getSettings().setJavaScriptEnabled(true);
            this.wvOnlineCourse.getSettings().setAllowContentAccess(true);
            this.wvOnlineCourse.getSettings().setMixedContentMode(
                WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
            // 设置所有连接在本WebView打开
            this.wvOnlineCourse.setWebViewClient(new WebViewClient() {
                @Override
                public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                    view.loadUrl(request.getUrl().toString());
                    return true;
                }
            });
            // 设置进度条
            this.wvOnlineCourse.setWebChromeClient(new WebChromeClient() {
                @Override
                public void onProgressChanged(WebView view, int newProgress) {
                    super.onProgressChanged(view, newProgress);

                    OnlineCourseVc.this.progress = newProgress;
                    OnlineCourseVc.this.notifyChange();
                }
            });
            this.wvOnlineCourse.setSaveEnabled(true);
            this.wvOnlineCourse.loadUrl(onlineCourseUrl);
        } catch (IOException e) {
            e.printStackTrace();
            PromptUtil.showToast(this.activity, e.getMessage());
        }
    }

    public int getProgress() {
        return this.progress;
    }

    public void setProgress(int progress) {
        this.progress = progress;
    }
}
