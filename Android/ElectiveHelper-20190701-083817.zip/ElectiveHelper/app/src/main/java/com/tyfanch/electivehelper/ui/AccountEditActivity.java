package com.tyfanch.electivehelper.ui;

import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.tyfanch.electivehelper.R;

public class AccountEditActivity extends AppCompatActivity {
    public static final int ID = 0x000003;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        this.setContentView(R.layout.activity_common);
    }

    @Override
    protected void onStart() {
        super.onStart();

        FragmentManager fragmentManager = this.getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        AccountEditFrag accountEditFrag;

        for (Fragment fragment : fragmentManager.getFragments()) {
            fragmentTransaction.remove(fragment);
        }

        accountEditFrag = new AccountEditFrag();
        fragmentTransaction
            .add(R.id.layCommon, accountEditFrag, AccountEditFrag.TAG)
            .commit();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        Log.d("----", "AccountEditActivity Destroyed");
    }
}
