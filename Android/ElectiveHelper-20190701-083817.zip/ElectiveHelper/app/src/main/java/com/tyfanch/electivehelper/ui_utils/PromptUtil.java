package com.tyfanch.electivehelper.ui_utils;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.core.app.NotificationCompat;
import androidx.databinding.DataBindingUtil;

import com.tyfanch.electivehelper.R;
import com.tyfanch.electivehelper.databinding.ToastBinding;
import com.tyfanch.electivehelper.view.vc.ToastVc;

public class PromptUtil {
    private PromptUtil() {}

    public static void showToast(Context ctx, String str) {
        LayoutInflater layoutInflater = LayoutInflater.from(ctx);
        ToastBinding toastBinding = DataBindingUtil.inflate(layoutInflater, R.layout.toast,
            null, false);
        ToastVc toastVc = new ToastVc(true, null, str);
        Toast toast = new Toast(ctx);

        toastBinding.setToastVc(toastVc);
        toast.setView(toastBinding.getRoot());
        //toast.setGravity(Gravity.TOP, 0, 0);
        toast.setDuration(Toast.LENGTH_SHORT);
        toast.show();
    }

    public static void showToast(Context ctx, int resId) {
        showToast(ctx, ctx.getString(resId));
    }

    public static void showLongToast(Context ctx, String str) {
        Toast.makeText(ctx, str, Toast.LENGTH_LONG).show();
    }

    public static void showLongToast(Context ctx, int resId) {
        Toast.makeText(ctx, resId, Toast.LENGTH_LONG).show();
    }

    public static void showDialog(Context ctx, String title, String message,
        CharSequence confirmMsg, CharSequence cancelMsg, Runnable onConfirm) {
        AlertDialog.Builder builder = new AlertDialog.Builder(ctx);

        builder.setTitle(title);
        builder.setMessage(message);
        builder.setPositiveButton(confirmMsg, (dialog, which) -> onConfirm.run());
        builder.setNegativeButton(cancelMsg, (dialog, which) -> dialog.dismiss());
        builder.setCancelable(true);
        builder.show();
    }

    public static void showNotification(Context ctx, Intent intent, CharSequence title,
        CharSequence message) {
        NotificationManager notificationManager = (NotificationManager) ctx.getSystemService(
            Context.NOTIFICATION_SERVICE);
        NotificationChannel notificationChannel;
        NotificationCompat.Builder builder;
        PendingIntent pendingIntent;

        // 适配Android O
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            notificationChannel = new NotificationChannel("channelId", "Notification",
                NotificationManager.IMPORTANCE_DEFAULT);
            notificationChannel.setDescription("No description");
            notificationManager.createNotificationChannel(notificationChannel);
        }

        builder = new NotificationCompat.Builder(ctx, "channelId");
        builder.setSmallIcon(R.mipmap.ic_launcher_round);
        builder.setContentTitle(title);
        builder.setContentText(message);
        builder.setCategory(NotificationCompat.CATEGORY_MESSAGE);
        builder.setDefaults(Notification.DEFAULT_ALL);
        builder.setAutoCancel(true);

        if (intent != null) {
            pendingIntent = PendingIntent.getActivity(ctx, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT);
            builder.setContentIntent(pendingIntent);
        }

        notificationManager.notify((int) System.currentTimeMillis(), builder.build());
    }
}
