package com.tyfanch.electivehelper.utils;

import android.util.Base64;

import java.nio.charset.StandardCharsets;

public class Base64Utils {
    private Base64Utils() {}

    public static String encode(String str) {
        byte[] bytes;
        String srcStr;
        String encodedStr;

        // 去除空行
        srcStr = str.replace("\n", "")
            .replace("\r", "")
            .replace("\r\n", "");
        bytes = srcStr.getBytes(StandardCharsets.UTF_8);
        encodedStr = Base64.encodeToString(bytes, Base64.NO_WRAP);

        // 去除空行
        return encodedStr.replace("\n", "")
            .replace("\r", "")
            .replace("\r\n", "");
    }

    public static String decode(String str) {
        String srcStr;
        String decodedStr;
        byte[] bytes;

        srcStr = str.replace("\n", "")
            .replace("\r", "")
            .replace("\r\n", "");
        bytes = Base64.decode(srcStr, Base64.NO_WRAP);
        decodedStr = new String(bytes, StandardCharsets.UTF_8);

        return decodedStr.replace("\n", "")
            .replace("\r", "")
            .replace("\r\n", "");
    }

    public static String encodeMime(String str) {
        //Base64.Encoder mimeEncoder = Base64.getMimeEncoder();
        //byte[] bytes = str.getBytes(StandardCharsets.UTF_8);
        //
        //return new String(mimeEncoder.encode(bytes), StandardCharsets.UTF_8);
        return encode(str);
    }

    public static String decodeMime(String str) {
        //Base64.Decoder mimeDecoder = Base64.getMimeDecoder();
        //byte[] bytes = str.getBytes(StandardCharsets.UTF_8);
        //
        //return new String(mimeDecoder.decode(bytes), StandardCharsets.UTF_8);
        return decode(str);
    }

    public static String encodeUrl(String str) {
        //Base64.Encoder urlEncoder = Base64.getUrlEncoder();
        //byte[] bytes = str.getBytes(StandardCharsets.UTF_8);
        //
        //return new String(urlEncoder.encode(bytes), StandardCharsets.UTF_8);
        return encode(str);
    }

    public static String decodeUrl(String str) {
        //Base64.Decoder urlDecoder = Base64.getUrlDecoder();
        //byte[] bytes = str.getBytes(StandardCharsets.UTF_8);
        //
        //return new String(urlDecoder.decode(bytes), StandardCharsets.UTF_8);
        return decode(str);
    }
}
