package com.tyfanch.electivehelper.service;

import com.tyfanch.electivehelper.bean.ReplyConst;
import com.tyfanch.electivehelper.constant.ServerConfig;
import com.tyfanch.electivehelper.interfaces.ResultCallback;
import com.tyfanch.electivehelper.utils.HttpUtils;

import java.util.HashMap;
import java.util.Map;

public class ReplyServiceImpl extends BaseCommonService implements ReplyService {
    @Override
    public void findByCourse(String replyJson, ResultCallback callback) {
        Map<String, String> postBody = new HashMap<>();

        postBody.put(ServerConfig.REQUEST_ACTION, "findByCourse");
        postBody.put(ReplyConst.NAME, replyJson);
        HttpUtils.post(ServerConfig.REPLY_VO_URL, postBody,
            result -> this.requestSuccess((String) result, callback),
            result -> this.requestFail(callback));
    }

    @Override
    public void save(String replyJson, ResultCallback callback) {
        Map<String, String> postBody = new HashMap<>();

        postBody.put(ServerConfig.REQUEST_ACTION, "save");
        postBody.put(ReplyConst.NAME, replyJson);
        HttpUtils.post(ServerConfig.REPLY_URL, postBody,
            result -> this.requestSuccess((String) result, callback),
            result -> this.requestFail(callback));
    }

    @Override
    public void deleteById(String replyJson, ResultCallback callback) {
        Map<String, String> postBody = new HashMap<>();

        postBody.put(ServerConfig.REQUEST_ACTION, "deleteById");
        postBody.put(ReplyConst.NAME, replyJson);
        HttpUtils.post(ServerConfig.REPLY_URL, postBody,
            result -> this.requestSuccess((String) result, callback),
            result -> this.requestFail(callback));
    }
}
