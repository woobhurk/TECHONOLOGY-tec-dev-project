package com.tyfanch.electivehelper.interfaces;

public interface ResultCallback {
    void onResult(Object result);
}
