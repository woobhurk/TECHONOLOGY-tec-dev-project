package com.tyfanch.electivehelper.ui;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;

import com.tyfanch.electivehelper.R;
import com.tyfanch.electivehelper.databinding.FragUserEditBinding;
import com.tyfanch.electivehelper.view.vc.AccountEditVc;

public class AccountEditFrag extends Fragment {
    public static final String TAG = "AccountEditFrag";

    private FragUserEditBinding userEditBinding;

    public AccountEditFrag() {}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
        Bundle savedInstanceState) {
        this.userEditBinding = DataBindingUtil.inflate(
            inflater, R.layout.frag_user_edit, container, false);

        return this.userEditBinding.getRoot();
    }

    @Override
    public void onStart() {
        super.onStart();

        AccountEditVc accountEditVc;

        accountEditVc = new AccountEditVc(this.getActivity(),
            this.getFragmentManager());
        this.userEditBinding.setAccountEditVc(accountEditVc);

        if (this.getActivity() != null) {
            this.getActivity().setTitle(R.string.user_edit);
        }
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);

        //if (isVisibleToUser && this.getActivity() != null) {
        //    this.getActivity().setTitle(R.string.user_edit);
        //}
    }

    @Override
    public void onDestroy() {
        Log.d(TAG, TAG + " Destroyed");
        super.onDestroy();
    }
}
