package com.tyfanch.electivehelper.ui;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.tyfanch.electivehelper.R;
import com.tyfanch.electivehelper.bean.User;
import com.tyfanch.electivehelper.bean.UserConst;
import com.tyfanch.electivehelper.databinding.FragMsgContentListBinding;
import com.tyfanch.electivehelper.utils.JsonUtils;
import com.tyfanch.electivehelper.view.vc.MsgContentListVc;

import java.io.IOException;

public class MsgContentListFrag extends Fragment {
    public static final String TAG = "MsgContentListFrag";

    private FragMsgContentListBinding msgContentListBinding;

    public MsgContentListFrag() {}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
        Bundle savedInstanceState) {
        this.msgContentListBinding = DataBindingUtil.inflate(
            inflater, R.layout.frag_msg_content_list, container, false);

        return this.msgContentListBinding.getRoot();
    }

    @Override
    public void onStart() {
        super.onStart();

        MsgContentListVc msgContentListVc;
        RecyclerView rvMsgContentList = this.msgContentListBinding.rvMsgContentList;
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this.getContext());
        String receiverJson;
        User receiver;

        linearLayoutManager.setStackFromEnd(true);
        rvMsgContentList.setLayoutManager(linearLayoutManager);

        msgContentListVc = new MsgContentListVc(this.getActivity(), this.getFragmentManager(),
            rvMsgContentList);
        this.msgContentListBinding.setMsgContentListVc(msgContentListVc);

        try {
            if (this.getActivity() != null) {
                receiverJson = this.getActivity().getIntent().getStringExtra(UserConst.NAME);
                receiver = JsonUtils.fromJson(receiverJson, User.class);
                this.getActivity().setTitle(receiver.getUsername());
            }
        } catch (IOException e) {
            e.printStackTrace();

            if (this.getActivity() != null) {
                this.getActivity().setTitle(R.string.send_msg);
            }
        }
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);

        //if (isVisibleToUser && this.getActivity() != null) {
        //    this.getActivity().setTitle(R.string.user_edit);
        //}
    }

    @Override
    public void onDestroy() {
        Log.d(TAG, TAG + " Destroyed");
        super.onDestroy();
    }
}
