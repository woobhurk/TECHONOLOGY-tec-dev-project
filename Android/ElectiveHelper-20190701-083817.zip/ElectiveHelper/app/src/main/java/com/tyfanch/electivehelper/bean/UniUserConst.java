package com.tyfanch.electivehelper.bean;

public class UniUserConst {
    protected UniUserConst() {}

    public static final String NAME = "uniUser";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_TYPE = "type";
    public static final String COLUMN_ID_NO = "account";
    public static final String COLUMN_PASSWORD = "password";
    public static final String COLUMN_USER_ID = "userId";
    public static final String COLUMN_NAME = "name";
    public static final String COLUMN_SCHOOL = "school";
    public static final String COLUMN_MAJOR = "major";
}
