package com.tyfanch.electivehelper.ui;


import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;

import com.tyfanch.electivehelper.R;
import com.tyfanch.electivehelper.databinding.FragUniUserLoginBinding;
import com.tyfanch.electivehelper.view.vc.UniAccountVc;

public class UniUserLoginFrag extends Fragment {
    public static final String TAG = "UniUserLoginFrag";

    private FragUniUserLoginBinding uniUserLoginBinding;

    public UniUserLoginFrag() {}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
        Bundle savedInstanceState) {
        this.uniUserLoginBinding = DataBindingUtil.inflate(
            inflater, R.layout.frag_uni_user_login, container, false);

        return this.uniUserLoginBinding.getRoot();
    }

    @Override
    public void onStart() {
        super.onStart();

        UniAccountVc uniAccountVc;

        uniAccountVc = new UniAccountVc(this.getActivity(),
            this.getFragmentManager());
        this.uniUserLoginBinding.setUniAccountVc(uniAccountVc);

        if (this.getActivity() != null) {
            this.getActivity().setTitle(R.string.uni_bind);
        }
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);

        //if (isVisibleToUser && this.getActivity() != null) {
        //    this.getActivity().setTitle(R.string.uni_bind);
        //}
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG, TAG + " Destroyed");
    }
}
