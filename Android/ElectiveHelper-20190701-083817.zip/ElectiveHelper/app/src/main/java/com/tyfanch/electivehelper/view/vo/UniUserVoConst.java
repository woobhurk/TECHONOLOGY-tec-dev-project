package com.tyfanch.electivehelper.view.vo;

public class UniUserVoConst {
    private UniUserVoConst() {}

    public static final String NAME = "uniUserVo";
}
