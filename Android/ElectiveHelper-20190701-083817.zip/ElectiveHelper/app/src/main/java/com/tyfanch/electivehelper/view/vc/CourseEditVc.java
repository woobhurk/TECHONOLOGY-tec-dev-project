package com.tyfanch.electivehelper.view.vc;

import android.annotation.SuppressLint;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;

import androidx.appcompat.widget.AppCompatSpinner;
import androidx.databinding.BaseObservable;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;

import com.fasterxml.jackson.core.type.TypeReference;
import com.tyfanch.electivehelper.bean.Classroom;
import com.tyfanch.electivehelper.bean.Course;
import com.tyfanch.electivehelper.bean.Teacher;
import com.tyfanch.electivehelper.bean.UniUser;
import com.tyfanch.electivehelper.bean.UniUserConst;
import com.tyfanch.electivehelper.constant.CourseConfig;
import com.tyfanch.electivehelper.interfaces.ResultCallback;
import com.tyfanch.electivehelper.service.ClassroomService;
import com.tyfanch.electivehelper.service.ClassroomServiceImpl;
import com.tyfanch.electivehelper.service.CourseService;
import com.tyfanch.electivehelper.service.CourseServiceImpl;
import com.tyfanch.electivehelper.ui_utils.PreferenceUtil;
import com.tyfanch.electivehelper.ui_utils.PromptUtil;
import com.tyfanch.electivehelper.utils.Base64Utils;
import com.tyfanch.electivehelper.utils.JsonUtils;
import com.tyfanch.electivehelper.utils.TyBeanUtils;
import com.tyfanch.electivehelper.view.vo.CourseVo;
import com.tyfanch.electivehelper.view.vo.CourseVoConst;
import com.tyfanch.electivehelper.view.vo.ResultInfo;
import com.tyfanch.electivehelper.view.vo.ResultInfoConst;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

public class CourseEditVc extends BaseObservable {
    private FragmentActivity activity;
    private FragmentManager fragmentManager;
    private AppCompatSpinner spClassroom;
    private AppCompatSpinner spDayOfWeek;
    private AppCompatSpinner spClassOfDay;
    private CourseService courseService = new CourseServiceImpl();
    private ClassroomService classroomService = new ClassroomServiceImpl();
    private CourseVo courseVo;
    private List<Classroom> classroomList;

    public CourseEditVc(FragmentActivity activity, FragmentManager fragmentManager,
        AppCompatSpinner spClassroom, AppCompatSpinner spDayOfWeek,
        AppCompatSpinner spClassOfDay) {
        this.activity = activity;
        this.fragmentManager = fragmentManager;
        this.spClassroom = spClassroom;
        this.spDayOfWeek = spDayOfWeek;
        this.spClassOfDay = spClassOfDay;

        this.initVc();
    }

    public void onEditClick(View view) {
        String courseVoJson = this.activity.getIntent().getStringExtra(CourseVoConst.NAME);
        Course course = new Course();
        String courseJson;
        String keywordsStr;
        List<String> keywordsList;

        if (!this.courseVo.getName().isEmpty()
            && !this.courseVo.getDescription().isEmpty()
            && !this.courseVo.getKeywords().isEmpty()) {
            try {
                keywordsStr = this.courseVo.getKeywords().trim()
                    .replace("，", ", ")
                    .replaceAll("  ", " ");
                this.courseVo.setKeywords(keywordsStr);
                keywordsList = new ArrayList<>(Arrays.asList(keywordsStr.split(",")));

                // 移除空的关键词
                for (int i = keywordsList.size() - 1; i >= 0; i--) {
                    if (keywordsList.get(i).isEmpty()) {
                        keywordsList.remove(i);
                    }
                }

                //course.setId(this.courseVo.getId());
                course.setTeacherId(this.courseVo.getTeacher().getId());
                //course.setName(this.courseVo.getName());
                //course.setDescription(this.courseVo.getDescription());
                //course.setKeywords(this.courseVo.getKeywords());
                //course.setStartTime(this.courseVo.getStartTime());
                //course.setEndTime(this.courseVo.getEndTime());
                course.setClassroomId(this.courseVo.getClassroom().getId());
                //course.setDayOfWeek(this.courseVo.getDayOfWeek());
                //course.setClassOfDay(this.courseVo.getClassOfDay());
                TyBeanUtils.copyObject(course, this.courseVo);
                courseJson = JsonUtils.toJson(course);

                if (courseVoJson != null) {
                    this.courseService.update(courseJson,
                        result -> this.proceedEditResult((ResultInfo) result));
                } else {
                    this.courseService.save(courseJson,
                        result -> this.proceedEditResult((ResultInfo) result));
                }
            } catch (IOException e) {
                e.printStackTrace();
                this.activity.runOnUiThread(
                    () -> PromptUtil.showToast(this.activity, e.getMessage()));
            }
        } else {
            PromptUtil.showToast(this.activity, ResultInfoConst.INVALID_PARAMETER);
        }
    }

    @SuppressLint("SimpleDateFormat")
    private void initVc() {
        String uniUserJson;
        UniUser uniUser;
        String courseVoJson = this.activity.getIntent().getStringExtra(CourseVoConst.NAME);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        try {
            uniUserJson = PreferenceUtil.getString(
                this.activity, UniUserConst.NAME, "");
            uniUser = JsonUtils.fromJson(Base64Utils.decode(uniUserJson), UniUser.class);

            if (courseVoJson != null) {
                this.courseVo = JsonUtils.fromJson(courseVoJson, CourseVo.class);
                this.courseVo.getTeacher().setId(uniUser.getId());
            } else {
                this.courseVo = new CourseVo();
                this.courseVo.setTeacher(new Teacher());
                this.courseVo.getTeacher().setId(uniUser.getId());
                this.courseVo.setName("");
                this.courseVo.setDescription("");
                this.courseVo.setKeywords("");
                this.courseVo.setStartTime(sdf.format(new Date()));
                this.courseVo.setEndTime(sdf.format(new Date()));
                this.courseVo.setClassroom(new Classroom());
                this.courseVo.getClassroom().setId(0);
                this.courseVo.setDayOfWeek(1);
                this.courseVo.setClassOfDay(1);
            }
        } catch (IOException e) {
            e.printStackTrace();
            this.activity.runOnUiThread(
                () -> PromptUtil.showToast(this.activity, e.getMessage()));
        }

        this.fetchClassroomList();

        this.notifyChange();
    }

    private void fetchClassroomList() {
        this.classroomService.findAll(
            result -> this.proceedFetchClassroomResult((ResultInfo) result));
    }

    private void proceedEditResult(ResultInfo resultInfo) {
        this.activity.runOnUiThread(
            () -> PromptUtil.showToast(this.activity, resultInfo.getResultMsg()));

        if (resultInfo.getSuccess()) {
            this.activity.finish();
        }

        this.notifyChange();
    }

    private void proceedFetchClassroomResult(ResultInfo resultInfo) {
        try {
            if (resultInfo.getSuccess()) {
                String classroomListJson = (String) resultInfo.getResultData();

                this.classroomList = JsonUtils.fromJson(classroomListJson,
                    new TypeReference<List<Classroom>>() {});
            } else {
                this.activity.runOnUiThread(
                    () -> PromptUtil.showToast(this.activity, resultInfo.getResultMsg()));
            }
        } catch (IOException e) {
            e.printStackTrace();
            this.activity.runOnUiThread(
                () -> PromptUtil.showToast(this.activity, e.getMessage()));
        }

        this.updateSpinnerList();
    }

    @SuppressLint("DefaultLocale")
    private void updateSpinnerList() {
        ArrayAdapter<String> spinnerAdapter;
        List<String> classroomData = new ArrayList<>();
        List<String> dayOfWeekData = new ArrayList<>();
        List<String> classOfDayData = new ArrayList<>();

        // 教室列表
        if (this.classroomList != null) {
            for (Classroom classroom : this.classroomList) {
                classroomData.add(String.format("%d-%s-%s", classroom.getId(),
                    classroom.getBuilding(), classroom.getRoom()));
            }
        }

        // 星期列表
        dayOfWeekData.addAll(Arrays.asList(CourseConfig.dayOfWeekList));

        // 上课节数列表
        for (int i = 1; i <= 4; i++) {
            classOfDayData.add(String.format("第%d, %d节课", (i * 2 - 1), i * 2));
        }

        // 教室
        spinnerAdapter = new ArrayAdapter<>(this.activity,
            android.R.layout.simple_spinner_item, classroomData);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        this.spClassroom.setAdapter(spinnerAdapter);
        this.spClassroom.setOnItemSelectedListener(new OnItemSelectedListener(
            result -> this.courseVo.setClassroom(this.classroomList.get((Integer) result))));

        // 设置当前选中教室
        if (this.classroomList != null) {
            for (int i = 0; i < this.classroomList.size(); i++) {
                if (this.courseVo.getClassroom().getId()
                    .equals(this.classroomList.get(i).getId())) {
                    this.spClassroom.setSelection(i);
                    break;
                }
            }
        }

        // 星期几
        spinnerAdapter = new ArrayAdapter<>(this.activity,
            android.R.layout.simple_spinner_item, dayOfWeekData);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        this.spDayOfWeek.setAdapter(spinnerAdapter);
        this.spDayOfWeek.setOnItemSelectedListener(new OnItemSelectedListener(
            result -> this.courseVo.setDayOfWeek((Integer) result + 1)));
        this.spDayOfWeek.setSelection(this.courseVo.getDayOfWeek() - 1);

        // 第几节课
        spinnerAdapter = new ArrayAdapter<>(this.activity,
            android.R.layout.simple_spinner_item, classOfDayData);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        this.spClassOfDay.setAdapter(spinnerAdapter);
        this.spClassOfDay.setOnItemSelectedListener(new OnItemSelectedListener(
            result -> this.courseVo.setClassOfDay((Integer) result + 1)));
        this.spClassOfDay.setSelection(this.courseVo.getClassOfDay() - 1);
    }

    public CourseVo getCourseVo() {
        return this.courseVo;
    }

    public void setCourseVo(CourseVo courseVo) {
        this.courseVo = courseVo;
    }

    private class OnItemSelectedListener implements AdapterView.OnItemSelectedListener {
        private ResultCallback callback;

        public OnItemSelectedListener(ResultCallback callback) {
            this.callback = callback;
        }

        @Override
        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
            this.callback.onResult(position);
        }

        @Override
        public void onNothingSelected(AdapterView<?> parent) {
            this.callback.onResult(0);
        }
    }
}
