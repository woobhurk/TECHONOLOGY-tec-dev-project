package com.tyfanch.electivehelper.ui;


import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.tyfanch.electivehelper.R;
import com.tyfanch.electivehelper.databinding.FragReplyListBinding;
import com.tyfanch.electivehelper.view.vc.ReplyListVc;

public class ReplyListFrag extends Fragment {
    public static final String TAG = "ReplyListFrag";

    private FragReplyListBinding replyListBinding;

    public ReplyListFrag() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
        Bundle savedInstanceState) {
        this.replyListBinding = DataBindingUtil.inflate(
            inflater, R.layout.frag_reply_list, container, false);

        return this.replyListBinding.getRoot();
    }

    @Override
    public void onStart() {
        super.onStart();

        ReplyListVc replyListVc;
        RecyclerView rvReplyList = this.replyListBinding.rvReplyList;

        rvReplyList.setLayoutManager(new LinearLayoutManager(this.getActivity()));
        replyListVc = new ReplyListVc(this.getActivity(), this.getFragmentManager(),
            rvReplyList);
        this.replyListBinding.setReplyListVc(replyListVc);

        //if (this.getActivity() != null) {
        //    this.getActivity().setTitle(R.string.course_list);
        //}
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);

        if (isVisibleToUser && this.getActivity() != null) {
            this.getActivity().setTitle(R.string.reply_list);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG, TAG + " Destroyed");
    }
}
