package com.tyfanch.electivehelper.view.vc;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.view.View;

import androidx.databinding.BaseObservable;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;

import com.fasterxml.jackson.core.type.TypeReference;
import com.tyfanch.electivehelper.bean.Reply;
import com.tyfanch.electivehelper.bean.User;
import com.tyfanch.electivehelper.bean.UserConst;
import com.tyfanch.electivehelper.service.ReplyService;
import com.tyfanch.electivehelper.service.ReplyServiceImpl;
import com.tyfanch.electivehelper.ui.MsgContentListActivity;
import com.tyfanch.electivehelper.ui.adapters.ReplyRvAdapter;
import com.tyfanch.electivehelper.ui_utils.PreferenceUtil;
import com.tyfanch.electivehelper.ui_utils.PromptUtil;
import com.tyfanch.electivehelper.utils.Base64Utils;
import com.tyfanch.electivehelper.utils.JsonUtils;
import com.tyfanch.electivehelper.view.vo.CourseVo;
import com.tyfanch.electivehelper.view.vo.CourseVoConst;
import com.tyfanch.electivehelper.view.vo.ReplyVo;
import com.tyfanch.electivehelper.view.vo.ResultInfo;
import com.tyfanch.electivehelper.view.vo.ResultInfoConst;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class ReplyListVc extends BaseObservable {
    private FragmentActivity activity;
    private FragmentManager fragmentManager;
    private RecyclerView rvReplyList;
    private ReplyService replyService = new ReplyServiceImpl();
    private CourseVo courseVo;
    private Reply newReply = new Reply();
    private ReplyVo innerReplyVo;
    private boolean showReplyList;

    public ReplyListVc(FragmentActivity activity, FragmentManager fragmentManager,
        RecyclerView rvReplyList) {
        this.activity = activity;
        this.fragmentManager = fragmentManager;
        this.rvReplyList = rvReplyList;

        this.initVc();
    }

    public void onReplyClick(View view, ReplyVo replyVo) {
        this.innerReplyVo = (this.innerReplyVo == null) ? replyVo : null;
        this.notifyChange();
    }

    public void onReplyDeleteClick(View view, ReplyVo replyVo) {
        Reply tmpReply = new Reply();
        String tmpRelyJson;

        try {
            tmpReply.setId(replyVo.getId());
            tmpRelyJson = JsonUtils.toJson(tmpReply);
            PromptUtil.showDialog(this.activity, "删除",
                "确认删除这条评论吗？",
                "确认", "取消",
                () -> this.replyService.deleteById(tmpRelyJson,
                    result -> this.proceedDeleteReplyResult((ResultInfo) result)));
        } catch (IOException e) {
            e.printStackTrace();
            PromptUtil.showToast(this.activity, e.getMessage());
        }
    }

    public void onSenderClick(View view, User sender) {
        Intent intent = new Intent(this.activity, MsgContentListActivity.class);
        String currentUserJson = PreferenceUtil.getString(
            this.activity, UserConst.NAME, "");
        User currentUser;

        try {
            currentUser = JsonUtils.fromJson(Base64Utils.decode(currentUserJson), User.class);

            if (!currentUser.getId().equals(sender.getId())) {
                intent.putExtra(UserConst.NAME, JsonUtils.toJson(sender));
                this.activity.startActivityForResult(intent, MsgContentListActivity.ID);
            }
        } catch (IOException e) {
            e.printStackTrace();
            PromptUtil.showToast(this.activity, e.getMessage());
        }
    }

    @SuppressLint("SimpleDateFormat")
    public void onSendReplyClick(View view) {
        String userJson = PreferenceUtil.getString(this.activity, UserConst.NAME, "");
        User user;
        String newReplyJson;
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        if (!this.newReply.getReplyText().isEmpty()) {
            try {
                user = JsonUtils.fromJson(Base64Utils.decode(userJson), User.class);
                this.newReply.setSenderId(user.getId());
                this.newReply.setCourseId(this.courseVo.getId());

                if (this.innerReplyVo != null) {
                    this.newReply.setReplyTo(this.innerReplyVo.getId());
                } else {
                    this.newReply.setReplyTo(null);
                }

                this.newReply.setReplyTime(sdf.format(new Date()));
                newReplyJson = JsonUtils.toJson(this.newReply);
                this.replyService.save(newReplyJson,
                    result -> this.proceedSendReplyResult((ResultInfo) result));
            } catch (IOException e) {
                e.printStackTrace();
                this.activity.runOnUiThread(
                    () -> PromptUtil.showToast(this.activity, e.getMessage()));
            }
        } else {
            PromptUtil.showToast(this.activity, ResultInfoConst.INVALID_PARAMETER);
        }
    }

    private void initVc() {
        this.fetchReplyList();
    }

    private void fetchReplyList() {
        String courseVoJson;
        Reply tmpReply = new Reply();
        String tmpReplyJson;

        try {
            courseVoJson = this.activity.getIntent().getStringExtra(CourseVoConst.NAME);
            this.courseVo = JsonUtils.fromJson(courseVoJson, CourseVo.class);
            tmpReply.setCourseId(this.courseVo.getId());
            tmpReplyJson = JsonUtils.toJson(tmpReply);
            this.replyService.findByCourse(tmpReplyJson,
                result -> this.proceedFetchReplyResult((ResultInfo) result));
        } catch (IOException e) {
            e.printStackTrace();
            this.activity.runOnUiThread(
                () -> PromptUtil.showToast(this.activity, e.getMessage()));
        }
    }

    private void proceedFetchReplyResult(ResultInfo resultInfo) {
        try {
            if (resultInfo.getSuccess()) {
                List<ReplyVo> replyVoList;
                String replyVoListJson = (String) resultInfo.getResultData();

                replyVoList = JsonUtils.fromJson(replyVoListJson,
                    new TypeReference<List<ReplyVo>>() {});
                this.updateReplyList(replyVoList);
            } else {
                this.activity.runOnUiThread(
                    () -> PromptUtil.showToast(this.activity, resultInfo.getResultMsg()));
            }
        } catch (IOException e) {
            e.printStackTrace();
            this.activity.runOnUiThread(
                () -> PromptUtil.showToast(this.activity, e.getMessage()));
        }
    }

    private void proceedDeleteReplyResult(ResultInfo resultInfo) {
        if (resultInfo.getSuccess()) {
            //this.fetchReplyList();
            if (this.rvReplyList.getAdapter() != null) {
                this.activity.runOnUiThread(() -> {
                    //this.rvReplyList.getAdapter().notifyItemRemoved(position);
                    this.fetchReplyList();
                    PromptUtil.showToast(this.activity, "已删除");
                });
            }
        } else {
            this.activity.runOnUiThread(
                () -> PromptUtil.showToast(this.activity, resultInfo.getResultMsg()));
        }
    }

    private void proceedSendReplyResult(ResultInfo resultInfo) {
        if (resultInfo.getSuccess()) {
            this.newReply = new Reply();
            this.innerReplyVo = null;
            this.fetchReplyList();
        } else {
            this.activity.runOnUiThread(
                () -> PromptUtil.showToast(this.activity, resultInfo.getResultMsg()));
        }
    }

    private void updateReplyList(List<ReplyVo> replyVoList) {
        ReplyRvAdapter replyRvAdapter;
        int scrollY = this.rvReplyList.getScrollY();

        if (this.rvReplyList.getAdapter() != null) {
            replyRvAdapter = (ReplyRvAdapter) this.rvReplyList.getAdapter();
            replyRvAdapter.setReplyVoList(replyVoList);
            this.activity.runOnUiThread(replyRvAdapter::notifyDataSetChanged);
        } else {
            replyRvAdapter = new ReplyRvAdapter(this.activity, this, replyVoList);
            this.activity.runOnUiThread(
                () -> this.rvReplyList.setAdapter(replyRvAdapter));
        }

        this.activity.runOnUiThread(
            () -> this.rvReplyList.scrollTo(0, scrollY));
        this.showReplyList = true;
        this.notifyChange();
    }

    public CourseVo getCourseVo() {
        return this.courseVo;
    }

    public void setCourseVo(CourseVo courseVo) {
        this.courseVo = courseVo;
    }

    public Reply getNewReply() {
        return this.newReply;
    }

    public void setNewReply(Reply newReply) {
        this.newReply = newReply;
    }

    public ReplyVo getInnerReplyVo() {
        return this.innerReplyVo;
    }

    public void setInnerReplyVo(ReplyVo innerReplyVo) {
        this.innerReplyVo = innerReplyVo;
    }

    public boolean isShowReplyList() {
        return this.showReplyList;
    }

    public void setShowReplyList(boolean showReplyList) {
        this.showReplyList = showReplyList;
    }
}
