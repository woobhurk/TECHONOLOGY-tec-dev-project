package com.tyfanch.electivehelper.ui;


import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.tyfanch.electivehelper.R;
import com.tyfanch.electivehelper.databinding.FragOnlineCourseListBinding;
import com.tyfanch.electivehelper.view.vc.OnlineCourseListVc;

public class OnlineCourseListFrag extends Fragment {
    public static final String TAG = "OnlineCourseListFrag";

    private FragOnlineCourseListBinding onlineCourseListBinding;

    public OnlineCourseListFrag() {}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
        Bundle savedInstanceState) {
        this.onlineCourseListBinding = DataBindingUtil.inflate(
            inflater, R.layout.frag_online_course_list, container, false);

        return this.onlineCourseListBinding.getRoot();
    }

    @Override
    public void onStart() {
        super.onStart();

        OnlineCourseListVc onlineCourseListVc;
        RecyclerView rvOnlineCourseList = this.onlineCourseListBinding.rvOnlineCourseList;

        rvOnlineCourseList.setLayoutManager(new LinearLayoutManager(this.getContext()));
        onlineCourseListVc = new OnlineCourseListVc(this.getActivity(), this.getFragmentManager(),
            rvOnlineCourseList);
        this.onlineCourseListBinding.setOnlineCourseListVc(onlineCourseListVc);

        //if (this.getActivity() != null) {
        //    this.getActivity().setTitle(R.string.recommend_course);
        //}
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);

        if (isVisibleToUser && this.getActivity() != null) {
            this.getActivity().setTitle(R.string.online_course);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG, TAG + " Destroyed");
    }
}
