package com.tyfanch.electivehelper.service;

import com.tyfanch.electivehelper.interfaces.ResultCallback;

public interface OnlineCourseService {
    void findByInterest(String uniUserJson, ResultCallback callback);

    //void findAll(ResultCallback callback);

    //void findByKeywords(String[] keywords, ResultCallback callback);
}
