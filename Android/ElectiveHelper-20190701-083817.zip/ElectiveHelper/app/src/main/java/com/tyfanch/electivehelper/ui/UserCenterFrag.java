package com.tyfanch.electivehelper.ui;


import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;

import com.tyfanch.electivehelper.R;
import com.tyfanch.electivehelper.databinding.FragUserCenterBinding;
import com.tyfanch.electivehelper.view.vc.AccountCenterVc;

public class UserCenterFrag extends Fragment {
    public static final String TAG = "UserCenterFrag";

    private FragUserCenterBinding userCenterBinding;

    public UserCenterFrag() {}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
        Bundle savedInstanceState) {
        this.userCenterBinding = DataBindingUtil.inflate(
            inflater, R.layout.frag_user_center, container, false);

        return this.userCenterBinding.getRoot();
    }

    @Override
    public void onStart() {
        super.onStart();

        AccountCenterVc accountCenterVc;

        accountCenterVc = new AccountCenterVc(this.getActivity(),
            this.getFragmentManager());
        this.userCenterBinding.setAccountCenterVc(accountCenterVc);

        //if (this.getActivity() != null) {
        //    this.getActivity().setTitle(R.string.user_center);
        //}
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);

        if (isVisibleToUser && this.getActivity() != null) {
            this.getActivity().setTitle(R.string.user_center);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG, TAG + " Destroyed");
    }
}
