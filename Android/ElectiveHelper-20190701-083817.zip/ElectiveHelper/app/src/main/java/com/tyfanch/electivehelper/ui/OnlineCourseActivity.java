package com.tyfanch.electivehelper.ui;

import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.tyfanch.electivehelper.R;

public class OnlineCourseActivity extends AppCompatActivity {
    public static final int ID = 0x000007;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        this.setContentView(R.layout.activity_common);
    }

    @Override
    protected void onStart() {
        super.onStart();

        FragmentManager fragmentManager = this.getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        OnlineCourseFrag onlineCourseFrag;

        for (Fragment fragment : fragmentManager.getFragments()) {
            fragmentTransaction.remove(fragment);
        }

        onlineCourseFrag = new OnlineCourseFrag();
        fragmentTransaction
            .add(R.id.layCommon, onlineCourseFrag, OnlineCourseFrag.TAG)
            .commit();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        Log.d("----", "AccountActivity Destroyed");
    }
}
