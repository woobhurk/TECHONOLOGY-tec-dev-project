package com.tyfanch.electivehelper.service;

import android.content.Context;

import com.tyfanch.electivehelper.interfaces.ResultCallback;

public interface AccountService {
    void login(String userVoJson, ResultCallback callback);

    void loginByIdAndPassword(String userJson, ResultCallback callback);

    void reg(String userVoJson, ResultCallback callback);

    void update(String userJson, ResultCallback callback);

    void isUsernameExist(String userJson, ResultCallback callback);

    void isEmailExist(String userJson, ResultCallback callback);

    void hasLogin(String userJson, ResultCallback callback);

    void logout(Context ctx, ResultCallback callback);
}
