package com.tyfanch.electivehelper.view.vc;

import androidx.databinding.BaseObservable;

public class ToastVc extends BaseObservable {
    private boolean success;
    private String title;
    private String msg;

    public ToastVc(boolean success, String title, String msg) {
        this.success = success;
        this.title = title;
        this.msg = msg;

        this.initVc();
    }

    private void initVc() {
        this.notifyChange();
    }

    public boolean isSuccess() {
        return this.success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public String getTitle() {
        return this.title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getMsg() {
        return this.msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}
