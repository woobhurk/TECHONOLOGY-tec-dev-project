package com.tyfanch.electivehelper.ui.adapters;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.tyfanch.electivehelper.R;
import com.tyfanch.electivehelper.databinding.ItemMsgContentBinding;
import com.tyfanch.electivehelper.view.vc.MsgContentItemVc;
import com.tyfanch.electivehelper.view.vc.MsgContentListVc;
import com.tyfanch.electivehelper.view.vo.MsgVo;

import java.util.List;

public class MsgContentRvAdapter
    extends RecyclerView.Adapter<MsgContentRvAdapter.MsgContentRvHolder> {
    private FragmentActivity activity;
    private MsgContentListVc msgContentListVc;
    private List<MsgVo> msgVoList;

    public MsgContentRvAdapter(FragmentActivity activity, MsgContentListVc msgContentListVc,
        List<MsgVo> msgVoList) {
        this.activity = activity;
        this.msgContentListVc = msgContentListVc;
        this.msgVoList = msgVoList;
    }

    @Override
    public MsgContentRvHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(this.activity);
        ItemMsgContentBinding msgContentBinding = DataBindingUtil.inflate(
            layoutInflater, R.layout.item_msg_content, parent, false);

        return new MsgContentRvHolder(msgContentBinding);
    }

    @Override
    public void onBindViewHolder(MsgContentRvHolder holder, int position) {
        MsgContentItemVc msgContentItemVc = new MsgContentItemVc(
            this.activity, this.msgVoList.get(position));

        holder.getMsgContentBinding().setMsgContentListVc(this.msgContentListVc);
        holder.getMsgContentBinding().setMsgContentItemVc(msgContentItemVc);
    }

    @Override
    public int getItemCount() {
        return this.msgVoList.size();
    }

    public List<MsgVo> getMsgVoList() {
        return this.msgVoList;
    }

    public void setMsgVoList(List<MsgVo> msgVoList) {
        this.msgVoList = msgVoList;
    }

    public static class MsgContentRvHolder extends RecyclerView.ViewHolder {
        private ItemMsgContentBinding msgContentBinding;

        public MsgContentRvHolder(ItemMsgContentBinding msgContentBinding) {
            super(msgContentBinding.getRoot());

            this.msgContentBinding = msgContentBinding;
        }

        public ItemMsgContentBinding getMsgContentBinding() {
            return this.msgContentBinding;
        }

        public void setMsgContentBinding(
            ItemMsgContentBinding msgContentBinding) {
            this.msgContentBinding = msgContentBinding;
        }
    }
}
