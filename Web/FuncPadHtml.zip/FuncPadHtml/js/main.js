// =========
// TODO List


// ===========
// Constants
KEY_LEFT = 37;
KEY_UP = 38;
KEY_RIGHT = 39;
KEY_DOWN = 40;
KEY_A = (new CharUtil()).charToAsc("A");
KEY_W = (new CharUtil()).charToAsc("W");
KEY_D = (new CharUtil()).charToAsc("D");
KEY_S = (new CharUtil()).charToAsc("S");
KEY_ZOOMIN = (new CharUtil()).charToAsc("9");
KEY_ZOOMOUT = (new CharUtil()).charToAsc("0");
FUNC_WIDTH = 1;
DOODLE_WIDTH = 5;
GRID_SIZE = 80;
GRID_MAX_SIZE = 500;
GRID_MIN_SIZE = 15;
COLOR_CANVPAD = 0x202020;
COLOR_COORD = 0xe0e0e0;
COLOR_GRID = 0x404040;
COLOR_MOUSE_COORD = 0x40f090;
COLOR_NORMALFUNC = 0x2080f0;
COLOR_PARAMETERFUNC = 0xf08040;
COLOR_DOODLE = 0xe0e0e0;
PRE_EVAL_STR = "abs = Math.abs;" +
    "acos = Math.acos;" +
    "acosh = Math.acosh;" +
    "asin = Math.asin;" +
    "asinh = Math.asinh;" +
    "atan = Math.atan;" +
    "atan2 = Math.atan2;" +
    "atanh = Math.atanh;" +
    "cos = Math.cos;" +
    "cosh = Math.cosh;" +
    "exp = Math.exp;" +
    "ln = Math.log;" +
    "log10 = Math.log10;" +
    "pow = Math.pow;" +
    "random = Math.random;" +
    "sin = Math.sin;" +
    "sinh = Math.sinh;" +
    "sqrt = Math.sqrt;" +
    "tan = Math.tan;" +
    "tanh = Math.tanh;" +
    "PI = Math.PI;" +
    "E = Math.E;\n";


// =================
// Global Variable
var inpCanvPadColor;
var inpCoordColor;
var inpGridColor;
var inpMouseCoordColor;
var inpShowCoord;
var inpShowGrid;
var inpShowMouseCoord;

var selDoodWidth;
var inpDoodColor;
var btnDoodMode;
var btnDoodUndo;

var inpNorEvalStrNew;
var inpNorScopeStartNew;
var inpNorScopeEndNew;
var selNorWidthNew;
var inpNorColorNew;
var btnNorDraw;
var inpNorEvalParameterNew;
var inpNorEvalResultNew;
var btnNorEvalNew;
var selNorFuncs;
var inpNorEvalStr;
var inpNorScopeStart;
var inpNorScopeEnd;
var selNorWidth;
var inpNorColor;
var btnNorUpdate;
var btnNorDel;
var inpNorEvalParameter;
var inpNorEvalResult;
var btnNorEval;

var inpParaEvalStrXNew;
var inpParaEvalStrYNew;
var inpParaScopeStartNew;
var inpParaScopeEndNew;
var inpParaDeltaNew;
var selParaWidthNew;
var inpParaColorNew;
var btnParaDraw;
var inpParaEvalParameterNew;
var inpParaEvalResultNew;
var btnParaEvalNew;
var selParaFuncs;
var inpParaEvalStrX;
var inpParaEvalStrY;
var inpParaScopeStart;
var inpParaScopeEnd;
var inpParaDelta;
var selParaWidth;
var inpParaColor;
var btnParaUpdate;
var btnParaDel;
var inpParaEvalParameter;
var inpParaEvalResult;
var btnParaEval;

var inpGridResizer;
var btnGridResizerMinus;
var btnGridResizerPlus;

var canvPadProp;
var canvPadOperate = new CanvPadOperate();
var mouseProp = new MouseProp();
var normalFuncs = [
    new NormalFunc("tanh(x)", "-PI", "3 * E", 1, COLOR_NORMALFUNC),
    new NormalFunc("ln(x) + sin(x)", "-3 * PI", "pow(3.1, 2)", 3, 0xb0b0b0)
];
var parameterFuncs = [
    new ParameterFunc("sin(t)", "cos(t)", "-(PI + 0.1)", "PI + 0.1", "0.02", 1, COLOR_PARAMETERFUNC),
    new ParameterFunc("2*sin(t)-sin(2*t)", "2*cos(t)-cos(2*t)", "-3.2",
                        "3.2", "sqrt(0.0004)", 4, 0xe03040)
];
var funcOperate = new FuncOperate();
var doodles = [];
var doodleOperate = new DoodleOperate();
var htmlOperate = new HtmlOperate();
var eventOperate = new EventOperate();
var converter = new Converter();
var colorUtil = new ColorUtil();
var charUtil = new CharUtil();
var util = new Util();

// =======================================
// Main
window.onload = eventOperate.windowOnLoad;
window.addEventListener("keydown", eventOperate.addKeyPressEvent, true);


// ============================================
// Class
// 存放Canvas所有信息
function CanvPadProp(canvPad, canvPadContext) {
    this.canvPad = canvPad;
    this.canvPadContext = canvPadContext;
    this.left = canvPad.offsetLeft;
    this.top = canvPad.offsetTop;
    this.width = canvPad.offsetWidth;
    this.height = canvPad.offsetHeight;
    this.zeroPoint = new Point(Math.floor(this.width / 2), Math.floor(this.height / 2));
    this.gridSize = GRID_SIZE;
    this.canvPadColor = COLOR_CANVPAD;
    this.coordColor = COLOR_COORD;
    this.gridColor = COLOR_GRID;
    this.mouseCoordColor = COLOR_MOUSE_COORD;
    this.showCoord = true;
    this.showGrid = true;
    this.showMouseCoord = true;
    this.doodleMode = false;

    // 判断线段是否在画布左侧，以下类似
    // @parameter pointStart 线段起点
    // @parameter pointEnd 线段终点
    // @return 是否全部在左侧
    this.isLineLeft = function (pointStart, pointEnd) {
        console.log("Left, " + pointStart.x + ", " + pointEnd.x + ", " + -this.zeroPoint.x);
        return (pointStart.x < -this.zeroPoint.x && pointEnd.x < -this.zeroPoint.x);
    };

    this.isLineRight = function (pointStart, pointEnd) {
        console.log("Right, " + pointStart.x + ", " + pointEnd.x + ", " + (-this.zeroPoint.x + this.width));
        return (pointStart.x > (-this.zeroPoint.x + this.width) && pointEnd.x > (-this.zeroPoint.x + this.width));
    };

    this.isLineTop = function (pointStart, pointEnd) {
        console.log("Top, " + pointStart.y + ", " + pointEnd.y + ", " + -this.zeroPoint.y);
        return (pointStart.y < -this.zeroPoint.y && pointEnd.y < -this.zeroPoint.y);
    };

    this.isLineBottom = function (pointStart, pointEnd) {
        console.log("Bottom, " + pointStart.y + ", " + pointEnd.y + ", " + (-this.zeroPoint.y + this.height));
        return (pointStart.y > (-this.zeroPoint.y + this.height) && pointEnd.y > (-this.zeroPoint.y + this.height));
    };

    // 判断线段是否和画布有交点
    // @parameter pointStart 线段起点
    // @parameter pointEnd 线段终点
    // @return 是否有交点
    this.isLineIn = function (pointStart, pointEnd) {
        return (pointStart.x >= -this.zeroPoint.x && pointStart.x <= (-this.zeroPoint.x + this.width) &&
                pointStart.y >= -this.zeroPoint.y && pointStart.y <= (-this.zeroPoint.y + this.height) ||
                pointEnd.x >= -this.zeroPoint.x && pointEnd.x <= (-this.zeroPoint.x + this.width) &&
                pointEnd.y >= -this.zeroPoint.y && pointEnd.y <= (-this.zeroPoint.y + this.height));
    };

    // 判断是否是焦点，用来判断获取到鼠标键盘事件时是否响应
    // @return 画布是否有焦点
    this.isFocused = function () {
        var body = document.getElementById("body");

        return (body == document.activeElement);
    };
}

// Canvas操作类
function CanvPadOperate() {
    // 移动Canvas
    // @parameter deltaX 横向移动量
    // @parameter deltaY 纵向移动量
    this.translate = function (deltaX, deltaY) {
        canvPadProp.zeroPoint.x += deltaX;
        canvPadProp.zeroPoint.y += deltaY;
        canvPadProp.canvPadContext.translate(deltaX, deltaY);
        this.validate();
    };

    // 调整网格大小
    // @parameter newGridSize 新的网格大小
    this.resize = function (newGridSize) {
        canvPadProp.gridSize = newGridSize;

        if (canvPadProp.gridSize > GRID_MAX_SIZE) {
            canvPadProp.gridSize = GRID_MAX_SIZE;
        } else if (canvPadProp.gridSize < GRID_MIN_SIZE) {
            canvPadProp.gridSize = GRID_MIN_SIZE;
        }

        inpGridResizer.value = canvPadProp.gridSize;
        this.validate();
    };

    // 更新设置
    this.updateSetting = function () {
        canvPadProp.canvPadColor = colorUtil.colorToInteger(inpCanvPadColor.value);
        canvPadProp.coordColor = colorUtil.colorToInteger(inpCoordColor.value);
        canvPadProp.gridColor = colorUtil.colorToInteger(inpGridColor.value);
        canvPadProp.mouseCoordColor = colorUtil.colorToInteger(inpMouseCoordColor.value);
        canvPadProp.showCoord = inpShowCoord.checked;
        canvPadProp.showGrid = inpShowGrid.checked;
        canvPadProp.showMouseCoord = inpShowMouseCoord.checked;
        this.validate();
    };

    // 重画
    this.validate = function () {
        this.drawCanvPad();
    };

    // 画出所有Canvas的元素
    this.drawCanvPad = function () {
        this.clearCanvPad();
        this.drawGrid();
        this.drawFuncs(normalFuncs);
        this.drawFuncs(parameterFuncs);
        this.drawCoord();
        this.drawDoodleMode();
        this.drawMouseCoord();
        this.drawDoodles();
    };

    // 清空Canvas
    this.clearCanvPad = function () {
        var canvPadContext = canvPadProp.canvPadContext;

        canvPadContext.beginPath();
        canvPadContext.fillStyle = colorUtil.integerToColor(canvPadProp.canvPadColor);
        canvPadContext.fillRect(-canvPadProp.zeroPoint.x, -canvPadProp.zeroPoint.y,
                                canvPadProp.width, canvPadProp.height);
    };

    // 画出函数
    // @parameter funcs 存放要画出函数的数组
    this.drawFuncs = function (funcs) {
        var canvPadContext = canvPadProp.canvPadContext;

        for (var funcIndex = 0; funcIndex < funcs.length; funcIndex++) {
            var needMove = true;

            funcs[funcIndex].generatePoints();
            canvPadContext.beginPath();
            canvPadContext.lineWidth = funcs[funcIndex].width;
            canvPadContext.lineCap = "round";
            canvPadContext.lineJoin = canvPadContext.lineCap;
            canvPadContext.strokeStyle = colorUtil.integerToColor(funcs[funcIndex].color);

            for (var pointIndex = funcs[funcIndex].firstPointIndex; pointIndex < funcs[funcIndex].points.length; pointIndex++) {
                var curPoint = funcs[funcIndex].points[pointIndex];

                // 如果当前点有效的话就让接下来的点接着这个点继续画，否则接下来的点要另起一条路径
                if (curPoint.isValid) {
                    // 判断是接着上一个点画还是另起路径
                    if (needMove) {
                        canvPadContext.stroke();
                        canvPadContext.moveTo(curPoint.x, curPoint.y);
                        needMove = false;
                    } else {
                        canvPadContext.lineTo(curPoint.x, curPoint.y);
                    }
                } else {
                    // 无效点，不画出，并且让接下来的点另起路径
                    needMove = true;
                }
            }

            canvPadContext.stroke();
        }
    };

    // 画出网格
    this.drawGrid = function () {
        var canvPadContext = canvPadProp.canvPadContext;
        var gridXStart = (Math.floor(-canvPadProp.zeroPoint.x / canvPadProp.gridSize) - 1) * canvPadProp.gridSize;
        var gridXEnd = gridXStart + (Math.floor(canvPadProp.width / canvPadProp.gridSize) + 3) * canvPadProp.gridSize;
        var gridYStart = (Math.floor(-canvPadProp.zeroPoint.y / canvPadProp.gridSize) - 1) * canvPadProp.gridSize;
        var gridYEnd = gridYStart + (Math.floor(canvPadProp.height / canvPadProp.gridSize) + 3) * canvPadProp.gridSize;

        if (canvPadProp.showGrid){
            canvPadContext.beginPath();
            canvPadContext.lineWidth = 1;
            canvPadContext.strokeStyle = colorUtil.integerToColor(canvPadProp.gridColor);

            // 竖线
            for (var gridX = gridXStart; gridX < gridXEnd; gridX += canvPadProp.gridSize) {
                canvPadContext.moveTo(gridX, gridYStart);
                canvPadContext.lineTo(gridX, gridYEnd);
                canvPadContext.stroke();
            }

            // 横线
            for (var gridY = gridYStart; gridY < gridYEnd; gridY += canvPadProp.gridSize) {
                canvPadContext.moveTo(gridXStart, gridY);
                canvPadContext.lineTo(gridXEnd, gridY);
                canvPadContext.stroke();
            }
        }
    };

    // 画出坐标系
    this.drawCoord = function () {
        var canvPadContext = canvPadProp.canvPadContext;
        var gridXStart = (Math.floor(-canvPadProp.zeroPoint.x / canvPadProp.gridSize) - 1) * canvPadProp.gridSize;
        var gridXEnd = gridXStart + (Math.floor(canvPadProp.width / canvPadProp.gridSize) + 3) * canvPadProp.gridSize;
        var gridYStart = (Math.floor(-canvPadProp.zeroPoint.y / canvPadProp.gridSize) - 1) * canvPadProp.gridSize;
        var gridYEnd = gridYStart + (Math.floor(canvPadProp.height / canvPadProp.gridSize) + 3) * canvPadProp.gridSize;

        if (canvPadProp.showCoord) {
            canvPadContext.beginPath();
            canvPadContext.lineWidth = 1;
            canvPadContext.strokeStyle = colorUtil.integerToColor(canvPadProp.coordColor);
            canvPadContext.font = "bold 12px Arial";
            canvPadContext.fillStyle = canvPadContext.strokeStyle;
            // X、Y坐标
            canvPadContext.moveTo(-canvPadProp.zeroPoint.x, 0);
            canvPadContext.lineTo(-canvPadProp.zeroPoint.x + canvPadProp.width, 0);
            canvPadContext.stroke();
            canvPadContext.moveTo(0, -canvPadProp.zeroPoint.y);
            canvPadContext.lineTo(0, -canvPadProp.zeroPoint.y + canvPadProp.height);
            canvPadContext.stroke();

            // X坐标上的数字
            for (var gridX = gridXStart; gridX < gridXEnd; gridX += canvPadProp.gridSize) {
                if (gridX != 0) {
                    // 坐标格指示
                    // canvPadContext.moveTo(gridX, -3);
                    // canvPadContext.lineTo(gridX, 0);
                    // canvPadContext.stroke();
                    // 坐标格数字
                    canvPadContext.fillText(converter.toCoordX(gridX).toString(), gridX - 4, 16);
                }
            }

            // Y坐标上的数字
            for (var gridY = gridYStart; gridY < gridYEnd; gridY += canvPadProp.gridSize) {
                if (gridY != 0) {
                    // 坐标格指示
                    // canvPadContext.moveTo(0, gridY);
                    // canvPadContext.lineTo(3, gridY);
                    // canvPadContext.stroke();
                    canvPadContext.fillText(converter.toCoordY(gridY).toString(), 6, gridY + 4);
                }
            }

            // 原点，特殊处理
            canvPadContext.fillText("O", 6, 16);
            // X坐标箭头
            canvPadContext.moveTo(-canvPadProp.zeroPoint.x + canvPadProp.width, 0);
            canvPadContext.lineTo(-canvPadProp.zeroPoint.x + canvPadProp.width - 12, -4);
            canvPadContext.lineTo(-canvPadProp.zeroPoint.x + canvPadProp.width - 12, 4);
            canvPadContext.fill();
            // Y坐标箭头
            canvPadContext.moveTo(0, -canvPadProp.zeroPoint.y);
            canvPadContext.lineTo(-4, -canvPadProp.zeroPoint.y + 12);
            canvPadContext.lineTo(4, -canvPadProp.zeroPoint.y + 12);
            canvPadContext.fill();
        }
    };

    // 画出涂鸦模式提示
    this.drawDoodleMode = function () {
        var canvPadContext = canvPadProp.canvPadContext;

        if (canvPadProp.doodleMode) {
            canvPadContext.beginPath();
            canvPadContext.lineWidth = 1;
            canvPadContext.strokeStyle = colorUtil.integerToColor(canvPadProp.coordColor);
            canvPadContext.fillStyle = canvPadContext.strokeStyle;
            canvPadContext.font = "bold 30px 微软雅黑";
            canvPadContext.fillText("涂鸦模式", -canvPadProp.zeroPoint.x + 40, -canvPadProp.zeroPoint.y + 60);
        }
    };

    // 画出鼠标坐标
    this.drawMouseCoord = function () {
        if (canvPadProp.showMouseCoord && mouseProp.curPos.isValid) {
            var canvPadContext = canvPadProp.canvPadContext;
            var mouseCoordX = -canvPadProp.zeroPoint.x + mouseProp.curPos.x;
            var mouseCoordY = -canvPadProp.zeroPoint.y + mouseProp.curPos.y;
            var coordX = converter.toCoordX(mouseCoordX);
            var coordY = converter.toCoordY(mouseCoordY);
            var coordXStr = coordX.toString().substr(0, 5);
            var coordYStr = coordY.toString().substr(0, 5);

            canvPadContext.beginPath();
            canvPadContext.lineWidth = 1;
            canvPadContext.strokeStyle = colorUtil.integerToColor(canvPadProp.mouseCoordColor);
            canvPadContext.moveTo(-canvPadProp.zeroPoint.x, mouseCoordY);
            canvPadContext.lineTo(-canvPadProp.zeroPoint.x + canvPadProp.width, mouseCoordY);
            canvPadContext.stroke();
            canvPadContext.moveTo(mouseCoordX, -canvPadProp.zeroPoint.y);
            canvPadContext.lineTo(mouseCoordX, -canvPadProp.zeroPoint.y + canvPadProp.height);
            canvPadContext.stroke();

            // 画出当前坐标点信息
            canvPadContext.font = "12px Arial";
            canvPadContext.fillStyle = canvPadContext.strokeStyle;
            canvPadContext.fillText("(" + coordXStr + ", " + coordYStr + ")", mouseCoordX + 5, mouseCoordY - 5);
        }
    };

    // 画出涂鸦
    this.drawDoodles = function () {
        var canvPadContext = canvPadProp.canvPadContext;

        for (var doodleIndex = 0; doodleIndex < doodles.length; doodleIndex++) {
            if (doodles[doodleIndex].coords.length == 0) {
                continue;
            }

            doodles[doodleIndex].generatePoints();
            canvPadContext.beginPath();
            canvPadContext.lineWidth = doodles[doodleIndex].width;
            canvPadContext.lineCap = "round";
            canvPadContext.lineJoin = canvPadContext.lineCap;
            canvPadContext.strokeStyle = colorUtil.integerToColor(doodles[doodleIndex].color);
            canvPadContext.moveTo(doodles[doodleIndex].points[0].x, doodles[doodleIndex].points[0].y);

            for (var pointIndex = 0; pointIndex < doodles[doodleIndex].points.length;
                    pointIndex++) {
                canvPadContext.lineTo(doodles[doodleIndex].points[pointIndex].x,
                                        doodles[doodleIndex].points[pointIndex].y);
            }

            canvPadContext.stroke();
        }
    };
}

// Canvas像素点信息
function Point(x, y) {
    this.x = Math.floor(x);
    this.y = Math.floor(y);
    this.isValid = true;
}

// 坐标系坐标点信息
function Coordinate(x, y) {
    this.x = x;
    this.y = y;
    this.isValid = true;
}

// 常规函数
function NormalFunc(evalStr, evalScopeStart, evalScopeEnd, width, color) {
    this.evalStr = evalStr;
    this.evalScopeStart = evalScopeStart;
    this.evalScopeEnd = evalScopeEnd;
    this.width = width;
    this.color = color;
    this.points = [];
    this.firstPointIndex = -1;

    // 计算并存储所有坐标值
    // @return 函数中是否有错误
    this.generatePoints = function () {
        var pointIndex = 0;
        var hasError = false;

        try {
            var pointXStart = converter.toPointX(util.evalEx(this.evalScopeStart));
            var pointXEnd = converter.toPointX(util.evalEx(this.evalScopeEnd));

            // 清空所有像素值，防止网格缩放之前的像素值仍存在数组中
            this.points.splice(0, this.points.length);
            // 重置第一个有效点下标
            this.firstPointIndex = -1;

            for (var pointX = pointXStart; pointX < pointXEnd; pointX++) {
                var coordX = converter.toCoordX(pointX);
                var coordY = util.evalEx(this.generateEvalStr(coordX));
                var pointY = converter.toPointY(coordY);

                // 如果这个点是有效的才要画出
                if (!isNaN(coordY) && isFinite(coordY)) {
                    this.points[pointIndex] = new Point(pointX, pointY);
                    this.points[pointIndex].isValid = true;
                    this.lastPointIndex = pointIndex;

                    // 将第一个有效点下标存起来
                    if (this.firstPointIndex == -1) {
                        this.firstPointIndex = pointIndex;
                    }
                } else {
                    this.points[pointIndex] = new Point(-canvPadProp.zeroPoint.x * 2, -canvPadProp.zeroPoint.y * 2);
                    this.points[pointIndex].isValid = false;
                }

                pointIndex++;
            }

            if (this.firstPointIndex == -1) {
                this.firstPointIndex = 0;
            }
        } catch (error) {
            hasError = true;
        }

        return hasError;
    };

    // 生成预处理语句
    // @parameter parameter 要加语句的字符串
    // @return 加上预处理语句后的字符串
    this.generateEvalStr = function (parameter) {
        return "x = " + parameter + ";\n" + this.evalStr;
    };

    // 生成求值后的语句
    // @parameter parameter 要求值的语句
    // @return 易读的求值后的结果
    this.evalToStr = function (parameter) {
        return util.evalEx(this.generateEvalStr(parameter)).toString();
    };

    // 将函数信息转换成易读的字符串
    // @return 易读的字符串
    this.toString = function () {
        return ("f(x) = " + this.evalStr);
    };
}

// 参数方程
function ParameterFunc(evalStrX, evalStrY, evalScopeStart, evalScopeEnd, delta, width, color) {
    this.evalStrX = evalStrX;
    this.evalStrY = evalStrY;
    this.evalScopeStart = evalScopeStart;
    this.evalScopeEnd = evalScopeEnd;
    this.delta = delta;
    this.width = width;
    this.color = color;
    this.points = [];
    this.firstPointIndex = -1;

    // 计算并存储所有坐标值
    // @return 函数中是否有错误
    this.generatePoints = function () {
        var pointIndex = 0;
        var hasError = false;

        try {
            var parameterStart = util.evalEx(this.evalScopeStart);
            var parameterEnd = util.evalEx(this.evalScopeEnd);
            var parameterDelta = util.evalEx(this.delta);

            // 清空所有像素值，防止网格缩放之前的像素值仍存在数组中
            this.points.splice(0, this.points.length);
            // 重置第一个有效点下标
            this.firstPointIndex = -1;

            for (var parameter = parameterStart; parameter <= parameterEnd; parameter += parameterDelta) {
                var coordX = util.evalEx(this.generateEvalStrX(parameter));
                var coordY = util.evalEx(this.generateEvalStrY(parameter));
                var pointX = converter.toPointX(coordX);
                var pointY = converter.toPointY(coordY);

                // 如果这个点是有效的才要画出
                if (!isNaN(coordX) && isFinite(coordX) && !isNaN(coordY) && isFinite(coordY)) {
                    this.points[pointIndex] = new Point(pointX, pointY);
                    this.points[pointIndex].isValid = true;
                    this.lastPointIndex = pointIndex;

                    // 将第一个有效点下标存起来
                    if (this.firstPointIndex == -1) {
                        this.firstPointIndex = pointIndex;
                    }
                } else {
                    this.points[pointIndex] = new Point(-canvPadProp.zeroPoint.x * 2, -canvPadProp.zeroPoint.y * 2);
                    this.points[pointIndex].isValid = false;
                }

                pointIndex++;
            }

            if (this.firstPointIndex == -1) {
                this.firstPointIndex = 0;
            }
        } catch (error) {
            hasError = true;
        }

        return hasError;
    };

    // 生成预处理语句
    // @parameter parameter 要加语句的字符串
    // @return 加上预处理语句后的字符串
    this.generateEvalStrX = function (parameter) {
        return "t = " + parameter + ";\n" + this.evalStrX;
    };

    // 生成预处理语句
    // @parameter parameter 要加语句的字符串
    // @return 加上预处理语句后的字符串
    this.generateEvalStrY = function (parameter) {
        return "t = " + parameter + ";\n" + this.evalStrY;
    };

    // 生成求值后的语句
    // @parameter parameter 要求值的语句
    // @return 易读的求值后的结果
    this.evalToStr = function (parameter) {
        var valueX = util.evalEx(this.generateEvalStrX(parameter));
        var valueY = util.evalEx(this.generateEvalStrY(parameter));

        return "(" + valueX + ", " + valueY + ")";
    };

    // 将函数信息转换成易读的字符串
    // @return 易读的字符串
    this.toString = function () {
        return ("x(t) = " + this.evalStrX + ", y(t) = " + this.evalStrY);
    };
}

// 函数操作类
function FuncOperate() {
    // 添加常规函数
    this.addNormalFunc = function () {
        var evalStr = inpNorEvalStrNew.value;
        var scopeStart = inpNorScopeStartNew.value;
        var scopeEnd = inpNorScopeEndNew.value;
        var width = parseInt(selNorWidthNew.options[selNorWidthNew.selectedIndex].text);
        var color = colorUtil.colorToInteger(inpNorColorNew.value);

        if (evalStr == "" || scopeStart == "" || scopeEnd == "") {
            alert("参数不能为空");
        } else {
            var normalFunc = new NormalFunc(evalStr, scopeStart, scopeEnd, width, color);

            // 如果函数参数有误就不存储也不画出
            if (!normalFunc.generatePoints()) {
                normalFuncs[normalFuncs.length] = normalFunc;
                htmlOperate.refreshSelect(selNorFuncs);
                canvPadOperate.validate();
            } else {
                alert("解析常规函数 " + normalFunc.toString() + " 时发生错误。");
            }
        }
    };

    // 将选择的函数信息读取到控件中
    this.readNormalFunc = function () {
        var funcIndex = selNorFuncs.selectedIndex;

        inpNorEvalStr.value = normalFuncs[funcIndex].evalStr;
        inpNorScopeStart.value = normalFuncs[funcIndex].evalScopeStart;
        inpNorScopeEnd.value = normalFuncs[funcIndex].evalScopeEnd;
        inpNorColor.value = colorUtil.integerToColor(normalFuncs[funcIndex].color);
        selNorWidth.selectedIndex = normalFuncs[funcIndex].width - 1;
    };

    // 更新函数
    this.updateNormalFunc = function () {
        var funcIndex = selNorFuncs.selectedIndex;
        var evalStr = inpNorEvalStr.value;
        var scopeStart = inpNorScopeStart.value;
        var scopeEnd = inpNorScopeEnd.value;
        var width = parseInt(selNorWidth.options[selNorWidth.selectedIndex].text);
        var color = colorUtil.colorToInteger(inpNorColor.value);

        if (funcIndex > -1) {
            if (evalStr == "" || scopeStart == "" || scopeEnd == "") {
                alert("参数不能为空");
            } else {
                var normalFunc = new NormalFunc(evalStr, scopeStart, scopeEnd, width, color);

                // 如果参数有误就不更新
                if (!normalFunc.generatePoints()) {
                    normalFuncs[funcIndex] = normalFunc;
                    canvPadOperate.validate();
                } else {
                    alert("解析常规函数 " + normalFunc.toString() + " 时发生错误。");
                    this.readNormalFunc();
                }
            }
        }
    };

    // 添加参数方程
    this.addParameterFunc = function () {
        var evalStrX = inpParaEvalStrXNew.value;
        var evalStrY = inpParaEvalStrYNew.value;
        var scopeStart = inpParaScopeStartNew.value;
        var scopeEnd = inpParaScopeEndNew.value;
        var delta = inpParaDeltaNew.value;
        var width = parseInt(selParaWidthNew.options[selParaWidthNew.selectedIndex].text);
        var color = colorUtil.colorToInteger(inpParaColorNew.value);

        if (evalStrX == "" || evalStrY == "" || scopeStart == "" || scopeEnd == "" || delta == "") {
            alert("参数不能为空");
        } else {
            var parameterFunc = new ParameterFunc(evalStrX, evalStrY, scopeStart, scopeEnd, delta, width, color);

            // 如果函数参数有误就不存储也不画出
            if (!parameterFunc.generatePoints()) {
                parameterFuncs[parameterFuncs.length] = parameterFunc;
                htmlOperate.refreshSelect(selParaFuncs);
                canvPadOperate.validate();
            } else {
                alert("解析参数方程 " + parameterFunc.toString() + " 时发生错误。");
            }
        }
    };

    // 将选择的参数方程信息读取到控件中
    this.readParameterFunc = function () {
        var funcIndex = selParaFuncs.selectedIndex;

        inpParaEvalStrX.value = parameterFuncs[funcIndex].evalStrX;
        inpParaEvalStrY.value = parameterFuncs[funcIndex].evalStrY;
        inpParaScopeStart.value = parameterFuncs[funcIndex].evalScopeStart;
        inpParaScopeEnd.value = parameterFuncs[funcIndex].evalScopeEnd;
        inpParaDelta.value = parameterFuncs[funcIndex].delta;
        inpParaColor.value = colorUtil.integerToColor(parameterFuncs[funcIndex].color);
        selParaWidth.selectedIndex = parameterFuncs[funcIndex].width - 1;
    };

    // 更新参数方程
    this.updateParameterFunc = function () {
        var funcIndex = selParaFuncs.selectedIndex;
        var evalStrX = inpParaEvalStrX.value;
        var evalStrY = inpParaEvalStrY.value;
        var scopeStart = inpParaScopeStart.value;
        var scopeEnd = inpParaScopeEnd.value;
        var delta = inpParaDelta.value;
        var width = parseInt(selParaWidth.options[selParaWidth.selectedIndex].text);
        var color = colorUtil.colorToInteger(inpParaColor.value);

        if (funcIndex > -1) {
            if (evalStrX == "" || evalStrY == "" || scopeStart == "" || scopeEnd == "" || delta == "") {
                alert("参数不能为空");
            } else {
                var parameterFunc = new ParameterFunc(evalStrX, evalStrY, scopeStart, scopeEnd, delta, width, color);

                // 如果参数有误就不更新
                if (!parameterFunc.generatePoints()) {
                    parameterFuncs[funcIndex] = parameterFunc;
                    canvPadOperate.validate();
                } else {
                    alert("解析参数方程 " + parameterFunc.toString() + " 时发生错误。");
                    this.readParameterFunc();
                }
            }
        }
    };

    // 删除方程
    // @parameter funcs 目标函数数组
    this.deleteFuncs = function (funcs) {
        var select = (funcs == normalFuncs) ? selNorFuncs : selParaFuncs;

        // 删除Select列表中选中的函数
        for (var i = funcs.length - 1; i > -1; i--) {
            if (select.options[i].selected) {
                funcs.splice(i, 1);
            }
        }

        htmlOperate.refreshSelect(select);
        canvPadOperate.validate();
    };

    // 对普通函数求值
    // @parameter inputParameter 用来判断是新函数还是已经存在的函数
    this.evalNormalFunc = function (inputParameter) {
        var evalStr;
        var inputResult;
        var normalFunc;

        // 判断要求值的是新生成的函数函数已经存在的函数
        if (inputParameter == inpNorEvalParameterNew) {
            evalStr = inpNorEvalStrNew.value;
            inputResult = inpNorEvalResultNew;
        } else {
            evalStr = inpNorEvalStr.value;
            inputResult = inpNorEvalResult;
        }

        // 参数不能为空
        if (evalStr != "" && inputParameter.value != "") {
            normalFunc = new NormalFunc(evalStr, null, null, null, null);
            inputResult.value = normalFunc.evalToStr(inputParameter.value);
        }
    };

    // 对参数方程求值
    // @parameter inputParameter 用来判断是新参数方程还是已经存在的方程
    this.evalParameterFunc = function (inputParameter) {
        var evalStrX;
        var evalStrY;
        var inputResult;
        var parameterFunc;

        // 判断要求值的是新方程还是已经存在的方程
        if (inputParameter == inpParaEvalParameterNew) {
            evalStrX = inpParaEvalStrXNew.value;
            evalStrY = inpParaEvalStrYNew.value;
            inputResult = inpParaEvalResultNew;
        } else {
            evalStrX = inpParaEvalStrX.value;
            evalStrY = inpParaEvalStrY.value;
            inputResult = inpParaEvalResult;
        }

        // 参数不能为空
        if (evalStrX != "" && evalStrY != "" && inputParameter.value != "") {
            parameterFunc = new ParameterFunc(evalStrX, evalStrY, null, null, null, null, null);
            inputResult.value = parameterFunc.evalToStr(inputParameter.value);
        }
    };
}

// 涂鸦
function Doodle(width, color) {
    this.width = width;
    this.color = color;
    this.coords = [];
    this.points = [];

    // 添加坐标点，用来给以后生成路径
    // @parameter coord 新的坐标点
    this.addCoord = function (coord) {
        this.coords[this.coords.length] = coord;
    };

    // 将所有坐标点转换成像素点
    this.generatePoints = function () {
        this.points.splice(0, this.points.length);

        for (var i = 0; i < this.coords.length; i++) {
            this.points[i] = converter.toPoint(this.coords[i]);
        }
    };
}

// 涂鸦操作类
function DoodleOperate() {
    // 添加涂鸦路径
    // @parameter coord 新的路径的起始坐标
    this.addDoodle = function (coord) {
        var width = parseInt(selDoodWidth.options[selDoodWidth.selectedIndex].text);
        var color = colorUtil.colorToInteger(inpDoodColor.value);

        doodles[doodles.length] = new Doodle(width, color);
        doodles[doodles.length - 1].addCoord(coord);
    };

    // 撤销涂鸦，删除最后一条路径
    this.deleteDoodles = function () {
        if (doodles.length > 0) {
            doodles.splice(doodles.length - 1, 1);
            canvPadOperate.validate();
        }
    };
}

// 鼠标信息
function MouseProp() {
    this.isMouseDown = false;
    this.prePos = new Point(0, 0);
    this.prePos.isValid = false;
    this.curPos = new Point(0, 0);
    this.curPos.isValid = false;

    // 按下
    this.mouseDown = function (event) {
        this.isMouseDown = true;
        this.curPos = this.getMousePos(event);
        this.curPos.isValid = true;
        this.prePos = this.curPos;

        // 涂鸦模式
        if (canvPadProp.doodleMode) {
            var point = new Point(-canvPadProp.zeroPoint.x + this.curPos.x,
                                    -canvPadProp.zeroPoint.y + this.curPos.y);

            doodleOperate.addDoodle(converter.toCoord(point));
        }

        // 鼠标点击就要画出鼠标坐标，因此要重画
        canvPadOperate.validate();
    };

    // 放开
    this.mouseUp = function (event) {
        this.isMouseDown = false;
    };

    // 移动
    this.mouseMove = function (event) {
        var deltaX;
        var deltaY;

        if (this.isMouseDown) {
            this.curPos = this.getMousePos(event);
            deltaX = this.curPos.x - this.prePos.x;
            deltaY = this.curPos.y - this.prePos.y;

            // 将鼠标在屏幕上（相对Canvas）的坐标转换成Canvas内的坐标
            var curPosOnCanvas = new Point(-canvPadProp.zeroPoint.x + this.curPos.x,
                                            -canvPadProp.zeroPoint.y + this.curPos.y);
            // var prePosOnCanvas = new Point(-canvPadProp.zeroPoint.x + this.prePos.x,
            //                                 -canvPadProp.zeroPoint.y + this.prePos.y);

            if (canvPadProp.doodleMode) {
                // 涂鸦模式，开始添加路径
                doodles[doodles.length - 1].addCoord(converter.toCoord(curPosOnCanvas));
                canvPadOperate.validate();
            } else {
                // 普通模式，移动Canvas
                canvPadOperate.translate(deltaX, deltaY);
                this.prePos = this.curPos;
            }
        }
    };

    // 将鼠标在屏幕上的坐标转换成相对Canvas的坐标
    this.getMousePos = function (event) {
        return (new Point(event.pageX - canvPadProp.left, event.pageY - canvPadProp.top));
    };
}

// HTML元素操作类
function HtmlOperate() {
    // 初始化HTML控件
    this.initHtml = function () {
        // 设置控件
        inpCanvPadColor = document.getElementById("inpCanvPadColor");
        inpCoordColor = document.getElementById("inpCoordColor");
        inpGridColor = document.getElementById("inpGridColor");
        inpMouseCoordColor = document.getElementById("inpMouseCoordColor");
        inpShowCoord = document.getElementById("inpShowCoord");
        inpShowGrid = document.getElementById("inpShowGrid");
        inpShowMouseCoord = document.getElementById("inpShowMouseCoord");

        // 涂鸦控件
        selDoodWidth = document.getElementById("selDoodWidth");
        inpDoodColor = document.getElementById("inpDoodColor");
        btnDoodMode = document.getElementById("btnDoodMode");
        btnDoodUndo = document.getElementById("btnDoodUndo");

        // 常规函数控件
        inpNorEvalStrNew = document.getElementById("inpNorEvalStrNew");
        inpNorScopeStartNew = document.getElementById("inpNorScopeStartNew");
        inpNorScopeEndNew = document.getElementById("inpNorScopeEndNew");
        selNorWidthNew = document.getElementById("selNorWidthNew");
        inpNorColorNew = document.getElementById("inpNorColorNew");
        btnNorDraw = document.getElementById("btnNorDraw");
        inpNorEvalParameterNew = document.getElementById("inpNorEvalParameterNew");
        inpNorEvalResultNew = document.getElementById("inpNorEvalResultNew");
        btnNorEvalNew = document.getElementById("btnNorEvalNew");
        selNorFuncs = document.getElementById("selNorFuncs");
        inpNorEvalStr = document.getElementById("inpNorEvalStr");
        inpNorScopeStart = document.getElementById("inpNorScopeStart");
        inpNorScopeEnd = document.getElementById("inpNorScopeEnd");
        selNorWidth = document.getElementById("selNorWidth");
        inpNorColor = document.getElementById("inpNorColor");
        btnNorUpdate = document.getElementById("btnNorUpdate");
        btnNorDel = document.getElementById("btnNorDel");
        inpNorEvalParameter = document.getElementById("inpNorEvalParameter");
        inpNorEvalResult = document.getElementById("inpNorEvalResult");
        btnNorEval = document.getElementById("btnNorEval");

        // 参数方程控件
        inpParaEvalStrXNew = document.getElementById("inpParaEvalStrXNew");
        inpParaEvalStrYNew = document.getElementById("inpParaEvalStrYNew");
        inpParaScopeStartNew = document.getElementById("inpParaScopeStartNew");
        inpParaScopeEndNew = document.getElementById("inpParaScopeEndNew");
        inpParaDeltaNew = document.getElementById("inpParaDeltaNew");
        selParaWidthNew = document.getElementById("selParaWidthNew");
        inpParaColorNew = document.getElementById("inpParaColorNew");
        btnParaDraw = document.getElementById("btnParaDraw");
        inpParaEvalParameterNew = document.getElementById("inpParaEvalParameterNew");
        inpParaEvalResultNew = document.getElementById("inpParaEvalResultNew");
        btnParaEvalNew = document.getElementById("btnParaEvalNew");
        selParaFuncs = document.getElementById("selParaFuncs");
        inpParaEvalStrX = document.getElementById("inpParaEvalStrX");
        inpParaEvalStrY = document.getElementById("inpParaEvalStrY");
        inpParaScopeStart = document.getElementById("inpParaScopeStart");
        inpParaScopeEnd = document.getElementById("inpParaScopeEnd");
        inpParaDelta = document.getElementById("inpParaDelta");
        selParaWidth = document.getElementById("selParaWidth");
        inpParaColor = document.getElementById("inpParaColor");
        btnParaUpdate = document.getElementById("btnParaUpdate");
        btnParaDel = document.getElementById("btnParaDel");
        inpParaEvalParameter = document.getElementById("inpParaEvalParameter");
        inpParaEvalResult = document.getElementById("inpParaEvalResult");
        btnParaEval = document.getElementById("btnParaEval");

        // 网格缩放控件
        inpGridResizer = document.getElementById("inpGridResizer");
        btnGridResizerMinus = document.getElementById("btnGridResizerMinus");
        btnGridResizerPlus = document.getElementById("btnGridResizerPlus");

        // 设置控件
        inpCanvPadColor.value = colorUtil.integerToColor(COLOR_CANVPAD);
        inpCanvPadColor.addEventListener("change", function () {
            canvPadOperate.updateSetting();
        });
        inpCoordColor.value = colorUtil.integerToColor(COLOR_COORD);
        inpCoordColor.addEventListener("change", function () {
            canvPadOperate.updateSetting();
        });
        inpGridColor.value = colorUtil.integerToColor(COLOR_GRID);
        inpGridColor.addEventListener("change", function () {
            canvPadOperate.updateSetting();
        });
        inpMouseCoordColor.value = colorUtil.integerToColor(COLOR_MOUSE_COORD);
        inpMouseCoordColor.addEventListener("change", function () {
            canvPadOperate.updateSetting();
        });
        inpShowCoord.checked = true;
        inpShowCoord.addEventListener("change", function () {
            canvPadOperate.updateSetting();
        });
        inpShowGrid.checked = true;
        inpShowGrid.addEventListener("change", function () {
            canvPadOperate.updateSetting();
        });
        inpShowMouseCoord.checked = true;
        inpShowMouseCoord.addEventListener("change", function () {
            canvPadOperate.updateSetting();
        });

        // 涂鸦控件
        selDoodWidth.selectedIndex = DOODLE_WIDTH - 1;
        inpDoodColor.value = colorUtil.integerToColor(COLOR_DOODLE);
        btnDoodMode.addEventListener("click", function () {
            canvPadProp.doodleMode = !canvPadProp.doodleMode;
            canvPadOperate.validate();
        });
        btnDoodUndo.addEventListener("click", function () {
            doodleOperate.deleteDoodles();
        });

        // 常规函数控件
        inpNorEvalStrNew.value = normalFuncs[0].evalStr;
        inpNorScopeStartNew.value = normalFuncs[0].evalScopeStart;
        inpNorScopeEndNew.value = normalFuncs[0].evalScopeEnd;
        selNorWidthNew.selectedIndex = FUNC_WIDTH - 1;
        inpNorColorNew.value = colorUtil.integerToColor(COLOR_NORMALFUNC);
        btnNorDraw.addEventListener("click", function () {
            funcOperate.addNormalFunc();
        });
        btnNorEvalNew.addEventListener("click", function () {
            funcOperate.evalNormalFunc(inpNorEvalParameterNew);
        });
        htmlOperate.refreshSelect(selNorFuncs);
        selNorFuncs.addEventListener("change", function () {
            funcOperate.readNormalFunc();
        });
        selNorWidth.selectedIndex = normalFuncs[0].width - 1;
        selNorWidth.addEventListener("change", function () {
            funcOperate.updateNormalFunc();
        });
        inpNorColor.value = colorUtil.integerToColor(normalFuncs[0].color);
        inpNorColor.addEventListener("change", function () {
            funcOperate.updateNormalFunc();
        });
        btnNorUpdate.addEventListener("click", function () {
            funcOperate.updateNormalFunc();
        });
        btnNorDel.addEventListener("click", function () {
            funcOperate.deleteFuncs(normalFuncs);
        });
        btnNorEval.addEventListener("click", function () {
            funcOperate.evalNormalFunc(inpNorEvalParameter);
        });

        // 参数方程控件
        inpParaEvalStrXNew.value = parameterFuncs[0].evalStrX;
        inpParaEvalStrYNew.value = parameterFuncs[0].evalStrY;
        inpParaScopeStartNew.value = parameterFuncs[0].evalScopeStart;
        inpParaScopeEndNew.value = parameterFuncs[0].evalScopeEnd;
        inpParaDeltaNew.value = parameterFuncs[0].delta;
        selParaWidthNew.selectedIndex = FUNC_WIDTH - 1;
        inpParaColorNew.value = colorUtil.integerToColor(COLOR_PARAMETERFUNC);
        btnParaDraw.addEventListener("click", function () {
            funcOperate.addParameterFunc();
        });
        btnParaEvalNew.addEventListener("click", function () {
            funcOperate.evalParameterFunc(inpParaEvalParameterNew);
        });
        htmlOperate.refreshSelect(selParaFuncs);
        selParaFuncs.addEventListener("change", function () {
            funcOperate.readParameterFunc();
        });
        selParaWidth.selectedIndex = parameterFuncs[0].width - 1;
        selParaWidth.addEventListener("change", function () {
            funcOperate.updateParameterFunc();
        });
        inpParaColor.value = colorUtil.integerToColor(parameterFuncs[0].color);
        inpParaColor.addEventListener("change", function () {
            funcOperate.updateParameterFunc();
        });
        btnParaUpdate.addEventListener("click", function () {
            funcOperate.updateParameterFunc();
        });
        btnParaDel.addEventListener("click", function () {
            funcOperate.deleteFuncs(parameterFuncs);
        });
        btnParaEval.addEventListener("click", function () {
            funcOperate.evalParameterFunc(inpParaEvalParameter);
        });

        // 网格缩放控件
        inpGridResizer.value = GRID_SIZE;
        inpGridResizer.max = GRID_MAX_SIZE;
        inpGridResizer.min = GRID_MIN_SIZE;
        inpGridResizer.addEventListener("change", function () {
            canvPadOperate.resize(parseInt(inpGridResizer.value));
        });
        btnGridResizerMinus.addEventListener("click", function () {
            canvPadOperate.resize(canvPadProp.gridSize - 1);
        });
        btnGridResizerPlus.addEventListener("click", function () {
            canvPadOperate.resize(canvPadProp.gridSize + 1);
        });
    };

    // 更新Select的列表
    // @parameter select 要刷新的select控件
    this.refreshSelect = function (select) {
        var funcs = (select == selNorFuncs ) ? normalFuncs : parameterFuncs;
        var option;

        while (select.length > 0) {
            select.remove(0);
        }

        for (var i = 0; i < funcs.length; i++) {
            option = document.createElement("option");
            option.text = funcs[i].toString();
            select.add(option, null);
        }
    };

    // 初始化Canvas
    this.initCanvPad = function () {
        var canvPad = document.getElementById("canvPad");
        var canvPadContext = canvPad.getContext('2d');

        canvPadProp = new CanvPadProp(canvPad, canvPadContext);
        canvPad.height = canvPad.offsetHeight;
        canvPad.width = canvPad.offsetWidth;
        canvPad.addEventListener('mousedown', function (event) {
            mouseProp.mouseDown(event);
        });
        canvPad.addEventListener('mouseup', function (event) {
            mouseProp.mouseUp(event);
        });
        canvPad.addEventListener('mousemove', function (event) {
            mouseProp.mouseMove(event);
        });
        canvPadContext.translate(canvPadProp.zeroPoint.x, canvPadProp.zeroPoint.y);
    };
}

// 事件处理类
function EventOperate() {
    // 加载事件
    this.windowOnLoad = function () {
        htmlOperate.initHtml();
        htmlOperate.initCanvPad();
        canvPadOperate.drawCanvPad();
    };

    // 添加事件处理器
    this.addKeyPressEvent = function (event) {
        var keyCode = event.keyCode ? event.keyCode : event.which;

        // 如果Canvas没有焦点就不作处理
        if (canvPadProp.isFocused()) {
            switch (keyCode) {
            case KEY_LEFT: case KEY_A:
                // 如果按下按键同时也按下了鼠标键，就移动鼠标坐标
                if (mouseProp.isMouseDown) {
                    mouseProp.curPos.x--;
                    canvPadOperate.validate();
                } else {
                    canvPadOperate.translate(canvPadProp.gridSize / 2, 0);
                }

                break;
            case KEY_RIGHT: case KEY_D:
                if (mouseProp.isMouseDown) {
                    mouseProp.curPos.x++;
                    canvPadOperate.validate();
                } else {
                    canvPadOperate.translate(-canvPadProp.gridSize / 2, 0);
                }

                break;
            case KEY_UP: case KEY_W:
                if (mouseProp.isMouseDown) {
                    mouseProp.curPos.y--;
                    canvPadOperate.validate();
                } else {
                    canvPadOperate.translate(0, canvPadProp.gridSize / 2);
                }

                break;
            case KEY_DOWN: case KEY_S:
                if (mouseProp.isMouseDown) {
                    mouseProp.curPos.y++;
                    canvPadOperate.validate();
                } else {
                    canvPadOperate.translate(0, -canvPadProp.gridSize / 2);
                }

                break;
            case KEY_ZOOMIN:
                canvPadOperate.resize(canvPadProp.gridSize + 5);
                break;
            case KEY_ZOOMOUT:
                canvPadOperate.resize(canvPadProp.gridSize - 5);
                break;
            default:
                break;
            }
        }
    };
}

function Converter() {
    // 将坐标系坐标转换成Canvas坐标
    // @parameter coordX 要转换的X坐标
    this.toPointX = function (coordX) {
        return Math.floor(coordX * canvPadProp.gridSize);
    };

    this.toPointY = function (coordY) {
        return Math.floor(-coordY * canvPadProp.gridSize);
    };

    this.toPoint = function (coord) {
        return (new Point(Math.floor(coord.x * canvPadProp.gridSize),
                            Math.floor(-coord.y * canvPadProp.gridSize)));
    };

    // 将Canvas坐标转换成坐标系坐标
    // @parameter pointX 要转换的X坐标
    this.toCoordX = function (pointX) {
        return pointX / canvPadProp.gridSize;
    };

    this.toCoordY = function (pointY) {
        return -pointY / canvPadProp.gridSize;
    };

    this.toCoord = function (point) {
        return (new Coordinate(point.x / canvPadProp.gridSize,
                                -point.y / canvPadProp.gridSize));
    };
}

function ColorUtil() {
    // 将10进制的数值转换成16进制的颜色字符串
    // @parameter integer 要转换的数值
    // @return 转换后的16进制颜色字符串，带有"#"
    this.integerToColor = function (integer) {
        var hexTable = ["0", "1", "2", "3", "4", "5", "6", "7",
                        "8", "9", "a", "b", "c", "d", "e", "f"];
        var colorStr = "";

        for (var i = 0; i < 6; i++) {
            colorStr = hexTable[integer % 16] + colorStr;
            integer = Math.floor(integer / 16);
        }

        return "#" + colorStr;
    };

    // 将16进制的颜色值转换成10进制的数值
    // @parameter color 16进制的颜色值字符串，带有"#"
    // @return 转换后的十进制数值
    this.colorToInteger = function (color) {
        var integer = 0;
        var colorStr = color.substr(1).toLowerCase();

        for (var i = 0; i < colorStr.length; i++) {
            var charCode = colorStr.charCodeAt(i);

            if (charCode >= charUtil.charToAsc("a")) {
                charCode = charCode - charUtil.charToAsc("a") + 10;
            } else {
                charCode -= charUtil.charToAsc("0");
            }

            integer = integer * 16 + charCode;
        }

        return integer;
    };
}

// 字符操作类
function CharUtil() {
    // 字符转ASCII码
    // @parameter char 要转换的字符
    // @return 转换后的字符ASCII码
    this.charToAsc = function (char) {
        return char.toString().charCodeAt(0);
    };

    // ASCII码转字符
    // @parameter asc 要转换的ASCII码
    // @return 转换后的字符
    this.ascToChar = function (asc) {
        return String.fromCharCode(asc);
    };
}

// 其他一些功能类
function Util() {
    // 给字符串添加预处理语句并求值
    // @parameter string 要求值的语句
    // @return 添加预处理语句后的字符串
    this.evalEx = function (string) {
        return eval(PRE_EVAL_STR + string);
    };
}
