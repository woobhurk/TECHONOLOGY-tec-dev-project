/*
============================
Name:WBH Assemble Debug
Author:Woobhurk.
Date:2012.07
All rights reserved.
============================
*/

#include <stdio.h>
#include <conio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <math.h>

#define STR_MAX 51
#define FGF ';'
#define TYPE_ADDR "addr "
#define TYPE_REG "reg "
#define MATH_SQRT "sqrt "
#define MATH_ADD "add "
#define MATH_SUB "sub "
#define MATH_MUL "mul "
#define MATH_DIV "div "
#define MATH_MOD "mod "
#define MATH_ABS "abs "
#define cutStr strcpy(tmpStr,lineStr+strlen(tmpStr));strcpy(lineStr,tmpStr)

void editStr(void);
void showReg(void);
void runCmd(void);
	void cmpCmd(void);
	int cmpCmd2(void);
		void loadVal(void);
		int loadVal2(void);
			void loadAddr(void);
			void loadReg(void);
		void calc(void);
		int calc2(void);
			void calc_val(void);
			void calc_reg(void);
void help(void);

int (*rp)(),r[4]={0,0,0,0};
char usrStr[STR_MAX]="-";
char codeStr[STR_MAX],lineStr[STR_MAX],tmpStr[STR_MAX];

int	main(void)
{
	rp=main;
	while(1)
	{
		printf("(WDebug) -");
		fgets(usrStr+1,STR_MAX,stdin);
		editStr();
		if(!strcmp(usrStr,"-register"))  //��ʾ�����Ĵ�����ֵ
			showReg();
		else if(!strcmp(usrStr,"-show r0")||!strcmp(usrStr,"-show r1")||!strcmp(usrStr,"-show r2")||!strcmp(usrStr,"-show r3"))
		{
			int num;
			num=usrStr[7]-'0';
			printf("r%d=%d\n",num,r[num]);
		}
		else if(!strcmp(usrStr,"-run"))  //��������
			runCmd();
		else if(!strcmp(usrStr,"-cls"))
			system("cls");
		else if(!strcmp(usrStr,"-help"))
			help();
		else if(!strcmp(usrStr,"-quit"))
			exit(0);
		else
			printf("\t'%s' is undefined. Please try 'help'.\a\n",usrStr);
	}
	return	0;
}


/*
======================
������editStr
���ܣ�����������ַ��������
���룺--
���أ�--
======================
*/
void editStr(void)
{
	int cnt;
	usrStr[strlen(usrStr)-1]=0;  //�����Ļس���ȥ��
	for(cnt=strlen(usrStr)-1;cnt>=0&&usrStr[cnt]==' ';cnt--)  //ȥ�����������пո�
		usrStr[cnt]=0;
	for(cnt=1;cnt<strlen(usrStr),usrStr[cnt]==' ';cnt++)
		;
	strcpy(usrStr+1,usrStr+cnt);  //ȥ���ո�
	for(cnt=0;cnt<strlen(usrStr);cnt++)
		usrStr[cnt]=tolower(usrStr[cnt]);
}


/*
======================
������showReg
���ܣ���ʾ�����Ĵ���ֵ
���룺--
���أ�--
======================
*/
void showReg(void)
{
	printf("Now this program's addr in the memary (rp) : %#X\n",(int)rp);
	printf("The value of all registers:\n");
	printf("r0=%-5d r1=%-5d r2=%-5d r3=%-5d\n",r[0],r[1],r[2],r[3]);
}


/*
======================
������runCmd
���ܣ������û����������
���룺--
���أ�--
======================
*/
void runCmd(void)
{
	fgets(codeStr,STR_MAX,stdin);
	int cnt;
	for(cnt=0;cnt<strlen(codeStr);cnt++)
		codeStr[cnt]=tolower(codeStr[cnt]);
	strcpy(lineStr,codeStr);
	strcpy(tmpStr,lineStr);
	cmpCmd();
}


/*
======================
������cmpCmd
���ܣ��ж�������������
���룺--
���أ�--
======================
*/
void cmpCmd()
{
	switch(cmpCmd2())
	{
	case 0: loadVal(); break;
	case 1: calc(); break;
	default: printf("Unknown command '%s'!\a\n",tmpStr);
	}
}

int cmpCmd2()  //�ж����������
{
	tmpStr[8]=0;
	if(!strcmp(tmpStr,"loadval.")) return 0;
	tmpStr[5]=0;
	if(!strcmp(tmpStr,"calc.")) return 1;
	return -1;
}


/*
======================
������loadVal
���ܣ�Ϊ�Ĵ�����ֵ
���룺--
���أ�--
======================
*/
void loadVal()
{
	switch(loadVal2())
	{
	case 0: loadAddr(); break;
	case 1: loadReg(); break;
	default: printf("Unknown load type '%s'!\a\n",tmpStr);
	}
}

int loadVal2()  //�жϸ�ֵ��ʽ
{
	cutStr;
	tmpStr[5]=0;
	if(!strcmp(tmpStr,TYPE_ADDR)) return 0;
	tmpStr[4]=0;
	if(!strcmp(tmpStr,TYPE_REG)) return 1;
	return -1;
}


/*
======================
������loadAddr
���ܣ�����ַ�µ�ֵ���浽�Ĵ�����
���룺--
���أ�--
======================
*/
void loadAddr(void)
{
	cutStr;
	if(tmpStr[0]=='r'&&tmpStr[1]<='3'&&tmpStr[2]==FGF)
	{
		int *addr;
		addr=(int *)+atoi(tmpStr+3);
		r[tmpStr[1]-'0']=*(addr);
	}
	else
		printf("No such register or no '%c'!\a\n",FGF);
}
/*
void loadAddr2(void)
{
	cutStr;
	int pos;
	pos=(int)strchr(tmpStr,FGF);
	if(pos)
	{
		tmpStr[pos]=0;
		int addr,value;
		addr=atoi(tmpStr);
		cutStr;
		value=atoi(tmpStr+1);
		memset(rp,value,addr);
	}
	else
		printf("Error! No find '%c'!\n",FGF);
}
*/


/*
======================
������loadReg
���ܣ���ֵ���浽�Ĵ�����
���룺--
���أ�--
======================
*/
void loadReg(void)
{
	cutStr;
	if(tmpStr[0]=='r'&&tmpStr[1]<='3'&&tmpStr[2]==FGF)
	{
		int value;
		value=atoi(tmpStr+3);
		r[tmpStr[1]-'0']=value;
	}
	else
		printf("No such register or no '%c'!\a\n",FGF);
}


/*
======================
������calc
���ܣ����м򵥵���ѧ����
���룺--
���أ�--
======================
*/
void calc(void)
{
	switch(calc2())
	{
	case 0:
	{
		if(tmpStr[8]=='r'&&tmpStr[9]<='3'&&tmpStr[10]=='\n')
		{
			strcpy(tmpStr,codeStr);
			strcpy(lineStr,tmpStr);
			tmpStr[5]=0;
			calc_reg();
		}
		else
		{
			strcpy(tmpStr,codeStr);
			strcpy(lineStr,tmpStr);
			tmpStr[5]=0;
			calc_val();
		}
		break;
	}
	default:
	{
		if(tmpStr[7]=='r'&&tmpStr[8]<='3'&&tmpStr[9]=='\n')
		{
			strcpy(tmpStr,codeStr);
			strcpy(lineStr,tmpStr);
			tmpStr[5]=0;
			calc_reg();
		}
		else
		{
			strcpy(tmpStr,codeStr);
			strcpy(lineStr,tmpStr);
			tmpStr[5]=0;
			calc_val();
		}
	}
	}
}

int calc2(void)
{
	cutStr;
	tmpStr[5]=0;
	if(!strcmp(tmpStr,MATH_SQRT)) return 0;
	tmpStr[4]=0;
	if(!strcmp(tmpStr,MATH_ADD)) return 1;
	if(!strcmp(tmpStr,MATH_SUB)) return 2;
	if(!strcmp(tmpStr,MATH_MUL)) return 3;
	if(!strcmp(tmpStr,MATH_DIV)) return 4;
	if(!strcmp(tmpStr,MATH_MOD)) return 5;
	if(!strcmp(tmpStr,MATH_ABS)) return 6;
	return -1;
}

void calc_reg(void)
{
	switch(calc2())
	{
	case 0:  //MATH_SQRT
	{
		cutStr;
		if(tmpStr[0]=='r'&&tmpStr[1]<='3'&&tmpStr[2]==FGF)
		{
			int value;
			value=(int)sqrt(r[tmpStr[4]-'0']);
			r[tmpStr[1]-'0']=value;
		}
		else
			printf("No such register or no '%c'!\a\n",FGF);
		break;
	}
	case 1:  //MATH_ADD
	{
		cutStr;
		if(tmpStr[0]=='r'&&tmpStr[1]<='3'&&tmpStr[2]==FGF)
			r[tmpStr[1]-'0']+=r[tmpStr[4]-'0'];
		else
			printf("No such register or no '%c'!\a\n",FGF);
		break;
	}
	case 2:  //MATH_SUB
	{
		cutStr;
		if(tmpStr[0]=='r'&&tmpStr[1]<='3'&&tmpStr[2]==FGF)
			r[tmpStr[1]-'0']-=r[tmpStr[4]-'0'];
		else
			printf("No such register or no '%c'!\a\n",FGF);
		break;
	}
	case 3:  //MATH_MUL
	{
		cutStr;
		if(tmpStr[0]=='r'&&tmpStr[1]<='3'&&tmpStr[2]==FGF)
			r[tmpStr[1]-'0']*=r[tmpStr[4]-'0'];
		else
			printf("No such register or no '%c'!\a\n",FGF);
		break;
	}
	case 4:  //MATH_DIV
	{
		cutStr;
		if(tmpStr[0]=='r'&&tmpStr[1]<='3'&&tmpStr[2]==FGF)
			r[tmpStr[1]-'0']/=r[tmpStr[4]-'0'];
		else
			printf("No such register or no '%c'!\a\n",FGF);
		break;
	}
	case 5:  //MATH_MOD
	{
		cutStr;
		if(tmpStr[0]=='r'&&tmpStr[1]<='3'&&tmpStr[2]==FGF)
			r[tmpStr[1]-'0']%=r[tmpStr[4]-'0'];
		else
			printf("No such register or no '%c'!\a\n",FGF);
		break;
	}
	case 6:  //MATH_ABS
	{
		cutStr;
		if(tmpStr[0]=='r'&&tmpStr[1]<='3'&&tmpStr[2]==FGF)
			r[tmpStr[1]-'0']=abs(r[tmpStr[4]-'0']);
		else
			printf("No such register or no '%c'!\a\n",FGF);
		break;
	}
	default:
		printf("Unknown calculation type '%s'!\a\n",tmpStr);
	}
}

void calc_val(void)
{
	switch(calc2())
	{
	case 0:  //MATH_SQRT
	{
		cutStr;
		if(tmpStr[0]=='r'&&tmpStr[1]<='3'&&tmpStr[2]==FGF)
		{
			int value;
			value=(int)sqrt(atof(tmpStr+3));
			r[tmpStr[1]-'0']=value;
		}
		else
			printf("No such register or no '%c'!\a\n",FGF);
		break;
	}
	case 1:  //MATH_ADD
	{
		cutStr;
		if(tmpStr[0]=='r'&&tmpStr[1]<='3'&&tmpStr[2]==FGF)
		{
			int value;
			value=atoi(tmpStr+3);
			r[tmpStr[1]-'0']+=value;
		}
		else
			printf("No such register or no '%c'!\a\n",FGF);
		break;
	}
	case 2:  //MATH_SUB
	{
		cutStr;
		if(tmpStr[0]=='r'&&tmpStr[1]<='3'&&tmpStr[2]==FGF)
		{
			int value;
			value=atoi(tmpStr+3);
			r[tmpStr[1]-'0']-=value;
		}
		else
			printf("No such register or no '%c'!\a\n",FGF);
		break;
	}
	case 3:  //MATH_MUL
	{
		cutStr;
		if(tmpStr[0]=='r'&&tmpStr[1]<='3'&&tmpStr[2]==FGF)
		{
			int value;
			value=atoi(tmpStr+3);
			r[tmpStr[1]-'0']*=value;
		}
		else
			printf("No such register or no '%c'!\a\n",FGF);
		break;
	}
	case 4:  //MATH_DIV
	{
		cutStr;
		if(tmpStr[0]=='r'&&tmpStr[1]<='3'&&tmpStr[2]==FGF)
		{
			int value;
			value=atoi(tmpStr+3);
			r[tmpStr[1]-'0']/=value;
		}
		else
			printf("No such register or no '%c'!\a\n",FGF);
		break;
	}
	case 5:  //MATH_MOD
	{
		cutStr;
		if(tmpStr[0]=='r'&&tmpStr[1]<='3'&&tmpStr[2]==FGF)
		{
			int value;
			value=atoi(tmpStr+3);
			r[tmpStr[1]-'0']%=value;
		}
		else
			printf("No such register or no '%c'!\a\n",FGF);
		break;
	}
	case 6:  //MATH_ABS
	{
		cutStr;
		if(tmpStr[0]=='r'&&tmpStr[1]<='3'&&tmpStr[2]==FGF)
		{
			int value;
			value=atoi(tmpStr+3);
			r[tmpStr[1]-'0']=abs(value);
		}
		else
			printf("No such register or no '%c'!\a\n",FGF);
		break;
	}
	default:
		printf("Unknown calculation type '%s'!\a\n",tmpStr);
	}
}


/*
======================
������calc
���ܣ����м򵥵���ѧ����
���룺--
���أ�--
======================
*/
void help(void)
{
	printf("WBHDebug - [help]\n");
	printf("You can input the following commands:\n");
	printf("\t-cls\t\tClean the screen.\n");
	printf("\t-register\tShow all values of the registers.\n");
	printf("\t-show rN\tShow the value of rN.\n");
	printf("\t-quit\t\tQuit the debug.\n");
	printf("____________________________________________________________\n");
	printf("In the command 'run' you can input the following commands:\n");
	printf("\tloadval:loadval.reg rN%cvalue\n",FGF);
	printf("\t\tloadval.addr rN%cvalue\n",FGF);
	printf("\tcalc:\tcalc.sqrt rN%crN/value\n",FGF);
	printf("\t\tcalc.add rN%crN/value\n",FGF);
	printf("\t\tcalc.sub rN%crN/value\n",FGF);
	printf("\t\tcalc.mul rN%crN/value\n",FGF);
	printf("\t\tcalc.div rN%crN/value\n",FGF);
	printf("\t\tcalc.mod rN%crN/value\n",FGF);
	printf("\t\tcalc.abs rN%crN/value\n",FGF);
}
