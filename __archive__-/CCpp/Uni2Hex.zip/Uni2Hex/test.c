/*
=========================================
Un2Hex
�����У�Uni2Hex �ַ��� ת��ģʽ �ߵ�λģʽ

ϵͳĬ�ϸߵ�λģʽ��LOW_HIGH
=========================================
*/
#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <string.h>
#include <locale.h>
#define SOME_CHAR 1
#define ALL_CHAR 2
#define LOW_HIGH 1
#define HIGH_LOW 2

void Uni2Hex_1(void);
void Uni2Hex_2(char *, char *);
void Uni2Hex(int, int);
void AddZero(char *, int);
void ExchangeBit(char *);

char SrcStr[4096];
char DestStr[4096];
FILE *DataFile;

int main(int argc, char *argv[])
{
	setlocale(LC_CTYPE, "chs");  //���õ���
	if (argc != 4)  //�޲����������ȫ
	{
		Uni2Hex_1();
	}
	else
	{
		strcpy(SrcStr, argv[1]);
		Uni2Hex_2(argv[2], argv[3]);
	}
	DataFile = fopen("Unicode.txt", "w");
	fprintf(DataFile, "%s\nԴ�ַ�����%s\n", DestStr, SrcStr);
	fclose(DataFile);
	//getch();
	return 0;
}



//�������в���ģʽ
void Uni2Hex_1(void)
{
	int ConType;  //ת��ģʽ
	int BitType;

	printf("��ת�����ַ�����\n");
	gets(SrcStr);
	printf("ת��ģʽ����1Ӣ���ַ���ת�� ����ȫ��ת����\n");
	ConType = getch() - '0';
	printf("�ߵ�λģʽ����1��λ��ǰ ������λ��ǰ��\n");
	BitType = getch() - '0';
	Uni2Hex(ConType, BitType);
	
}



//���������в���ģʽ
void Uni2Hex_2(char *ConType, char *BitType)
{
	int _ConType;  //ת��ģʽ
	int _BitType;

	if (!strcmp(ConType, "1"))
		_ConType = SOME_CHAR;
	else
		_ConType = ALL_CHAR;
	if (!strcmp(BitType, "1"))
		_BitType = LOW_HIGH;
	else
		_BitType = HIGH_LOW;
	Uni2Hex(_ConType, _BitType);
}



//ת��
void Uni2Hex(int ConType, int BitType)
{
	wchar_t WideStr[4096];  //Unicode�ַ���
	int CharPos;
	char BitStr[20];
	
	swprintf(WideStr, L"%S", SrcStr);
	if (ConType == SOME_CHAR)  //Ӣ���ַ���ת��
	{
		for (CharPos = 0; CharPos < wcslen(WideStr); CharPos++)
		{
			if (WideStr[CharPos] <= 0xff)
			{
				sprintf(DestStr, "%s%c", DestStr, WideStr[CharPos]);
			}
			else
			{
				sprintf(BitStr, "%x", WideStr[CharPos]);
				AddZero(BitStr, 4);
				if (BitType == HIGH_LOW) ExchangeBit(BitStr);
				sprintf(DestStr, "%s\\u%s", DestStr, BitStr);
			}
		}
	}
	else if (ConType == ALL_CHAR)  //ȫ��ת��
	{
		for (CharPos = 0; CharPos < wcslen(WideStr); CharPos++)
		{
			sprintf(BitStr, "%x", WideStr[CharPos]);
			AddZero(BitStr, 4);
			if (BitType == HIGH_LOW) ExchangeBit(BitStr);
			sprintf(DestStr, "%s\\u%s", DestStr, BitStr);
		}
	}
}



//��߲���0
void AddZero(char *SrcStr, int StrLen)
{
	int CharPos;
	char TmpStr[20];
	
	for (CharPos = 0; CharPos < StrLen - strlen(SrcStr); CharPos++)
	{
		TmpStr[CharPos] = '0';
	}
	TmpStr[CharPos] = '\0';
	strcat(TmpStr, SrcStr);
	strcpy(SrcStr, TmpStr);
}



//�����ߵ�λ
void ExchangeBit(char *SrcStr)
{
	int CharPos;
	char TmpChar;
	
	for (CharPos = 0; CharPos < strlen(SrcStr); CharPos += 4)
	{
		TmpChar = SrcStr[CharPos + 2];
		SrcStr[CharPos + 2] = SrcStr[CharPos];
		SrcStr[CharPos] = TmpChar;
		TmpChar = SrcStr[CharPos + 3];
		SrcStr[CharPos + 3] = SrcStr[CharPos + 1];
		SrcStr[CharPos + 1] = TmpChar;
	}
}
