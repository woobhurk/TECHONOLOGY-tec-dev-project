#include <stdio.h>
#include <conio.h>
#define LINE 7

int main(void)
{
	int a, b = 1, i = 0;
	
	/*for (a = 0; a < LINE; a++)
	{
		for (b = 0; b < 3 - a; b++)
			putchar(' ');
		for (b = 0; b < a * 2 + 1; b++)
			putchar('*');
		putchar('\n');
	}*/
	do
	{
		for (a = 0; a < 3 - i;  a++)
			putchar(' ');
		for (a = 0; a < i * 2 + 1; a++)
			putchar('*');
		if (i == LINE / 2) b = -1;
		i += b;
		putchar('\n');
	}
	while (i > -1);
	getch();
	return 0;
}
