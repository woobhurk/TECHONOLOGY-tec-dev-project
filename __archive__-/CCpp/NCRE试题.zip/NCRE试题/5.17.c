#include <stdio.h>
#include <conio.h>
#include "LTLib.h"

int main(void)
{
	int a, i = 1, sum = 0;

	for (a = 1; a <= 101; a += 2)
	{
		sum += a * i;
		i = -i;
	}
	printf("1-3+5-7+9-...-99+101 = %d\n", sum);
	getch();
	return 0;
}
