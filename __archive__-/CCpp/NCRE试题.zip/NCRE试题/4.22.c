#include <stdio.h>
#include <conio.h>

int main(void)
{
	int y0, m0, d0;
	int y1, m1, d1;
	int y2, m2, d2;
	
	printf("Please input the date of birth:\n");
	scanf("%d %d %d", &y0, &m0, &d0);
	printf("Please input the current date:\n");
	scanf("%d %d %d", &y1, &m1, &d1);
	d2 = d1 - d0;
	if (d2 < 0)
	{
		d2 += 31;
		--m1;
	}
	m2 = m1 - m0;
	if (m2 < 0)
	{
		m2 += 12;
		--y1;
	}
	y2 = (y1 - y0 < 0) ? 0 : (y1 - y0);
	printf("Your age: %d year(s), %d month(s), %d day(s).\n", y2, m2, d2);
	getch();
	return 0;
}
