#include <stdio.h>
#include <conio.h>

int main(void)
{
	int num;
	
	printf("Input a number: ");
	scanf("%d", &num);
	printf("The num '%d' is %s.\n", num, (num % 2) ? "����" : "ż��");
	getch();
	return 0;
}
