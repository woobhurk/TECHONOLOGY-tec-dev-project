#include <stdio.h>
#include <conio.h>

int main(void)
{
	int y, i = 0;
	
	printf("��Ԫ2000�ꡫ3000��֮��������У�\n");
	for (y = 2000; y <= 3000; y++)
	{
		if ((y % 4 == 0 && y % 100 != 0) || y % 400 == 0)
		{
			++i;
			printf("%d%c", y, (i % 10 == 0) ? '\n' : ' ');
		}
	}
	putchar('\n');
	getch();
	return 0;
}
