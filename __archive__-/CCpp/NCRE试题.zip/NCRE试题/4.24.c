#include <stdio.h>
#include <conio.h>

int main(void)
{
	int a, b, c;

	printf("Input 3 numbers:\n");
	scanf("%d %d %d", &a, &b, &c);
	if (a < b) a = b;
	if (a < c) a = c;
	printf("The maxmum is %d.\n", a);
	getch();
	return 0;
}
