#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include <windows.h>
#define ICO_MAIN 0
#define STC_WORD 100
#define STC_MEAN 110
#define EDT_SEARCH 120
#define BTN_CMD 130
#define TMR_TIMER 200

#define TIMERTIME 6000  //ʱ����
#define MAXWORDNUM 1695  //������
#define DEF_WIDTH 335
#define DEF_HEIGHT 106

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
void LoadWord(void);
int SearchWord(char *);
void UptoLower(char *);

struct
{
	char wlWord[51];
	char wlMean[51];
}WList[1700];

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nShowCmd)
{
	char *cName = TEXT("Window1");
	char *cCaption = TEXT("WordList V6.2 (c)2012 by L.W.");
	HWND hWnd;
	MSG msg;
	WNDCLASSEX wc;
	
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 0;
	wc.cbSize = sizeof(WNDCLASSEX);
	wc.style = CS_HREDRAW | CS_VREDRAW;
	wc.hbrBackground = CreateSolidBrush(0x0080ffff);
	wc.hIcon = LoadIcon(hInstance, MAKEINTRESOURCE(ICO_MAIN));
	wc.hIconSm = LoadIcon(hInstance, MAKEINTRESOURCE(ICO_MAIN));
	wc.hCursor = LoadCursor(NULL, MAKEINTRESOURCE(IDC_ARROW));
	wc.hInstance = hInstance;
	wc.lpfnWndProc = WndProc;
	wc.lpszClassName = cName;
	wc.lpszMenuName = NULL;
	RegisterClassEx(&wc);
	hWnd = CreateWindowEx(WS_EX_TOOLWINDOW, cName, cCaption, WS_VISIBLE | WS_DLGFRAME, 0, 0, DEF_WIDTH, DEF_HEIGHT, NULL, NULL, hInstance, NULL);
	if(hWnd == NULL)
	{
		MessageBox(NULL, TEXT("Cannot create the window!\n"), TEXT("Error"), MB_ICONERROR);
		return 0;
	}
	ShowWindow(hWnd, nShowCmd);
	UpdateWindow(hWnd);
	while(GetMessage(&msg, NULL, 0, 0))
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
	return msg.wParam;
}




LRESULT CALLBACK WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	static HWND stcWord, stcMean, edtSearch, btnCmd;
	static HFONT hFont;
	static LOGFONT lf;
	static int WordNum;
	static BOOL isStop = FALSE;
	static int ScreenX;
	static int WindowPos;
	HDC hDC;
	HBRUSH hBrush;
	int MouseX, MouseY;
	char ShowedStr[51];

	switch(msg)
	{
	case WM_CREATE:
		stcWord = CreateWindow(TEXT("static"), NULL, WS_CHILD | WS_VISIBLE | SS_LEFT, 0, 0, DEF_WIDTH - 5, 50, hWnd, (HMENU)STC_WORD, ((LPCREATESTRUCT)lParam) -> hInstance, NULL);
		stcMean = CreateWindow(TEXT("static"), NULL, WS_CHILD | WS_VISIBLE | SS_LEFT, 0, 50, DEF_WIDTH - 5, 15, hWnd, (HMENU)STC_MEAN, ((LPCREATESTRUCT)lParam) -> hInstance, NULL);
		edtSearch = CreateWindow(TEXT("edit"), NULL, WS_CHILD | WS_VISIBLE | ES_AUTOVSCROLL | ES_AUTOHSCROLL, 0, 65, DEF_WIDTH - 65, 20, hWnd, (HMENU)EDT_SEARCH, ((LPCREATESTRUCT)lParam) -> hInstance, NULL);
		btnCmd = CreateWindow(TEXT("button"), TEXT("Stop"), WS_CHILD | WS_VISIBLE, DEF_WIDTH - 65, 65, 60, 20, hWnd, (HMENU)BTN_CMD, ((LPCREATESTRUCT)lParam) -> hInstance, NULL);
		LoadWord();
		lstrcpy(lf.lfFaceName, "Times New Roman");
		lf.lfWeight = FW_BOLD;

		lf.lfItalic = TRUE;
		lf.lfHeight = 50;
		hFont = CreateFontIndirect(&lf);
		SendMessage(stcWord, WM_SETFONT, (WPARAM)hFont, MAKELPARAM(TRUE, 0));

		lf.lfItalic = FALSE;
		lf.lfHeight = 15;
		hFont = CreateFontIndirect(&lf);
		SendMessage(stcMean, WM_SETFONT, (WPARAM)hFont, MAKELPARAM(TRUE, 0));
		SendMessage(edtSearch, WM_SETFONT, (WPARAM)hFont, MAKELPARAM(TRUE, 0));
		SendMessage(btnCmd, WM_SETFONT, (WPARAM)hFont, MAKELPARAM(TRUE, 0));

		sprintf(ShowedStr, " %s", WList[0].wlWord);  //�ӿո���Ϊ�˷�ֹб���Ӣ����ʾ������
		SetWindowText(stcWord, ShowedStr);
		sprintf(ShowedStr, "1     %s", WList[0].wlMean);
		SetWindowText(stcMean, ShowedStr);
		SetTimer(hWnd, TMR_TIMER, TIMERTIME, NULL);
		WordNum = 0;
		ScreenX = GetSystemMetrics(SM_CXSCREEN);
		WindowPos = 0;
		SetWindowPos(hWnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
		return 0;
	/*case WM_CTLCOLORBTN:
		hDC = (HDC)wParam;
		SetTextColor(hDC, 0x000000ff);
		//SetBkMode(hDC, TRANSPARENT);
		SetBkColor(hDC, 0x00ff8000);
		return (long)CreateSolidBrush(0x00ff8000);*/
	case WM_CTLCOLORSTATIC:
		hDC = (HDC)wParam;
		SetBkMode(hDC, TRANSPARENT);
		if((HWND)lParam == stcWord) SetTextColor(hDC, 0x000000ff);  //�����ʿ�Ϊ��ɫ
		hBrush = CreateSolidBrush(0x0080ffff);
		SelectObject(hDC, hBrush);
		Rectangle(hDC, -1, -1, DEF_WIDTH - 5, 51);  //����
		DeleteObject(hBrush);
		return (long)(HBRUSH)GetStockObject(NULL_BRUSH);
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{
		case EDT_SEARCH:
			if(HIWORD(wParam) == EN_CHANGE)
			{
				char WordStr[51];
				int cnt;

				GetWindowText(edtSearch, WordStr, 50);
				WordStr[50] = '\0';
				if((cnt = SearchWord(WordStr)) == -1) return 0;
				SetWindowText(stcWord, WList[cnt].wlWord);
				SetWindowText(stcMean, WList[cnt].wlMean);
				if(!isStop)
				{
					KillTimer(hWnd, TMR_TIMER);
					SetTimer(hWnd, TMR_TIMER, TIMERTIME, NULL);  //���¼�ʱ
				}
			}
			break;
		case BTN_CMD:
			isStop = !isStop;
			if(isStop) KillTimer(hWnd, TMR_TIMER);
			else SetTimer(hWnd, TMR_TIMER, TIMERTIME, NULL);
			SetWindowText(btnCmd, isStop ? TEXT("Continue") : TEXT("Stop"));
			break;
		}
		SetWindowPos(hWnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
		return 0;
	case WM_TIMER:  //˳��ȡ��
		++WordNum;
		if(WordNum >= MAXWORDNUM)
		{
			SetWindowText(stcWord, TEXT("��ʾ���"));
			SetWindowText(stcMean, NULL);
			SetWindowPos(hWnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
			WordNum = -1;
			return 0;
		}
		sprintf(ShowedStr, " %s", WList[WordNum].wlWord);
		SetWindowText(stcWord, ShowedStr);
		sprintf(ShowedStr, "%-4d %s", WordNum + 1, WList[WordNum].wlMean);
		SetWindowText(stcMean, ShowedStr);
		SetWindowPos(hWnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
		return 0;
	case WM_MOUSEMOVE:
		if(WindowPos) MoveWindow(hWnd, 0, 0, DEF_WIDTH, DEF_HEIGHT, TRUE);
		else MoveWindow(hWnd, ScreenX - DEF_WIDTH, 0, DEF_WIDTH, DEF_HEIGHT, TRUE);
		WindowPos = !WindowPos;
		//MessageBeep(MB_ICONERROR);
		Beep(4444, 400);
		return 0;
	/*case WM_NCMOUSEMOVE:
		;
		POINT pt;
		MouseX = LOWORD(lParam);
		MouseY = HIWORD(lParam);
		pt.x = MouseX;
		pt.y = MouseY;
		ScreenToClient(hWnd, &pt);
		MouseX = pt.x;
		MouseY = pt.y;
		if(MouseX < 10 && MouseY < 10) return 0;
		if(!WindowPos) MoveWindow(hWnd, 0, 0, 248, 110, TRUE);
		else MoveWindow(hWnd, ScreenX - 250, 0, 248, 110, TRUE);
		WindowPos = !WindowPos;
		return 0;*/
	case WM_NCLBUTTONDOWN:
	case WM_NCRBUTTONDOWN:
		if(WindowPos) MoveWindow(hWnd, 0, 0, DEF_WIDTH, DEF_HEIGHT, TRUE);
		else MoveWindow(hWnd, ScreenX - DEF_WIDTH, 0, DEF_WIDTH, DEF_HEIGHT, TRUE);
		WindowPos = !WindowPos;
		//MessageBeep(MB_ICONERROR);
		Beep(4444, 400);
		return 0;
	case WM_NCMBUTTONDOWN:
		;
		POINT pt;

		MouseX = LOWORD(lParam);
		MouseY = HIWORD(lParam);
		pt.x = MouseX;
		pt.y = MouseY;
		ScreenToClient(hWnd, &pt);
		MouseX = pt.x;
		MouseY = pt.y;
		if(MouseX < 10 && MouseY < 10) PostQuitMessage(0);
		return 0;
	case WM_CLOSE:
	case WM_DESTROY:
		return 0;
	}
	return DefWindowProc(hWnd, msg, wParam, lParam);
}




void LoadWord(void)
{
	FILE *datFile;
	int WordNum = 0;
	//char tmp[50];

	if((datFile = fopen("WLData.dat", "rt")) == NULL) for(;;) ++WordNum;
	while(!feof(datFile))
	{
		//fgets(tmp, 50, datFile);
		//tmp[strchr(tmp, ' ')] = '\0';
		//strcpy(WList[WordNum].wlWord, tmp);
		//strcpy(Wlist[WordNum].wlMean, tmp + strlen(tmp) + 1);
		fscanf(datFile, "%s%s", WList[WordNum].wlWord, WList[WordNum].wlMean);
		++WordNum;
	}
}




int SearchWord(char *WordStr)
{
	int WordNum;
	char tmpStr[51];

	if(strlen(WordStr) == 0) return -1;
	for(WordNum = 0; WordNum < MAXWORDNUM; WordNum++)
	{
		strcpy(tmpStr, WList[WordNum].wlWord);
		tmpStr[strlen(WordStr)] = '\0';
		UptoLower(WordStr);
		UptoLower(tmpStr);
		if(!strcmp(WordStr, tmpStr)) return WordNum;
	}
	return -1;
}




void UptoLower(char *str)
{
	int cnt;

	for(cnt = 0; str[cnt]; cnt++) tolower(str[cnt]);
}
