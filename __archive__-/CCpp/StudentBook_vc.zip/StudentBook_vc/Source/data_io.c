/***********
 * data_io.c
 * ���û���ȡ���ݻ�������ݡ�
 */

#include <stdio.h>
#include <stdlib.h>
#include "data.h"
#include "data_get.h"
#include "data_io.h"
#include "utils.h"
#include "types.h"
#include "const.h"
#include "global.h"


/***********
 * inputData
 " - ��ȡ��Ϣ
 * ����
 * - data Ŀ������
 * - mode ����ģʽ
 * -   INPUT_DATA_ADD �������ݣ�ѧ�Ų����ظ���Ϊ��
 * -   INPUT_DATA_ADD �޸����ݣ�ѧ�Ų����ظ�
 */
void inputData(STUDATA *data, int mode)
{
    char s_years[STR_SIZE];
    BOOL loop;

    do
    {
        loop = FALSE;
        printf("ѧ�ţ�  ");
        gets(data->stuNum);

        if (mode == INPUT_DATA_ADD && EMPTYSTR(data->stuNum))
        {
            puts("ѧ��Ϊ��!");
            loop = TRUE;
            continue;
        }
        if (!EMPTYSTR(data->stuNum) && getDataAddr(data->stuNum) != NULL)
        {
            puts("ѧ���Ѵ���!");
            loop = TRUE;
            continue;
        }
    }
    while (loop);

    data->stuNum[STR_SIZE - 1] = '\0';
    printf("������  ");
    gets(data->name);
    data->name[STR_SIZE - 1] = '\0';
    printf("����֤��");
    gets(data->stuId);
    data->stuId[STR_SIZE - 1] = '\0';
    strToUpper(data->stuId);
    printf("�༶��  ");
    gets(data->className);
    data->className[STR_SIZE - 1] = '\0';
    printf("ѧԺ��  ");
    gets(data->institute);
    data->institute[STR_SIZE - 1] = '\0';;
    printf("רҵ��  ");
    gets(data->major);
    data->major[STR_SIZE - 1] = '\0';
    printf("ѧ�ƣ�  ");
    gets(s_years);
    s_years[STR_SIZE - 1] = '\0';
    data->years = atoi(s_years);
    printf("�绰��  ");
    gets(data->phoneNum);
    data->phoneNum[STR_SIZE - 1] = '\0';
    printf("QQ�ţ�  ");
    gets(data->qqNum);
    data->qqNum[STR_SIZE - 1] = '\0';
    printf("E-Mail��");
    gets(data->email);
    data->email[STR_SIZE - 1] = '\0';
    printf("���᣺  ");
    gets(data->domitory);
    data->domitory[STR_SIZE - 1] = '\0';
    printf("���᣺  ");
    gets(data->origion);
    data->origion[STR_SIZE - 1] = '\0';

    #ifdef TCC
        INPUT_DATA(data->stuNum);
        INPUT_DATA(data->name);
        INPUT_DATA(data->stuId);
        INPUT_DATA(data->className);
        INPUT_DATA(data->institute);
        INPUT_DATA(data->major);
        INPUT_DATA(data->phoneNum);
        INPUT_DATA(data->qqNum);
        INPUT_DATA(data->email);
        INPUT_DATA(data->domitory);
        INPUT_DATA(data->origion);
    #endif
}




/***********
 * printData
 * - ��ʾ����
 */
void printData(const STUDATA *data)
{
    puts("------------------------------------------------------------------");
    printf("ѧ��:   %s\n", data->stuNum);
    printf("����:   %s\n", data->name);
    printf("����֤: %s\n", data->stuId);
    printf("�༶:   %s\n", data->className);
    printf("ѧԺ:   %s\n", data->institute);
    printf("רҵ:   %s\n", data->major);
    printf("ѧ��:   %d\n", data->years);
    printf("�绰:   %s\n", data->phoneNum);
    printf("QQ��:   %s\n", data->qqNum);
    printf("E-Mail: %s\n", data->email);
    printf("����:   %s\n", data->domitory);
    printf("����:   %s\n", data->origion);
}
