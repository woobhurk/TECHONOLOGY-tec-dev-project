/*************
 * data_move.c
 * �ƶ����ݡ�
 */

#include <stdio.h>
//#include <conio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include "data.h"
#include "data_move.h"
#include "data_get.h"
#include "utils.h"
#include "types.h"
#include "const.h"
#include "global.h"


/****************
 * getMoveSrcData
 * - ��ȡҪ�ƶ������ݵ�ַ
 * ����
 * - Ҫ�ƶ������ݵ�ַ
 */
STUDATA *getMoveSrcData()
{
    STUDATA *srcData;
    char stuNum[STR_SIZE];
    char s_id[STR_SIZE];
    char choice;

    puts("��ѡ��λ��ʽ:");
    puts("a. ѧ��   b. ���");
    choice = tolower(getch());

    if (choice < 'a' || choice > 'b')
    {
        return NULL;
    }

    switch (choice)
    {
    case 'a':
        puts("������ѧ��:");
        gets(stuNum);
        stuNum[STR_SIZE - 1] = '\0';

        if (EMPTYSTR(stuNum))
        {
            puts("ѧ��Ϊ��!");
            srcData = NULL;
            break;
        }

        srcData = getDataAddr(stuNum);

        if (srcData == NULL)
        {
            puts("δ�ҵ�ѧ��!");
            break;
        }

        break;
    case 'b':
        puts("��������:");
        gets(s_id);
        s_id[STR_SIZE - 1] = '\0';

        if (EMPTYSTR(s_id))
        {
            puts("���Ϊ��!");
            srcData = NULL;
            break;
        }

        srcData = getDataAddrById(atoi(s_id));

        if (srcData == NULL)
        {
            puts("δ�ҵ����!");
            break;
        }

        break;
    default:
        break;
    }

    return srcData;
}




int getMoveDest()
{
    int moveDest;
    char choice;

    puts("�ƶ���:");
    puts("a. ��Ϣ��ͷ   b. ĳѧ��֮��   c. ĳ���֮��   d. ��Ϣ��β");
    choice = tolower(getch());

    if (choice < 'a' || choice > 'd')
    {
        moveDest = -1;
    }
    else
    {
        switch (choice)
        {
        case 'a':
            moveDest = MOVE_DATA_HEADER;
            break;
        case 'b':
            moveDest = MOVE_DATA_STUNUM;
            break;
        case 'c':
            moveDest = MOVE_DATA_ID;
            break;
        case 'd':
            moveDest = MOVE_DATA_TAIL;
            break;
        default:
            break;
        }
    }

    return moveDest;
}




/*****************
 * getMoveDestData
 * - ��ȡĿ��λ�õ����ݵ�ַ
 * ����:
 *   moveDest �ƶ�λ��
 *   srcData ԭ���ݵ�ַ
 * ����
 *   �ƶ��������ݵ�ַ
 */
STUDATA *getMoveDestData(int moveDest, STUDATA *srcData)
{
    STUDATA *destData;
    char stuNum[STR_SIZE];
    char s_id[STR_SIZE];

    switch (moveDest)
    {
    case MOVE_DATA_HEADER:
        if (srcData == dataHeader)
        {
            puts("Ŀ��λ����ԭλ����ͬ.");
            destData = NULL;
        }
        else
        {
            destData = dataHeader;
        }

        break;
    case MOVE_DATA_STUNUM:
        puts("������ѧ��:");
        gets(stuNum);
        stuNum[STR_SIZE - 1] = '\0';

        if (EMPTYSTR(stuNum))
        {
            puts("ѧ��Ϊ��!\n");
            destData = NULL;
            break;
        }

        destData = getDataAddr(stuNum);

        if (destData == NULL)
        {
            puts("ѧ�Ų�����!");
            break;
        }
        else if (destData == srcData)
        {
            puts("Ŀ��λ����ԭλ����ͬ.");
            destData = NULL;
            break;
        }

        break;
    case MOVE_DATA_ID:
        puts("��������:");
        gets(s_id);
        s_id[STR_SIZE - 1] = '\0';

        if (EMPTYSTR(s_id))
        {
            puts("ѧ��Ϊ��!\n");
            destData = NULL;
            break;
        }

        destData = getDataAddrById(atoi(s_id));

        if (destData == NULL)
        {
            puts("ѧ�Ų�����!");
            break;
        }
        else if (destData == srcData)
        {
            puts("Ŀ��λ����ԭλ����ͬ.");
            destData = NULL;
            break;
        }

        break;
    case MOVE_DATA_TAIL:
        if (srcData == dataTail)
        {
            puts("Ŀ��λ����ԭλ����ͬ.");
            destData = NULL;
            break;
        }
        else
        {
            destData = dataTail;
        }

        break;
    default:
        break;
    }

    return destData;
}




/************
 * moveDataTo
 * - �ƶ����ݵ�ָ��λ��
 * ����
 * - srcData Ҫ�ƶ�������
 */
void moveDataTo(int moveDest, STUDATA *srcData, STUDATA *destData)
{
    STUDATA *srcPrevData;
    STUDATA *tailPrevData;

    srcPrevData = getPrevDataAddr(srcData->stuNum);
    tailPrevData = getPrevDataAddr(dataTail->stuNum);

    switch (moveDest)
    {
    case MOVE_DATA_HEADER:
        if (srcData == dataTail)
        {
            dataTail = tailPrevData;
            dataTail->next = NULL;
        }
        else
        {
            srcPrevData->next = srcData->next;
        }

        srcData->next = dataHeader;
        dataHeader = srcData;
        break;
    case MOVE_DATA_STUNUM:
    case MOVE_DATA_ID:
        if (srcData == dataHeader)
        {
            // �ƶ�ͷ
            dataHeader = srcData->next;

            if (destData == dataTail)
            {
                // ͷ�ƶ���β
                dataTail->next = srcData;
                dataTail = srcData;
                dataTail->next = NULL;
            }
            else
            {
                // ͷ�ƶ����м�
                srcData->next = destData->next;
                destData->next = srcData;
            }
        }
        else if (srcData == dataTail)
        {
            // �ƶ�β
            dataTail = tailPrevData;
            dataTail->next = NULL;

            if (destData == dataHeader)
            {
                // β�ƶ���ͷ
                srcData->next = dataHeader;
                dataHeader = srcData;
            }
            else
            {
                // β�ƶ����м�
                srcData->next = destData->next;
                destData->next = srcData;
            }
        }
        else
        {
            // �ƶ��м�
            srcPrevData->next = srcData->next;

            if (destData == dataHeader)
            {
                // �м��ƶ���ͷ
                srcData->next = dataHeader;
                dataHeader = srcData;
            }
            else if (destData == dataTail)
            {
                // �м��ƶ���β
                dataTail->next = srcData;
                dataTail = srcData;
                dataTail->next = NULL;
            }
            else
            {
                // �м��ƶ����м�
                srcData->next = destData->next;
                destData->next = srcData;
            }
        }

        break;
    case MOVE_DATA_TAIL:
        if (srcData == dataHeader)
        {
            dataHeader = srcData->next;
        }
        else
        {
            srcPrevData->next = srcData->next;
        }

        dataTail->next = srcData;
        dataTail = srcData;
        dataTail->next = NULL;
        break;
    default:
        break;
    }
}
