/*************
 * data_move.c
 * 移动数据。
 */

#include <stdio.h>
//#include <conio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include "data.h"
#include "data_move.h"
#include "data_get.h"
#include "utils.h"
#include "types.h"
#include "const.h"
#include "global.h"


/****************
 * getMoveSrcData
 * - 获取要移动的数据地址
 * 返回
 * - 要移动的数据地址
 */
STUDATA *getMoveSrcData()
{
    STUDATA *srcData;
    char stuNum[STR_SIZE];
    char s_id[STR_SIZE];
    char choice;

    puts("请选择定位方式:");
    puts("a. 学号   b. 编号");
    choice = tolower(getch());

    if (choice < 'a' || choice > 'b')
    {
        return NULL;
    }

    switch (choice)
    {
    case 'a':
        puts("请输入学号:");
        gets(stuNum);
        stuNum[STR_SIZE - 1] = '\0';

        if (EMPTYSTR(stuNum))
        {
            puts("学号为空!");
            srcData = NULL;
            break;
        }

        srcData = getDataAddr(stuNum);

        if (srcData == NULL)
        {
            puts("未找到学号!");
            break;
        }

        break;
    case 'b':
        puts("请输入编号:");
        gets(s_id);
        s_id[STR_SIZE - 1] = '\0';

        if (EMPTYSTR(s_id))
        {
            puts("编号为空!");
            srcData = NULL;
            break;
        }

        srcData = getDataAddrById(atoi(s_id));

        if (srcData == NULL)
        {
            puts("未找到编号!");
            break;
        }

        break;
    default:
        break;
    }

    return srcData;
}




int getMoveDest()
{
    int moveDest;
    char choice;

    puts("移动到:");
    puts("a. 信息簿头   b. 某学号之后   c. 某编号之后   d. 信息簿尾");
    choice = tolower(getch());

    if (choice < 'a' || choice > 'd')
    {
        moveDest = -1;
    }
    else
    {
        switch (choice)
        {
        case 'a':
            moveDest = MOVE_DATA_HEADER;
            break;
        case 'b':
            moveDest = MOVE_DATA_STUNUM;
            break;
        case 'c':
            moveDest = MOVE_DATA_ID;
            break;
        case 'd':
            moveDest = MOVE_DATA_TAIL;
            break;
        default:
            break;
        }
    }

    return moveDest;
}




/*****************
 * getMoveDestData
 * - 获取目标位置的数据地址
 * 参数:
 *   moveDest 移动位置
 *   srcData 原数据地址
 * 返回
 *   移动到的数据地址
 */
STUDATA *getMoveDestData(int moveDest, STUDATA *srcData)
{
    STUDATA *destData;
    char stuNum[STR_SIZE];
    char s_id[STR_SIZE];

    switch (moveDest)
    {
    case MOVE_DATA_HEADER:
        if (srcData == dataHeader)
        {
            puts("目标位置与原位置相同.");
            destData = NULL;
        }
        else
        {
            destData = dataHeader;
        }

        break;
    case MOVE_DATA_STUNUM:
        puts("请输入学号:");
        gets(stuNum);
        stuNum[STR_SIZE - 1] = '\0';

        if (EMPTYSTR(stuNum))
        {
            puts("学号为空!\n");
            destData = NULL;
            break;
        }

        destData = getDataAddr(stuNum);

        if (destData == NULL)
        {
            puts("学号不存在!");
            break;
        }
        else if (destData == srcData)
        {
            puts("目标位置与原位置相同.");
            destData = NULL;
            break;
        }

        break;
    case MOVE_DATA_ID:
        puts("请输入编号:");
        gets(s_id);
        s_id[STR_SIZE - 1] = '\0';

        if (EMPTYSTR(s_id))
        {
            puts("学号为空!\n");
            destData = NULL;
            break;
        }

        destData = getDataAddrById(atoi(s_id));

        if (destData == NULL)
        {
            puts("学号不存在!");
            break;
        }
        else if (destData == srcData)
        {
            puts("目标位置与原位置相同.");
            destData = NULL;
            break;
        }

        break;
    case MOVE_DATA_TAIL:
        if (srcData == dataTail)
        {
            puts("目标位置与原位置相同.");
            destData = NULL;
            break;
        }
        else
        {
            destData = dataTail;
        }

        break;
    default:
        break;
    }

    return destData;
}




/************
 * moveDataTo
 * - 移动数据到指定位置
 * 参数
 * - srcData 要移动的数据
 */
void moveDataTo(int moveDest, STUDATA *srcData, STUDATA *destData)
{
    STUDATA *srcPrevData;
    STUDATA *tailPrevData;

    srcPrevData = getPrevDataAddr(srcData->stuNum);
    tailPrevData = getPrevDataAddr(dataTail->stuNum);

    switch (moveDest)
    {
    case MOVE_DATA_HEADER:
        if (srcData == dataTail)
        {
            dataTail = tailPrevData;
            dataTail->next = NULL;
        }
        else
        {
            srcPrevData->next = srcData->next;
        }

        srcData->next = dataHeader;
        dataHeader = srcData;
        break;
    case MOVE_DATA_STUNUM:
    case MOVE_DATA_ID:
        if (srcData == dataHeader)
        {
            // 移动头
            dataHeader = srcData->next;

            if (destData == dataTail)
            {
                // 头移动到尾
                dataTail->next = srcData;
                dataTail = srcData;
                dataTail->next = NULL;
            }
            else
            {
                // 头移动到中间
                srcData->next = destData->next;
                destData->next = srcData;
            }
        }
        else if (srcData == dataTail)
        {
            // 移动尾
            dataTail = tailPrevData;
            dataTail->next = NULL;

            if (destData == dataHeader)
            {
                // 尾移动到头
                srcData->next = dataHeader;
                dataHeader = srcData;
            }
            else
            {
                // 尾移动到中间
                srcData->next = destData->next;
                destData->next = srcData;
            }
        }
        else
        {
            // 移动中间
            srcPrevData->next = srcData->next;

            if (destData == dataHeader)
            {
                // 中间移动到头
                srcData->next = dataHeader;
                dataHeader = srcData;
            }
            else if (destData == dataTail)
            {
                // 中间移动到尾
                dataTail->next = srcData;
                dataTail = srcData;
                dataTail->next = NULL;
            }
            else
            {
                // 中间移动到中间
                srcData->next = destData->next;
                destData->next = srcData;
            }
        }

        break;
    case MOVE_DATA_TAIL:
        if (srcData == dataHeader)
        {
            dataHeader = srcData->next;
        }
        else
        {
            srcPrevData->next = srcData->next;
        }

        dataTail->next = srcData;
        dataTail = srcData;
        dataTail->next = NULL;
        break;
    default:
        break;
    }
}
