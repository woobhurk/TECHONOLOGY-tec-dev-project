/********
 * main.c
 * 主界面和杂项操作。
 */

#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <ctype.h>
#include "main.h"
#include "book.h"
#include "data.h"
#include "types.h"
#include "const.h"
#include "global.h"


char bookName[STR_SIZE];
STUDATA *dataHeader;
STUDATA *dataTail;
int dataCount;
BOOL fileOpened;
BOOL fileModified;


int main()
{
    initVars();

    while (TRUE)
    {
        showMenu();
        getOperation();
    }

    return 0;
}




/**********
 * initVars
 * - 初始化数据
 */
void initVars()
{
    dataHeader = NULL;
    dataTail = NULL;
    dataCount = 0;
    fileOpened = FALSE;
    fileModified = FALSE;
}




/**********
 * showMenu
 * - 显示菜单
 */
void showMenu()
{
    //printf("---- %d, %d, %d, %d\n", strncmpEx("abc", "aBCD", 3), strncmpEx("ab", "aBCdEf", 3), strncmp("ef", "eGf", 10), strncmpEx("ancGs", "Anc", 20));
    puts("##################################################################");
    puts("#                          学 生 信 息 簿                        #");
    puts("# 文件                                                           #");
    puts("#  n. 新建      o. 打开     s. 保存     S. 另存为      c. 关闭   #");
    puts("#  E. 退出                                                       #");
    puts("# 数据                                                           #");
    puts("#  l. 列出      a. 添加     f. 查找     m. 修改        d. 删除   #");
    puts("#  v. 移动      p. 属性     C. 清屏                              #");
    puts("##################################################################");

    // 显示打开的文件
    if (fileOpened)
    {
        printf("# <%s>%c\n", bookName, fileModified ? '*' : ' ');
    }

    puts("请选择操作: ");
}




/**************
 * getOperation
 * - 获取用户操作
 */
void getOperation()
{
    char op;
    BOOL loop;

    do
    {
        loop = FALSE;
        op = getch();

        switch (op)
        {
        case 'n':
            newBook();
            break;
        case 'o':
            openBook();
            break;
        case 's':
            saveBook();
            break;
        case 'S':
            saveBookAs();
            break;
        case 'c':
            closeBook();
            break;
        case 'E':
            exitProg();
            break;
        case 'l':
            listData();
            break;
        case 'a':
            addData();
            break;
        case 'f':
            searchData();
            break;
        case 'm':
            modifyData();
            break;
        case 'd':
            deleteData();
            break;
        case 'v':
            moveData();
            break;
        case 'p':
            bookProperty();
            break;
        case 'C':
            clearScreen();
            return;
            break;
        default:
            loop = TRUE;
            break;
        }
    }
    while (loop);

    puts("任意键返回...");
    getch();
    puts("\n\n");
}




/**********
 * exitProg
 * - 退出程序
 */
void exitProg()
{
    puts("[退出程序]");

    if (fileOpened && fileModified)
    {
        askToSave();
    }

    exit(0);
}




/*************
 * clearScreen
 * - 清屏
 */
void clearScreen()
{
    #ifdef LINUX
        system("clear");
    #else
        system("cls");
    #endif
}
