#ifndef UTILS_H
#define UTILS_H

#include <stdio.h>


long getFileSize(FILE *);
char *strToUpper(char *);
int strcmpEx(const char *, const char *);
int strncmpEx(const char *, const char *, int);
char *strstrEx(const char *, const char *);
#endif /* utils.h */
