#ifndef DATA_IO_H
#define DATA_IO_H

#include "types.h"


void inputData(STUDATA *, int);
void printData(const STUDATA *);
#endif /* data_io.h */
