/***********
 * data_io.c
 * 从用户读取数据或输出数据。
 */

#include <stdio.h>
#include <stdlib.h>
#include "data.h"
#include "data_get.h"
#include "data_io.h"
#include "utils.h"
#include "types.h"
#include "const.h"
#include "global.h"


/***********
 * inputData
 " - 读取信息
 * 参数
 * - data 目标数据
 * - mode 输入模式
 * -   INPUT_DATA_ADD 增加数据，学号不能重复或为空
 * -   INPUT_DATA_ADD 修改数据，学号不能重复
 */
void inputData(STUDATA *data, int mode)
{
    char s_years[STR_SIZE];
    BOOL loop;

    do
    {
        loop = FALSE;
        printf("学号：  ");
        gets(data->stuNum);

        if (mode == INPUT_DATA_ADD && EMPTYSTR(data->stuNum))
        {
            puts("学号为空!");
            loop = TRUE;
            continue;
        }
        if (!EMPTYSTR(data->stuNum) && getDataAddr(data->stuNum) != NULL)
        {
            puts("学号已存在!");
            loop = TRUE;
            continue;
        }
    }
    while (loop);

    data->stuNum[STR_SIZE - 1] = '\0';
    printf("姓名：  ");
    gets(data->name);
    data->name[STR_SIZE - 1] = '\0';
    printf("身份证：");
    gets(data->stuId);
    data->stuId[STR_SIZE - 1] = '\0';
    strToUpper(data->stuId);
    printf("班级：  ");
    gets(data->className);
    data->className[STR_SIZE - 1] = '\0';
    printf("学院：  ");
    gets(data->institute);
    data->institute[STR_SIZE - 1] = '\0';;
    printf("专业：  ");
    gets(data->major);
    data->major[STR_SIZE - 1] = '\0';
    printf("学制：  ");
    gets(s_years);
    s_years[STR_SIZE - 1] = '\0';
    data->years = atoi(s_years);
    printf("电话：  ");
    gets(data->phoneNum);
    data->phoneNum[STR_SIZE - 1] = '\0';
    printf("QQ号：  ");
    gets(data->qqNum);
    data->qqNum[STR_SIZE - 1] = '\0';
    printf("E-Mail：");
    gets(data->email);
    data->email[STR_SIZE - 1] = '\0';
    printf("宿舍：  ");
    gets(data->domitory);
    data->domitory[STR_SIZE - 1] = '\0';
    printf("籍贯：  ");
    gets(data->origion);
    data->origion[STR_SIZE - 1] = '\0';

    #ifdef TCC
        INPUT_DATA(data->stuNum);
        INPUT_DATA(data->name);
        INPUT_DATA(data->stuId);
        INPUT_DATA(data->className);
        INPUT_DATA(data->institute);
        INPUT_DATA(data->major);
        INPUT_DATA(data->phoneNum);
        INPUT_DATA(data->qqNum);
        INPUT_DATA(data->email);
        INPUT_DATA(data->domitory);
        INPUT_DATA(data->origion);
    #endif
}




/***********
 * printData
 * - 显示数据
 */
void printData(const STUDATA *data)
{
    puts("------------------------------------------------------------------");
    printf("学号:   %s\n", data->stuNum);
    printf("姓名:   %s\n", data->name);
    printf("身份证: %s\n", data->stuId);
    printf("班级:   %s\n", data->className);
    printf("学院:   %s\n", data->institute);
    printf("专业:   %s\n", data->major);
    printf("学制:   %d\n", data->years);
    printf("电话:   %s\n", data->phoneNum);
    printf("QQ号:   %s\n", data->qqNum);
    printf("E-Mail: %s\n", data->email);
    printf("宿舍:   %s\n", data->domitory);
    printf("籍贯:   %s\n", data->origion);
}
