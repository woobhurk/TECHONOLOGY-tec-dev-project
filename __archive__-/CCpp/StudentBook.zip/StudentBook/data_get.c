/************
 * data_get.c
 * 获取数据地址。
 */

#include <stdio.h>
#include <string.h>
#include "data.h"
#include "data_get.h"
#include "utils.h"
#include "types.h"
//#include "const.h"
#include "global.h"


/******************************
 * getPrevDataAddr -> STUDATA *
 * - 通过学号查找前一个节点的地址
 * 参数
 * - stuNum 学号
 * 返回
 * - 该节点的地址
 */
STUDATA *getPrevDataAddr(const char *stuNum)
{
    STUDATA *data;
    STUDATA *prevData;

    prevData = dataHeader;
    data = dataHeader;

    while (data != NULL && strncmpEx(stuNum, data->stuNum, strlen(stuNum)) != 0)
    {
        prevData = data;
        data = data->next;
    }

    return prevData;
}




/**************************
 * getDataAddr -> STUDATA *
 * - 通过学号查找节点地址
 * 参数
 * - stuNum 学号
 * 返回
 * - 该节点的地址
 */
STUDATA *getDataAddr(const char *stuNum)
{
    STUDATA *data;

    data = dataHeader;

    while (data != NULL && strncmpEx(stuNum, data->stuNum, strlen(stuNum)) != 0)
    {
        data = data->next;
    }

    return data;
}




/**********************************
 * getPrevDataAddrById -> STUDATA *
 * - 通过内部编号查找前一个节点的地址
 * 参数
 * - id 内部编号
 * 返回
 * - 该节点的地址
 */
STUDATA *getPrevDataAddrById(int id)
{
    STUDATA *prevData;
    STUDATA *data;
    int curId;

    prevData = dataHeader;
    data = dataHeader;
    curId = 0;

    while (data != NULL && curId != id)
    {
        curId++;
        prevData = data;
        data = data->next;
    }

    return prevData;
}




/******************************
 * getDataAddrById -> STUDATA *
 * - 通过内部编号查找节点的地址
 * 参数
 * - id 内部编号
 * 返回
 * - 该节点地址
 */
STUDATA *getDataAddrById(int id)
{
    STUDATA *data;
    int curId;

    data = dataHeader;
    curId = 0;

    while (data != NULL && curId != id)
    {
        curId++;
        data = data->next;
    }

    return data;
}
