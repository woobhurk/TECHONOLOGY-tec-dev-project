/************
 * data_add.c
 * 添加数据。
 */

#include <stdio.h>
//#include <conio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include "data.h"
#include "data_add.h"
#include "data_get.h"
#include "data_io.h"
#include "utils.h"
#include "types.h"
#include "const.h"
#include "global.h"


/************
 * getAddDest
 * - 获取插入位置
 * 返回
 * - 插入位置
 */
int getAddDest()
{
    int addDest;
    char choice;

    puts("添加位置:");
    puts("a. 信息簿头   b. 某学号之后   c. 某编号之后   d. 信息簿尾");

    do
    {
        choice = tolower(getch());
    }
    while (choice < 'a' || choice > 'd');

    switch (choice)
    {
    case 'a':
        addDest = ADD_DATA_HEADER;
        break;
    case 'b':
        addDest = ADD_DATA_STUNUM;
        break;
    case 'c':
        addDest = ADD_DATA_ID;
        break;
    case 'd':
        addDest = ADD_DATA_TAIL;
        break;
    default:
        break;
    }

    return addDest;
}




/***************
 * getAddPosAddr
 * - 获取插入位置的地址
 * 参数
 * - addPos 插入位置
 * 返回
 * - 插入位置的地址
 */
STUDATA *getAddDestData(int addDest)
{
    STUDATA *destData;
    char stuNum[STR_SIZE];
    char s_id[STR_SIZE];
    BOOL loop;

    switch (addDest)
    {
    case ADD_DATA_HEADER:
        destData = dataHeader;
        break;
    case ADD_DATA_STUNUM:
        // 如果数据错误则循环，而不是直接返回，输入的防止信息丢失
        do
        {
            loop = FALSE;
            puts("请输入学号:");
            gets(stuNum);
            stuNum[STR_SIZE - 1] = '\0';

            if (EMPTYSTR(stuNum))
            {
                puts("学号为空!");
                loop = TRUE;
            }

            destData = getDataAddr(stuNum);

            if (destData == NULL)
            {
                puts("未找到学号!");
                loop = TRUE;
            }
        }
        while (loop);

        break;
    case ADD_DATA_ID:
        // 如果数据错误则循环，而不是直接返回，输入的防止信息丢失
        do
        {
            loop = FALSE;
            puts("请输入编号:");
            gets(s_id);
            s_id[STR_SIZE - 1] = '\0';

            if (EMPTYSTR(s_id))
            {
                puts("编号为空!");
                loop = TRUE;
            }

            destData = getDataAddrById(atoi(s_id));

            if (destData == NULL)
            {
                puts("未找到编号!");
                loop = TRUE;
            }
        }
        while (loop);

        break;
    case ADD_DATA_TAIL:
        destData = dataHeader;
        break;
    default:
        break;
    }

    return destData;
}




/***********
 * addDataTo
 * - 添加数据到指定位置
 * 参数
 * - addPos 插入位置
 * - newData 要添加的数据
 * - prevData 插入位置的地址
 */
void addDataTo(int addDest, STUDATA *newData, STUDATA *destData)
{
    switch (addDest)
    {
    case ADD_DATA_HEADER:
        if (dataHeader == NULL)
        {
            dataTail = newData;
        }

        newData->next = dataHeader;
        dataHeader = newData;
        break;
    case ADD_DATA_STUNUM:
    case ADD_DATA_ID:
        newData->next = destData->next;
        destData->next = newData;

        if (destData == dataTail)
        {
            dataTail = newData;
            dataTail->next = NULL;
        }

        break;
    case ADD_DATA_TAIL:
        dataTail->next = newData;
        dataTail = newData;
        dataTail->next = NULL;
        break;
    default:
        break;
    }
}
