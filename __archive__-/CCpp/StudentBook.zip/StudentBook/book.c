/********
 * book.c
 * 对信息簿进行操作。
 */

#include <stdio.h>
//#include <conio.h>
#include <string.h>
#include <ctype.h>
#include <malloc.h>
#include "book.h"
#include "utils.h"
#include "types.h"
#include "const.h"
#include "global.h"


/*********
 * newBook
 * - 新建信息簿
 */
void newBook()
{
    char newName[STR_SIZE];
    FILE *bookFile;
    char choice;

    puts("[新建信息簿]");

    if (fileOpened && fileModified)
    {
        askToSave();
    }

    printf("文件名: (%s)\n", BOOK_EXT);
    gets(newName);
    // 留出最后五个字符存放后缀名和'\0'
    newName[STR_SIZE - 5] = '\0';

    if (EMPTYSTR(newName))
    {
        puts("文件名为空!");
        return;
    }

    strcat(newName, BOOK_EXT);

    if ((bookFile = fopen(newName, "rb")) != NULL)
    {
        puts("文件已存在，是否删除原文件? (Y/n)");

        do
        {
            choice = tolower(getch());
        }
        while (choice != 'y' && choice != 'n');

        if (choice == 'n')
        {
            puts("未创建信息簿.");
            return;
        }
    }

    if ((bookFile = fopen(newName, "wb")) == NULL)
    {
        printf("无法打开或创建文件: %s\n", bookName);
        printf("请重试.\n");
        return;
    }

    fclose(bookFile);
    strcpy(bookName, newName);
    dataHeader = NULL;
    dataTail = NULL;
    dataCount = 0;
    fileOpened = TRUE;
    // 假设已修改，将提示保存
    fileModified = TRUE;
    puts("信息簿已创建.");
}




/**********
 * openBook
 * - 打开信息簿
 */
void openBook()
{
    STUDATA *data;
    char newName[STR_SIZE];
    FILE *bookFile;
    long bookSize;
    int count;

    puts("[打开信息簿]");

    if (fileOpened && fileModified)
    {
        askToSave();
    }

    printf("文件名: (%s)\n", BOOK_EXT);
    gets(newName);
    newName[STR_SIZE - 5] = '\0';

    //printf("------ %d, %d %d %d\n", strlen(newName), newName[0], newName[1], newName[2]);
    if (EMPTYSTR(newName))
    {
        puts("文件名为空!");
        return;
    }

    strcat(newName, BOOK_EXT);

    if ((bookFile = fopen(newName, "rb")) == NULL)
    {
        printf("无法打开文件: %s\n", newName);
        printf("文件不存在或无法读取!\n");
        return;
    }

    strcpy(bookName, newName);
    bookSize = getFileSize(bookFile);

    if (bookSize < INT_SIZE)
    {
        printf("%ld数据错误!\n", bookSize);
        fclose(bookFile);
        return;
    }

    puts("加载数据中...");
    bookFile = fopen(bookName, "rb");
    fread(&dataCount, INT_SIZE, 1, bookFile);

    if (dataCount > 0)
    {
        data = (STUDATA *)malloc(sizeof(STUDATA));
        fread(data, sizeof(STUDATA), 1, bookFile);
        data->next = NULL;
        dataHeader = data;
        count = 1;

        // 用feof的话读取的数据会出错
        //while (!feof(bookFile))
        while (count < dataCount)
        {
            data->next = (STUDATA *)malloc(sizeof(STUDATA));
            fread(data->next, sizeof(STUDATA), 1, bookFile);
            data = data->next;
            data->next = NULL;
            count++;
        }

        dataTail = data;
    }

    fclose(bookFile);
    fileOpened = TRUE;
    fileModified = FALSE;
    puts("加载完毕.");
}




/**********
 * saveBook
 * - 保存信息簿
 */
void saveBook()
{
    FILE *bookFile;
    STUDATA *data;

    puts("[保存信息簿]");

    if (!fileOpened)
    {
        puts("未打开文件.");
        return;
    }

    puts("保存中...");

    if ((bookFile = fopen(bookName, "wb")) == NULL)
    {
        printf("无法保存文件: %s\n", bookName);
        return;
    }

    fwrite(&dataCount, INT_SIZE, 1, bookFile);
    data = dataHeader;

    while (data != NULL)
    {
        fwrite(data, sizeof(STUDATA), 1, bookFile);
        data = data->next;
    }

    fclose(bookFile);
    fileModified = FALSE;
    puts("保存完毕.");
}




/************
 * saveBookAs
 * - 另存信息簿
 */
void saveBookAs()
{
    char newName[STR_SIZE];
    FILE *bookFile;
    char choice;

    puts("[信息簿另存为]");

    if (!fileOpened)
    {
        puts("未打开文件.");
        return;
    }

    printf("文件名: (%s)\n", BOOK_EXT);
    gets(newName);
    newName[STR_SIZE - 5] = '\0';

    if (EMPTYSTR(newName))
    {
        puts("文件名为空!");
        return;
    }

    strcat(newName, BOOK_EXT);

    if ((bookFile = fopen(newName, "rb")) != NULL)
    {
        puts("文件已存在，是否删除原文件? (Y/n)");

        do
        {
            choice = tolower(getch());
        }
        while (choice != 'y' && choice != 'n');

        if (choice == 'n')
        {
            puts("未另存信息簿.");
            return;
        }
    }

    if ((bookFile = fopen(newName, "wb")) == NULL)
    {
        printf("无法打开文件: %s\n", newName);
        return;
    }

    fclose(bookFile);
    strcpy(bookName, newName);
    saveBook();
    fileOpened = TRUE;
    fileModified = FALSE;
}




/***********
 * closeBook
 * - 关闭信息簿
 */
void closeBook()
{
    puts("[关闭信息簿]");

    if (!fileOpened)
    {
        puts("未打开文件.");
        return;
    }

    if (fileModified)
    {
        askToSave();
    }

    fileOpened = FALSE;
    fileModified = FALSE;
    puts("文件已关闭.");
}




/***********
 * askToSave
 * - 提示用户保存信息
 */
void askToSave()
{
    char choice;

    puts("信息簿未保存, 是否保存? (y/N)");

    do
    {
        choice = tolower(getch());
    }
    while (choice != 'y' && choice != 'n');

    if (choice == 'y')
    {
        saveBook();
    }
}




/**************
 * bookProperty
 * - 显示信息簿属性
 */
void bookProperty()
{
    long size;
    double d_size;
    char *sizeFmt;
    char *sizeExt;

    puts("[信息簿属性]");

    if (!fileOpened)
    {
        puts("未打开文件.");
        return;
    }

    size = INT_SIZE + sizeof(STUDATA) * dataCount;
    sizeFmt = "文件大小: %.2lf %s\n";

    if (size < 0x400)
    {
        d_size = (double)size;
        sizeFmt = "文件大小: %.0lf %s\n";
        sizeExt = "B";
    }
    else if (size < 0x100000)
    {
        d_size = (double)size / 0x400;
        sizeExt = "KB";
    }
    else
    {
        d_size = (double)size / 0x100000;
        sizeExt = "MB";
    }

    printf("文件名: %s\n", bookName);
    printf(sizeFmt, d_size, sizeExt);
    printf("数据数量: %d\n", dataCount);
}
