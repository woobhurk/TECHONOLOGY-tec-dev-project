/***********
 * globals.h
 * 全局用到的宏和变量。
 */

#ifndef GLOBAL_H
#define GLOBAL_H

#include "types.h"
#include "const.h"

#define LINUX
//#define TCC

#ifdef TCC
    // 判断字符串是否为空，因为tcc的gets读入的空字符串的结尾是'\n'，而gcc的是'\0'
    #define EMPTYSTR(str) (str[0] == '\0' || str[0] == '\n')
#else
    #define EMPTYSTR(str) (str[0] == '\0')
#endif


extern char bookName[STR_SIZE];
extern STUDATA *dataHeader;
extern STUDATA *dataTail;
extern int dataCount;
extern BOOL fileOpened;
extern BOOL fileModified;
#endif /* global.h */
