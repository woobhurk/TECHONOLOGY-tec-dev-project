/**
 ScriptEval
 Author: Woobhurk.
 Copyright(C)2015 Shyee Woobhurk.
 All rights reserved.
 ---------------------------------
 Version: 0.8.7 (2015.06.29 13:50)
 Chang Log:
 0. CHANGE THE NAME OF WORKGROUP.
 1. Rebuild.
 2. Some errors fixed.
 ---------------------------------
 Version: 0.8.6 (2015.05.16 11:42)
 Change Log:
 0. CHANGE THE NAME OF WORKGROUP.
 1. A little slight improvement.
 ---------------------------------
 Version: 0.8.5 (2015.05.10 11:47)
 Change Log:
 1. Change theme.
 2. Fix time showing error. :)
 3. Other small changes.
 ---------------------------------
 Version: 0.8.4 (2015.05.07 22:49)
 Change Log:
 1. Fix many bugs.
 ---------------------------------
 Version: 0.8.1 (2015.05.07 22:01)
 Change Log:
 1. Add a dialog for opening file.
 2. Other changes.
 Note:
 A 'fancy' open file dialog. :)
 ---------------------------------
 Version: 0.7.2 (2015.05.07 11:54)
 Change Log:
 1. Add secondary editor which can be used for comparing.
 2. Change the textScaleX of editors and output.
 ---------------------------------
 Version: 0.6.4 (2015.05.01 22:46)
 Change Log:
 0. The first release.
 Note:
 This application may be long-term-supported. :)
 */

package com.tsueyl.scripteval;

import android.app.*;
import android.os.*;
import android.text.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import java.io.*;

import android.content.DialogInterface;


public class MainActivity extends Activity
{
	public static final String SEV_NAME = "lwScriptEval";
	public static final String SEV_ACTIVITY = "SevActivity";
	public static final String RHI_NAME = ">> Rhino-1.7.6";
	public static final String RHI_SOURCENAME = "SevEditor";
	public static final String BSH_NAME = ">> Beanshell-2.0b4";
	public static final String DEF_CODENAME = "test_code.txt";
	public static final String DEF_RESULTNAME = "test_result.txt";
	public static final String DEF_DATEFORMAT = "yyyy-MM-dd HH:mm:ss.SSS";
	public static final int COLOR_TEXT = 0xfff0f0f0;
	public static final int COLOR_INFO = 0xffe0e0e0;
	public static final int COLOR_WARN = 0xfff08000;
	public static final int COLOR_ERROR = 0xfff04040;
	public static final int COLOR_SAVED = 0xfff0f0f0;
	public static final int COLOR_NOTSAVED = 0xfff08000;
	public static final int COLOR_FILE = 0xfff00080;
	public static final int COLOR_DIR = 0xff80f000;
	public static final int COLOR_NONE = 0xfff04040;
	public static final long TIME_SYNC_DELAY = 20;
	public static final String STR_SDCARD_NOT_FOUND = "External storage not found!";
	public static final String STR_FILE_NOT_SAVED = "File has been modified. Do you want to save changes?";
	public static final String STR_ILLEGAL_FILE_NAME = "Illegal file name!";
	public static final String STR_FILE_NOT_EXIST = "File not exist!";
	public static final String STR_NOT_A_FILE = "The path is not a name of a file!";
	public static final String STR_CANNOT_OPEN = "Cannot open this directory!";


	// Main widgets
	private View vw_code;
	private View vw_result;
	//private View vw_open;

	// Code widgets
	private ScrollView sv_codepannel;
	private Button btn_coderesult;
	private Button btn_codeclear;
	private Button btn_codeevalrhino;
	private Button btn_codeevalbsh;
	private Button btn_codeopen;
	private Button btn_codesave;
	private Button btn_codesaveas;
	private Button btn_codeexit;
	private EditText et_codename;
	private ScrollView sv_code1;
	private EditText et_code1;
	private ScrollView sv_code2;
	private EditText et_code2;

	// Result widgets
	private ScrollView sv_resultpannel;
	private Button btn_resultcode;
	private Button btn_resultclear;
	private Button btn_resultsave;
	private Button btn_resultexit;
	private ScrollView sv_result;
	private EditText et_resultname;
	private LinearLayout lay_result;

	// Open dialog
	private Dialog dia_open;
	private EditText et_open;
	private LinearLayout lay_open;

	private String dirroot;
	private String dirfiles;
	private String dircache;
	private String dirsdcard = null;
	private String lastfile = null;
	private String lastdir = null;
	private boolean resultui = false;
	private boolean bshstrictjava = false;
	private boolean synceditors = true;
	private boolean codesaved = true;
	private static String sevoutput = "";




    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState)
	{
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.main_code);

		LayoutInflater li_inflater;

		li_inflater = getLayoutInflater();
		vw_code = li_inflater.inflate(R.layout.main_code, null);
		vw_result = li_inflater.inflate(R.layout.main_result, null);
		//vw_open = li_inflater.inflate(R.layout.open_dialog, null);
		getActionBar().hide();
		// When use this, **getActionBar()** will not work later.
		//requestWindowFeature(Window.FEATURE_NO_TITLE);

		// main_result should be initialized first,
		// because the main UI is main_code.
		sevInitResultUI();
		sevInitCodeUI();
		sevInitVariables();
    }



	/** Called when the menu is first created. */
	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		MenuInflater mi_mainmenu;

		mi_mainmenu = getMenuInflater();
		mi_mainmenu.inflate(R.menu.main_menu, menu);

		//return super.onCreateOptionsMenu(menu);
		return true;
	}




	/** Called when a menu item is selected. */
	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		switch (item.getItemId())
		{
		case R.id.mnu_switchui:
			if (resultui)
			{
				btnResultCode();
			}
			else
			{
				btnCodeResult();
			}

			break;
		case R.id.mnu_evalrhino:
			btnEvalRhino();
			break;
		case R.id.mnu_evalbsh:
			btnEvalBsh();
			break;
		case R.id.mnu_bshstrictjava:
			item.setChecked(!item.isChecked());
			bshstrictjava = item.isChecked();
			break;
		case R.id.mnu_showactionbar:
			item.setChecked(!item.isChecked());

			if (item.isChecked())
			{
				getActionBar().show();
			}
			else
			{
				getActionBar().hide();
			}

			break;
		case R.id.mnu_showcodepanel:
			item.setChecked(!item.isChecked());

			if (item.isChecked())
			{
				sv_codepannel.setVisibility(View.VISIBLE);
			}
			else
			{
				sv_codepannel.setVisibility(View.GONE);
			}

			break;
		case R.id.mnu_showresultpanel:
			item.setChecked(!item.isChecked());

			if (item.isChecked())
			{
				sv_resultpannel.setVisibility(View.VISIBLE);
			}
			else
			{
				sv_resultpannel.setVisibility(View.GONE);
			}

			break;
		case R.id.mnu_showtwoeditors:
			item.setChecked(!item.isChecked());

			if (item.isChecked())
			{
				sv_code2.setVisibility(View.VISIBLE);
			}
			else
			{
				sv_code2.setVisibility(View.GONE);
			}

			break;
		case R.id.mnu_synctwoeditors:
			item.setChecked(!item.isChecked());
			synceditors = item.isChecked();

			if (synceditors)
			{
				sevSyncTwoEditors();
			}

			break;
		case R.id.mnu_exit:
			btnExit();
			break;
		default:
			return super.onOptionsItemSelected(item);
		}

		return true;
	}




	//*******************************************
	// Initialize UI
	private void sevInitCodeUI()
	{
		setContentView(vw_code);

		// Code widgets
		sv_codepannel = (ScrollView) vw_code.findViewById(R.id.sv_codepannel);
		btn_coderesult = (Button) vw_code.findViewById(R.id.btn_coderesult);
		btn_codeclear = (Button) vw_code.findViewById(R.id.btn_codeclear);
		btn_codeevalrhino = (Button) vw_code.findViewById(R.id.btn_codeevalrhino);
		btn_codeevalbsh = (Button) vw_code.findViewById(R.id.btn_codeevalbsh);
		btn_codeopen = (Button) vw_code.findViewById(R.id.btn_codeopen);
		btn_codesave = (Button) vw_code.findViewById(R.id.btn_codesave);
		btn_codesaveas = (Button) vw_code.findViewById(R.id.btn_codesaveas);
		btn_codeexit = (Button) vw_code.findViewById(R.id.btn_codeexit);
		et_codename = (EditText) vw_code.findViewById(R.id.et_codename);
		sv_code1 = (ScrollView) vw_code.findViewById(R.id.sv_code1);
		et_code1 = (EditText) vw_code.findViewById(R.id.et_code1);
		sv_code2 = (ScrollView) vw_code.findViewById(R.id.sv_code2);
		et_code2 = (EditText) vw_code.findViewById(R.id.et_code2);

		// Code widgets
		btn_coderesult.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View view)
				{
					btnCodeResult();
				}
			});

		btn_codeclear.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View view)
				{
					btnCodeClear();
				}
			});

		btn_codeevalrhino.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View view)
				{
					btnEvalRhino();
				}
			});

		btn_codeevalbsh.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View view)
				{
					btnEvalBsh();
				}
			});

		btn_codeopen.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View view)
				{
					btnCodeOpen();
				}
			});

		btn_codesave.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View view)
				{
					btnCodeSave();
				}
			});

		btn_codesaveas.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View view)
				{
					btnCodeSaveAs();
				}
			});

		btn_codeexit.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View view)
				{
					btnExit();
				}
			});

		sv_code1.setOnTouchListener(new OnTouchListener() {
				@Override
				public boolean onTouch(View v, MotionEvent me)
				{
					et_code1.requestFocus();
					return false;
				}
			});

		et_code1.addTextChangedListener(new TextWatcher() {
				@Override
				public void beforeTextChanged(CharSequence p1, int p2, int p3, int p4)
				{
					// TODO: Implement this method
				}

				@Override
				public void onTextChanged(CharSequence p1, int p2, int p3, int p4)
				{
					// TODO: Implement this method
				}

				@Override
				public void afterTextChanged(Editable p1)
				{
					if (!et_code1.hasFocus())
					{
						return;
					}

					et_code2.setText(et_code1.getText().toString());
					et_codename.setTextColor(COLOR_NOTSAVED);
					codesaved = false;
				}
			});
		et_code1.requestFocus();

		sv_code2.setOnTouchListener(new OnTouchListener() {
				@Override
				public boolean onTouch(View v, MotionEvent me)
				{
					et_code2.requestFocus();
					return false;
				}
			});

		et_code2.addTextChangedListener(new TextWatcher() {
				@Override
				public void beforeTextChanged(CharSequence p1, int p2, int p3, int p4)
				{
					// TODO: Implement this method
				}

				@Override
				public void onTextChanged(CharSequence p1, int p2, int p3, int p4)
				{
					// TODO: Implement this method
				}

				@Override
				public void afterTextChanged(Editable p1)
				{
					if (!et_code2.hasFocus())
					{
						return;
					}

					et_code1.setText(et_code2.getText().toString());
					et_codename.setTextColor(COLOR_NOTSAVED);
					codesaved = false;
				}
			});

		sevSyncTwoEditors();
	}



	private void sevInitResultUI()
	{
		// This will not show main_result,
		// but do this for initialization.
		// main_code is really what to show later.
		setContentView(vw_result);

		// Result widgets
		sv_resultpannel = (ScrollView) vw_result.findViewById(R.id.sv_resultpannel);
		btn_resultcode = (Button) vw_result.findViewById(R.id.btn_resultcode);
		btn_resultclear = (Button) vw_result.findViewById(R.id.btn_resultclear);
		btn_resultsave = (Button) vw_result.findViewById(R.id.btn_resultsave);
		btn_resultexit = (Button) vw_result.findViewById(R.id.btn_resultexit);
		sv_result = (ScrollView) vw_result.findViewById(R.id.sv_result);
		et_resultname = (EditText) vw_result.findViewById(R.id.et_resultname);
		lay_result = (LinearLayout) vw_result.findViewById(R.id.lay_result);

		// Result widgets
		btn_resultcode.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View view)
				{
					btnResultCode();
				}
			});

		btn_resultclear.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View view)
				{
					btnResultClear();
				}
			});

		btn_resultsave.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View view)
				{
					btnResultSave();
				}
			});

		btn_resultexit.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View view)
				{
					btnExit();
				}
			});
	}



	// Initialize variables
	private void sevInitVariables()
	{
		dirroot = Environment.getRootDirectory().getPath();
		dirfiles = getFilesDir().getPath();
		dircache = getCacheDir().getPath();

		if (!Environment.getExternalStorageState().equals(Environment.MEDIA_UNMOUNTED))
		{
			dirsdcard = Environment.getExternalStorageDirectory().getPath();
		}

		et_codename.setText(dirsdcard + File.separator + DEF_CODENAME);
		et_codename.setTextColor(COLOR_SAVED);
		et_resultname.setText(dirsdcard + File.separator + DEF_RESULTNAME);
		et_resultname.setTextColor(COLOR_SAVED);
		lastdir = dirsdcard;
	}



	// Switch UI
	private void btnCodeResult()
	{
		//sv_result.fullScroll(View.FOCUS_DOWN);
		// Scroll to bottom.
		// Using **post** in case ScrollView does not
		// scroll completely.
		sv_result.post(new Runnable() {
				@Override
				public void run()
				{
					sv_result.fullScroll(View.FOCUS_DOWN);
				}
			});
		setContentView(vw_result);
		resultui = true;
	}



	private void btnResultCode()
	{
		et_code1.requestFocus();
		setContentView(vw_code);
		resultui = false;
	}



	// Functions
	private void btnCodeClear()
	{
		AlertDialog.Builder dia_codeclear;

		if (!codesaved)
		{
			dia_codeclear = new AlertDialog.Builder(MainActivity.this);
			dia_codeclear.setTitle("Warning");
			dia_codeclear.setMessage(STR_FILE_NOT_SAVED);
			dia_codeclear.setCancelable(false);
			dia_codeclear.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface p1, int p2)
					{
						btnCodeSave();

						if (codesaved)
						{
							et_code1.setText("");
							et_codename.setTextColor(COLOR_SAVED);
							codesaved = true;
						}
					}
				});
			dia_codeclear.setNeutralButton("No", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface p1, int p2)
					{
						et_code1.setText("");
						et_codename.setTextColor(COLOR_SAVED);
						codesaved = true;
					}
				});
			dia_codeclear.setNegativeButton("Cancel", null);
			dia_codeclear.show();
		}
		else
		{
			et_code1.setText("");
			et_codename.setTextColor(COLOR_SAVED);
			codesaved = true;
		}
	}



	private void btnEvalRhino()
	{
		org.mozilla.javascript.Context rhictx;
		org.mozilla.javascript.Scriptable rhiscope;
		Object rhiresult_o;
		String rhicode, rhiresult_s;

		// Create an execution environment.
		rhictx = org.mozilla.javascript.Context.enter();
		// Turn compilation off
		rhictx.setOptimizationLevel(-1);

		try
		{
			// Initialize a variable scope with bindnings for
			// standard objects (Object, Function, etc.)
			rhiscope = rhictx.initStandardObjects();

            // Set a global variable that holds the activity instance.
            org.mozilla.javascript.ScriptableObject.putProperty(rhiscope, SEV_ACTIVITY, org.mozilla.javascript.Context.javaToJS(MainActivity.this, rhiscope));

			// Evaluate the script.
			rhicode = et_code1.getText().toString();
			rhiresult_o = rhictx.evaluateString(rhiscope, sevGenInitJsCode() + rhicode, RHI_SOURCENAME, 1, null);
			rhiresult_s = org.mozilla.javascript.Context.toString(rhiresult_o);
			sevOutputInfo(RHI_NAME, rhiresult_s);
		}
		catch (Exception error)
		{
			sevOutputErr(RHI_NAME, sevTraceToString(error));
		}
		finally
		{
			org.mozilla.javascript.Context.exit();
		}

		btnCodeResult();
	}



	private void btnEvalBsh()
	{
		bsh.Interpreter bshinter;
		String bshcode, bshresult;

		try
		{
			bshinter = new bsh.Interpreter();
			bshinter.set(SEV_ACTIVITY, MainActivity.this);
			bshinter.setStrictJava(bshstrictjava);
			bshcode = et_code1.getText().toString();
			bshresult = bshinter.eval(bshcode).toString();
			sevOutputInfo(BSH_NAME, bshresult);
		}
		catch (Exception error)
		{
			sevOutputErr(BSH_NAME, sevTraceToString(error));
			//sevAlertDialog("Error", sevTraceToString(error));
		}

		btnCodeResult();
	}



	private void btnCodeOpen()
	{
		Button btn_opencancel, btn_openopen;

		if (lastdir == null)
		{
			sevAlertDialog("Error", STR_SDCARD_NOT_FOUND);
			return;
		}

		dia_open = new Dialog(MainActivity.this);

		dia_open.setContentView(R.layout.open_dialog);
		dia_open.setTitle("Open File");
		btn_opencancel = (Button) dia_open.findViewById(R.id.btn_opencancel);
		btn_openopen = (Button) dia_open.findViewById(R.id.btn_openopen);
		et_open = (EditText) dia_open.findViewById(R.id.et_open);
		lay_open = (LinearLayout) dia_open.findViewById(R.id.lay_open);

		btn_opencancel.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v)
				{
					dia_open.dismiss();
				}
			});

		btn_openopen.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v)
				{
					lastfile = et_open.getText().toString();

					if (!lastfile.equals(""))
					{
						btnCodeOpen_open();
					}

					dia_open.dismiss();
				}
			});

		et_open.addTextChangedListener(new TextWatcher() {
				@Override
				public void beforeTextChanged(CharSequence p1, int p2, int p3, int p4)
				{
					// TODO: Implement this method
				}

				@Override
				public void onTextChanged(CharSequence p1, int p2, int p3, int p4)
				{
					// TODO: Implement this method
				}

				@Override
				public void afterTextChanged(Editable p1)
				{
					// TODO: Implement this method
					lastfile = et_open.getText().toString();
					btnCodeOpen_update();
				}
			});
		et_open.setText(lastdir);
		et_open.setTextColor(COLOR_DIR);

		//lay_open.setShowDividers(LinearLayout.SHOW_DIVIDER_MIDDLE);
		//lay_open.setDividerDrawable(getResources().getDrawable(android.R.drawable.divider_horizontal_dark));

		dia_open.show();
	}



	private void btnCodeOpen_open()
	{
		String codename;
		String codeall;
		byte[] codebytes;
		File fcode;
		FileInputStream fiscode;

		codename = lastfile;
		//codename = et_codename.getText().toString();

		if (codename.endsWith(File.separator))
		{
			sevAlertDialog("Error", STR_ILLEGAL_FILE_NAME);
			return;
		}

		fcode = new File(codename);

		if (!fcode.exists())
		{
			sevAlertDialog("Error", STR_FILE_NOT_EXIST);
			return;
		}

		if (!fcode.isFile())
		{
			sevAlertDialog("Error", STR_NOT_A_FILE);
			return;
		}

		lastdir = fcode.getParent();

		try
		{
			fiscode = new FileInputStream(fcode);
			codebytes = new byte[(int) fcode.length()];
			fiscode.read(codebytes);
			codeall = new String(codebytes);
		}
		catch (Exception error)
		{
			sevAlertDialog("Error", sevTraceToString(error));
			return;
		}

		et_code1.setText(codeall);
		et_codename.setText(lastfile);
		et_codename.setTextColor(COLOR_SAVED);
		codesaved = true;
	}



	private void btnCodeOpen_update()
	{
		File fopenlist;
		String[] openlists;
		TextView tv_openlist;
		int cnt = 0;

		lay_open.removeAllViews();
		fopenlist = new File(lastfile);

		if (!fopenlist.exists())
		{
			et_open.setTextColor(COLOR_NONE);
			return;
		}

		if (fopenlist.isFile())
		{
			et_open.setTextColor(COLOR_FILE);
			return;
		}
		else if (fopenlist.isDirectory())
		{
			et_open.setTextColor(COLOR_DIR);
		}

		//et_open.setTextColor(COLOR_INFO);
		tv_openlist = lwAddTextView("..", COLOR_INFO);
		tv_openlist.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v)
				{
					String filepath;

					filepath = et_open.getText().toString();
					filepath = filepath.substring(0, filepath.lastIndexOf(File.separator));

					if (filepath.equals(""))
					{
						filepath = File.separator;
					}

					et_open.setText(filepath);
				}
			});

		lay_open.addView(tv_openlist);
		openlists = fopenlist.list();

		if (openlists == null)
		{
			sevAlertDialog("Error", STR_CANNOT_OPEN);
			return;
		}

		for (String openlist : openlists)
		{
			tv_openlist = lwAddTextView(openlist, COLOR_INFO);
			tv_openlist.setBackgroundColor((cnt++ % 2 == 0) ? 0xff202020 : 0xff404040);
			tv_openlist.setTextScaleX(0.85f);
			tv_openlist.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v)
					{
						File ffilepath;
						String filepath;
						String filename;

						filename = ((TextView) v).getText().toString();
						filepath = et_open.getText().toString();
						ffilepath = new File(filepath);

						if (ffilepath.isFile())
						{
							filepath = filepath.substring(0, filepath.lastIndexOf(File.separator));
						}

						if (filepath.equals(File.separator))
						{
							et_open.setText(filepath + filename);
						}
						else
						{
							et_open.setText(filepath + File.separator + filename);
						}
					}
				});

			lay_open.addView(tv_openlist);
		}
	}



	private void btnCodeSave()
	{
		String codename;
		File fcode;
		FileOutputStream foscode;

		if (dirsdcard == null)
		{
			sevAlertDialog("Warning", STR_SDCARD_NOT_FOUND);
			return;
		}

		codename = et_codename.getText().toString();

		if (codename.equals("") || codename.endsWith(File.separator))
		{
			sevAlertDialog("Error", STR_ILLEGAL_FILE_NAME);
			return;
		}

		fcode = new File(codename);

		if (!fcode.exists())
		{
			try
			{
				fcode.createNewFile();
			}
			catch (Exception error)
			{
				sevAlertDialog("Error", sevTraceToString(error));
				return;
			}
		}

		try
		{
			foscode = new FileOutputStream(fcode);
			foscode.write(et_code1.getText().toString().getBytes());
			foscode.close();
		}
		catch (Exception error)
		{
			sevAlertDialog("Error", sevTraceToString(error));
			return;
		}

		et_codename.setTextColor(COLOR_SAVED);
		codesaved = true;
		sevToast("Code saved");
	}



	private void btnCodeSaveAs()
	{
		//sevToast("Code saved");
	}



	private void btnExit()
	{
		AlertDialog.Builder dia_exit;

		if (!codesaved)
		{
			dia_exit = new AlertDialog.Builder(MainActivity.this);
			dia_exit.setTitle("Warning");
			dia_exit.setMessage(STR_FILE_NOT_SAVED);
			dia_exit.setCancelable(false);
			dia_exit.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface p1, int p2)
					{
						btnCodeSave();

						if (codesaved)
						{
							finish();
						}
					}
				});
			dia_exit.setNeutralButton("No", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface p1, int p2)
					{
						finish();
					}
				});
			dia_exit.setNegativeButton("Cancel", null);
			dia_exit.show();
		}
		else
		{
			finish();
		}
	}



	private void btnResultClear()
	{
		lay_result.removeAllViews();
		et_resultname.setTextColor(COLOR_SAVED);
	}



	private void btnResultSave()
	{
		String resultall = "";
		String resultname;
		int tvid, tvcount;
		File fresult;
		FileOutputStream fosresult;

		tvcount = lay_result.getChildCount();

		for (tvid = 0; tvid < tvcount; tvid++)
		{
			resultall += (
				((TextView) lay_result.getChildAt(tvid)).getText() +
				"\n--------------------------------------------\n\n"
				);
		}

		resultname = et_resultname.getText().toString();

		if (resultname.equals("") || resultname.endsWith(File.separator))
		{
			sevAlertDialog("Error", STR_ILLEGAL_FILE_NAME);
			return;
		}

		fresult = new File(resultname);

		if (!fresult.exists())
		{
			try
			{
				fresult.createNewFile();
			}
			catch (Exception error)
			{
				sevAlertDialog("Error", sevTraceToString(error));
				return;
			}
		}

		try
		{
			fosresult = new FileOutputStream(fresult);
			fosresult.write(resultall.getBytes());
			fosresult.close();
		}
		catch (Exception error)
		{
			sevAlertDialog("Error", sevTraceToString(error));
			return;
		}

		et_resultname.setTextColor(COLOR_SAVED);
		sevToast("Result saved");
		return;
	}



	// Other functions
	private String sevTraceToString(Exception error)
	{
		String trace;

		trace = error.toString() + "\n";

		for (StackTraceElement ste : error.getStackTrace())
		{
			trace += "  at " + ste.toString() + "\n";
		}

		return trace;
	}



	private void sevSyncTwoEditors()
	{
		if (!synceditors)
		{
			return;
		}

		if (et_code1.hasFocus())
		{
			// **et_code2.scrollTo** does not work.
			sv_code2.scrollTo(sv_code1.getScrollX(), sv_code1.getScrollY());
		}
		else if (et_code2.hasFocus())
		{
			sv_code1.scrollTo(sv_code2.getScrollX(), sv_code2.getScrollY());
		}

		new android.os.Handler().postDelayed(new Runnable() {
				@Override
				public void run()
				{
					sevSyncTwoEditors();
				}
			}, TIME_SYNC_DELAY);
	}



	private String sevGetTimeString()
	{
		String time;
		java.util.Date d_date;
		java.text.SimpleDateFormat sdf_date;

		d_date = new java.util.Date();
		sdf_date = new java.text.SimpleDateFormat(DEF_DATEFORMAT);
		time = sdf_date.format(d_date);
		//sevToast(time);

		return time;
	}



	private String sevGenInitJsCode()
	{
		String initcode;
		String[] methods = {
			"print", "help"
		};

		initcode = "var Pkg = Packages.cn.ltwbh.lwscripteval.MainActivity;\n";

		for (String method : methods)
		{
			initcode += "var " + method + " = Pkg.rhiFunc_" + method + ";\n";
		}

		initcode += "Pkg = undefined;\n";

		return initcode;
	}



	// Output information
	private void sevToast(String info)
	{
		Toast.makeText(MainActivity.this, info, Toast.LENGTH_SHORT).show();
	}



	private void sevAlertDialog(String title, String info)
	{
		AlertDialog.Builder dia_info;

		dia_info = new AlertDialog.Builder(MainActivity.this);
		dia_info.setTitle(title);
		dia_info.setMessage(info);
		dia_info.setPositiveButton("Close", null);
		dia_info.show();
	}



	// Output functions
	private void sevOutputInfo(String prefix, String info)
	{
		TextView tv_info;
		String infoall;

		infoall = "Info:\n" + info;

		if (prefix != null)
		{
			infoall = prefix + ": " + infoall;
		}

		infoall = sevGetTimeString() + "\n" + infoall;
		tv_info = lwAddTextView(infoall, COLOR_INFO);
		tv_info.setTextScaleX(0.85f);
		lay_result.addView(tv_info);
		et_resultname.setTextColor(COLOR_NOTSAVED);
	}



	private void sevOutputWarn(String prefix, String warn)
	{
		TextView tv_warn;
		String warnall;

		warnall = "Warning:\n" + warn;

		if (prefix != null)
		{
			warnall = prefix + ": " + warnall;
		}

		warnall = sevGetTimeString() + "\n" + warnall;
		tv_warn = lwAddTextView(warnall, COLOR_WARN);
		tv_warn.setTextScaleX(0.85f);
		lay_result.addView(tv_warn);
		et_resultname.setTextColor(COLOR_NOTSAVED);
	}



	private void sevOutputErr(String prefix, String error)
	{
		TextView tv_error;
		String errorall;

		errorall = "ERROR:\n" + error;

		if (prefix != null)
		{
			errorall = prefix + ": " + errorall;
		}

		errorall = sevGetTimeString() + "\n" + errorall;
		tv_error = lwAddTextView(errorall, COLOR_ERROR);
		tv_error.setTextScaleX(0.85f);
		lay_result.addView(tv_error);
		et_resultname.setTextColor(COLOR_NOTSAVED);
	}



	// Create widgets
	private TextView lwAddTextView(String text, int color)
	{
		TextView newtv = new TextView(this);

		newtv.setText(text);
		newtv.setTextColor(color);
		//newtv.setBackgroundColor(color);
		newtv.setTextSize(12);
		newtv.setTypeface(android.graphics.Typeface.MONOSPACE);
		newtv.setTextIsSelectable(true);

		return newtv;
	}



	// Rhino functions
	public static String rhiFunc_print(String msg)
	{
		sevoutput += msg + "\n";

		return msg;
	}



	public static void rhiFunc_help()
	{
		String helpinfo;

		helpinfo = (
			"TODO\n" +
			"\n"
			);
		rhiFunc_print(helpinfo);
		return;
	}
}
