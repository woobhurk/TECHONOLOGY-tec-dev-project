package com.tsueyl.funcpad;

public class NFuncData
{
	public static final String DEF_EXP = "pow(sin(x), 3.0)";
	public static final String DEF_RANGESTART = "-2 * pi";
	public static final String DEF_RANGEEND = "1.5 * pi";
	public static final String DEF_RANGEDELTA = "0.1";

	private String nfExp;
	private String nfRangeStart;
	private String nfRangeEnd;
	private String nfRangeDelta;


	public NFuncData()
	{
		nfExp = DEF_EXP;
		nfRangeStart = DEF_RANGESTART;
		nfRangeEnd = DEF_RANGEEND;
		nfRangeDelta = DEF_RANGEDELTA;
	}


	public NFuncData(String exp, String rangeStart, String rangeEnd,
			String rangeDelta)
	{
		nfExp = exp;
		nfRangeStart = rangeStart;
		nfRangeEnd = rangeEnd;
		nfRangeDelta = rangeDelta;
	}


	public String getExp()
	{
		return nfExp;
	}


	public String getRangeStart()
	{
		return nfRangeStart;
	}


	public String getRangeEnd()
	{
		return nfRangeEnd;
	}


	public String getRangeDelta()
	{
		return nfRangeDelta;
	}


	public void setExp(String exp)
	{
		nfExp = exp;
	}


	public void setRangeStart(String rangeStart)
	{
		nfRangeStart = rangeStart;
	}


	public void setRangeEnd(String rangeEnd)
	{
		nfRangeEnd = rangeEnd;
	}


	public void setRangeDelta(String rangeDelta)
	{
		nfRangeDelta = rangeDelta;
	}
}

