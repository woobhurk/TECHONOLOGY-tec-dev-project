/*******************
 * Name: FuncPadView
 * Author: Woobhurk
 * Copyright (C) 2015 Tsueyl
 * All rights reserved.
 * *************************
 * This class is the main view where the graphics draw.
 * Note:
 *   Screen coordinate: The real pixel coordinate.
 *   Canvas coordinate: The coordinate in Math.
 */

package com.tsueyl.funcpad;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Point;
import android.graphics.PointF;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.os.Environment;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import com.tsueyl.extras.Utils;

public class FuncPadView extends View
{
	// 默认值
	public static final boolean SHOW_GRID = true;
	public static final boolean SHOW_COORDNUM = true;
	public static final boolean SHOW_ZOOMTOOL = true;
	public static final boolean SHOW_POINTER = true;
	public static final boolean ANTI_ALIAS = true;
	public static final int COLOR_CANVAS = 0xffffffff;
	public static final int COLOR_GRID = 0xffa0a0a0;
	public static final int COLOR_COORD = 0xff000000;
	public static final int COLOR_COORDNUM = 0xff000000;
	public static final int COLOR_FUNC = 0xffa06020;
	public static final int COLOR_POINTER = 0xff503010;
	public static final int SIZE_COORDNUM = 14;
	public static final float ZOOM_FACTOR = 3.0f;

	private ArrayList<NFuncData> nfDataList;
	private ArrayList<PFuncData> pfDataList;

	private Context ctx;
	private Canvas canvas;
	private boolean showGrid;
	private boolean showCoordNum;
	private boolean showZoomTool;
	private boolean showPointer;
	private boolean antiAlias;
	private int colorCanvas;
	private int colorGrid;
	private int colorCoord;
	private int colorCoordNum;
	private int colorFunc;
	private int colorPointer;
	private int canvasWidth;
	private int canvasHeight;
	private int canvasWidthH;
	private int canvasHeightH;
	private int gridSize;
	private int gridSizeDelta;
	private Point pointO;
	private Point pointer;
	private boolean needInit = true;
	private boolean needDrawZoomTool;
	private String codeInitRhino;


	/*public FuncPadView(Context ctx)
	 {
	 super(ctx);
	 Toast.makeText(ctx, "FuncPadView", Toast.LENGTH_SHORT).show();
	 }*/

	public FuncPadView(Context ctx, AttributeSet attrs)
	{
		super(ctx, attrs);
		this.ctx = ctx;
	}


	public FuncPadView(Context ctx, AttributeSet attrs, int defStyle)
	{
		super(ctx, attrs, defStyle);
		this.ctx = ctx;
	}


	/********
	 * onDraw
	 * - 画出网格、坐标轴、坐标轴单位、函数图像、放大镜、触点坐标线
	 * Notes:
	 * - 关于onDraw的触发：一般由invalidate()强制触发，但是目前发现getDrawingCache
	 * - 也会触发onDraw，这也是在drawZoomTool中加入判断的原因。
	 */
	@Override
	protected void onDraw(Canvas cvs)
	{
		super.onDraw(cvs);

		// 需要每次更新canvas，否则会闪退。
		canvas = cvs;

		if (needInit)
		{
			initVar();
			needInit = false;
		}

		//Log.w("onDraw", "-------------- onDraw");
		canvas.drawColor(colorCanvas);
		// 画图的顺序很重要，先画网格，再坐标轴、坐标轴单位、函数图像。
		drawGrid();
		drawCoord();
		drawCoordNum();
		drawAllNFunc();
		drawAllPFunc();
		// 先画放大镜，这样就不会放大触摸点的坐标了。
		drawZoomTool();
		drawPointer();
		needDrawZoomTool = true;
	}


	/*************
	 * drawAllFunc
	 * - 画出所有函数图像。
	 * Parameters:
	 * - nfDataList: 函数数据列表。
	 * - pfDataList: 参数方程数据列表。
	 */
	public void drawAllFunc(ArrayList<NFuncData> nfDataList,
			ArrayList<PFuncData> pfDataList)
	{
		this.nfDataList = nfDataList;
		this.pfDataList = pfDataList;
		invalidate();
	}


	/**************
	 * clearAllFunc
	 * - 清除所有函数（数据）。
	 */
	public void clearAllFunc()
	{
		nfDataList.clear();
		pfDataList.clear();
		// 不画出触摸点坐标
		pointer.set(-1, -1);
		invalidate();
	}


	/**********
	 * zoomFunc
	 * - 缩放函数。
	 * Parameters:
	 * - gridSize: 新的网格大小。
	 */
	public void zoomFunc(int gridSize)
	{
		if (gridSize < gridSizeDelta)
		{
			gridSize = gridSizeDelta;
		}

		this.gridSize = gridSize;
		invalidate();
	}


	/************
	 * moveFuncBy
	 * - 移动函数图像
	 * Parameters:
	 * - deltaX: x变化量
	 * - deltaY: y变化量
	 * Notes:
	 * - 将会导致原点的屏幕坐标改变。
	 * - 不设置成moveFunc是为了MainActivity中更方便调用。
	 */
	public void moveFuncBy(int deltaX, int deltaY)
	{
		//setOpos(new Point(pointO.x + deltaX, pointO.y + deltaY));
		pointO.x += deltaX;
		pointO.y += deltaY;
		invalidate();
	}


	/*************
	 * movePointer
	 * - 移动触点坐标线
	 * Parameters:
	 * - pointerX: 新的x坐标
	 * - pointerY: 新的y坐标
	 * Notes:
	 * - 将会导致触点的屏幕坐标改变。
	 */
	public void movePointer(int pointerX, int pointerY)
	{
		pointer.x = pointerX;
		pointer.y = pointerY;
		invalidate();
	}


	/****************
	 * takeScreenShot
	 * - 截屏
	 */
	public void takeScreenShot()
	{
		View screenView;
		String pngName;
		Bitmap canvasBmp;
		File pngPath;
		File pngFile;
		FileOutputStream pngFos;
		SimpleDateFormat dateFormat;

		if (Environment.getExternalStorageState().equals(
				Environment.MEDIA_UNMOUNTED))
		{
			Utils.showToast(ctx, "No external storage found.");
			return;
		}

		screenView = this;
		// 这个原本是用来防止canvasBmp值为null的，但加入之后反而会变成null了:'(
		/*screenView.measure(View.MeasureSpec.makeMeasureSpec(0,
				View.MeasureSpec.UNSPECIFIED), View.MeasureSpec
				.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
		screenView.layout(0, 0, screenView.getMeasuredWidth(),
				screenView.getMeasuredHeight());*/
		screenView.setDrawingCacheEnabled(true);
		screenView.buildDrawingCache();
		canvasBmp = screenView.getDrawingCache();

		if (canvasBmp == null)
		{
			Utils.showToast(ctx, "Cannot take screenshot");
			return;
		}

		pngPath = Environment
				.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM);

		if (!pngPath.exists())
		{
			pngPath.mkdirs();
		}

		dateFormat = new SimpleDateFormat("yyyyMMdd_HHmmss");
		pngName = "FuncPad-" + dateFormat.format(new Date()) + ".png";
		pngName = pngPath.getPath() + File.separator + pngName;
		pngFile = new File(pngName);

		try
		{
			pngFile.createNewFile();
			pngFos = new FileOutputStream(pngFile);
			canvasBmp.compress(Bitmap.CompressFormat.PNG, 100, pngFos);
			pngFos.flush();
			pngFos.close();
		}
		catch (Exception e)
		{
			Utils.showTraceDialog(ctx, e);
		}

		screenView.destroyDrawingCache();
		screenView.setDrawingCacheEnabled(false);
		Utils.showToast(ctx, "File saved to " + pngName);
	}


	/********************************
	 * getGridSize & getGridSizeDelta
	 * - 获取网格大小和大小变化量
	 * Notes:
	 * - MainActivity中用来缩放函数。
	 */
	public int getGridSize()
	{
		return gridSize;
	}


	public int getGridSizeDelta()
	{
		return gridSizeDelta;
	}


	/*******************
	 * Getters & Setters
	 * - 获取和设置属性
	 * Notes:
	 * - 基本上Getters都不会用到。
	 */
	public boolean getShowGrid()
	{
		return showGrid;
	}


	public void setShowGrid(boolean showGrid)
	{
		this.showGrid = showGrid;
	}


	public boolean getShowCoordNum()
	{
		return showCoordNum;
	}


	public void setShowCoordNum(boolean showCoordNum)
	{
		this.showCoordNum = showCoordNum;
	}


	public boolean getShowZoomTool()
	{
		return showZoomTool;
	}


	public void setShowZoomTool(boolean showZoomTool)
	{
		this.showZoomTool = showZoomTool;
	}


	public boolean getShowPointer()
	{
		return showPointer;
	}


	public void setShowPointer(boolean showPointer)
	{
		this.showPointer = showPointer;
	}


	public boolean getAntiAlias()
	{
		return antiAlias;
	}


	public void setAntiAlias(boolean antiAlias)
	{
		this.antiAlias = antiAlias;
	}


	/*public void setColors(int colorCanvas, int colorGrid, int colorCoord,
			int colorCoordNum, int colorFunc, int colorPointer)
	{
		this.colorCanvas = colorCanvas;
		this.colorGrid = colorGrid;
		this.colorCoord = colorCoord;
		this.colorCoordNum = colorCoordNum;
		this.colorFunc = colorFunc;
		this.colorPointer = colorPointer;
		invalidate();
	}*/


	public int getCanvasColor()
	{
		return colorCanvas;
	}


	public void setCanvasColor(int colorCanvas)
	{
		this.colorCanvas = colorCanvas;
	}


	public int getGridColor()
	{
		return colorGrid;
	}


	public void setGridColor(int colorGrid)
	{
		this.colorGrid = colorGrid;
	}


	public int getCoordColor()
	{
		return colorCoord;
	}


	public void setCoordColor(int colorCoord)
	{
		this.colorCoord = colorCoord;
	}


	public int getCoordNumColor()
	{
		return colorCoordNum;
	}


	public void setCoordNumColor(int colorCoordNum)
	{
		this.colorCoordNum = colorCoordNum;
	}


	public int getFuncColor()
	{
		return colorFunc;
	}


	public void setFuncColor(int colorFunc)
	{
		this.colorFunc = colorFunc;
	}


	public int getPointerColor()
	{
		return colorPointer;
	}


	public void setPointerColor(int colorPointer)
	{
		this.colorPointer = colorPointer;
	}


	private void initVar()
	{
		// 这些值在MainActivity中设置好了
		/*colorCanvas = COLOR_CANVAS;
		colorGrid = COLOR_GRID;
		colorCoord = COLOR_COORD;
		colorCoordNum = COLOR_COORDNUM;
		colorFunc = COLOR_FUNC;
		colorPointer = COLOR_POINTER;*/

		canvasWidth = canvas.getWidth();
		canvasHeight = canvas.getHeight();
		canvasWidthH = canvasWidth / 2;
		canvasHeightH = canvasHeight / 2;
		gridSize = canvasWidth / 12;
		gridSizeDelta = gridSize / 8;
		// 开始时原点坐标在屏幕中心
		pointO = new Point(canvasWidthH, canvasHeightH);
		// 开始时不画出触点线坐标
		pointer = new Point(-1, -1);
		needDrawZoomTool = true;
		codeInitRhino = ctx.getResources().getString(R.string.code_init_rhino);
	}


	/**************
	 * drawAllNFunc
	 * - 画出所有函数图像
	 */
	private void drawAllNFunc()
	{
		for (int nfIndex = 0; nfIndex < nfDataList.size(); nfIndex++)
		{
			drawNFunc(nfIndex);
		}
	}


	/***********
	 * drawNFunc
	 * - 画出单个函数图像
	 * Parameters:
	 * - nfIndex: 函数数据对象的索引
	 * Note:
	 * - 本来可以直接传递nfData对象的，但之前用多线程改成这样了，也就懒得改回去了。
	 */
	private void drawNFunc(int nfIndex)
	{
		NFuncData nfData;
		float[] linePts;
		String[] s_canvasPts;
		float canvasX;
		float canvasY;
		float f_nfRangeStart;
		float f_nfRangeEnd;
		float f_nfRangeDelta;
		int rangeLength;
		int lineCount;
		Paint funcPaint;
		org.mozilla.javascript.Context rhinoCtx;
		org.mozilla.javascript.Scriptable rhinoScope;
		Object result;
		String codeGenNFLine;

		/*if (nfIndex >= nfDataList.size())
		{
			return;
		}*/

		nfData = nfDataList.get(nfIndex);
		rhinoCtx = org.mozilla.javascript.Context.enter();
		rhinoCtx.setOptimizationLevel(-1);

		// 求出范围的值
		try
		{
			rhinoScope = rhinoCtx.initStandardObjects();
			rhinoCtx.evaluateString(rhinoScope, codeInitRhino,
					"drawNFunc.codeInitRhino1", 1, null);
			result = rhinoCtx.evaluateString(rhinoScope,
					nfData.getRangeStart(), "drawNFunc.rangeStart", 1, null);
			f_nfRangeStart = Float.parseFloat(rhinoCtx.toString(result));
			result = rhinoCtx.evaluateString(rhinoScope, nfData.getRangeEnd(),
					"drawNFunc.rangeEnd", 1, null);
			f_nfRangeEnd = Float.parseFloat(rhinoCtx.toString(result));
			result = rhinoCtx.evaluateString(rhinoScope,
					nfData.getRangeDelta(), "drawNFunc.rangeDelta", 1, null);
			f_nfRangeDelta = Float.parseFloat(rhinoCtx.toString(result));
		}
		catch (Exception error)
		{
			Utils.showTraceDialog(ctx, error);
			return;
		}
		finally
		{
			rhinoCtx.exit();
		}

		// 范围长度，不是区间长度，而是在屏幕上需要的像素个数。
		// * 5是为了防止数组越界，因为float的计算不是很准确，所以开辟一些额外的
		// 长度。
		rangeLength = (int)((f_nfRangeEnd - f_nfRangeStart) / f_nfRangeDelta) * 5;
		linePts = new float[rangeLength];
		codeGenNFLine = ctx.getResources().getString(
				R.string.code_gen_nflinepos);
		rhinoCtx = org.mozilla.javascript.Context.enter();
		rhinoCtx.setOptimizationLevel(-1);

		try
		{
			canvasX = f_nfRangeStart;
			rhinoScope = rhinoCtx.initStandardObjects();
			// 初始化上下文，以便提供数学函数更方便的调用。
			rhinoCtx.evaluateString(rhinoScope, codeInitRhino,
					"drawNFunc.codeInitRhino2", 1, null);
			// 格式化JS代码，即存入真实的变量值。
			codeGenNFLine = String.format(codeGenNFLine, canvasX,
					f_nfRangeStart, f_nfRangeEnd, f_nfRangeDelta,
					nfData.getExp(), nfData.getExp());
			//Utils.showDialog(ctx, null, codeGenNFLine);
			// 开始求值，求值过程在JS代码中。
			rhinoCtx.evaluateString(rhinoScope, codeGenNFLine, "codeGenNFLine",
					1, null);
			// 获取求出的值的数组（将转化为字符串）。
			result = org.mozilla.javascript.ScriptableObject.getProperty(
					rhinoScope, "canvasPts");
			// 将字符串打散成数组。
			s_canvasPts = rhinoCtx.toString(result).split(",");
			//Utils.showDialog(ctx, null, Arrays.toString(s_canvasPts));
			//Utils.showDialog(ctx, null, rhinoCtx.toString(result));
			//Utils.showDialog(ctx, null, Arrays.toString(linePts));

			// 开始存入各个点的屏幕坐标。
			for (lineCount = 0; lineCount < s_canvasPts.length; lineCount += 2)
			{
				canvasX = Float.parseFloat(s_canvasPts[lineCount]);
				canvasY = Float.parseFloat(s_canvasPts[lineCount + 1]);
				linePts[lineCount] = (float)canvasToScreenX(canvasX);
				linePts[lineCount + 1] = (float)canvasToScreenY(canvasY);
			}
		}
		catch (Exception error)
		{
			Utils.showTraceDialog(ctx, error);
			return;
		}
		finally
		{
			rhinoCtx.exit();
		}

		funcPaint = new Paint();
		funcPaint.setAntiAlias(antiAlias);
		funcPaint.setColor(colorFunc);
		// lineCount - 2：因为linePts存的是[x1 y1 x2 y2 x2 y2 x3 y3 ...]形式的
		// 坐标，所以最后会有一对x和y多余。
		// 不这样也行，画出来的效果似乎一样，但保险起见，还是增加吧！
		canvas.drawLines(linePts, 0, lineCount - 2, funcPaint);
	}


	/***************
	 * drawNFunc_bak
	 * - 画出单个函数图像。
	 * Note:
	 * - 已不用，因为速度更慢，但算法有价值，保留。
	 */
	private void drawNFunc_bak(int nfIndex)
	{
		NFuncData nfData;
		float[] linePts;
		float canvasX;
		float canvasY;
		float f_nfRangeStart;
		float f_nfRangeEnd;
		float f_nfRangeDelta;
		int rangeLength;
		int lineCount;
		Paint funcPaint;
		org.mozilla.javascript.Context rhinoCtx;
		org.mozilla.javascript.Scriptable rhinoScope;
		Object result;

		/*if (nfIndex >= nfDataList.size())
		{
			return;
		}*/

		nfData = nfDataList.get(nfIndex);
		rhinoCtx = org.mozilla.javascript.Context.enter();
		rhinoCtx.setOptimizationLevel(-1);

		try
		{
			rhinoScope = rhinoCtx.initStandardObjects();
			rhinoCtx.evaluateString(rhinoScope, codeInitRhino,
					"drawNFunc.codeInitRhino1", 1, null);
			result = rhinoCtx.evaluateString(rhinoScope,
					nfData.getRangeStart(), "drawNFunc.rangeStart", 1, null);
			f_nfRangeStart = Float.parseFloat(rhinoCtx.toString(result));
			result = rhinoCtx.evaluateString(rhinoScope, nfData.getRangeEnd(),
					"drawNFunc.rangeEnd", 1, null);
			f_nfRangeEnd = Float.parseFloat(rhinoCtx.toString(result));
			result = rhinoCtx.evaluateString(rhinoScope,
					nfData.getRangeDelta(), "drawNFunc.rangeDelta", 1, null);
			f_nfRangeDelta = Float.parseFloat(rhinoCtx.toString(result));
		}
		catch (Exception error)
		{
			Utils.showTraceDialog(ctx, error);
			return;
		}
		finally
		{
			rhinoCtx.exit();
		}

		rangeLength = (int)((f_nfRangeEnd - f_nfRangeStart) / f_nfRangeDelta) * 5;
		linePts = new float[rangeLength];
		rhinoCtx = org.mozilla.javascript.Context.enter();
		rhinoCtx.setOptimizationLevel(-1);

		try
		{
			canvasX = f_nfRangeStart;
			rhinoScope = rhinoCtx.initStandardObjects();
			rhinoCtx.evaluateString(rhinoScope, codeInitRhino,
					"drawNFunc.codeInitRhino2", 1, null);
			org.mozilla.javascript.ScriptableObject.putProperty(rhinoScope,
					"x", org.mozilla.javascript.Context.javaToJS(canvasX,
							rhinoScope));
			result = rhinoCtx.evaluateString(rhinoScope, nfData.getExp(),
					"drawNFunc.nfExp", 1, null);
			canvasY = Float.parseFloat(rhinoCtx.toString(result));
			linePts[0] = (float)canvasToScreenX(canvasX);
			linePts[1] = (float)canvasToScreenY(canvasY);
			lineCount = 2;
			canvasX += f_nfRangeDelta;

			for (; canvasX <= f_nfRangeEnd; canvasX += f_nfRangeDelta)
			{
				org.mozilla.javascript.ScriptableObject.putProperty(rhinoScope,
						"x", org.mozilla.javascript.Context.javaToJS(canvasX,
								rhinoScope));
				result = rhinoCtx.evaluateString(rhinoScope, nfData.getExp(),
						"drawNFunc.nfExp", 1, null);
				canvasY = Float.parseFloat(rhinoCtx.toString(result));
				linePts[lineCount++] = (float)canvasToScreenX(canvasX);
				linePts[lineCount++] = (float)canvasToScreenY(canvasY);
				linePts[lineCount++] = (float)canvasToScreenX(canvasX);
				linePts[lineCount++] = (float)canvasToScreenY(canvasY);
				//lineCount += 4;
			}
		}
		catch (Exception error)
		{
			Utils.showTraceDialog(ctx, error);
			return;
		}
		finally
		{
			rhinoCtx.exit();
		}

		funcPaint = new Paint();
		funcPaint.setAntiAlias(antiAlias);
		funcPaint.setColor(colorFunc);
		canvas.drawLines(linePts, 0, lineCount - 2, funcPaint);
	}


	private void drawAllPFunc()
	{
		for (int pfIndex = 0; pfIndex < pfDataList.size(); pfIndex++)
		{
			drawPFunc(pfIndex);
		}
	}


	private void drawPFunc(int pfIndex)
	{
		PFuncData pfData;
		float[] linePts;
		String[] s_canvasPts;
		float varT;
		float canvasX;
		float canvasY;
		float f_pfRangeStart;
		float f_pfRangeEnd;
		float f_pfRangeDelta;
		int rangeLength;
		int lineCount;
		Paint funcPaint;
		org.mozilla.javascript.Context rhinoCtx;
		org.mozilla.javascript.Scriptable rhinoScope;
		Object result;
		String codeGenPFLine;

		/*if (pfIndex >= pfDataList.size())
		{
			return;
		}*/

		pfData = pfDataList.get(pfIndex);
		rhinoCtx = org.mozilla.javascript.Context.enter();
		rhinoCtx.setOptimizationLevel(-1);

		try
		{
			rhinoScope = rhinoCtx.initStandardObjects();
			rhinoCtx.evaluateString(rhinoScope, codeInitRhino,
					"drawPFunc.codeInitRhino1", 1, null);
			result = rhinoCtx.evaluateString(rhinoScope,
					pfData.getRangeStart(), "drawPFunc.rangeStart", 1, null);
			f_pfRangeStart = Float.parseFloat(rhinoCtx.toString(result));
			result = rhinoCtx.evaluateString(rhinoScope, pfData.getRangeEnd(),
					"drawPFunc.rangeEnd", 1, null);
			f_pfRangeEnd = Float.parseFloat(rhinoCtx.toString(result));
			result = rhinoCtx.evaluateString(rhinoScope,
					pfData.getRangeDelta(), "drawPFunc.rangeDelta", 1, null);
			f_pfRangeDelta = Float.parseFloat(rhinoCtx.toString(result));
		}
		catch (Exception error)
		{
			Utils.showTraceDialog(ctx, error);
			return;
		}
		finally
		{
			rhinoCtx.exit();
		}

		rangeLength = (int)((f_pfRangeEnd - f_pfRangeStart) / f_pfRangeDelta) * 5;
		linePts = new float[rangeLength];
		codeGenPFLine = ctx.getResources().getString(
				R.string.code_gen_pflinepos);
		rhinoCtx = org.mozilla.javascript.Context.enter();
		rhinoCtx.setOptimizationLevel(-1);

		try
		{
			varT = f_pfRangeStart;
			rhinoScope = rhinoCtx.initStandardObjects();
			rhinoCtx.evaluateString(rhinoScope, codeInitRhino,
					"drawPFunc.codeInitRhino2", 1, null);
			codeGenPFLine = String.format(codeGenPFLine, varT, f_pfRangeStart,
					f_pfRangeEnd, f_pfRangeDelta, pfData.getExpX(),
					pfData.getExpY(), pfData.getExpX(), pfData.getExpY());
			//Utils.showDialog(ctx, null, codeGenPFLine);
			rhinoCtx.evaluateString(rhinoScope, codeGenPFLine, "codeGenPFLine",
					1, null);
			result = org.mozilla.javascript.ScriptableObject.getProperty(
					rhinoScope, "canvasPts");
			s_canvasPts = rhinoCtx.toString(result).split(",");
			//Utils.showDialog(ctx, null, Arrays.toString(s_canvasPts));

			for (lineCount = 0; lineCount < s_canvasPts.length; lineCount += 2)
			{
				canvasX = Float.parseFloat(s_canvasPts[lineCount]);
				canvasY = Float.parseFloat(s_canvasPts[lineCount + 1]);
				linePts[lineCount] = (float)canvasToScreenX(canvasX);
				linePts[lineCount + 1] = (float)canvasToScreenY(canvasY);
			}
		}
		catch (Exception error)
		{
			Utils.showTraceDialog(ctx, error);
			return;
		}
		finally
		{
			rhinoCtx.exit();
		}

		funcPaint = new Paint();
		funcPaint.setAntiAlias(antiAlias);
		funcPaint.setColor(colorFunc);
		canvas.drawLines(linePts, 0, lineCount - 2, funcPaint);
	}


	private void drawPFunc_bak(int pfIndex)
	{
		PFuncData pfData;
		float[] linePts;
		float varT;
		float canvasX;
		float canvasY;
		float f_pfRangeStart;
		float f_pfRangeEnd;
		float f_pfRangeDelta;
		int rangeLength;
		int lineCount;
		Paint funcPaint;
		org.mozilla.javascript.Context rhinoCtx;
		org.mozilla.javascript.Scriptable rhinoScope;
		Object result;

		/*if (pfIndex >= pfDataList.size())
		{
			return;
		}*/

		pfData = pfDataList.get(pfIndex);
		rhinoCtx = org.mozilla.javascript.Context.enter();
		rhinoCtx.setOptimizationLevel(-1);

		try
		{
			rhinoScope = rhinoCtx.initStandardObjects();
			rhinoCtx.evaluateString(rhinoScope, codeInitRhino,
					"drawPFunc.codeInitRhino1", 1, null);
			result = rhinoCtx.evaluateString(rhinoScope,
					pfData.getRangeStart(), "drawPFunc.rangeStart", 1, null);
			f_pfRangeStart = Float.parseFloat(rhinoCtx.toString(result));
			result = rhinoCtx.evaluateString(rhinoScope, pfData.getRangeEnd(),
					"drawPFunc.rangeEnd", 1, null);
			f_pfRangeEnd = Float.parseFloat(rhinoCtx.toString(result));
			result = rhinoCtx.evaluateString(rhinoScope,
					pfData.getRangeDelta(), "drawPFunc.rangeDelta", 1, null);
			f_pfRangeDelta = Float.parseFloat(rhinoCtx.toString(result));
		}
		catch (Exception error)
		{
			Utils.showTraceDialog(ctx, error);
			return;
		}
		finally
		{
			rhinoCtx.exit();
		}

		rangeLength = (int)((f_pfRangeEnd - f_pfRangeStart) / f_pfRangeDelta) * 5;
		linePts = new float[rangeLength];
		rhinoCtx = org.mozilla.javascript.Context.enter();
		rhinoCtx.setOptimizationLevel(-1);

		try
		{
			varT = f_pfRangeStart;
			rhinoScope = rhinoCtx.initStandardObjects();
			rhinoCtx.evaluateString(rhinoScope, codeInitRhino,
					"drawPFunc.codeInitRhino2", 1, null);
			org.mozilla.javascript.ScriptableObject.putProperty(rhinoScope,
					"t",
					org.mozilla.javascript.Context.javaToJS(varT, rhinoScope));
			result = rhinoCtx.evaluateString(rhinoScope, pfData.getExpX(),
					"drawPFunc.pfExpX1", 1, null);
			canvasX = Float.parseFloat(rhinoCtx.toString(result));
			result = rhinoCtx.evaluateString(rhinoScope, pfData.getExpY(),
					"drawPFunc.pfExpY1", 1, null);
			canvasY = Float.parseFloat(rhinoCtx.toString(result));
			linePts[0] = (float)canvasToScreenX(canvasX);
			linePts[1] = (float)canvasToScreenY(canvasY);
			lineCount = 2;
			varT += f_pfRangeDelta;

			for (; varT <= f_pfRangeEnd; varT += f_pfRangeDelta)
			{
				org.mozilla.javascript.ScriptableObject.putProperty(rhinoScope,
						"t", org.mozilla.javascript.Context.javaToJS(varT,
								rhinoScope));
				result = rhinoCtx.evaluateString(rhinoScope, pfData.getExpX(),
						"drawPFunc.pfExpX2", 1, null);
				canvasX = Float.parseFloat(rhinoCtx.toString(result));
				result = rhinoCtx.evaluateString(rhinoScope, pfData.getExpY(),
						"drawPFunc.pfExpY2", 1, null);
				canvasY = Float.parseFloat(rhinoCtx.toString(result));
				linePts[lineCount++] = (float)canvasToScreenX(canvasX);
				linePts[lineCount++] = (float)canvasToScreenY(canvasY);
				linePts[lineCount++] = (float)canvasToScreenX(canvasX);
				linePts[lineCount++] = (float)canvasToScreenY(canvasY);
				//lineCount += 4;
				if (lineCount >= linePts.length)
				{
					break;
				}
			}
		}
		catch (Exception error)
		{
			Utils.showTraceDialog(ctx, error);
			return;
		}
		finally
		{
			rhinoCtx.exit();
		}

		funcPaint = new Paint();
		funcPaint.setAntiAlias(antiAlias);
		funcPaint.setColor(colorFunc);
		canvas.drawLines(linePts, 0, lineCount - 2, funcPaint);
	}


	/**********
	 * drawGrid
	 * - 画出网格
	 */
	private void drawGrid()
	{
		int lineStartX;
		int lineStartY;
		int lineEndX;
		int lineEndY;
		Paint gridPaint;

		if (!showGrid)
		{
			return;
		}

		gridPaint = new Paint();
		gridPaint.setAntiAlias(false);
		gridPaint.setColor(colorGrid);
		// 为了防止少画网格，所以 + 1，这样会画到屏幕外面，就看不出了。
		lineStartX = pointO.x - (pointO.x / gridSize + 1) * gridSize;
		lineStartY = pointO.y - (pointO.y / gridSize + 1) * gridSize;
		lineEndX = pointO.x + ((canvasWidth - pointO.x) / gridSize + 1)
				* gridSize;
		lineEndY = pointO.y + ((canvasHeight - pointO.y) / gridSize + 1)
				* gridSize;

		// 画竖线
		for (int currentX = lineStartX; currentX < lineEndX; currentX += gridSize)
		{
			canvas.drawLine((float)currentX, (float)lineStartY,
					(float)currentX, (float)lineEndY, gridPaint);
		}

		// 画横线
		for (int currentY = lineStartY; currentY < lineEndY; currentY += gridSize)
		{
			canvas.drawLine((float)lineStartX, (float)currentY,
					(float)lineEndX, (float)currentY, gridPaint);
		}
	}


	/***********
	 * drawCoord
	 * - 画出坐标系
	 */
	private void drawCoord()
	{
		Paint coordPaint;
		Path arrow;

		coordPaint = new Paint();
		coordPaint.setAntiAlias(false);
		coordPaint.setColor(colorCoord);
		// 竖线
		canvas.drawLine((float)pointO.x, 0.0f, (float)pointO.x,
				(float)canvasHeight, coordPaint);
		// 横线
		canvas.drawLine(0.0f, (float)pointO.y, (float)canvasWidth,
				(float)pointO.y, coordPaint);

		// y坐标轴箭头
		coordPaint.setAntiAlias(antiAlias);
		arrow = new Path();
		arrow.moveTo((float)pointO.x, 0.0f);
		arrow.lineTo((float)(pointO.x - SIZE_COORDNUM / 4),
				(float)SIZE_COORDNUM);
		arrow.lineTo((float)(pointO.x + SIZE_COORDNUM / 4 + 1),
				(float)SIZE_COORDNUM);
		arrow.close();
		canvas.drawPath(arrow, coordPaint);
		// x坐标轴箭头
		arrow.moveTo((float)canvasWidth, (float)pointO.y);
		arrow.lineTo((float)(canvasWidth - SIZE_COORDNUM),
				(float)(pointO.y - SIZE_COORDNUM / 4));
		arrow.lineTo((float)(canvasWidth - SIZE_COORDNUM), (float)(pointO.y
				+ SIZE_COORDNUM / 4 + 1));
		arrow.close();
		canvas.drawPath(arrow, coordPaint);
	}


	/**************
	 * drawCoordNum
	 * - 画出坐标轴单位
	 */
	private void drawCoordNum()
	{
		int lineStartX;
		int lineStartY;
		int lineEndX;
		int lineEndY;
		int coordCanvasStartX;
		int coordCanvasStartY;
		int coordCanvasEndX;
		int coordCanvasEndY;
		int coordScreenX;
		int coordScreenY;
		Paint coordNumPaint;

		if (!showCoordNum)
		{
			return;
		}

		coordNumPaint = new Paint();
		coordNumPaint.setAntiAlias(antiAlias);
		coordNumPaint.setColor(colorCoordNum);
		coordNumPaint.setTextSize((float)SIZE_COORDNUM);
		coordNumPaint.setTextAlign(Paint.Align.LEFT);
		coordNumPaint.setTypeface(Typeface.SERIF);

		lineStartX = pointO.x - (pointO.x / gridSize + 1) * gridSize;
		lineStartY = pointO.y - (pointO.y / gridSize + 1) * gridSize;
		lineEndX = pointO.x + ((canvasWidth - pointO.x) / gridSize + 1)
				* gridSize;
		lineEndY = pointO.y + ((canvasHeight - pointO.y) / gridSize + 1)
				* gridSize;
		// NOTICE
		// 数学坐标系中y坐标为由下到上递增，而在屏幕中y坐标由下到上递减。
		// lineStartY在屏幕上方，lineEndY在屏幕下方，所以画坐标数字时应该颠倒画。
		coordCanvasStartX = (int)screenToCanvasX(lineStartX);
		coordCanvasStartY = (int)screenToCanvasY(lineEndY);
		coordCanvasEndX = (int)screenToCanvasX(lineEndX);
		coordCanvasEndY = (int)screenToCanvasY(lineStartY);
		coordScreenX = pointO.x;
		coordScreenY = pointO.y;

		// 防止坐标数字画到屏幕外。
		if (coordScreenX < 0)
		{
			coordScreenX = 0;
		}
		else if (coordScreenX > canvasWidth - SIZE_COORDNUM * 2)
		{
			coordScreenX = canvasWidth - SIZE_COORDNUM * 2;
		}

		if (coordScreenY < 0)
		{
			coordScreenY = 0;
		}
		else if (coordScreenY > canvasHeight - SIZE_COORDNUM)
		{
			coordScreenY = canvasHeight - SIZE_COORDNUM;
		}

		// x坐标单位
		for (int currentCanvasX = coordCanvasStartX; currentCanvasX <= coordCanvasEndX; currentCanvasX++)
		{
			// 原点另外画
			if (currentCanvasX == 0)
			{
				continue;
			}

			canvas.drawText("" + currentCanvasX,
					canvasToScreenX((float)currentCanvasX),
					(float)(coordScreenY + SIZE_COORDNUM), coordNumPaint);
		}

		// y坐标单位
		for (int currentCanvasY = coordCanvasStartY; currentCanvasY <= coordCanvasEndY; currentCanvasY++)
		{
			if (currentCanvasY == 0)
			{
				continue;
			}

			canvas.drawText("" + currentCanvasY, (float)coordScreenX,
					canvasToScreenY((float)currentCanvasY)
							+ (float)SIZE_COORDNUM, coordNumPaint);
		}

		// 画出原点
		coordNumPaint.setTypeface(Typeface.create(Typeface.SERIF,
				Typeface.ITALIC));
		canvas.drawText("O", (float)coordScreenX,
				(float)(coordScreenY + SIZE_COORDNUM), coordNumPaint);
	}


	/**************
	 * drawZoomTool
	 * - 画出放大镜
	 * Notes:
	 * - 可用版本。
	 */
	private void drawZoomTool()
	{
		View zoomView;
		Bitmap zoomBmp;
		Rect zoomSrcRect;
		Rect zoomDestRect;
		Rect zoomEdgeRect;
		Paint zoomEdgePaint;
		int zoomSrcSize;
		int zoomDestSize;

		// 可能不需要判断x、y坐标是否大于canvasWidth、canvasHeight
		/*if (!showZoomTool || !needDraw || pointer.x < 0
				|| pointer.x > canvasWidth || pointer.y < 0
				|| pointer.y > canvasHeight)
		{
			return;
		}*/
		// !needDrawZoomTool作用：
		// zoomView.getDrawingCache会触发onDraw，而onDraw中又会调用
		// drawZoomTool，如果没有这个判断，就会造成死循环了。
		// 加入之后，如果值为假，则表示不用画出放大镜，也就表示是在drawZoomTool
		// 触发onDraw的。
		if (!showZoomTool || !needDrawZoomTool || pointer.x < 0
				|| pointer.y < 0)
		{
			return;
		}

		// 为了更好看
		zoomView = this;
		zoomView.setDrawingCacheEnabled(true);
		// 这次触发onDraw之后再调用drawZoomTool时就直接退出
		needDrawZoomTool = false;
		zoomBmp = zoomView.getDrawingCache();

		if (zoomBmp == null)
		{
			Utils.showToast(ctx, "Unable to build tool");
			return;
		}

		// 需要放大的矩形区域
		zoomSrcRect = new Rect();
		// 放大后显示的矩形区域
		zoomDestRect = new Rect();
		// 放大镜边框
		zoomEdgeRect = new Rect();
		zoomEdgePaint = new Paint();
		zoomDestSize = (int)((float)canvasHeight / ZOOM_FACTOR);
		zoomSrcSize = (int)((float)zoomDestSize / ZOOM_FACTOR);

		zoomSrcRect.left = pointer.x - zoomSrcSize / 2;
		zoomSrcRect.top = pointer.y - zoomSrcSize / 2;

		if (zoomSrcRect.left < 0)
		{
			zoomSrcRect.left = 0;
		}
		else if (zoomSrcRect.left > canvasWidth - zoomSrcSize)
		{
			zoomSrcRect.left = canvasWidth - zoomSrcSize;
		}

		zoomSrcRect.right = zoomSrcRect.left + zoomSrcSize;
		zoomSrcRect.bottom = zoomSrcRect.top + zoomSrcSize;

		if (zoomSrcRect.top < 0)
		{
			zoomSrcRect.top = 0;
		}
		else if (zoomSrcRect.top > canvasHeight - zoomSrcSize)
		{
			zoomSrcRect.top = canvasHeight - zoomSrcSize;
		}

		if (zoomSrcRect.left < zoomDestSize && zoomSrcRect.top < zoomDestSize)
		{
			zoomDestRect.top = canvasHeight - zoomDestSize;
		}
		else
		{
			zoomDestRect.top = 0;
		}

		zoomDestRect.left = 0;
		zoomDestRect.right = zoomDestRect.left + zoomDestSize;
		zoomDestRect.bottom = zoomDestRect.top + zoomDestSize;

		zoomEdgeRect.left = zoomDestRect.left - 4;
		zoomEdgeRect.top = zoomDestRect.top - 4;
		zoomEdgeRect.right = zoomDestRect.right + 4;
		zoomEdgeRect.bottom = zoomDestRect.bottom + 4;

		// 放大镜边框设置为函数图像颜色，因为函数图像颜色一般不会和背景同色，除非
		// 用户无聊让自己看不见函数图像。:)
		zoomEdgePaint.setColor(colorFunc);
		// drawXXX不会触发onDraw
		canvas.drawRect(zoomEdgeRect, zoomEdgePaint);
		canvas.drawBitmap(zoomBmp, zoomSrcRect, zoomDestRect, null);
		//Log.w("drawZoomTool", "drawZoomTool ended");
	}


	/******************
	 * drawZoomTool_bak
	 * - 画出放大镜
	 * Notes:
	 * - 无法使用，保留是为了以后的研究。:)
	 */
	private void drawZoomTool_bak()
	{
		Canvas zoomCanvas;
		Bitmap zoomBmp;
		Rect zoomSrcRect;
		Rect zoomDestRect;
		int zoomSrcSize;
		int zoomDestSize;

		if (!showZoomTool || !needDrawZoomTool || pointer.x < 0
				|| pointer.x > canvasWidth || pointer.y < 0
				|| pointer.y > canvasHeight)
		{
			return;
		}

		zoomBmp = Bitmap.createBitmap(canvasHeight, canvasHeight,
				Bitmap.Config.ARGB_8888);
		zoomCanvas = new Canvas(zoomBmp);
		zoomSrcRect = new Rect();
		zoomDestRect = new Rect();
		zoomDestSize = (int)((float)canvasHeight / ZOOM_FACTOR);
		zoomSrcSize = (int)((float)zoomDestSize / ZOOM_FACTOR);
		zoomSrcRect.left = pointer.x - zoomSrcSize / 2;
		zoomSrcRect.top = pointer.y - zoomSrcSize / 2;

		if (zoomSrcRect.left < 0)
		{
			zoomSrcRect.left = 0;
		}
		else if (zoomSrcRect.left > canvasWidth - zoomSrcSize)
		{
			zoomSrcRect.left = canvasWidth - zoomSrcSize;
		}

		zoomSrcRect.right = zoomSrcRect.left + zoomSrcSize;
		zoomSrcRect.bottom = zoomSrcRect.top + zoomSrcSize;

		if (zoomSrcRect.top < 0)
		{
			zoomSrcRect.top = 0;
		}
		else if (zoomSrcRect.top > canvasHeight - zoomSrcSize)
		{
			zoomSrcRect.top = canvasHeight - zoomSrcSize;
		}

		if (zoomSrcRect.left < zoomDestSize && zoomSrcRect.top < zoomDestSize)
		{
			zoomDestRect.top = canvasHeight - zoomDestSize;
		}
		else
		{
			zoomDestRect.top = 0;
		}

		zoomDestRect.left = 0;
		zoomDestRect.right = zoomDestRect.left + zoomDestSize;
		zoomDestRect.bottom = zoomDestRect.top + zoomDestSize;

		//canvas.drawBitmap(canvasBmp, zoomSrcRect, zoomDestRect, new Paint());
		Paint paint = new Paint();
		paint.setColor(colorFunc);
		needDrawZoomTool = false;
		//canvas.drawRect(zoomDestRect, paint);
		draw(zoomCanvas);
		canvas.drawBitmap(zoomBmp, zoomSrcRect, zoomDestRect, null);
		Log.w("drawZoomTool", "drawZoomTool ended");
	}


	/*************
	 * drawPointer
	 * - 画出触点线坐标
	 * Notes:
	 * - 如果触点线坐标x或y小于零，则不画出。
	 */
	private void drawPointer()
	{
		float canvasX;
		float canvasY;
		Paint pointerPaint;

		// 可能不需要判断是否大于canvasWidth，用户不可能点到外面
		/*if (!showPointer || pointer.x < 0 || pointer.x > canvasWidth
				|| pointer.y < 0 || pointer.y > canvasHeight)
		{
			return;
		}*/
		if (!showPointer || pointer.x < 0 || pointer.y < 0)
		{
			return;
		}

		pointerPaint = new Paint();
		pointerPaint.setAntiAlias(false);
		pointerPaint.setColor(colorPointer);
		canvas.drawLine((float)pointer.x, 0.0f, (float)pointer.x,
				(float)canvasHeight, pointerPaint);
		canvas.drawLine(0.0f, (float)pointer.y, (float)canvasWidth,
				(float)pointer.y, pointerPaint);

		pointerPaint.setAntiAlias(antiAlias);
		pointerPaint.setTypeface(Typeface.SERIF);
		canvasX = screenToCanvasX(pointer.x);
		canvasY = screenToCanvasY(pointer.y);
		/*canvas.drawText("(" + canvasX + ", " + canvasY + ")", (float)pointer.x,
				(float)(pointer.y + SIZE_COORDNUM), pointerPaint);*/
		// 更好看的实现
		canvas.drawText(String.format("(%f, %f)", canvasX, canvasY),
				(float)pointer.x, (float)(pointer.y + SIZE_COORDNUM),
				pointerPaint);
	}


	/****************
	 * screenToCanvas
	 * - 屏幕坐标转换为画布坐标
	 * Parameter：
	 * - sp: 屏幕坐标的点对象
	 * Return:
	 * - 画布坐标的点对象
	 * Notes:
	 * - 基本不会直接用，因为很少同时计算x、y坐标。
	 */
	private PointF screenToCanvas(Point sp)
	{
		PointF cp;

		cp = new PointF();
		cp.x = ((float)(sp.x - pointO.x)) / gridSize;
		cp.y = ((float)-(sp.y - pointO.y)) / gridSize;

		return cp;
	}


	private float screenToCanvasX(int spX)
	{
		return screenToCanvas(new Point(spX, 0)).x;
	}


	private float screenToCanvasY(int spY)
	{
		return screenToCanvas(new Point(0, spY)).y;
	}


	/****************
	 * canvasToScreen
	 * - 画布坐标转换为屏幕坐标
	 * Parameters:
	 * - cp: 画布坐标的点对象
	 * Return:
	 * - 屏幕坐标的点对象
	 * Notes:
	 * - 基本不会直接用，因为很少同时计算x、y坐标。
	 */
	private Point canvasToScreen(PointF cp)
	{
		Point sp;

		sp = new Point();
		sp.x = (int)(cp.x * (float)gridSize) + pointO.x;
		sp.y = (int)(-cp.y * (float)gridSize) + pointO.y;

		return sp;
	}


	private int canvasToScreenX(float cpX)
	{
		return canvasToScreen(new PointF(cpX, 0.0f)).x;
	}


	private int canvasToScreenY(float cpY)
	{
		return canvasToScreen(new PointF(0.0f, cpY)).y;
	}
}
