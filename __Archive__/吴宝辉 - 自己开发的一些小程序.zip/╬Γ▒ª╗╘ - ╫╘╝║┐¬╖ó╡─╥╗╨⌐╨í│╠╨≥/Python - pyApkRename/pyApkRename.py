#encoding = utf-8
'''Name: pyApkRename
Author: Woobhurk
Copyright(C)2015 Lation Woobhurk.
All rights reserved.
----------------------------------------------------------------
Verison: 0.6.0 (2015.03.30 13:26:32)
ChangeLog:
1. 修正终端不能输出中文的问题。
----------------------------------------------------------------
Version: 0.5.7 (2015.03.29 19:39:16)
ChangeLog:
0. 完成基本功能。
Notes:
完成了！这个程序是我好久以前就想写的，但因为能力一直拖延...
这个程序可以通过指定的文件名格式来重命名apk文件，目前处于测试当中。
第一次使用面向对象方法来写Python程序。
程序有个问题：直接运行脚本无法指定是否输出日志，需要实例化ApkRename
并直接调用主方法才可以。
'''

import os
import os.path as ospath
import sys
import subprocess
import codecs
import time





################################################################
# CONSTANTS
################################################################
DEF_PATTERN = '{apkn} {vern}.apk';
DEF_ROOTDIR = ospath.curdir;
#DEF_ROOTDIR = os.getcwd();
AAPT_CMD = 'aapt d badging "{0}">{1}';
TMP_FILE = '_temporary';
LOG_FILE = 'pyApkRename-log_{0}.htm';




################################################################
# CLASSES
################################################################
class ApkRename:
    '''用指定的文件名格式重命名apk文件。

    主方法：
    renameFile：重命名单个apk文件；
    renameFolder：重命名文件夹下的apk文件。
    '''
    def __init__(self):
        '''初始化一些变量。'''
        self.apkdirs = [];
        self.apknames = [];
        # 以下变量是用来储存log信息的。
        self.succount = 0;
        self.error = False;
        self.logexp = True;
        self.logfile = '';
        self.logtab = {
            'apkname': '',
            'newapkname': '',
            'apkdir': '',
            'state': '',
            'errlog': '',
            'apkinfo': ''
        };
        self.loghtm = '';
        print("ApkRename.__init__");
        return None;



    def addFile(self, apkdir, apkname):
        '''添加文件夹和文件名到列表中。

        apkdir：文件夹；
        apkname：文件名。
        '''
        self.apkdirs.append(apkdir);
        self.apknames.append(apkname);
        return None;



    def addFolder(self, rootdir):
        '''遍历文件夹，添加文件夹和文件到列表中。

        rootdir：遍历的文件夹。
        '''
        for apkdir, _, filenames in os.walk(rootdir):
            for apkname in filenames:
                if apkname.endswith('.apk'):
                    self.addFile(apkdir, apkname);
        return None;



    def renameFile(self, pattern, apkfile, logexp=True):
        '''重命名单个apk文件，主方法。

        pattern：文件名格式；
        apkfile：完整的文件路径；
        logexp：是否输出日志。
        '''
        apkdir = ospath.split(apkfile)[0];
        apkname = ospath.split(apkfile)[1];

        if pattern == '':
            pattern = DEF_PATTERN;
        # 如果遗漏了后缀名则自动添加。
        if not pattern.endswith('.apk'):
            pattern += '.apk';
        if apkdir == '':
            apkdir = DEF_ROOTDIR;

        # 重新初始化列表，以便函数可以重复使用。
        self.apkdirs = [];
        self.apknames = [];
        self.logexp = logexp;
        self.checkPattern(pattern);
        self.addFile(apkdir, apkname);
        self.renameAllApk(pattern);
        return None;



    def renameFolder(self, pattern, rootdir, logexp=True):
        '''重命名文件夹下的所有apk文件，主方法。

        pattern：文件名格式；
        rootdir：遍历的文件夹；
        logexp：是否输出日志。
        '''
        if pattern == '':
            pattern = DEF_PATTERN;
        if not pattern.endswith('.apk'):
            pattern += '.apk';
        if rootdir == '':
            rootdir = DEF_ROOTDIR;

        self.apkdirs = [];
        self.apknames = [];
        self.logexp = logexp;
        self.checkPattern(pattern);
        self.addFolder(rootdir);
        self.renameAllApk(pattern);
        return None;



    def renameAllApk(self, pattern):
        '''重命名所有apk文件，主要过程。

        pattern：文件名格式。
        '''
        #print("renameAllApk: pattern: ", pattern, self.apkdirs, self.apknames);
        self.logfile = LOG_FILE.format(time.strftime('%Y%m%d-%H%M%S'));
        # 日志文件的头信息。
        self.loghtm = (
            '<!DOCTYPE html>'
            '<html style="color:#50453b; background-color:#f0d0b0; font-family:Lucida Sans Unicode">'
            '<head>'
            '<meta charset="utf-8" />'
            '<title>{logfile}</title>'
            '<style>'
            'table {{border:2px solid #f08000}}'
            'th {{border:1px solid #f08000; text-align:right; min-width:160px}}'
            'td {{border:1px solid #f08000; text-align:left; min-width:500px}}'
            'hr {{border:2px solid #804000}}'
            '</style>'
            '</head>'
            '<body>'
            '<h1>{logfile}</h1>'
            '<b>Rename pattern:</b> {pattern}<br />'
            '<hr />'
        ).format(logfile=self.logfile, pattern=pattern);

        apkcount = len(self.apknames);
        self.succount = 0;
        cnt = 0;
        while cnt < apkcount:
            self.error = False;
            self.setLog(errlog='(None)');
            apkdir = self.apkdirs[cnt];
            apkname = self.apknames[cnt];
            apkfile = apkdir + os.sep + apkname;
            patterntab = self.getPatternTab(apkfile);
            newapkname = self.getNewApkName(pattern, patterntab);
            self.renameOneApk(apkdir, apkname, newapkname);
            self.setLog(apkname=apkname,
                        newapkname=newapkname,
                        apkdir=ospath.abspath(apkdir),
                        apkinfo=patterntab);
            self.appendLog();
            cnt += 1;
            if not self.error:
                self.succount += 1;
            print(("renameAllApk: {0}/{2} finished, "
                   "{1}/{2} successfully."
                   ).format(cnt, self.succount, apkcount));
        os.remove(TMP_FILE);

        if self.logexp:
            self.exportLog();
            print(("renameAllApk: Logs have been saved in {0}, "
                   "please check it."
                   ).format(self.logfile));
        return None;



    def renameOneApk(self, apkdir, apkname, newapkname):
        '''重命名单个apk文件，主过程。

        apkdir：apk所在目录；
        apkname：apk文件名；
        newapkname：新的文件名。
        '''
        apkname = apkdir + os.sep + apkname;
        newapkname = apkdir + os.sep + newapkname;
        try:
            os.rename(apkname, newapkname);
        except Exception as errexp:
            self.error = True;
            self.setLog(state='<td style="color:#ff0000; font-weight:bold">FAILED</td>',
                        errlog=errexp);
            print("renameOneApk: errexp: ", errexp);
        else:
            self.setLog(state='<td style="color:#00a000; font-weight:bold">Successfully</td>');
        return None;



    def getPatternTab(self, apkfile):
        '''获取apk信息，储存在字典中。

        apkfile：完整的apk文件路径。
        返回：存有信息的字典。
        '''
        patterntab = {
            'orin': '',
            'pkgn': '',
            'apkn': '',
            'vern': '',
            'verc': ''
        };
        # 去掉原文件名的后缀。
        patterntab['orin'] = ospath.split(apkfile)[1][:-4];
        cmd = AAPT_CMD.format(apkfile, TMP_FILE);
        subprocess.call(cmd, shell=True);
        with codecs.open(TMP_FILE, 'r', 'utf-8') as tmpfile:
            lines = tmpfile.readlines();
            #print("getPatternTab: lines: ", lines);
            for line in lines:
                if line.startswith('package:'):
                    startpos = line.find('name=\'') + 6;
                    patterntab['pkgn'] = line[startpos:line.find('\'', startpos)];
                    startpos = line.find('versionCode=\'') + 13;
                    patterntab['verc'] = line[startpos:line.find('\'', startpos)];
                    startpos = line.find('versionName=\'') + 13;
                    patterntab['vern'] = line[startpos:line.rfind('\'')];
                elif line.startswith('application:'):
                    startpos = line.find('label=\'') + 7;
                    patterntab['apkn'] = line[startpos:line.find('\'', startpos)];
                    break;
        #print("getPatternTab: patterntab: ", patterntab);
        return patterntab;



    def getNewApkName(self, pattern, patterntab):
        '''获取新的文件名。

        pattern：文件名格式；
        patterntab：apk信息字典。
        返回：新的文件名。
        '''
        newapkname = pattern.format(**patterntab);
        #print("getNewApkName: newapkname: ", newapkname);
        return newapkname;



    def checkPattern(self, pattern):
        '''检查文件名格式是否合法。

        pattern：文件名格式。
        '''
        # 临时创建空键值的字典，判断是否合法。
        patterntab = {
            'orin': '',
            'pkgn': '',
            'apkn': '',
            'vern': '',
            'verc': ''
        };
        try:
            pattern.format(**patterntab);
        except Exception as errexp:
            print("checkPattern: Invalid pattern: ", pattern);
            self.showUsage();
            exit();
        return None;



    def setLog(self, **logtab):
        '''设置日志信息。

        logtab：日志信息的字典。
        '''
        for key in logtab.keys():
            self.logtab[key] = logtab[key];
        #print("setLog: logtab: ", self.logtab);
        return None;



    def appendLog(self):
        '''追加日志信息。

        日志信息是经过格式化的。
        '''
        # 重命名信息
        logtxt = (
            '<b>Rename information:</b><br />'
            '<table>'
            '<tr><th>Old apk name:</th><td>{apkname}</td></tr>'
            '<tr><th>New apk name:</th><td>{newapkname}</td></tr>'
            '<tr><th>Apk directory:</th><td>{apkdir}</td></tr>'
            '<tr><th>State:</th>{state}</tr>'
            '<tr><th>Error log:</th><td>{errlog}</td></tr>'
            '</table><br />'
        ).format(**self.logtab);
        # apk信息
        logtxt += (
            '<b>Apk information:</b><br />'
            '<table>'
            '<tr><th>Package name:</th><td>{pkgn}</td></tr>'
            '<tr><th>Version Code:</th><td>{verc}</td></tr>'
            '<tr><th>Version Name:</th><td>{vern}</td></tr>'
            '<tr><th>Application label:</th><td>{apkn}</td></tr>'
            '</table><br /><hr />'
        ).format(**self.logtab['apkinfo']);
        # 这是旧的格式化方法。
        '''logtxt = (
            '<b>Old apk name:</b> {apkname}<br />'
            '<b>New apk name:</b> {newapkname}<br />'
            '<b>Apk directory:</b> {apkdir}<br />'
            '<b>State:</b> {state}<br />'
            '<b>Error log:</b><br />'
            '<em style="color:#ff0000; padding-left:4%">{errlog}</em><br />'
            '<b>Apk information:</b><br />'
        ).format(**self.logtab);
        logtxt += (
            '<b style="padding-left:4%">Package name:</b> {pkgn}<br />'
            '<b style="padding-left:4%">Version Code:</b> {verc}<br />'
            '<b style="padding-left:4%">Version Name:</b> {vern}<br />'
            '<b style="padding-left:4%">Application label:</b> {apkn}<br />'
            '<hr />'
        ).format(**self.logtab['apkinfo']);'''
        self.loghtm += logtxt;
        return None;



    def exportLog(self):
        '''输出日志文件。'''
        # 追加html尾部的信息。
        self.loghtm += (
            '</body>'
            '</html>'
        );
        with codecs.open(self.logfile, 'w', 'utf-8') as logfile:
            logfile.write(self.loghtm);
        return None;



    def showUsage(self):
        '''显示帮助。'''
        # 以下是翻译的用法。
        usageinfo = '''pyApkRename
重命名一个.apk文件或一个文件夹里的所有.apk文件。
----------------------------------------------------------------
USAGE
    pyApkRename APK_PATTERN='{0}' APK_ROOTDIR='{1}'

----------------------------------------------------------------
ARGUMENTS
    APK_PATTERN：目标文件的格式，有以下参数可用：
        * orin：原始文件名（没有.apk后缀）；
        * apkn：应用程序的名称，不是.apk文件名；
        * pkgn：应用程序的包名；
        * vern：应用程序的VersionName；
        * verc：应用程序的VersionCode。
    APK_ROOTDIR：将要扫描的文件夹，注意将会扫描子文件夹。

----------------------------------------------------------------
NOTE
    小心！如果你不相信这个工具，请事先备份.apk文件，因为这个工具会重
    命名（而不是复制）你的.apk文件。

    你可以将APK_PATTERN和（或）APK_ROOTDIR指定为空字符串（''），但
    不能将这些参数留空。默认格式将为{0}，默认路径为{1}。

    如果你在格式中遗漏了'.apk'后缀，程序将自动加上。

----------------------------------------------------------------
EXAMPLE
    pyApkRename '{0}' '{1}'
        将会重命名当前文件下及子文件夹下的.apk文件。
    pyApkRaname '' ''
        将会用默认参数重命名所有.apk文件。
    还有更多...
'''.format(DEF_PATTERN, DEF_ROOTDIR);
        # 判断终端是否支持中文字符。
        try:
            print(usageinfo);
        except:
            usageinfo = '''pyApkRename
Rename a single .apk file or all .apk files in a directory.
----------------------------------------------------------------
USAGE
    pyApkRename APK_PATTERN='{0}' APK_ROOTDIR='{1}'

----------------------------------------------------------------
ARGUMENTS
    APK_PATTERN: The pattern of target names. The following
        arguments are available:
        * orin: The original name of the file;
        * apkn: The name of the application, not the file name;
        * pkgn: The package name of the application;
        * vern: The VersionName of the application;
        * verc: The VersionCode of the application.
    APK_ROOT_DIR: The diractory to be scanned. Note that ALL
        .apk files in the APK_ROOT_DIR and it's subfolders will
        be scanned.

----------------------------------------------------------------
NOTE
    BE CAUTIOUS! Please backup the .apk files if you don't
    trust this tool, since it will RENAME, not COPY, all the
    files.

    You can specify APK_PATTERN and(or) APK_ROOTDIR as an empty
    string (''), but cannot remain them empty. The default
    directory will be the default pattern will be '{0}'
    and the current working directory '{1}'.

    If you omit the extension name (.apk), this tool will add it
    automatically.

----------------------------------------------------------------
EXAMPLE
    pyApkRename '{0}' '{1}'
        Will rename all the .apk files in the current dir.
    pyApkRaname '' ''
        Will rename all the .apk files using default options.
    And more...
'''.format(DEF_PATTERN, DEF_ROOTDIR);
            print(usageinfo);
            pass;
        return None;




# main FUNCTION
def main(argv=sys.argv[1:]):
    argc = len(argv);
    apkrename = ApkRename();

    if argc != 2:
        apkrename.showUsage();
        return None;

    # 判断是文件还是文件夹。
    if ospath.isfile(argv[1]):
        apkrename.renameFile(argv[0], argv[1]);
    elif ospath.isdir(argv[1]) or argv[1] == '':
        apkrename.renameFolder(argv[0], argv[1]);
    else:
        print("main: Invalid arguments: ", argv);
        apkrename.showUsage();
    return None;






################################################################
# MAIN
################################################################
if __name__ == "__main__":
    main();
