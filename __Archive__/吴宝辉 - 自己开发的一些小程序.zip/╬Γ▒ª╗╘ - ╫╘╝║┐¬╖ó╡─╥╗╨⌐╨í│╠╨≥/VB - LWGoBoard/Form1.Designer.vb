﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MainForm
	Inherits System.Windows.Forms.Form

	'Form 重写 Dispose，以清理组件列表。
	<System.Diagnostics.DebuggerNonUserCode()> _
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		Try
			If disposing AndAlso components IsNot Nothing Then
				components.Dispose()
			End If
		Finally
			MyBase.Dispose(disposing)
		End Try
	End Sub

	'Windows 窗体设计器所必需的
	Private components As System.ComponentModel.IContainer

	'注意: 以下过程是 Windows 窗体设计器所必需的
	'可以使用 Windows 窗体设计器修改它。
	'不要使用代码编辑器修改它。
	<System.Diagnostics.DebuggerStepThrough()> _
	Private Sub InitializeComponent()
		Me.components = New System.ComponentModel.Container
		Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MainForm))
		Me.DrawTimer = New System.Windows.Forms.Timer(Me.components)
		Me.Board1 = New System.Windows.Forms.Label
		Me.BWBtn = New System.Windows.Forms.Label
		Me.BBtn = New System.Windows.Forms.Label
		Me.WBtn = New System.Windows.Forms.Label
		Me.POBtn = New System.Windows.Forms.Label
		Me.ClrBtn = New System.Windows.Forms.Label
		Me.SQBtn = New System.Windows.Forms.Label
		Me.InfoLab = New System.Windows.Forms.Label
		Me.ChmBtn = New System.Windows.Forms.Label
		Me.Board = New System.Windows.Forms.PictureBox
		CType(Me.Board, System.ComponentModel.ISupportInitialize).BeginInit()
		Me.SuspendLayout()
		'
		'DrawTimer
		'
		Me.DrawTimer.Enabled = True
		Me.DrawTimer.Interval = 20
		'
		'Board1
		'
		Me.Board1.BackColor = System.Drawing.Color.Khaki
		Me.Board1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.Board1.Location = New System.Drawing.Point(254, 410)
		Me.Board1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
		Me.Board1.Name = "Board1"
		Me.Board1.Size = New System.Drawing.Size(236, 139)
		Me.Board1.TabIndex = 0
		Me.Board1.Visible = False
		'
		'BWBtn
		'
		Me.BWBtn.BackColor = System.Drawing.Color.DarkGreen
		Me.BWBtn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me.BWBtn.Cursor = System.Windows.Forms.Cursors.Hand
		Me.BWBtn.Font = New System.Drawing.Font("微软雅黑", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
		Me.BWBtn.ForeColor = System.Drawing.Color.LawnGreen
		Me.BWBtn.Location = New System.Drawing.Point(0, 650)
		Me.BWBtn.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
		Me.BWBtn.Name = "BWBtn"
		Me.BWBtn.Size = New System.Drawing.Size(70, 20)
		Me.BWBtn.TabIndex = 3
		Me.BWBtn.Text = "黑 / 白棋"
		Me.BWBtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		'
		'BBtn
		'
		Me.BBtn.BackColor = System.Drawing.Color.ForestGreen
		Me.BBtn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me.BBtn.Cursor = System.Windows.Forms.Cursors.Hand
		Me.BBtn.Font = New System.Drawing.Font("微软雅黑", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
		Me.BBtn.ForeColor = System.Drawing.Color.LawnGreen
		Me.BBtn.Location = New System.Drawing.Point(140, 650)
		Me.BBtn.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
		Me.BBtn.Name = "BBtn"
		Me.BBtn.Size = New System.Drawing.Size(70, 20)
		Me.BBtn.TabIndex = 4
		Me.BBtn.Text = "黑棋"
		Me.BBtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		'
		'WBtn
		'
		Me.WBtn.BackColor = System.Drawing.Color.ForestGreen
		Me.WBtn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me.WBtn.Cursor = System.Windows.Forms.Cursors.Hand
		Me.WBtn.Font = New System.Drawing.Font("微软雅黑", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
		Me.WBtn.ForeColor = System.Drawing.Color.LawnGreen
		Me.WBtn.Location = New System.Drawing.Point(210, 650)
		Me.WBtn.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
		Me.WBtn.Name = "WBtn"
		Me.WBtn.Size = New System.Drawing.Size(70, 20)
		Me.WBtn.TabIndex = 5
		Me.WBtn.Text = "白棋"
		Me.WBtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		'
		'POBtn
		'
		Me.POBtn.BackColor = System.Drawing.Color.ForestGreen
		Me.POBtn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me.POBtn.Cursor = System.Windows.Forms.Cursors.Hand
		Me.POBtn.Font = New System.Drawing.Font("微软雅黑", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
		Me.POBtn.ForeColor = System.Drawing.Color.LawnGreen
		Me.POBtn.Location = New System.Drawing.Point(280, 650)
		Me.POBtn.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
		Me.POBtn.Name = "POBtn"
		Me.POBtn.Size = New System.Drawing.Size(70, 20)
		Me.POBtn.TabIndex = 6
		Me.POBtn.Text = "提子"
		Me.POBtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		'
		'ClrBtn
		'
		Me.ClrBtn.BackColor = System.Drawing.Color.ForestGreen
		Me.ClrBtn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me.ClrBtn.Cursor = System.Windows.Forms.Cursors.Hand
		Me.ClrBtn.Font = New System.Drawing.Font("微软雅黑", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
		Me.ClrBtn.ForeColor = System.Drawing.Color.LawnGreen
		Me.ClrBtn.Location = New System.Drawing.Point(420, 650)
		Me.ClrBtn.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
		Me.ClrBtn.Name = "ClrBtn"
		Me.ClrBtn.Size = New System.Drawing.Size(70, 20)
		Me.ClrBtn.TabIndex = 7
		Me.ClrBtn.Text = "清盘"
		Me.ClrBtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		'
		'SQBtn
		'
		Me.SQBtn.BackColor = System.Drawing.Color.ForestGreen
		Me.SQBtn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me.SQBtn.Cursor = System.Windows.Forms.Cursors.Hand
		Me.SQBtn.Font = New System.Drawing.Font("微软雅黑", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
		Me.SQBtn.ForeColor = System.Drawing.Color.LawnGreen
		Me.SQBtn.Location = New System.Drawing.Point(350, 650)
		Me.SQBtn.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
		Me.SQBtn.Name = "SQBtn"
		Me.SQBtn.Size = New System.Drawing.Size(70, 20)
		Me.SQBtn.TabIndex = 8
		Me.SQBtn.Text = "显示气眼"
		Me.SQBtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		'
		'InfoLab
		'
		Me.InfoLab.AutoSize = True
		Me.InfoLab.BackColor = System.Drawing.Color.DarkKhaki
		Me.InfoLab.Font = New System.Drawing.Font("微软雅黑", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
		Me.InfoLab.ForeColor = System.Drawing.Color.Khaki
		Me.InfoLab.Location = New System.Drawing.Point(0, 0)
		Me.InfoLab.Name = "InfoLab"
		Me.InfoLab.Size = New System.Drawing.Size(90, 19)
		Me.InfoLab.TabIndex = 9
		Me.InfoLab.Text = "黑棋0，白棋0"
		'
		'ChmBtn
		'
		Me.ChmBtn.BackColor = System.Drawing.Color.ForestGreen
		Me.ChmBtn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me.ChmBtn.Cursor = System.Windows.Forms.Cursors.Hand
		Me.ChmBtn.Font = New System.Drawing.Font("微软雅黑", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
		Me.ChmBtn.ForeColor = System.Drawing.Color.LawnGreen
		Me.ChmBtn.Location = New System.Drawing.Point(70, 650)
		Me.ChmBtn.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
		Me.ChmBtn.Name = "ChmBtn"
		Me.ChmBtn.Size = New System.Drawing.Size(70, 20)
		Me.ChmBtn.TabIndex = 10
		Me.ChmBtn.Text = "一色棋"
		Me.ChmBtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		'
		'Board
		'
		Me.Board.BackColor = System.Drawing.Color.Khaki
		Me.Board.Cursor = System.Windows.Forms.Cursors.Hand
		Me.Board.Location = New System.Drawing.Point(47, 410)
		Me.Board.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
		Me.Board.Name = "Board"
		Me.Board.Size = New System.Drawing.Size(393, 244)
		Me.Board.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
		Me.Board.TabIndex = 1
		Me.Board.TabStop = False
		Me.Board.Visible = False
		'
		'MainForm
		'
		Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 19.0!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.BackColor = System.Drawing.Color.DarkKhaki
		Me.ClientSize = New System.Drawing.Size(619, 672)
		Me.Controls.Add(Me.ChmBtn)
		Me.Controls.Add(Me.InfoLab)
		Me.Controls.Add(Me.SQBtn)
		Me.Controls.Add(Me.ClrBtn)
		Me.Controls.Add(Me.POBtn)
		Me.Controls.Add(Me.WBtn)
		Me.Controls.Add(Me.BBtn)
		Me.Controls.Add(Me.BWBtn)
		Me.Controls.Add(Me.Board)
		Me.Controls.Add(Me.Board1)
		Me.Font = New System.Drawing.Font("微软雅黑", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
		Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
		Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
		Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
		Me.MaximizeBox = False
		Me.Name = "MainForm"
		Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
		Me.Text = "LWGoBoard"
		CType(Me.Board, System.ComponentModel.ISupportInitialize).EndInit()
		Me.ResumeLayout(False)
		Me.PerformLayout()

	End Sub
	Friend WithEvents DrawTimer As System.Windows.Forms.Timer
	Friend WithEvents Board1 As System.Windows.Forms.Label
	Friend WithEvents Board As System.Windows.Forms.PictureBox
	Friend WithEvents BWBtn As System.Windows.Forms.Label
	Friend WithEvents BBtn As System.Windows.Forms.Label
	Friend WithEvents WBtn As System.Windows.Forms.Label
	Friend WithEvents POBtn As System.Windows.Forms.Label
	Friend WithEvents ClrBtn As System.Windows.Forms.Label
	Friend WithEvents SQBtn As System.Windows.Forms.Label
	Friend WithEvents InfoLab As System.Windows.Forms.Label
	Friend WithEvents ChmBtn As System.Windows.Forms.Label

End Class
