#encoding = utf-8
'''Name: pyPingPong.py
Author: Woobhurk
Copyright(C)2015 Lation Woobhurk
All rights reserved.
--------------------------------------------
Version: 1.1.7b (2015.02.21 19:15)
Changelog:
1. 修改故意出错的位移量的算法，出错率更大：getDestPos。
2. 修改难度算法，出错率更大：getDestPos。
Notes:
哈哈，使用了更“高级”的语句：x if y else z，找了半天没找到，
后来到Python官网看了下Cpp2Python文档，恍然大悟！^_^
--------------------------------------------
Version: 1.1.0b (2015.02.21 15:09)
Changelog:
1. 增加球碰壁或被拍击时的声音，其实就是响铃。
--------------------------------------------
Version: 1.0.4b (2015.02.20 19:00)
Changelog:
1. 增加难度选择功能。
2. 修改配色方案。
Notes:
基本功能完成，本来想增加两个玩家的功能的，但是想了一下还是算了（懒^_^!）。
配色方案修改了一下，主要是橙黄主题。
还有，难度选择窗口本来是想用下拉菜单实现的，但是不会用，只能用单选按钮实现了，
而且还比较丑陋...
--------------------------------------------
Version: 0.2.75b (2015.02.19 22:06)
Changelog:
1. 修改配色方案。
2. 修正重新开始后的运行问题。
--------------------------------------------
Version: 0.2.39b (2015.02.19 20:25)
Changelog:
1. 完成基本功能。
Notes:
就快要完成了，挺激动的。
这个游戏里面主要的内容就是游戏的循环部分和游戏状态判断。
循环部分用after方法来在一定时间后调用指定函数。
在使用这个方法时要保证调用的函数是游戏中可以一直循环的部分，否则将出错。
游戏的总体思路：
初始化（initGame）、进入循环部分（loopGame）。
循环部分showBegin、handleGame、drawGame，这些都是需要循环才能完成动态显示的部分。
'''

import tkinter as tk
import tkinter.ttk as ttk
import random

############################################
# FUNCTIONS
############################################
# events
def onKeyPress(event):
    '''按键按下事件

    主要是左右键移动拍子，空格键暂停，回车键继续或重玩。
    '''
    global gamepaused, gameover;
    global bat1speed, bat2speed;

    keysym = event.keysym;
    #print("onKeyPress: event: ", keysym);
    if (keysym == 'Left'):
        bat2speed = -BAT_SPEED;
    elif (keysym == 'Right'):
        bat2speed = BAT_SPEED;
    elif (keysym == 'space'):
        if (gameover is False):
            showPaused();
    elif (keysym == 'Return'):
        if (gamepaused is True):
            gamepaused=  False;
            wnd_canv.delete(TAG_GAMEPAUSED);
        elif (gameover is True):
            replayGame();
    return None;




def onKeyRelease(event):
    '''释放按键事件

    用来将己方拍子速度置零，拍子移动过程在handleGame中处理。
    '''
    global bat2speed;

    bat2speed = 0;
    return None;




def onFocusOut(event):
    '''失去焦点事件

    暂停游戏。
    '''
    global gameover;

    if (gameover is False):
        showPaused();
    return None;




def mode_onQuit():
    '''退出事件

    仅在选择难度时按下取消或关闭窗口按钮时发生。
    但是处理得不是很好，Python终端会提示是否杀死进程。
    '''
    print("mode_onQuit");
    wnd_root.destroy();
    wnd_root.quit();
    exit();
    return None;




def rb_onChecked(rbnum):
    '''单选按钮事件

    改变难度。
    '''
    global difficulty;

    difficulty = rbnum;
    print("rb_onChecked: difficulty: ", difficulty);
    return None;




#-------------------------------------------
# functions
def chooseDfficulty():
    '''选择难度

    代码很乱，完全像是草草了事而写出来的。
    '''
    global difficulty;

    var_diffi = tk.IntVar();
    var_diffi.set(difficulty);

    # 隐藏主窗口。
    wnd_root.wm_withdraw();

    wnd_mode = tk.Toplevel(wnd_root);
    wnd_mode.wm_geometry('245x220' + '+' + \
                         str(int((wnd_root.winfo_screenwidth() - CANV_WIDTH) / 2)) + '+' + \
                         str(int((wnd_root.winfo_screenheight() - CANV_HEIGHT) / 2)));
    wnd_mode.wm_resizable(0, 0);
    wnd_mode.wm_attributes('-topmost', 1);
    wnd_mode.focus_set();

    lbl_diffi = ttk.Label(wnd_mode, text = "Difficulty: ", \
                          font = ('Roboto', 20, 'bold'), foreground = COLOR_BAT1);
    lbl_diffi.grid(columnspan = 2);

    for rbnum in range(6):
        rb_ = tk.Radiobutton(wnd_mode, text = str(rbnum), variable = var_diffi, value = rbnum, \
                            font = ('Roboto', 16, 'bold'), foreground = COLOR_BAT2, \
                            command = (lambda rbnum = rbnum: rb_onChecked(rbnum)));
        rb_.grid(row = int(rbnum / 2) + 1, column = (rbnum % 2), columnspan = 1);

    ttk.Button(wnd_mode, text = "\nOK\n", width = 16, command = (lambda : wnd_mode.destroy())).grid(row = 4);
    ttk.Button(wnd_mode, text = "\nCancel\n", width = 16, command = mode_onQuit).grid(row = 4, column = 1);

    wnd_mode.protocol('WM_DELETE_WINDOW', mode_onQuit);
    # 主窗口一直等待，直到难度选择窗口关闭。
    wnd_root.wait_window(wnd_mode);
    print("chooseDifficulty: difficulty: ", difficulty);
    # 显示主窗口。
    wnd_root.wm_deiconify();
    return None;




def replayGame():
    '''重玩游戏

    只有三个个过程。
    '''
    chooseDfficulty();
    initGame();
    loopGame();
    return None;




def initGame():
    '''初始化游戏

    将所有数据初始化。
    '''
    global gamebegin, gamepaused, gameover;
    global ballposx, ballposy, ballspeedx, ballspeedy;
    global bat1posx, bat1posy, bat1speed, bat1destx, bat1life;
    global bat2posx, bat2posy, bat2speed, bat2life;

    # 游戏开始时等待的时间。
    gamebegin = DELAY_BEGIN;
    # 游戏状态。
    gamepaused = gameover = False;

    # 球。
    resetBall();  #
    # 球拍。
    bat1posx = canvwidthh - int(BAT_WIDTH / 2);
    bat1posy = BAT_HEIGHT;
    bat1destx = bat1posx;
    bat1speed = 0;
    bat1life = BAT_LIFE;  #
    bat2posx = canvwidthh - int(BAT_WIDTH / 2);
    bat2posy = canvheight - BAT_HEIGHT * 2;
    bat2speed = 0;
    bat2life = BAT_LIFE;

    # 重画所有控件。
    wnd_canv.delete('all');
    wnd_canv.create_rectangle(0, BAT_HEIGHT, \
                              canvwidth + 4, canvheight - BAT_HEIGHT, \
                              outline = COLOR_BG, fill = COLOR_BG);  #
    wnd_canv.create_rectangle(ballposx, ballposy, \
                              ballposx + BALL_SIZE, ballposy + BALL_SIZE, \
                              outline = COLOR_BALL, fill = COLOR_BALL, \
                              tags = TAG_BALL);
    wnd_canv.create_rectangle(bat1posx, bat1posy, \
                              bat1posx + BAT_WIDTH, bat1posy + BAT_HEIGHT, \
                              outline = COLOR_BAT1, fill = COLOR_BAT1, \
                              tags = TAG_BAT1);
    wnd_canv.create_rectangle(0, 0, \
                              canvwidth, BAT_HEIGHT, \
                              outline = COLOR_LIFE1, fill = COLOR_LIFE1, \
                              tags = TAG_BAT1LIFE);  #
    wnd_canv.create_rectangle(bat2posx, bat2posy, \
                              bat2posx + BAT_WIDTH, bat2posy + BAT_HEIGHT, \
                              outline = COLOR_BAT2, fill = COLOR_BAT2, \
                              tags = TAG_BAT2);
    wnd_canv.create_rectangle(0, canvheight - BAT_HEIGHT, \
                              canvwidth, canvheight, \
                              outline = COLOR_LIFE2, fill = COLOR_LIFE2, \
                              tags = TAG_BAT2LIFE);  #
    wnd_canv.create_text(canvwidthh, canvheighth, \
                         text = "READY", \
                         font = ('Roboto', 60, 'bold'), justify = 'center', fill = COLOR_BAT1, \
                         tags = TAG_GAMEBEGIN);
    return None;




def loopGame():
    '''循环游戏

    这一部分只有在游戏一直循环时才能动态显示。
    '''
    showBegin();
    drawGame();
    handleGame();
    # 如果游戏已经结束则不能再循环了，否则游戏重新开始后会再次调用，这样游戏速度就是原来的两倍了O_O。
    if (gameover is False):
        wnd_canv.after(DELAY_GAME, loopGame);
    return None;




def showBegin():
    '''显示开始时的READY、GO

    必须动态显示。
    '''
    global gamebegin;

    gamebegin -= int(DELAY_BEGIN / 50);

    # 三分之一的时间显示GO
    if (gamebegin <= int(DELAY_BEGIN / 3)):
        wnd_canv.itemconfig(TAG_GAMEBEGIN, text = "GO!!", fill = COLOR_BAT2);
    if (gamebegin <= 0):
        gamebegin = 0;
        wnd_canv.delete(TAG_GAMEBEGIN);
    return None;




def drawGame():
    '''画出游戏画面

    也是必须动态显示的。
    '''
    global ballposx, ballposy, ballspeedx, ballspeedy;
    global bat1posx, bat1posy, bat1speed, bat1destx, bat1life;
    global bat2posx, bat2posy, bat2speed, bat2life;

    ballid = wnd_canv.find_withtag(TAG_BALL);
    bat1id = wnd_canv.find_withtag(TAG_BAT1);
    bat1lifeid = wnd_canv.find_withtag(TAG_BAT1LIFE);
    bat2id = wnd_canv.find_withtag(TAG_BAT2);
    bat2lifeid = wnd_canv.find_withtag(TAG_BAT2LIFE);

    wnd_canv.coords(ballid, ballposx, ballposy, ballposx + BALL_SIZE, ballposy + BALL_SIZE);  #
    wnd_canv.coords(bat1id, bat1posx, bat1posy, bat1posx + BAT_WIDTH, bat1posy + BAT_HEIGHT);
    wnd_canv.coords(bat1lifeid, 0, 0, bat1life * canvwidth / BAT_LIFE, BAT_HEIGHT);  #
    wnd_canv.coords(bat2id, bat2posx, bat2posy, bat2posx + BAT_WIDTH, bat2posy + BAT_HEIGHT);
    wnd_canv.coords(bat2lifeid, 0, canvheight - BAT_HEIGHT, bat2life * canvwidth / BAT_LIFE, canvheight);
    return None;




def handleGame():
    '''处理游戏数据

    必须动态，不解释^_^。
    '''
    global gamebegin, gamepaused, gameover;
    global ballposx, ballposy, ballspeedx, ballspeedy;
    global bat1posx, bat1posy, bat1speed, bat1destx, bat1life;
    global bat2posx, bat2posy, bat2speed, bat2life;

    #print("playGame");
    # 只有在游戏开始之后、未暂停、未结束状态下才处理数据。
    if (gamebegin > 0 or \
        gamepaused is True or \
        gameover is True):
        return None;

    # 移动球。
    ballposx += ballspeedx;
    ballposy += ballspeedy;
    if (ballposx < 0):
        ballposx = 0;
        ballspeedx = -ballspeedx;
        wnd_root.bell();
    elif (ballposx > canvwidth - BALL_SIZE):
        ballposx = canvwidth - BALL_SIZE;
        ballspeedx = -ballspeedx;
        wnd_root.bell();
    # 如果球进入可拍击范围则判断是否被击中。
    if (ballposy < BAT_HEIGHT * 2):
        ballposy = BAT_HEIGHT * 2;
        checkBat1Pos();
    elif (ballposy > canvheight - BAT_HEIGHT * 3):
        ballposy = canvheight - BAT_HEIGHT * 3;
        checkBat2Pos();

    # 处理对方球拍。
    # 注意，只有在球拍需要移动时才会移动。
    # 需要移动的意思就是球拍还没到达目标位置并且速度方向正确。
    bat1posx += bat1speed;
    if (bat1posx < bat1destx and bat1speed < 0):
        bat1posx = bat1destx;
    elif (bat1posx > bat1destx and bat1speed > 0):
        bat1posx = bat1destx;

    # 移动己方球拍。
    bat2posx += bat2speed;
    if (bat2posx < 0):
        bat2posx = 0;
    elif (bat2posx > canvwidth - BAT_WIDTH):
        bat2posx = canvwidth - BAT_WIDTH;
    return None;




def showPaused():
    '''显示暂停

    无需动态处理，因为用户按下按键时会有事件产生。
    '''
    global gamepaused;

    #lbl_paused = ttk.Label(wnd_canv, text = "PAUSED\nEnter to continue", font = ('Roboto', 30, 'bold'));
    #wnd_canv.create_window(canvwidthh - 100, canvheighth - 100, window = lbl_paused);
    # 游戏开始后才能暂停。
    if (gamebegin > 0):
        return None;

    gamepaused = True;
    wnd_canv.create_text(canvwidthh, canvheighth, \
                         text = "PAUSED\n[Enter] to continue", \
                         font = ('Roboto', 40, 'bold'), justify = 'center', fill = COLOR_PROMPT, \
                         tags = TAG_GAMEPAUSED);
    return None;




def showGameOver():
    '''显示游戏结束

    也无需动态处理。
    '''
    global gameover;
    global bat1life;
    global bat2life;

    #print("showGameOver: ", bat1life, bat2life);
    gameover = True;
    if (bat1life == 0):
        showtext = "You WIN!\n[Enter] to replay";
    else:
        showtext = "You LOST!\n[Enter] to replay";
    wnd_canv.create_text(canvwidthh, canvheighth, \
                         text = showtext, \
                         font = ('Roboto', 40, 'bold'), justify = 'center', fill = COLOR_PROMPT, \
                         tags = TAG_GAMEOVER);
    return None;




def resetBall():
    '''重置球的状态

    因为在后面要调用，所以专门写成函数。
    '''
    global ballposx, ballposy, ballspeedx, ballspeedy;

    ballposx = canvwidthh - int(BALL_SIZE / 2);
    ballposy = canvheighth - int(BALL_SIZE / 2);
    ballspeedx = 0;
    ballspeedy = BALL_SPEED + random.randint(-BALL_SPEEDRANGE, BALL_SPEEDRANGE);
    # 随机设置发球方向
    if (random.randint(0, 9) % 2 == 0):
        ballspeedy = -ballspeedy;
    return None;




def checkBat1Pos():
    '''判断对方是否击中'''
    global ballposx, ballposy, ballspeedx, ballspeedy;
    global bat1posx, bat1posy, bat1life;

    # 是否在击中范围内，算法没什么特殊意义，只是用来精确判断。
    if (bat1posx > ballposx + BALL_SIZE - 6 or bat1posx + BAT_WIDTH - 6 < ballposx):
        bat1life -= 1;
        if (bat1life == 0):
            showGameOver();
        else:
            resetBall();
            getDestPos();
    else:
        # 击中，修改速度。
        # 这里的 * ((random.randint(0, 9) % 3) - 2)是为了随机修改横向速度方向，懒得使用判断。
        ballspeedx = (BALL_SPEED + random.randint(-BALL_SPEEDRANGE, BALL_SPEEDRANGE)) * ((random.randint(0, 9) % 3) - 2);
        ballspeedy = BALL_SPEED + random.randint(-BALL_SPEEDRANGE, BALL_SPEEDRANGE);
        wnd_root.bell();
    return None;




def checkBat2Pos():
    '''判断己方是否击中'''
    global ballposx, ballposy, ballspeedx, ballspeedy;
    global bat2posx, bat2posy, bat2life;

    if (bat2posx > ballposx + BALL_SIZE - 6 or bat2posx + BAT_WIDTH - 6 < ballposx):
        bat2life -= 1;
        if (bat2life == 0):
            showGameOver();
        else:
            resetBall();
            getDestPos();
    else:
        ballspeedx = (BALL_SPEED + random.randint(-BALL_SPEEDRANGE, BALL_SPEEDRANGE)) * ((random.randint(0, 9) % 3) - 2);
        ballspeedy = -BALL_SPEED + random.randint(-BALL_SPEEDRANGE, BALL_SPEEDRANGE);
        getDestPos();
        wnd_root.bell();
    return None;




def getDestPos():
    '''获取球的目标位置

    这是对方球拍能移动到正确位置的关键部分。
    '''
    global canvwidth;
    global difficulty;
    global ballposx, ballposy, ballspeedx, ballspeedy;
    global bat1posx, bat1posy, bat1speed, bat1destx;

    # 竖直速度方向不对，返回。
    # 之前一直没有判断，老出错。
    if (ballspeedy > 0):
        return None;

    _ballposx = ballposx;  _ballposy = ballposy;
    _ballspeedx = ballspeedx;  _ballspeedy = ballspeedy;
    while (_ballposy > BAT_HEIGHT * 2):
        _ballposx += _ballspeedx;
        _ballposy += _ballspeedy;
        if (_ballposx < 0):
            _ballposx = 0;
            _ballspeedx = -_ballspeedx;
        elif (_ballposx > canvwidth - BALL_SIZE):
            _ballposx = canvwidth - BALL_SIZE;
            _ballspeedx = -_ballspeedx;

    # 为了让拍子中心和球中心对齐，后面的 + random.randint(-BALL_SIZE, BALL_SIZE)是为了微调位置。
    bat1destx = _ballposx - int((BAT_WIDTH - BALL_SIZE) / 2) + random.randint(-BALL_SIZE, BALL_SIZE);

    # 判断是否故意出错，出错几率由难度决定，算法没内涵。
    # 算法不是很好，故意出错时也不一定会移动到错误位置。
    if (random.randint(0, difficulty * 2) == difficulty):
        # 最小移动量是拍子宽度的一半。
        deltax = int(BAT_WIDTH / 2) + random.randint(0, int(BAT_WIDTH / 2));
        # 判断向哪边移动，如果目标位置在最左边则向右移，以此类推。
        if (bat1destx <= 0):
            bat1destx += deltax;
            print("getDestPos: fault: Left");
        elif (bat1destx >= canvwidth - BAT_WIDTH):
            bat1destx -= deltax;
            print("getDestPos: fault: Right");
        else:
            # 如果在中间则随便往哪边移动
            bat1destx += deltax if (random.randint(0, 1) == 0) else -deltax;
            print("getDestPos: fault: Middle");

    # 判断位置的合法性，是为了防止超出画面。
    if (bat1destx < 0):
        bat1destx = 0;
    elif (bat1destx > canvwidth - BAT_WIDTH):
        bat1destx = canvwidth - BAT_WIDTH;

    # 判断速度方向
    if (bat1destx < bat1posx):
        bat1speed = -BAT_SPEED;
    else:
        bat1speed = BAT_SPEED;
    return None;





############################################
# MAIN
############################################
# constants
DELAY_GAME = 40;
DELAY_BEGIN = 1600;
BALL_SIZE = 20;
BAT_WIDTH = 100;
BAT_HEIGHT = 20;
BALL_SPEED = 10;
BALL_SPEEDRANGE = 3;
BAT_SPEED = BALL_SPEED + BALL_SPEEDRANGE + 4;
CANV_WIDTH = 550;
CANV_HEIGHT = 600;
'''COLOR_BG = '#e0ffe0';
COLOR_BALL = '#10a040';
COLOR_BAT1 = '#225544';
COLOR_BAT2 = '#116622';
COLOR_LIFE1 = '#00d0a0';
COLOR_LIFE2 = '#408080';
COLOR_LIFEBG = '#d0f0b0';
COLOR_PROMPT = '#a000d0';'''
COLOR_BG = '#fff0d0';
COLOR_BALL = '#aa7744';
COLOR_BAT1 = '#eebb44';
COLOR_BAT2 = '#ee7733';
COLOR_LIFE1 = '#f0c0a0';
COLOR_LIFE2 = '#e0e090';
COLOR_LIFEBG = '#fff0f0';
COLOR_PROMPT = '#e0d050';
TAG_GAMEBEGIN = 'gamebegin';
TAG_GAMEPAUSED = 'gamepaused';
TAG_GAMEOVER = 'gameover';
TAG_BALL = 'ball';
TAG_BAT1 = 'bat1';
TAG_BAT1LIFE = 'bat1life';
TAG_BAT2 = 'bat2';
TAG_BAT2LIFE = 'bat2life';
BAT_LIFE = 5;

# create window
wnd_root = tk.Tk();
wnd_canv = tk.Canvas(wnd_root, width = CANV_WIDTH, height = CANV_HEIGHT, bg = COLOR_LIFEBG);

wnd_root.title("pyPingPong");
wnd_root.resizable(0, 0);
wnd_root.geometry('+' + str(int((wnd_root.winfo_screenwidth() - CANV_WIDTH) / 2)) + '+' + \
                  str(int((wnd_root.winfo_screenheight() - CANV_HEIGHT) / 2)));
wnd_root.bind('<KeyPress>', onKeyPress);
wnd_root.bind('<KeyRelease>', onKeyRelease);
wnd_root.bind('<FocusOut>', onFocusOut);
wnd_canv.grid();

# global variables
canvwidth = CANV_WIDTH;
canvheight = CANV_HEIGHT;
canvwidthh = int(canvwidth / 2);
canvheighth = int(canvheight / 2);
difficulty = 0;
gamebegin = DELAY_BEGIN;
gamepaused = False;
gameover = False;
ballposx = ballposy = 0;  ballspeedx = ballspeedy = 0;
bat1posx = bat1posy = 0;  bat1speed = 0;  bat1destx = 0;  bat1life = BAT_LIFE;
bat2posx = bat2posy = 0;  bat2speed = 0;  bat2life = BAT_LIFE;

# main procedure
replayGame();

wnd_root.mainloop();
