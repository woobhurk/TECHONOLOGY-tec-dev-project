#encoding = utf-8
'''坐标系统：从上到下y递增，从左到右x递增；开始时画布左上角位于屏幕中央。
屏幕坐标：指相对于绘画窗口左上角的位置；
画布坐标：指相对于画布左上角的位置。
'''

import os
import tkinter as tk
import tkinter.ttk as ttk
from math import *

############################################
# FUNCTIONS
############################################
# events
def canv_onMouseDown(event):
    '''鼠标按下事件（左键）

    用来记录鼠标按下位置以及鼠标按下状态，以便后面使用。
    '''
    global mousedown;
    global mousestartx, mousestarty;
    global mouselinex, mouseliney;

    #print("event.down: ", event.num);
    if (event.num == 1):
        mousedown = True;
        mouselinex = mousestartx = event.x;
        mouseliney = mousestarty = event.y;
        wnd_canv.focus_set();
        updateUI();
    return;



def canv_onMouseUp(event):
    '''鼠标松开事件（左键）

    用来记录鼠标按下状态，以便后面使用。
    '''
    global mousedown;

    #print("event.up: ", event.num);
    if (event.num == 1):
        mousedown = False;
    return;



def canv_onMouseMove(event):
    '''鼠标移动事件（拖拽）

    用来移动画布，并且修改鼠标线条坐标。
    '''
    global mousedown;
    global mousestartx, mousestarty;
    global mouselinex, mouseliney;

    #print("event.move: ", event.x, event.y);
    #print("screenxy: ", getScreenX(getWorldX(event.x)), getScreenY(getWorldY(event.y)));
    #print("canvxy: ", int(wnd_canv.canvasx(event.x)), int(wnd_canv.canvasy(event.y)));
    #print("worldxy: ", getWorldX(event.x), getWorldY(event.y));
    if (mousedown is True):
        mouseendx = event.x;
        mouseendy = event.y;
        deltax = mouseendx - mousestartx;
        deltay = mouseendy - mousestarty;
        mouselinex = mousestartx = mouseendx;
        mouseliney = mousestarty = mouseendy;
        moveWorld(deltax, deltay);
    return;



def canv_onMouseWheel(event):
    '''鼠标滚轮事件

    用来缩放画布。
    '''
    global gridsize;

    #print("event.wheel: ", event.delta);
    if (event.delta > 0):
        gridsize += 10;
    else:
        gridsize -= 10;

    if (gridsize < 8):
        gridsize = 8;
    #print("gridsize: ", gridsize);
    #zoomWorld();
    updateUI();
    return;



def canv_onKeyPress(event):
    '''键盘按键事件（方向键）

    如果鼠标未按下则移动画布，否则微调鼠标线条坐标。
    '''
    global mousedown;
    global mouselinex, mouseliney;
    global gridsize;

    #print(event.keycode, event.keysym);
    if (mousedown is False):
        if (event.keysym == 'Left'):
            moveWorld(gridsize - 2, 0);
        elif (event.keysym == 'Right'):
            moveWorld(-(gridsize - 2), 0);
        elif (event.keysym == 'Up'):
            moveWorld(0, gridsize + 2);
        elif (event.keysym == 'Down'):
            moveWorld(0, -(gridsize - 2));
    else:
        if (event.keysym == 'Left'):
            mouselinex -= 1;
        elif (event.keysym == 'Right'):
            mouselinex += 1;
        elif (event.keysym == 'Up'):
            mouseliney -= 1;
        elif (event.keysym == 'Down'):
            mouseliney += 1;
        updateUI();
    return;



def btn_drawNFunc():
    '''按钮事件（画出普通函数）

    先判断用户输入是否合法，再调用addNewNFunc储存函数信息。
    '''
    global nfexp;
    global nfnumtotal;

    newnfexp = var_nfexp.get();
    newnfminx_s = var_nfminx.get();
    newnfmaxx_s = var_nfmaxx.get();

    if (newnfexp == "" or newnfminx_s == "" or newnfmaxx_s == ""):
        print("btn_drawNFunc: NullStr");
        return;

    if (eval(newnfminx_s) > eval(newnfmaxx_s)):
        print("btn_drawNFunc: newnfminx > newnfmaxx: ", nfnumtotal);
        return;

    addNewNFunc();
    updateUI();
    return;



def btn_drawPFunc():
    '''按钮事件（画出参数方程）

    先判断用户输入是否合法，再调用addNewPFunc储存方程信息。
    '''
    global pfexpx, pfexpy;

    newpfexpx = var_pfexpx.get();
    newpfexpy = var_pfexpy.get();
    newpfmint_s = var_pfmint.get();
    newpfmaxt_s = var_pfmaxt.get();
    newpfdeltat_s = var_pfdeltat.get();

    if (newpfexpx == "" or newpfexpy == "" or newpfmint_s == "" or newpfmaxt_s == "" or newpfdeltat_s == ""):
        print("btn_drawPFunc: NullStr");
        return;

    if (eval(newpfmint_s) > eval(newpfmaxt_s)):
        print("btn_drawPFunc: newpfmint > newpfmaxt: ", pfnumtotal);
        return;

    if (eval(newpfdeltat_s) <= 0):
        print("btn_drawPFunc: newpfdeltat <= 0");
        return;

    addNewPFunc();
    updateUI();
    return;



# messages
def showErrorDlg(errmsg):
    return;



def showWarningDlg(warnmsg):
    return;



# functions
def addNewNFunc():
    '''储存函数信息

    储存表达式、x最小值、x最大值。
    '''
    global nfexp;
    global nfnumtotal;
    global nfminx, nfmaxx;

    newnfexp = var_nfexp.get();
    newnfminx = eval(var_nfminx.get());
    newnfmaxx = eval(var_nfmaxx.get());
    nfnumtotal += 1;
    nfexp.append(newnfexp);
    nfminx.append(newnfminx);
    nfmaxx.append(newnfmaxx);
    print("addNewNFunc: ", nfnumtotal, nfexp, nfminx, nfmaxx);
    return;



def addNewPFunc():
    '''储存方程信息

    储存xy表达式、t最大值、t最小值、t变化值。
    '''
    global pfexpx, pfexpy;
    global pfnumtotal;
    global pfmint, pfmaxt;
    global pfdeltat;

    newpfexpx = var_pfexpx.get();
    newpfexpy = var_pfexpy.get();
    newpfmint = eval(var_pfmint.get());
    newpfmaxt = eval(var_pfmaxt.get());
    newpfdeltat = eval(var_pfdeltat.get());
    pfnumtotal += 1;
    pfexpx.append(newpfexpx);
    pfexpy.append(newpfexpy);
    pfmint.append(newpfmint);
    pfmaxt.append(newpfmaxt);
    pfdeltat.append(newpfdeltat);
    print("addNewPFunc: ", pfnumtotal, pfexpx, pfexpy, pfmint, pfmaxt);
    return;



def test_drawAllNFunc():
    '''画出函数图像（测试用）'''
    global gridsize;

    wnd_canv.create_line(0, 0, 1, 1);
    linestartx = -999;
    lineendx = 999;
    linefromx = linestartx;
    x = linefromx / gridsize;
    linefromy = -eval("x ** 3") * gridsize;
    while (linefromx < lineendx):
        linetox = linefromx + 1;
        x = linetox / gridsize;
        linetoy = -eval("x ** 3") * gridsize;
        wnd_canv.create_line(linefromx, linefromy, linetox, linetoy, fill = linecolor);
        linefromx = linetox;
        linefromy = linetoy;
    return;



def drawAllNFunc():  #
    '''画出所有普通函数图像

    逐个画出。
    '''
    global nfexp;

    #print("drawAllNFunc");
    #test_drawAllNFunc();
    nfnum = 0;
    nfnummax = len(nfexp);
    while (nfnum < nfnummax):
        #print("drawAllFunc: draw");
        drawOneNFunc(nfnum);
        nfnum += 1;
    return;



def drawOneNFunc(nfnum):
    '''画出单个普通函数图像
    nfnum：要画出的函数的编号；
    '''
    global nfexp;
    global nfposxall;
    global nfminx, nfmaxx;

    # 将x的区间范围转化为x的像素范围。
    linefromx = int(nfminx[nfnum] * gridsize);
    #x = linefromx / gridsize;
    linetox = linefromx;
    linetoy = linefromy = 0;
    # 假设已经出错，是为了防止函数第一个点和原点连接。
    erroccur = True;
    linetoxmax = int(nfmaxx[nfnum] * gridsize);
    while (linetox <= linetoxmax):
        linetox = linefromx + 1;
        x = linetox / gridsize;
        try:
            linetoy = -int(eval(nfexp[nfnum]) * gridsize);
        except Exception as errexp:
            erroccur = True;
            #print("drawOneNFunc: errexp: ", errexp);
        else:
            # 如果之前出错则不能将这两个点连接起来。
            if (erroccur is False):
                wnd_canv.create_line(linefromx, linefromy, linetox, linetoy, fill = linecolor);
            linefromy = linetoy;
            erroccur = False;
        linefromx = linetox;
    return;



def _drawOneNFunc(nfnum):
    '''画出单个普通函数图像
    nfnum：要画出的函数的编号；
    '''
    global nfexp;
    global nfminx, nfmaxx;
    global gridsize;

    linefromx = nfposxall[nfnum][0];
    x = linefromx / gridsize;
    linefromy = -int(eval(nfexp[nfnum]) * gridsize);
    for linetox in nfposxall[nfnum]:
        x = linetox / gridsize;
        linetoy = -int(eval(nfexp[nfnum]) * gridsize);
        if (linetox - linefromx == 1):
            wnd_canv.create_line(linefromx, linefromy, linetox, linetoy, fill = linecolor);
            linefromx = linetox;
            linefromy = linetoy;
            #print("drawOneNFunc: linefromxy: ", linefromx, linefromy, linetox, linetoy, x);
        else:
            #print("drawOneNFunc: ", linetox - linefromx);
            linefromx = linetox;
            linefromy = linetoy;
    return;



def evalNFunc():
    '''计算普通函数的值

    这里没用nfexp来获取函数表达式，是为了防止当前表达式没有存储就计算值而引发错误。
    '''
    #print("evalNFunc");
    newnfexp = var_nfexp.get();
    nfevalx_s = var_nfevalx.get();
    if (newnfexp == "" or nfevalx_s == ""):
        var_nfevaly.set("");
        return;

    x = eval(nfevalx_s);
    try:
        nfevaly = eval(newnfexp);
    except Exception as errexp:
        print("evalNFunc: errexp: ", errexp);
        var_nfevaly.set("ERROR!!");
    else:
        var_nfevaly.set(str(nfevaly));
    return;



def drawAllPFunc():  #
    '''画出所有参数方程图像

    逐个画出。
    '''
    global pfexpx, pfexpy;

    #print("drawAllPFunc");
    pfnum = 0;
    pfnummax = len(pfexpx);
    while (pfnum < pfnummax):
        #print("drawAllPFunc: draw");
        drawOnePFunc(pfnum);
        pfnum += 1;
    return;



def drawOnePFunc(pfnum):
    '''画出单个参数方程图像
    pfnum：要画的参数方程的编号；
    '''
    global pfexpx, pfexpy;
    global pfmint, pfmaxt;
    global gridsize;

    pfcntt = pfmint[pfnum];
    pfcnttmax = pfmaxt[pfnum];
    linefromx = linetox = 0;
    linefromy = linetoy = 0;
    # 假设已经出错，是为了防止参数方程第一个点和原点连接。
    erroccur = True;
    while (pfcntt <= pfcnttmax):
        t = pfcntt;
        try:
            linetox = int(eval(pfexpx[pfnum]) * gridsize);
            linetoy = -int(eval(pfexpy[pfnum]) * gridsize);
        except Exception as errexp:
            erroccur = True;
            print("drawOnePFunc: errexp: ", errexp);
        else:
            # 如果之前出错，则不能将这两个点连接起来。
            if (erroccur is False):
                wnd_canv.create_line(linefromx, linefromy, linetox, linetoy, fill = linecolor);
            linefromx = linetox;
            linefromy = linetoy;
            erroccur = False;
        pfcntt += pfdeltat[pfnum];
    return;



def _drawOnePFunc(pfnum):
    '''画出单个参数方程图像
    pfnum：要画的参数方程的编号；
    '''
    global pfexpx, pfexpy;
    global pfpostall;

    t = pfpostall[pfnum][0];
    linefromx = int(eval(pfexpx[pfnum]) * gridsize);
    linefromy = int(eval(pfexpy[pfnum]) * gridsize);
    for pfcnt in pfpostall[pfnumtotal]:
        t = pfcnt;
        linetox = int(eval(pfexpx[pfnum]) * gridsize);
        linetoy = int(eval(pfexpy[pfnum]) * gridsize);
        wnd_canv.create_line(linefromx, linefromy, linetox, linetoy, fill = linecolor);
        linefromx = linetox;
        linefromy = linetoy;
    return;



def evalPFunc():
    '''计算参数方程的值

    这里没有使用pfexpx、pfexpy来获取表达式，是为了防止表达式没存储就计算而引发错误。
    '''
    #print("evalPFunc");
    newpfexpx = var_pfexpx.get();
    newpfexpy = var_pfexpy.get();
    t_s = var_pfevalt.get();
    if (newpfexpx == "" or newpfexpy == "" or t_s == ""):
        var_pfevalxy.set("");
        return;
    t = eval(t_s);
    try:
        xvalue = eval(newpfexpx);
        yvalue = eval(newpfexpy);
    except Exception as errexp:
        print("evalPFunc: errexp: ", errexp);
        var_pfevalxy.set("ERROR!!");
    else:
        var_pfevalxy.set("(" + str(xvalue) + ", " + str(yvalue) + ")");
    return;



def clearFunc():  #
    '''清除所画的图象

    其实就是将所有函数和方程的信息丢弃，这样就不会再画出图象了。'''
    global nfnumtotal;
    global nfexp;
    global nfminx, nfmaxx;
    global pfnumtotal;  #
    global pfexpy, pfexpx;
    global pfmint, pfmaxt;
    global pfdeltat;

    nfnumtotal = -1;
    nfexp = [];
    nfminx = []; nfmaxx = [];
    pfnumtotal = -1;  #
    pfexpx = [];  pfexpy = [];
    pfmint = [];  pfmaxt = [];
    pfdeltat = [];
    updateUI();
    return;



def analyzeNFunc():
    '''分析普通函数，将所有合法的x的取值储存
    返回：表达式合法（定义域内能求到函数值）返回True，否则返回False；
    '''
    global nfminx, nfmaxx;
    global nfposxall;

    '''开始记录真正有效的x的范围，这样做是为了防止给出的范围内有无效值。
    合法的x取值将储存在nfposxall中。
    '''
    print("analyzeNFunc: nfnumtotal: ", nfnumtotal);
    nfcountx = nfminx[nfnumtotal];
    nfposxall.append([]);
    nfposxall[nfnumtotal] = [];
    while (nfcountx <= nfmaxx[nfnumtotal]):
        try:
            x = nfcountx / gridsize;
            float(eval(nfexp[nfnumtotal]));
        except Exception as errexp:
            pass;
            #print("analyzeNFunc: errexp: ", errexp);
        else:
            nfposxall[nfnumtotal].append(nfcountx);
        nfcountx += 1;
    #newfile = open('.\\analyzeNFunc.log', 'w+');
    #newfile.write(str(nfposxall));
    #newfile.close();
    if (len(nfposxall[nfnumtotal]) == 0):
        return False;
    print("analyzeNFunc: OK: ", nfexp[nfnumtotal], len(nfposxall[nfnumtotal]));
    return True;



def analyzePFunc():
    '''分析普通函数，将所有合法的x的取值储存
    返回：表达式合法（定义域内能求到函数值）返回True，否则返回False；
    '''
    global pfmint, pfmaxt;
    global pfpostall;

    '''开始记录真正有效的t的范围，这样做是为了防止给出的范围内有无效值。
    合法的x取值将储存在pfpostall中。
    '''
    print("analyzePFunc: pfnumtotal: ", pfnumtotal);
    pfcountt = pfmint[pfnumtotal];
    pfpostall.append([]);
    pfpostall[pfnumtotal] = [];
    while (pfcountt <= pfmaxt[pfnumtotal]):
        try:
            t = pfcountt;
            float(eval(pfexpx[pfnumtotal]));
            float(eval(pfexpy[pfnumtotal]));
        except Exception as errexp:
            pass;
            #print("analyzePFunc: errexp: ", errexp);
        else:
            pfpostall[pfnumtotal].append(pfcountt);
        pfcountt += 1;
    #newfile = open('.\\analyzePFunc.log', 'w+');
    #newfile.write(str(pfpostall));
    #newfile.close();
    if (len(pfpostall[pfnumtotal]) == 0):
        return False;
    print("analyzePFunc: OK: ", pfexpx[pfnumtotal], pfexpy[pfnumtotal], len(pfpostall[pfnumtotal]));
    return True;



def moveWorld(deltax, deltay):
    '''移动画布
    deltax：x方向位移，左正右负，
    deltay：y方向位移，下正上负；
    '''
    global posOx, posOy;
    
    '''posOx、posOy表示显示的画布范围的中心画布坐标，
    也就相当于把屏幕想象成摄像头，posOx、posOy是摄像头中心的画布坐标，
    因此要进行相反方向的移动，画布才会顺着鼠标的拖拽而移动。
    '''
    posOx -= deltax;
    posOy -= deltay;
    wnd_canv.config(scrollregion = (posOx - wndwidthh, posOy - wndheighth, posOx + wndwidthh, posOy + wndheighth));
    updateUI();
    return;



def zoomWorld():
    '''缩放函数图象'''
    global gridsize;

    updateUI();
    return;



def getWorldX(screenx):
    '''屏幕坐标x to 画布坐标x
    screenx：屏幕坐标x；
    返回：画布坐标x；

    可以使用canvasx转换。
    这里使用普通方法转换，转换出来的坐标比实际的大2，不知为什么。
    '''
    global wndwidthh;
    global posOx, posOy;
    
    return screenx - wndwidthh + posOx - 2;
    #return int(wnd_canv.canvasx(screenx));



def getWorldY(screeny):
    '''屏幕坐标y to 画布坐标y
    screeny：屏幕坐标y；
    返回：画布坐标y；

    可以使用canvasy转换。
    这里使用普通方法转换，转换出来的坐标比实际的大2，不知为什么。
    '''
    global wndheighth;
    global posOx, posOy;
    
    return screeny - wndheighth + posOy - 2;
    #return int(wnd_canv.canvasy(screeny));



def getScreenX(worldx):
    '''画布坐标x to 屏幕坐标x
    worldx：画布坐标x；
    返回：屏幕坐标x；
    '''
    global wndwidthh;
    global posOx, posOy;
    
    return worldx - posOx + wndwidthh;



def getScreenY(worldy):
    '''画布坐标y to 屏幕坐标y
    worldy：画布坐标y；
    返回：屏幕坐标y；
    '''
    global wndheighth;
    global posOx, posOy;
    
    return worldy - posOy + wndheighth;



def updateUI():
    '''更新画布

    注意画图的顺序：函数图像、网格、坐标，这样才会好看些^_^。
    '''
    wnd_canv.delete('all');
    drawAllNFunc();
    drawAllPFunc();
    drawGrid();
    drawCoord();
    drawMouseCoord();
    return;



def drawCoord():
    '''画出坐标系（x轴、y轴、原点、箭头）'''
    return;



def drawGrid():
    '''画出网格'''
    global gridsize;

    '''linestartx：开始画线的画布坐标x，和网格对齐，-1是为了防止少画一竖；
    linestarty：开始画线的画布坐标y，和网格对齐，-1是为了防止少画一横；
    lineendx：结束画线的画布坐标x，和网格对齐，+1是为了防止少画一竖；
    lineendy：结束画线的画布坐标y，和网格对齐，+1是为了防止少画一横；
    linefromx：当前画线的画布坐标x，会自增；
    linefromy：当前画线的画布坐标y，会自增；
    '''
    linestartx = (int(getWorldX(0) / gridsize) - 1) * gridsize;
    linestarty = (int(getWorldY(0) / gridsize) - 1) * gridsize;
    lineendx = (int(getWorldX(wndwidth) / gridsize) + 1) * gridsize;
    lineendy = (int(getWorldY(wndheight) / gridsize) + 1) * gridsize;
    linefromx = linestartx;
    while (linefromx < lineendx):
        wnd_canv.create_line(linefromx, linestarty, linefromx, lineendy, fill = gridcolor);
        linefromx += gridsize;

    linefromy = linestarty;
    while (linefromy < lineendy):
        wnd_canv.create_line(linestartx, linefromy, lineendx, linefromy, fill = gridcolor);
        linefromy += gridsize;
    return;



def drawMouseCoord():
    '''画出鼠标所在坐标和线条

    需要鼠标左键单击后才会画出。
    '''
    global mousedown;
    global mouselinex, mouseliney;

    if (mousedown is False):
        return;

    mouseworldx = getWorldX(mouselinex);
    mouseworldy = getWorldY(mouseliney);
    coordstr = "(" + str(mouseworldx / gridsize) + ", " + str(-mouseworldy / gridsize) + ")";
    wnd_canv.create_line(mouseworldx, getWorldY(0), mouseworldx, getWorldY(wndheight), fill = mousecolor);
    wnd_canv.create_line(getWorldX(0), mouseworldy, getWorldX(wndwidth), mouseworldy, fill = mousecolor);
    wnd_canv.create_text(mouseworldx + 5, mouseworldy + 5, text = coordstr, anchor = 'nw');
    return;





############################################
# INIT
############################################
# constants
FONT_FTYPE = ('Tahoma', 12, 'bold');
FONT_FX = ('Times New Roman', 13, 'italic');
FONT_EXP = ('Times New Roman', 13, 'normal');
FONT_EVAL = ('Tahoma', 9, 'bold');
FONT_NORMAL = ('Tahoma', 10, 'normal');
SIZE_ENTRY = 16;
SIZE_BUTTON = 28;
DEF_CANVWIDTH = 800;  DEF_CANVHEIGHT = 600;
DEF_CANVCOLOR = '#d0f0b0';
DEF_COORDCOLOR = '#000000';
DEF_GRIDCOLOR = '#668855';
DEF_LINECOLOR = '#d04020';
DEF_MOUSECOLOR = '#f08040';
DEF_GRIDSIZE = 20;
DEF_NFEXP = "sin(x)";
DEF_PFEXPX = "sin(t)";  DEF_PFEXPY = "cos(t)";
DEF_NFMINX = -9.5;  DEF_NFMAXX = 9.5;
DEF_PFMINT = -9;  DEF_PFMAXT = 9;
DEF_PFDELTAT = 0.1;

# windows configure
wnd_root = tk.Tk();
wnd_root.wm_title('pyFuncPad');
wnd_root.wm_iconbitmap('.' + os.sep + 'Icon.ico');
wnd_root.resizable(width = 0, height = 0);
#wnd_root.attributes('-alpha', 0.8);
wnd_canv = tk.Canvas(wnd_root, width = DEF_CANVWIDTH, height = DEF_CANVHEIGHT, background = DEF_CANVCOLOR);

# global variables
var_nfexp = tk.StringVar();
var_nfminx = tk.StringVar();  var_nfmaxx = tk.StringVar();
var_nfevalx = tk.StringVar();  var_nfevaly = tk.StringVar();
var_pfexpx = tk.StringVar();  var_pfexpy = tk.StringVar();  #
var_pfmint = tk.StringVar();  var_pfmaxt = tk.StringVar();
var_pfdeltat = tk.StringVar();
var_pfevalt = tk.StringVar();  var_pfevalxy = tk.StringVar();

# create widgets
lbl_nf = ttk.Label(wnd_root, text = "Normal Function")
lbl_nfy = ttk.Label(wnd_root, text = "f(x)=");  ent_nfexp = ttk.Entry(wnd_root);
ent_nfminx = ttk.Entry(wnd_root);  lbl_nfrangex = ttk.Label(wnd_root, text = "~");  ent_nfmaxx = ttk.Entry(wnd_root);
btn_nfdraw = ttk.Button(wnd_root, text = "Draw!");
lbl_nfeval = ttk.Label(wnd_root, text = "Evaluation");
lbl_nfevalx = ttk.Label(wnd_root, text = "x=");  ent_nfevalx = ttk.Entry(wnd_root);
lbl_nfevaly = ttk.Label(wnd_root, text = "f(x)=");  ent_nfevaly = ttk.Entry(wnd_root);
btn_nfeval = ttk.Button(wnd_root, text = "Evalute!");
lbl_pf = ttk.Label(wnd_root, text = "\nParametric Equation");  #
lbl_pfx = ttk.Label(wnd_root, text = "x=");  ent_pfexpx = ttk.Entry(wnd_root);
lbl_pfy = ttk.Label(wnd_root, text = "y=");  ent_pfexpy = ttk.Entry(wnd_root);
ent_pfmint = ttk.Entry(wnd_root);  lbl_pfranget = ttk.Label(wnd_root, text = "~");  ent_pfmaxt = ttk.Entry(wnd_root);
lbl_pfdeltat = ttk.Label(wnd_root, text = "Delta=");  ent_pfdeltat = ttk.Entry(wnd_root);
btn_pfdraw = ttk.Button(wnd_root, text = "Draw!");
lbl_pfeval = ttk.Label(wnd_root, text = "Evaluation");
lbl_pfevalt = ttk.Label(wnd_root, text = "t=");  ent_pfevalt = ttk.Entry(wnd_root);
lbl_pfevalxy = ttk.Label(wnd_root, text = "(x, y)=");  ent_pfevalxy = ttk.Entry(wnd_root);
btn_pfeval = ttk.Button(wnd_root, text = "Evalute!");
btn_clear = ttk.Button(wnd_root, text = "CLEAR!");  #
# configure widgets
lbl_nf.config(font = FONT_FTYPE);
lbl_nfy.config(font = FONT_FX);  ent_nfexp.config(textvariable = var_nfexp, width = SIZE_ENTRY, font = FONT_EXP);
ent_nfminx.config(textvariable = var_nfminx, width = int(SIZE_BUTTON / 2) - 4, font = FONT_EXP);
lbl_nfrangex.config(font = FONT_EXP);
ent_nfmaxx.config(textvariable = var_nfmaxx, width = int(SIZE_BUTTON / 2) - 4, font = FONT_EXP);
btn_nfdraw.config(command = btn_drawNFunc, width = SIZE_BUTTON);
lbl_nfeval.config(font = FONT_EVAL);
lbl_nfevalx.config(font = FONT_EXP);  ent_nfevalx.config(textvariable = var_nfevalx, width = SIZE_ENTRY, font = FONT_EXP);
lbl_nfevaly.config(font = FONT_FX);  ent_nfevaly.config(textvariable = var_nfevaly, width = SIZE_ENTRY, font = FONT_EXP, state = 'readonly');
btn_nfeval.config(command = evalNFunc, width = SIZE_BUTTON);
lbl_pf.config(font = FONT_FTYPE);  #
lbl_pfx.config(font = FONT_EXP);  ent_pfexpx.config(textvariable = var_pfexpx, width = SIZE_ENTRY, font = FONT_EXP);
lbl_pfy.config(font = FONT_EXP);  ent_pfexpy.config(textvariable = var_pfexpy, width = SIZE_ENTRY, font = FONT_EXP);
ent_pfmint.config(textvariable = var_pfmint, width = int(SIZE_BUTTON / 2) - 4, font = FONT_EXP);
lbl_pfranget.config(font = FONT_EXP);
ent_pfmaxt.config(textvariable = var_pfmaxt, width = int(SIZE_BUTTON / 2) - 4, font = FONT_EXP);
lbl_pfdeltat.config(font = FONT_EXP);  ent_pfdeltat.config(textvariable = var_pfdeltat, width = SIZE_ENTRY, font = FONT_EXP);
btn_pfdraw.config(command = btn_drawPFunc, width = SIZE_BUTTON);
lbl_pfeval.config(font = FONT_EVAL);
lbl_pfevalt.config(font = FONT_EXP);  ent_pfevalt.config(textvariable = var_pfevalt, width = SIZE_ENTRY, font = FONT_EXP);
lbl_pfevalxy.config(font = FONT_EXP);  ent_pfevalxy.config(textvariable = var_pfevalxy, width = SIZE_ENTRY, font = FONT_EXP, state = 'readonly');
btn_pfeval.config(command = evalPFunc, width = SIZE_BUTTON);
btn_clear.config(command = clearFunc, width = SIZE_BUTTON);
# show widgets
lbl_nf.grid(columnspan = 2);
lbl_nfy.grid(row = 1, sticky = 'e');  ent_nfexp.grid(row = 1, column = 1);
ent_nfminx.grid(row = 2, columnspan = 2, sticky = 'w');  lbl_nfrangex.grid(row = 2, columnspan = 2);  ent_nfmaxx.grid(row = 2, columnspan = 2, sticky = 'e');
btn_nfdraw.grid(row = 3, columnspan = 2);
lbl_nfeval.grid(row = 4, columnspan = 2);
lbl_nfevalx.grid(row = 5, sticky = 'e');  ent_nfevalx.grid(row = 5, column = 1);
lbl_nfevaly.grid(row = 6, sticky = 'e');  ent_nfevaly.grid(row = 6, column = 1);
btn_nfeval.grid(row = 7, columnspan = 2);
lbl_pf.grid(row = 20, columnspan = 2);  #
lbl_pfx.grid(row = 21, sticky = 'e');  ent_pfexpx.grid(row = 21, column = 1);
lbl_pfy.grid(row = 22, sticky = 'e');  ent_pfexpy.grid(row = 22, column = 1);
ent_pfmint.grid(row = 23, columnspan = 2, sticky = 'w');  lbl_pfranget.grid(row = 23, columnspan = 2);  ent_pfmaxt.grid(row = 23, columnspan = 2, sticky = 'e');
lbl_pfdeltat.grid(row = 24, sticky = 'e');  ent_pfdeltat.grid(row = 24, column = 1);
btn_pfdraw.grid(row = 25, columnspan = 2);
lbl_pfeval.grid(row = 26, columnspan = 2);
lbl_pfevalt.grid(row = 27, sticky = 'e');  ent_pfevalt.grid(row = 27, column = 1);
lbl_pfevalxy.grid(row = 28, sticky = 'e');  ent_pfevalxy.grid(row = 28, column = 1);
btn_pfeval.grid(row = 29, columnspan = 2);
btn_clear.grid(row = 40, columnspan = 2);  #
wnd_canv.grid(row = 0, column = 2, rowspan = 999);





############################################
# MAIN
############################################
# global variables
wndwidth = DEF_CANVWIDTH;
wndheight = DEF_CANVHEIGHT;
wndwidthh =  int(wndwidth / 2);
wndheighth = int(wndheight / 2);
canvcolor = DEF_CANVCOLOR;
coordcolor = DEF_COORDCOLOR;
gridcolor = DEF_GRIDCOLOR;
linecolor = DEF_LINECOLOR;
mousecolor = DEF_MOUSECOLOR;
gridsize = DEF_GRIDSIZE;
# 坐标原点O(0, 0)，表示的是画布坐标而不是屏幕坐标
posOx = posOy = 0;
mousedown = False;
mousestartx = mousestarty = 0;
mouselinex = mouseliney = 0;
# 函数初始化
nfnumtotal = -1;
pfnumtotal = -1;
nfexp = [];
nfminx = [];  nfmaxx = [];
pfexpx = [];  pfexpy = [];  #
pfmint = [];  pfmaxt = [];
pfdeltat = [];

# binding events
wnd_canv.bind('<ButtonPress>', canv_onMouseDown);
wnd_canv.bind('<ButtonRelease>', canv_onMouseUp);
wnd_canv.bind('<Motion>', canv_onMouseMove);
wnd_canv.bind('<MouseWheel>', canv_onMouseWheel);
wnd_canv.bind('<KeyPress>', canv_onKeyPress);

# main procedure
var_nfexp.set(DEF_NFEXP);
var_nfminx.set(DEF_NFMINX);  var_nfmaxx.set(DEF_NFMAXX);
var_pfexpx.set(DEF_PFEXPX);  var_pfexpy.set(DEF_PFEXPY);  #
var_pfmint.set(DEF_PFMINT);  var_pfmaxt.set(DEF_PFMAXT);
var_pfdeltat.set(DEF_PFDELTAT);

wnd_canv.config(scrollregion = (posOx - wndwidthh, posOy - wndheighth, posOx + wndwidthh, posOy + wndheighth));
addNewNFunc();
addNewPFunc();
updateUI();

wnd_root.mainloop();
