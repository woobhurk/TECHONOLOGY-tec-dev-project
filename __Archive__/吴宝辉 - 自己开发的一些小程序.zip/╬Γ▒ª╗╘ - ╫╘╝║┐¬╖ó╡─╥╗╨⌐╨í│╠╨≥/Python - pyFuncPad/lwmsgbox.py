#encoding = utf-8
import tkinter as tk
import tkinter.ttk as ttk

############################################
# INIT
############################################
# constants
DEF_MSGBOXTITLE = 'LWMsgBox';
MSGBOX_MINWIDTH = 400;
MSGBOX_MINHEIGHT = 120;





# classes
class LWMsgBox():
    def __init__(self, master):
        self.master = master;
        self.msgbox = tk.Toplevel(master);
        self.msgbox.wm_withdraw();
        self.msgbox.wm_resizable(0, 0);
        self.msgbox.minsize(MSGBOX_MINWIDTH, MSGBOX_MINHEIGHT);
        self.msgbox.protocol('WM_DELETE_WINDOW', self._onDestroy);
        return;


    def _createMsg(self):
        self.lbl_msgtext = ttk.Label(self.msgbox, text = self.msgtext);
        self.lbl_msgtext.pack(side = 'top');
        return;


    def _createButton(self):
        self.btn_OK = ttk.Button(self.msgbox, text = "OK");
        self.btn_OK.config(command = self._onDestroy);
        self.btn_OK.pack(side = 'bottom', pady = 5, ipadx = 15, ipady = 5);
        return;


    def _showMsgBox(self, title, text):
        self.msgbox.wm_title(title);
        self.msgtext = text;
        self._createMsg();
        self._createButton();
        self.msgbox.deiconify();
        self.msgbox.focus_set();
        self.msgbox.attributes('-topmost', 1);
        return;


    def _onDestroy(self):
        self.master.focus_set();
        self.msgbox.destroy();
        return;


    #---------------------------------------
    # public methods
    def showNormal(self, title = DEF_MSGBOXTITLE, text = ''):
        self._showMsgBox(title, text);
        self.msgbox.mainloop();
        return;


    def showModal(self, title = DEF_MSGBOXTITLE, text = ''):
        self._showMsgBox(title, text);
        self.msgbox.grab_set();  #
        self.master.wait_window(self.msgbox);
        self.msgbox.mainloop();
        return;





############################################
# MAIN
############################################
def main():
    root = tk.Tk();
    newdlg = LWMsgBox(root);
    newdlg.showModal(text = "Hello world!");
    root.mainloop();
    return;




# main procedure
if (__name__ == '__main__'):
    main();
