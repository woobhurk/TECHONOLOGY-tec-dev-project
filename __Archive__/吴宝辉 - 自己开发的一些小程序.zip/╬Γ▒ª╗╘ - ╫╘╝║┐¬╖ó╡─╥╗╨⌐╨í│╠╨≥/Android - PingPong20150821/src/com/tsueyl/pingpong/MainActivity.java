/****************
 * Name: PingPong
 * Author: Woobhurk
 * Copyright (C) 2015 Tsueyl
 * All rights reserved.
 * ********************************
 * Version: 0.1.88 (20150821 18:03)
 * Change Log:
 * - 修复：在游戏准备阶段会移动拍子的问题
 * - 修复：在选择传感器后直接退出会停止的问题
 * - 修改：游戏速度的算法，减少视觉上不连续现象
 * - 增加：速度设置
 * ********************************
 * Version: 0.1.45 (20150820 17:27)
 * Change Log:
 * - 修正：拍子出错时的附加移动距离
 * ********************************
 * Version: 0.1.31 (20150820 15:43)
 * Change Log:
 * - 0. THE FIRST RELEASE.
 */

package com.tsueyl.pingpong;

import android.app.Activity;
import android.app.Service;
import android.content.pm.ActivityInfo;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.ToggleButton;
import com.tsueyl.extras.Utils;

public class MainActivity extends Activity
{
	private View vwMain;
	private View vwGame;

	private ToggleButton tbtnPlayerMode;
	private SeekBar sbDifficulty;
	private SeekBar sbGameSpeed;
	private ToggleButton tbtnTheme;
	private ToggleButton tbtnSensor;
	private Button btnOrientation;
	private Button btnExit;
	private Button btnStart;

	private GameView gvGame;

	private SensorManager sensorManager;
	private SensorListener sensorListener;
	private Sensor sensorAcc;

	private boolean needInitGame;
	private boolean isMainUI;
	private boolean isFirstPlay;
	private boolean isGameStarted;
	private int playerMode;
	private int difficulty;
	private int gameSpeed;
	private int theme;
	private boolean useSensor;


	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);

		LayoutInflater liMain;

		//Log.w("onCreate", "--------------- onCreate");
		getActionBar().hide();
		liMain = getLayoutInflater();
		vwMain = liMain.inflate(R.layout.main, null);
		vwGame = liMain.inflate(R.layout.game, null);

		initVars();
		initMainUI();
		initMainWidgets();
	}


	/***********
	 * onKeyDown
	 * - 处理按键事件
	 * Notes:
	 * - 专门处理返回键事件。
	 */
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event)
	{
		if (keyCode != KeyEvent.KEYCODE_BACK)
		{
			return super.onKeyDown(keyCode, event);
		}

		if (!isMainUI)
		{
			if (gvGame.getGamePaused() || gvGame.getGameOver())
			{
				// 如果游戏暂停或者游戏结束则返回主界面
				gvGame.overGame();
				switchToMain();
				// 注意：每次返回主界面都要注销监听器，否则每次startGame都会重新
				// 注册一个导致几个监听器同时工作，而造成拍子移动速度翻倍-_-!
				unregisterSensorListener();
			}
			else
			{
				// 游戏运行中，暂停
				gvGame.setGamePaused(true);
			}

			return false;
		}
		else
		{
			//gvGame.exitGame();
			// 退出游戏时也要注销
			//unregisterSensorListener();
			finish();
		}

		return super.onKeyDown(keyCode, event);
	}



	private void switchToMain()
	{
		setContentView(vwMain);
		isMainUI = true;
	}


	private void switchToGame()
	{
		if (needInitGame)
		{
			initGameUI();
			initGameWidgets();
			needInitGame = false;
		}

		setContentView(vwGame);
		isMainUI = false;
	}


	private void initVars()
	{
		//Log.w("initVars", "--------------- initVars");
		sensorManager = (SensorManager)getSystemService(Service.SENSOR_SERVICE);
		sensorAcc = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
		sensorListener = new SensorListener();

		playerMode = GameView.PLAYERMODE_SINGLE;
		difficulty = GameView.DIFFICULTY;
		gameSpeed = GameView.GAMESPEED;
		theme = GameView.THEME_LIGHT;
		useSensor = false;

		needInitGame = true;
		isMainUI = true;
		isFirstPlay = true;
		isGameStarted = false;
	}


	private void initMainUI()
	{
		//Log.w("initMainUI", "-------------- initMainUI");
		tbtnPlayerMode = (ToggleButton)vwMain.findViewById(R.id.tbtnPlayerMode);
		sbDifficulty = (SeekBar)vwMain.findViewById(R.id.sbDifficulty);
		sbGameSpeed = (SeekBar)vwMain.findViewById(R.id.sbGameSpeed);
		tbtnTheme = (ToggleButton)vwMain.findViewById(R.id.tbtnTheme);
		tbtnSensor = (ToggleButton)vwMain.findViewById(R.id.tbtnSensor);
		btnOrientation = (Button)vwMain.findViewById(R.id.btnOrientation);
		btnExit = (Button)vwMain.findViewById(R.id.btnExit);
		btnStart = (Button)vwMain.findViewById(R.id.btnStart);
		setContentView(vwMain);
	}


	private void initGameUI()
	{
		gvGame = (GameView)vwGame.findViewById(R.id.gvGame);
	}


	private void initMainWidgets()
	{
		//Log.w("initMainWidgets", "------------- initMainWidgets");
		tbtnPlayerMode.setChecked(playerMode == GameView.PLAYERMODE_SINGLE);
		tbtnPlayerMode.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v)
			{
				playerMode = ((ToggleButton)v).isChecked() ? GameView.PLAYERMODE_SINGLE
						: GameView.PLAYERMODE_NONE;
			}
		});
		sbDifficulty.setProgress(difficulty);
		sbDifficulty
				.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
					@Override
					public void onProgressChanged(SeekBar seekBar,
							int progress, boolean fromUser)
					{
						difficulty = progress;
					}


					@Override
					public void onStartTrackingTouch(SeekBar seekBar)
					{
					}


					@Override
					public void onStopTrackingTouch(SeekBar seekBar)
					{
					}
				});
		sbGameSpeed.setProgress(gameSpeed - 3);
		sbGameSpeed
				.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
					@Override
					public void onProgressChanged(SeekBar seekBar,
							int progress, boolean fromUser)
					{
						// SeekBar的范围是0~6，则加上基数后的范围是3~9
						gameSpeed = progress + 3;
					}


					@Override
					public void onStartTrackingTouch(SeekBar seekBar)
					{
					}


					@Override
					public void onStopTrackingTouch(SeekBar seekBar)
					{
					}
				});
		tbtnTheme.setChecked(theme == GameView.THEME_LIGHT);
		tbtnTheme.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v)
			{
				theme = ((ToggleButton)v).isChecked() ? GameView.THEME_LIGHT
						: GameView.THEME_DARK;
			}
		});
		tbtnSensor.setChecked(useSensor);
		tbtnSensor.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v)
			{
				useSensor = ((ToggleButton)v).isChecked();
			}
		});
		btnOrientation.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v)
			{
				switch (getRequestedOrientation())
				{
				case ActivityInfo.SCREEN_ORIENTATION_PORTRAIT:
					//Utils.showToast(MainActivity.this, "portrait");
					setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
					break;
				case ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE:
					//Utils.showToast(MainActivity.this, "landscape");
					setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
					break;
				default:
					//Utils.showToast(MainActivity.this, "other");
					setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
				}

				Utils.showToast(MainActivity.this,
						"Please reset all datas to work approximately");
			}
		});
		btnExit.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v)
			{
				//gvGame.overGame();
				unregisterSensorListener();
				finish();
			}
		});
		btnStart.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v)
			{
				startGame();
			}
		});
	}


	private void initGameWidgets()
	{
		gvGame.setOnTouchListener(new View.OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event)
			{
				int touchX = (int)event.getX();

				// 触摸屏幕左1/3处左移，中间暂停，有边右移
				switch (event.getAction())
				{
				case MotionEvent.ACTION_DOWN:
					if (touchX > gvGame.getCanvasWidth() / 3
							&& touchX < gvGame.getCanvasWidth() * 2 / 3)
					{
						gvGame.setGamePaused(!gvGame.getGamePaused());
					}
				case MotionEvent.ACTION_MOVE:
					if (touchX < gvGame.getCanvasWidth() / 3)
					{
						gvGame.movePad2ByUser(-gvGame.getPadBaseSpeed());
					}
					else if (touchX > gvGame.getCanvasWidth() * 2 / 3)
					{
						gvGame.movePad2ByUser(gvGame.getPadBaseSpeed());
					}

					return true;
					//break;
				}
				return false;
			}
		});
	}


	private void registerSensorListener()
	{
		if (useSensor && playerMode == GameView.PLAYERMODE_SINGLE)
		{
			sensorManager.registerListener(sensorListener, sensorAcc,
					SensorManager.SENSOR_DELAY_GAME);
			Log.w("registerSensorListener",
					"------------- sensorListener registered");
		}
	}


	private void unregisterSensorListener()
	{
		if (useSensor)
		{
			sensorManager.unregisterListener(sensorListener);
			Log.w("unregisterSensorListener",
					"------------- sensorListener unregistered");
		}
	}


	private void startGame()
	{
		switchToGame();
		gvGame.setPlayerMode(playerMode);
		gvGame.setDifficulty(difficulty);
		gvGame.setGameSpeed(gameSpeed);
		gvGame.setTheme(theme);

		if (!isFirstPlay)
		{
			gvGame.resetGame();
		}

		gvGame.startReadyGame();
		registerSensorListener();
		// 用于判断是否重置游戏数据
		isFirstPlay = false;
		// 用于监听器判断游戏是否开始，如果未开始则不能移动拍子，否则造成
		// NullPointerException异常。
		isGameStarted = true;
	}




	private class SensorListener implements SensorEventListener
	{
		private float minimumXY = 0.6f;
		private float maximumXY = 8.0f;


		@Override
		public void onAccuracyChanged(Sensor sensor, int accuracy)
		{
		}


		@Override
		public void onSensorChanged(SensorEvent event)
		{
			float x = event.values[0];
			float y = event.values[1];
			float speedFactor;
			int speedDirection;

			// 游戏未开始
			if (!isGameStarted)
			{
				return;
			}

			// 判断是否是竖屏
			if (getRequestedOrientation() == ActivityInfo.SCREEN_ORIENTATION_PORTRAIT)
			{
				//Log.w("onSensorChanged", "-------------- portrait");
				// 速度“缩放”大小
				// 手机翻转程度越大则速度越大
				speedFactor = Math.abs(x);

				if (speedFactor < minimumXY)
				{
					// 翻转程度过小，不移动
					return;
				}
				else if (speedFactor > maximumXY)
				{
					// 速度缩放程度不能太大 :)
					speedFactor = maximumXY;
				}

				// 判断方向
				// 这里没有判断x是否小于零，因为在前面的判断中已经保证x大于
				// minimumXY或小于-minimumXY，所有如果不是大于minimumXY就是
				// 小于-minimumXY了。
				speedFactor *= 2.0f;
				speedDirection = x > minimumXY ? GameView.DIRECTION_LEFT
						: GameView.DIRECTION_RIGHT;
			}
			else
			{
				//Log.w("onSensorChanged", "---------------- landscape");
				//Utils.showToast(MainActivity.this, "Landscape");
				speedFactor = Math.abs(y);

				if (speedFactor < minimumXY)
				{
					return;
				}
				else if (speedFactor > maximumXY)
				{
					speedFactor = maximumXY;
				}

				speedFactor *= 2.0f;
				speedDirection = y > minimumXY ? GameView.DIRECTION_RIGHT
						: GameView.DIRECTION_LEFT;
			}

			//Log.w("onSensorChanged", "x " + x + ", y " + y);
			gvGame.movePad2ByUser((int)((float)(gvGame.getPadBaseSpeed() / 4 * speedDirection) * speedFactor));
		}
	}
}
