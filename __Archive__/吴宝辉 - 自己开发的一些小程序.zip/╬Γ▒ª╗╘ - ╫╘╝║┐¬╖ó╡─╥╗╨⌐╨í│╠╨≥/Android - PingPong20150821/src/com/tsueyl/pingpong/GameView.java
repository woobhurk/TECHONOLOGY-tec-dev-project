/****************
 * Name: GameView
 * Author: Woobhurk
 * Copyright (C) 2015 Tsueyl
 * All rights reserved.
 * *************************
 * Notes:
 * - This is where the game's graphics draw.
 */

package com.tsueyl.pingpong;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import java.util.Random;
import com.tsueyl.extras.Utils;

public class GameView extends View
{
	public static final int PLAYERMODE_SINGLE = 0;
	public static final int PLAYERMODE_NONE = 1;
	public static final int DIFFICULTY = 3;
	public static final int GAMESPEED = 4;
	public static final int THEME_LIGHT = 0;
	public static final int THEME_DARK = 1;
	public static final int MAX_LIFE = 5;
	public static final int MAX_DIFFICULTY = 9;
	public static final int MAX_GAMESPEED = 12;
	public static final int SPEED_GAME = 10;
	public static final int DIRECTION_PLAYER1 = -1;
	public static final int DIRECTION_PLAYER2 = 1;
	public static final int DIRECTION_LEFT = -1;
	public static final int DIRECTION_RIGHT = 1;

	private Context ctx;
	private View gameView;
	private Canvas canvas;

	private int canvasWidth;
	private int canvasHeight;
	private int canvasWidthH;
	private int canvasHeightH;
	private int origCanvasHeight;
	private boolean needInit = true;

	private int playerMode;
	private int difficulty;
	private int gameSpeed;
	private int theme;
	private Rect padRect1;
	private Rect padRect2;
	private Rect ballRect;
	private int padDestPosX1;
	private int padDestPosX2;
	private int padDirection1;
	private int padDirection2;
	private int padLife1;
	private int padLife2;
	private int sizePad;
	private int sizeBall;
	private int padBaseSpeed;
	private int ballSpeedX;
	private int ballSpeedY;
	private int ballBaseSpeed;
	private int ballDeltaSpeed;
	private int gameStartDelay;
	private boolean gamePaused;
	private boolean gameOver;

	// 主题色，用数组更方便
	private int[] colorBg = {0xffffeedd, 0xff20a080};
	private int[] colorLifeBg = {0xfff0d0b0, 0xff10a090};
	private int[] colorLife = {0xffd0b0a0, 0xff209080};
	private int[] colorBall = {0xffb0c080, 0xff307050};
	private int[] colorPad = {0xffe0c080, 0xff008060};


	public GameView(Context ctx, AttributeSet attrs)
	{
		super(ctx, attrs);
		this.ctx = ctx;
	}


	@Override
	protected void onDraw(Canvas cvs)
	{
		super.onDraw(canvas);

		//Log.w("onDraw", "---------- onDraw");
		canvas = cvs;

		if (needInit)
		{
			initVars();
			resetGame();
			needInit = false;
		}

		// 在initVars中对不符合比例的宽高进行调整，因此这里要移动画布到合法位置。
		//canvas.translate(0.0f, (float)((origCanvasHeight - canvasHeight) / 2));
		// 先画出生命值背景，再用背景颜色覆盖，这样就不用单个画出生命值背景了。
		drawLifeBackground();

		if (gameStartDelay >= 0)
		{
			// 处于倒计时
			drawReady();
		}
		else if (gamePaused)
		{
			// 暂停
			drawPause();
		}
		else
		{
			// 正常游戏
			drawBackground();
			drawLife();
			drawBall();
			drawPad();
		}
	}



	/****************
	 * startReadyGame
	 * - 显示倒计时，即准备阶段
	 */
	public void startReadyGame()
	{
		if (gameStartDelay >= 0)
		{
			// 倒计时
			new Handler().postDelayed(new Runnable() {
				@Override
				public void run()
				{
					invalidate();
					gameStartDelay--;
					startReadyGame();
				}
			}, 1000);
		}
		else
		{
			// 倒计时完毕，开始运行游戏主体
			runGame();
		}
		//Utils.showToast(ctx, "startGame");
	}


	/***********
	 * resetGame
	 * - 重置游戏数据
	 * Notes:
	 * - 修饰为public是因为在MainActivity中要在再次进入游戏时重置数据。
	 */
	public void resetGame()
	{
		//Log.w("resetGame", "------------- resetGame");
		// ballSpeedX不能太大，否则拍子无法追上
		// 速度算法：
		// SeekBar范围为0~6，加上基数后为3~9，所以速度范围是球大小的1/4~3/4。
		ballBaseSpeed = sizeBall * gameSpeed / MAX_GAMESPEED;
		ballDeltaSpeed = ballBaseSpeed * 2 / 3;
		padBaseSpeed = ballBaseSpeed * 2;
		resetBallPos();
		// 随机方向发球
		changeBallSpeed(isAcceptableRandom() ? DIRECTION_PLAYER1
				: DIRECTION_PLAYER2, true);

		padRect1.left = canvasWidthH - sizePad / 2;
		padRect1.top = sizeBall;
		// .right和.bottom只需赋值一次，在游戏中不会改变
		padRect1.right = padRect1.left + sizePad;
		padRect1.bottom = padRect1.top + sizeBall;
		padRect2.left = canvasWidthH - sizePad / 2;
		padRect2.top = canvasHeight - sizeBall * 2;
		padRect2.right = padRect2.left + sizePad;
		padRect2.bottom = padRect2.top + sizeBall;
		padDestPosX1 = padRect1.left;
		padDestPosX2 = padRect2.left;
		changePadDestPos1();
		changePadDestPos2();
		padLife1 = MAX_LIFE;
		padLife2 = MAX_LIFE;

		gameStartDelay = 3;
		gamePaused = false;
		gameOver = false;
	}


	/**********
	 * overGame
	 * - 结束游戏
	 * Notes:
	 * - 不命名为setGameOver是因为在MainActivity中不需要设置gameOver为true，
	 * - 因此为了好看命名为overGame :)
	 */
	public void overGame()
	{
		gameOver = true;
	}


	/*************
	 * getGameOver
	 * - 返回游戏是否结束
	 * Return:
	 * - 游戏是否结束
	 * Notes:
	 * - 为了统一名字才命名为getGameOver而不是isGameOver。
	 */
	public boolean getGameOver()
	{
		return gameOver;
	}


	/***************
	 * setGamePaused
	 * - 设置游戏是否暂停
	 * Parameters:
	 * - gamePaused: 是否暂停
	 */
	public void setGamePaused(boolean gamePaused)
	{
		this.gamePaused = gamePaused;
	}


	/***************
	 * getGamePaused
	 * - 返回游戏是否暂停
	 * Return:
	 * - 游戏是否暂停
	 */
	public boolean getGamePaused()
	{
		return gamePaused;
	}


	public void setPlayerMode(int playerMode)
	{
		this.playerMode = playerMode;
	}


	public void setDifficulty(int difficulty)
	{
		this.difficulty = difficulty;
	}


	public void setGameSpeed(int gameSpeed)
	{
		this.gameSpeed = gameSpeed;
	}


	public void setTheme(int theme)
	{
		this.theme = theme;
	}


	public int getCanvasWidth()
	{
		return canvasWidth;
	}


	public int getPadBaseSpeed()
	{
		return padBaseSpeed;
	}


	/*****************
	 * moveBall2ByUser
	 * - 表示是用户移动拍子
	 */
	public void movePad2ByUser(int delta)
	{
		// 无人游戏或游戏未开始或游戏暂停或游戏结束则不移动
		// 无人游戏或游戏暂停：为了防止用户触摸移动拍子
		// 游戏暂停或游戏结束：为了防止监听器移动拍子
		if (playerMode == PLAYERMODE_NONE || gameStartDelay >= 0 || gamePaused
				|| gameOver)
		{
			return;
		}

		padRect2.left += delta;

		if (padRect2.left < 0)
		{
			padRect2.left = 0;
		}
		else if (padRect2.left > canvasWidth - sizePad)
		{
			padRect2.left = canvasWidth - sizePad;
		}
	}


	/**********
	 * initVars
	 * - 初始化一些只要赋值一次的数据
	 * Notes:
	 * - 这些数据被称为“设备常量”，设备之间可能不同，但对于同一台设备是一样的。
	 */
	private void initVars()
	{
		//Log.w("initVars", "----------- initVars");
		gameView = this;
		canvasWidth = gameView.getWidth();
		canvasHeight = gameView.getHeight();
		origCanvasHeight = canvasHeight;

		// 判断屏幕比例是否合法，否则调整比例
		// 最小宽高比为2:3
		/*if (canvasHeight > canvasWidth * 2 / 2)
		{
			canvasHeight = canvasWidth * 2 / 2;
		}*/

		padRect1 = new Rect();
		padRect2 = new Rect();
		ballRect = new Rect();
		canvasWidthH = canvasWidth / 2;
		canvasHeightH = canvasHeight / 2;
		sizePad = canvasHeight / 6;
		sizeBall = sizePad / 5;
	}


	/*********
	 * runGame
	 * - 游戏运行过程的主体
	 */
	private void runGame()
	{
		if (!gameOver)
		{
			new Handler().postDelayed(new Runnable() {
				@Override
				public void run()
				{
					runGame();
				}
			}, SPEED_GAME);
		}

		if (!gamePaused)
		{
			moveBall();
			movePad1();
			movePad2();
		}

		// 无论是游戏暂停还是游戏运行都要更新画布
		invalidate();
		//runGame();
	}


	private void drawLifeBackground()
	{
		Paint canvasPaint;

		canvasPaint = new Paint();
		canvasPaint.setColor(colorLifeBg[theme]);
		canvas.drawRect(0.0f, 0.0f, (float)canvasWidth, (float)canvasHeight,
				canvasPaint);
		//canvas.drawColor(colorLifeBg[theme]);

	}


	private void drawReady()
	{
		Paint readyPaint;
		String readyPrompt;

		readyPaint = new Paint();
		readyPaint.setAntiAlias(true);
		readyPaint.setTypeface(Typeface.MONOSPACE);
		readyPaint.setTextSize(canvasWidth / 5);
		readyPaint.setTextAlign(Paint.Align.CENTER);
		readyPaint.setColor(colorBall[theme]);
		readyPrompt = (gameStartDelay > 0) ? "" + gameStartDelay : "GO!";
		canvas.drawText(readyPrompt, (float)canvasWidthH, (float)canvasHeightH,
				readyPaint);
	}


	private void drawPause()
	{
		Paint pausePaint;

		pausePaint = new Paint();
		pausePaint.setAntiAlias(true);
		pausePaint.setTypeface(Typeface.MONOSPACE);
		pausePaint.setTextSize(canvasWidth / 5);
		pausePaint.setTextAlign(Paint.Align.CENTER);
		pausePaint.setColor(colorBall[theme]);
		canvas.drawText("Paused", (float)canvasWidthH, (float)canvasHeightH,
				pausePaint);
	}


	private void drawBackground()
	{
		Rect bgRect;
		Paint bgPaint;

		bgPaint = new Paint();
		bgRect = new Rect();
		bgPaint.setAntiAlias(false);
		bgPaint.setColor(colorBg[theme]);
		bgRect.left = 0;
		bgRect.top = sizeBall;
		bgRect.right = canvasWidth;
		bgRect.bottom = canvasHeight - sizeBall;
		canvas.drawRect(bgRect, bgPaint);
	}


	private void drawLife()
	{
		Paint lifePaint;
		Rect lifeRect;

		lifePaint = new Paint();
		lifeRect = new Rect();
		lifePaint.setAntiAlias(false);
		lifePaint.setColor(colorLife[theme]);
		lifeRect.left = 0;
		lifeRect.top = 0;
		lifeRect.right = canvasWidth * padLife1 / MAX_LIFE;
		lifeRect.bottom = sizeBall;
		canvas.drawRect(lifeRect, lifePaint);

		lifeRect.top = canvasHeight - sizeBall;
		lifeRect.right = canvasWidth * padLife2 / MAX_LIFE;
		lifeRect.bottom = canvasHeight;
		canvas.drawRect(lifeRect, lifePaint);
	}


	private void drawBall()
	{
		Paint ballPaint;

		ballPaint = new Paint();
		ballPaint.setAntiAlias(true);
		ballPaint.setColor(colorBall[theme]);
		canvas.drawCircle((float)(ballRect.left + sizeBall / 2),
				(float)(ballRect.top + sizeBall / 2), (float)(sizeBall / 2),
				ballPaint);
	}


	private void drawPad()
	{
		Paint padPaint;

		padPaint = new Paint();
		padPaint.setAntiAlias(false);
		padPaint.setColor(colorPad[theme]);
		padRect1.right = padRect1.left + sizePad;
		canvas.drawRect(padRect1, padPaint);
		padRect2.right = padRect2.left + sizePad;
		canvas.drawRect(padRect2, padPaint);
	}


	private void moveBall()
	{
		ballRect.left += ballSpeedX;
		ballRect.top += ballSpeedY;
		//padRect1.bottom = padRect1.top + sizeBall;

		if (ballRect.left <= 0)
		{
			ballRect.left = 0;
			ballSpeedX = -ballSpeedX;
		}
		else if (ballRect.left >= canvasWidth - sizeBall)
		{
			ballRect.left = canvasWidth - sizeBall;
			ballSpeedX = -ballSpeedX;
		}

		if (ballRect.top <= padRect1.top + sizeBall)
		{
			ballRect.top = padRect1.top + sizeBall;
			checkPadPos();
		}
		else if (ballRect.top >= padRect2.top - sizeBall)
		{
			ballRect.top = padRect2.top - sizeBall;
			checkPadPos();
		}
	}


	private void movePad1()
	{
		// 判断是否移动过头
		if (padRect1.left > padDestPosX1 && padDirection1 == DIRECTION_LEFT)
		{
			padRect1.left -= padBaseSpeed;
		}
		else if (padRect1.left < padDestPosX1
				&& padDirection1 == DIRECTION_RIGHT)
		{
			padRect1.left += padBaseSpeed;
		}

		// 检查合法性
		if (padRect1.left < 0)
		{
			padRect1.left = 0;
		}
		else if (padRect1.left > canvasWidth - sizePad)
		{
			padRect1.left = canvasWidth - sizePad;
		}
	}


	private void movePad2()
	{
		// 单人游戏则不自动移动，由MainActivity的onTouch和监听器移动。
		if (playerMode == PLAYERMODE_SINGLE)
		{
			return;
		}

		if (padRect2.left > padDestPosX2 && padDirection2 == DIRECTION_LEFT)
		{
			padRect2.left -= padBaseSpeed;
		}
		else if (padRect2.left < padDestPosX2
				&& padDirection2 == DIRECTION_RIGHT)
		{
			padRect2.left += padBaseSpeed;
		}

		if (padRect2.left < 0)
		{
			padRect2.left = 0;
		}
		else if (padRect2.left > canvasWidth - sizePad)
		{
			padRect2.left = canvasWidth - sizePad;
		}
	}


	private void resetBallPos()
	{
		ballRect.left = canvasWidthH - sizeBall / 2;
		ballRect.top = canvasHeightH - sizeBall / 2;
	}


	private void checkPadPos()
	{
		//Utils.showToast(ctx, "checkPadPos");
		//Log.w("checkPadPos", "------------- checkPadPos start");
		ballRect.right = ballRect.left + sizeBall;
		padRect1.right = padRect1.left + sizePad;
		padRect2.right = padRect2.left + sizePad;

		// 如果ballSpeedY小于零则表示需要检查球拍位置的玩家为上方的
		if (ballSpeedY < 0)
		{
			if (ballRect.left >= padRect1.left - sizeBall / 2
					&& ballRect.right <= padRect1.right + sizeBall / 2)
			{
				// 改变球的速度
				changeBallSpeed(DIRECTION_PLAYER2, false);
				changePadDestPos2();
			}
			else
			{
				padLife1--;
				checkLife();
				resetBallPos();
				changeBallSpeed(DIRECTION_PLAYER1, true);
				changePadDestPos1();
			}
		}
		else
		{
			if (ballRect.left >= padRect2.left - sizeBall / 2
					&& ballRect.right <= padRect2.right + sizeBall / 2)
			{
				changeBallSpeed(DIRECTION_PLAYER1, false);
				changePadDestPos1();
			}
			else
			{
				padLife2--;
				checkLife();
				resetBallPos();
				changeBallSpeed(DIRECTION_PLAYER2, true);
				changePadDestPos2();
			}
		}

		//Utils.showToast(ctx, "checkPadPos.padDestPosX1 " + padDestPosX1 + ", padDestPosX2 " + padDestPosX2);
		//Log.w("checkPadPos", "------------- checkPadPos end");
	}


	/***************
	 * getPadDestPos
	 * - 获取球拍最佳目标位置
	 * Return:
	 * - 球拍位置
	 * Notes:
	 * - 不会检查位置合法性，因为在球拍移动中会检查。
	 */
	private int getPadDestPos()
	{
		int ballPosX;
		int ballPosY;
		int _ballSpeedX;
		int padDestPosX;
		int padRandDeltaPosX;

		ballPosX = ballRect.left;
		ballPosY = ballRect.top;
		_ballSpeedX = ballSpeedX;

		// 要计算的是球到下方时的位置
		if (ballSpeedY > 0)
		{
			// 开始模拟球的移动以确认球的最终位置
			while (ballPosY <= padRect2.top - sizeBall)
			{
				ballPosX += _ballSpeedX;
				ballPosY += ballSpeedY;

				if (ballPosX <= 0)
				{
					ballPosX = 0;
					_ballSpeedX = -_ballSpeedX;
				}
				else if (ballPosX >= canvasWidth - sizeBall)
				{
					ballPosX = canvasWidth - sizeBall;
					_ballSpeedX = -_ballSpeedX;
				}
			}
		}
		else
		{
			while (ballPosY >= padRect1.top + sizeBall)
			{
				ballPosX += _ballSpeedX;
				ballPosY += ballSpeedY;

				if (ballPosX <= 0)
				{
					ballPosX = 0;
					_ballSpeedX = -_ballSpeedX;
				}
				else if (ballPosX >= canvasWidth - sizeBall)
				{
					ballPosX = canvasWidth - sizeBall;
					_ballSpeedX = -_ballSpeedX;
				}
			}
		}

		// 计算球拍额外移动距离，用于故意出错
		// 算法：
		// 假设n为难度，如果3^n <= n，则计算球拍大幅度移动距离，
		// 否则计算小幅度移动距离。因此难度越大则出错率呈指数减少，一些粗略估计：
		// 出错率为(n+1)/(2.5^(n+1)+1)
		// 难度：出错率
		// 0 : 1/4, 1 : 2/5, 2 : 1/7, ..., 9 : 1/5905
		if (getRandom(0, (int)Math.pow(3.0, (double)(difficulty + 1))) <= difficulty)
		{
			//Utils.showToast(ctx, "Yes");
			Log.w("getPadDestPos", "---- Yes");
			// 出错时大幅度移动，但也可能不出错 :)
			// 算法1：最小移动距离为拍子大小的2/3的(9-n)/9，附加距离为随机的1/(n+1)
			/*padRandDeltaPosX = sizePad * 2 / 3 * (MAX_DIFFICULTY - difficulty)
					/ MAX_DIFFICULTY + getRandom(-sizePad, sizePad)
					/ (difficulty + 1);*/
			// 算法2：最小移动距离为拍子大小的2/3，
			padRandDeltaPosX = sizePad * 2 / 3 + getRandom(-sizePad, sizePad);
		}
		else
		{
			//Utils.showToast(ctx, "No");
			//Log.w("getPadDestPos", "------------ No");
			// 不出错时小幅度移动，但也可能会导致出错 :)
			// 移动距离为球的(9-n)/9倍
			padRandDeltaPosX = getRandom(-sizeBall, sizeBall)
					* (MAX_DIFFICULTY - difficulty) / MAX_DIFFICULTY;
		}

		// 随机改变移动方向
		if (isAcceptableRandom())
		{
			padRandDeltaPosX = -padRandDeltaPosX;
		}

		//padDestPosX = ballPosX + sizeBall / 2 - sizePad / 2 +padRandDeltaPosX;
		padDestPosX = ballPosX + (sizeBall - sizePad) / 2 + padRandDeltaPosX;

		return padDestPosX;
	}


	private void checkLife()
	{
		if (padLife1 == 0 || padLife2 == 0)
		{
			gameOver = true;
			showWinner();
		}
	}


	/*****************
	 * changeBallSpeed
	 * - 改变球的速度
	 * Parameters:
	 * - direction: 发球方向
	 * - needResetSpeed: 是否重置速度
	 */
	private void changeBallSpeed(int direction, boolean needResetSpeed)
	{
		int randNum;

		if (needResetSpeed)
		{
			ballSpeedX = 0;
			ballSpeedY = direction * ballBaseSpeed;
		}
		else
		{
			ballSpeedX = ballBaseSpeed
					+ getRandom(-ballDeltaSpeed * 2, ballDeltaSpeed / 2);
			ballSpeedY = direction
					* (ballBaseSpeed + getRandom(-ballDeltaSpeed / 2,
							ballDeltaSpeed));
			randNum = getRandom(0, 9);

			// 发球左右方向：左、中、右
			/*if (randNum < 4)
			{
				ballSpeedX = -ballSpeedX;
			}
			else if (randNum > 7)
			{
				ballSpeedX = 0;
			}*/
			if (isAcceptableRandom())
			{
				ballSpeedX = -ballSpeedX;
			}
		}
	}


	/*******************
	 * changePadDestPos1
	 * - 重新计算球拍目标位置
	 */
	private void changePadDestPos1()
	{
		// 方向错误，不计算
		if (ballSpeedY > 0)
		{
			return;
		}

		padDestPosX1 = getPadDestPos();
		padDirection1 = (padDestPosX1 > padRect1.left) ? DIRECTION_RIGHT
				: DIRECTION_LEFT;
	}


	private void changePadDestPos2()
	{
		if (ballSpeedY < 0)
		{
			return;
		}

		padDestPosX2 = getPadDestPos();
		padDirection2 = (padDestPosX2 > padRect2.left) ? DIRECTION_RIGHT
				: DIRECTION_LEFT;
	}


	private void showWinner()
	{
		AlertDialog.Builder dlgWinner;
		String winnerTitle;
		String winnerMsg;

		if (playerMode == PLAYERMODE_SINGLE)
		{
			winnerTitle = (padLife1 == 0) ? "You won!" : "You lost!";
		}
		else
		{
			winnerTitle = (padLife1 == 0) ? "Player 2" : "Player 1";
			winnerTitle += " won!";
		}

		winnerMsg = "Play again?";
		dlgWinner = new AlertDialog.Builder(ctx);
		dlgWinner.setCancelable(false);
		dlgWinner.setTitle(winnerTitle);
		dlgWinner.setMessage(winnerMsg);
		dlgWinner.setPositiveButton("Yes ^O^",
				new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface p1, int p2)
					{
						resetGame();
						invalidate();
						startReadyGame();
					}
				});
		dlgWinner.setNegativeButton("No -_-",
				new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface p1, int p2)
					{
						Utils.showToast(ctx, "Press BACK to return");
					}
				});
		dlgWinner.show();
		//Utils.showDialog(ctx, null, winner);
		//Log.w("showWinner", winner);
	}


	/***********
	 * getRamdom
	 * - 产生rangeFrom到rangeTo的随机数，包括端点值
	 * Parameters:
	 * - rangeFrom: 范围起始值
	 * - rangeTo: 终止值
	 * Return:
	 * - 区间内的随机数
	 */
	private int getRandom(int rangeFrom, int rangeTo)
	{
		Random rand;

		rand = new Random();
		rand.setSeed(SystemClock.uptimeMillis());
		return rand.nextInt(rangeTo - rangeFrom + 1) + rangeFrom;
	}


	/********************
	 * isAcceptableRandom
	 * - 判断一个随机数是否符合条件，用于在两个选择中随机选择一个
	 */
	private boolean isAcceptableRandom()
	{
		return (getRandom(0, 9) < 5);
	}
}
