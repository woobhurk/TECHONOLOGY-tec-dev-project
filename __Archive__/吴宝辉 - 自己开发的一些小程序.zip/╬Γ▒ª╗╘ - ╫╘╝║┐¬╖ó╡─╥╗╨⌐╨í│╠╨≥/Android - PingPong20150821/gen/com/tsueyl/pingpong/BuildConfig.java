/** Automatically generated file. DO NOT MODIFY */
package com.tsueyl.pingpong;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}