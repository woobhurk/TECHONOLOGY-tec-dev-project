#ifndef BOOK_H
#define BOOK_H


void newBook();
void openBook();
void saveBook();
void saveBookAs();
void closeBook();
void askToSave();
void bookProperty();
#endif /* book.h */
