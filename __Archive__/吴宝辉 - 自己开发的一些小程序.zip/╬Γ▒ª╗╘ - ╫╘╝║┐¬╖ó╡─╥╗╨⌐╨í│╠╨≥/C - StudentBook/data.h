#ifndef DATA_H
#define DATA_H

#include "global.h"

#define ADD_DATA_HEADER 0
#define ADD_DATA_STUNUM 1
#define ADD_DATA_ID 2
#define ADD_DATA_TAIL 3
#define MOVE_DATA_HEADER 0
#define MOVE_DATA_STUNUM 1
#define MOVE_DATA_ID 2
#define MOVE_DATA_TAIL 3
#define INPUT_DATA_ADD 0
#define INPUT_DATA_MODIFY 1

#ifdef TCC
    // 用于inputData，将空字符串置'\0'，仅tcc需要
    #define INPUT_DATA(str) \
        if (str[0] == '\n') \
        { \
            str[0] = '\0'; \
        }
#else
    #define INPUT_DATA(str)
#endif

// 用于searchData，输出符合条件的数据
#define SEARCH_DATA(str) \
    if (strstrEx(str, schContent) != NULL) \
    { \
        schCount++; \
        printf("%06d: %-20s: %s\n", id, data->stuNum, str); \
    }
// 用于modifyData，判断是否保持原始数据
#define MODIFY_DATA(str, newStr) \
    if (!EMPTYSTR(newStr)) \
    { \
        strcpy(str, newStr); \
    }


void listData();
void addData();
void searchData();
void modifyData();
void deleteData();
void moveData();
#endif /* data.h */
