/*********
 * types.h
 * 自定义数据类型。
 */

#ifndef TYPES_H
#define TYPES_H

#include "const.h"


typedef short BOOL;
typedef struct _STUDATA {
    char stuNum[STR_SIZE];  // 学号
    char name[STR_SIZE];  // 姓名
    char stuId[STR_SIZE];  // 身份证 
    char className[STR_SIZE];  // 班级
    char institute[STR_SIZE];  // 学院
    char major[STR_SIZE]; // 专业
    int years;  // 学制
    char phoneNum[STR_SIZE];  // 电话
    char qqNum[STR_SIZE];  // QQ
    char email[STR_SIZE];  // E-Mail
    char domitory[STR_SIZE];  // 宿舍
    char origion[STR_SIZE];  // 籍贯
    struct _STUDATA *next;
} STUDATA;
#endif /* types.h */
