#ifndef DATA_ADD_H
#define DATA_ADD_H

#include "types.h"


int getAddDest();
STUDATA *getAddDestData(int);
void addDataTo(int, STUDATA *, STUDATA *);
#endif /* data_add.h*/
