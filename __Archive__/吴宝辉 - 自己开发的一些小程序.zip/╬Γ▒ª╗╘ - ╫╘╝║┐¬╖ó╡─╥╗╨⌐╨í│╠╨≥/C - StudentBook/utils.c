/*********
 * utils.c
 * 其他工具。
 */

#include <stdio.h>
//#include <conio.h>
#include <string.h>
#include <ctype.h>
#include <malloc.h>
#include "utils.h"


/*********************
 * getFileSize -> long
 * - 获取文件大小
 * 参数
 * - file 文件
 * 返回
 * - 文件大小
 */
long getFileSize(FILE *file)
{
    long curPos;
    long size;

    // 保存当前指针位置
    curPos = ftell(file);
    fseek(file, 0, SEEK_END);
    size = ftell(file);
    // 恢复文件指针位置
    fseek(file, curPos, SEEK_SET);

    return size;
}




/**********************
 * strToUpper -> char *
 * - 转换字符串为大写
 * 参数
 * - str 目标字符串
 * 返回
 * - 源字符串的地址
 * 备注
 * - 不能转换常量字符串。
 */
char *strToUpper(char *str)
{
    while (*str != '\0')
    {
        *str = toupper(*str);
        str++;
    }

    return str;
}




/*****************
 * strcmpEx -> int
 * - 比较字符串，不区分大小写
 * 参数
 * - str1, str2 比较的字符串
 " 返回
 * - 比较后的结果
 */
int strcmpEx(const char *str1, const char *str2)
{
    while (tolower(*str1) == tolower(*str2) && *str1 != '\0' && *str2 != '\0')
    {
        str1++;
        str2++;
    }

    return (*str1 - *str2);
}




/******************
 * strncmpEx -> int
 * - 比较字符串，最大长度为n，不区分大小写
 * 参数
 * - str1, str2 比较的字符串
 * - n 比较的最大长度
 * 返回
 * - 比较后的结果
 */
int strncmpEx(const char *str1, const char *str2, int n)
{
    while (--n >= 0 && tolower(*str1) == tolower(*str2) && *str1 != '\0' && *str2 != '\0')
    {
        str1++;
        str2++;
    }

    return (n < 0 || *str1 == '\0' || *str2 == '\0') ? 0 : (*str1 - *str2);
}
/*int _strncmpEx(const char *str1, const char *str2, int n)
{
    char *tmpStr1;
    char *tmpStr2;
    int slen1;
    int slen2;

    slen1 = strlen(str1);
    slen2 = strlen(str2);
    tmpStr1 = (char *)malloc(slen1);
    tmpStr2 = (char *)malloc(slen2);

    if (n > slen1 || n > slen2)
    {
        //n = (slen1 > slen2) ? slen2 : slen1;
        n = slen1;
    }

    strncpy(tmpStr1, str1, n);
    strncpy(tmpStr2, str2, n);

    return strcmpEx(tmpStr1, tmpStr2);
}*/




/********************
 * strstrEx -> char *
 * - 查找字符串，不区分大小写
 * 参数
 * - strIn 查找的字符串位置
 *   strBy 要查找的内容
 * 返回
 * - 查找到的地址。
 * 备注
 * - 返回的地址将不可用，只能作为判断是否查找到的依据。
 */
char *strstrEx(const char *strIn, const char *strBy)
{
    char *tmpStrIn;
    char *tmpStrBy;
    char *result;

    tmpStrIn = (char *)malloc(strlen(strIn) + 1);
    tmpStrBy = (char *)malloc(strlen(strBy) + 1);
    strcpy(tmpStrIn, strIn);
    strcpy(tmpStrBy, strBy);
    strToUpper(tmpStrIn);
    strToUpper(tmpStrBy);
    result = strstr(tmpStrIn, tmpStrBy);
    free(tmpStrIn);
    free(tmpStrBy);

    return result;
}
