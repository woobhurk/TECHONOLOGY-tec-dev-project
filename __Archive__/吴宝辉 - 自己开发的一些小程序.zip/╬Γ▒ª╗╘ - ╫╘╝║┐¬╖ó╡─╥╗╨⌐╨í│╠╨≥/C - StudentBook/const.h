/*********
 * const.h
 * 定义全局用到的常量。
 */

#ifndef CONST_H
#define CONST_H

#define TRUE 1
#define FALSE 0
#define STR_SIZE 100
#define INT_SIZE 4
#define BOOK_EXT ".sbk"
#endif
