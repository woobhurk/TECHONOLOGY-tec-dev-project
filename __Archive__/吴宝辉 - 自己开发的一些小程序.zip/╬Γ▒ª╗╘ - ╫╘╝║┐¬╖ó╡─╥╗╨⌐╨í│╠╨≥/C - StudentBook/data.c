/********
 * data.c
 * 对数据进行操作。
 */

#include <stdio.h>
//#include <conio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <malloc.h>
#include "data.h"
#include "data_add.h"
#include "data_move.h"
#include "data_get.h"
#include "data_io.h"
#include "utils.h"
#include "types.h"
#include "const.h"
#include "global.h"


/**********
 * listData
 * - 列出数据
 */
void listData()
{
    STUDATA *data;
    char stuNum[STR_SIZE];
    char s_id[STR_SIZE];
    char choice;
    int cnt;
    int pauseCnt;

    puts("[列出数据]");

    if (!fileOpened)
    {
        puts("未打开文件.");
        return;
    }

    puts("a. 列出学号对应数据     b. 列出编号对应数据");
    puts("c. 列出所有学号和姓名   d. 列出所有数据(可能较多)");
    choice = tolower(getch());

    if (choice < 'a' || choice > 'd')
    {
        return;
    }

    switch (choice)
    {
    case 'a':
        puts("请输入学号:");
        gets(stuNum);
        stuNum[STR_SIZE - 1] = '\0';

        if (EMPTYSTR(stuNum))
        {
            puts("学号为空!");
            break;
        }

        data = getDataAddr(stuNum);

        if (data == NULL)
        {
            puts("未找到学号!");
            break;
        }

        printData(data);
        break;
    case 'b':
        puts("请输入编号:");
        gets(s_id);
        s_id[STR_SIZE - 1] = '\0';

        if (EMPTYSTR(s_id))
        {
            puts("编号为空!");
            break;
        }

        data = getDataAddrById(atoi(s_id));

        if (data == NULL)
        {
            puts("未找到编号!");
            break;
        }

        printData(data);
        break;
    case 'c':
    case 'd':
        data = dataHeader;
        cnt = 0;
        pauseCnt = (choice == 'c') ? 40 : 5;

        while (data != NULL)
        {
            if (choice == 'c')
            {
                printf("%06d: %-20s: %s\n", cnt, data->stuNum, data->name);
            }
            else
            {
                printData(data);
            }

            data = data->next;
            cnt++;

            if (cnt % pauseCnt == 0 && dataCount > pauseCnt)
            {
                puts("任意键继续, e退出...");

                if (tolower(getch()) == 'e')
                {
                    break;
                }
            }
        }

        break;
    default:
        break;
    }
}




/************
 * addData
 * - 添加数据
 */
void addData()
{
    STUDATA *newData;
    STUDATA *destData;
    int addDest;

    puts("[添加数据]");

    if (!fileOpened)
    {
        puts("未打开文件.");
        return;
    }

    newData = (STUDATA *)malloc(sizeof(STUDATA));
    inputData(newData, INPUT_DATA_ADD);

    // 如果原链表中没有数据则直接增加，否则提示插入位置
    if (dataHeader == NULL)
    {
        addDataTo(ADD_DATA_HEADER, newData, NULL);
    }
    else
    {
        addDest = getAddDest();
        destData = getAddDestData(addDest);
        addDataTo(addDest, newData, destData);
    }

    dataCount++;
    fileModified = TRUE;
    puts("数据已添加.");
}




/************
 * searchData
 * - 查找数据
 */
void searchData()
{
    STUDATA *data;
    int schCount;
    int id;
    char choice;
    char schContent[STR_SIZE];

    puts("[查找数据]");

    if (!fileOpened)
    {
        puts("未打开文件.");
        return;
    }

    puts("a. 学号   b. 姓名   c. 身份证号  d. 班级     e. 学院   f. 专业");
    puts("g. 学制   h. 电话   i. QQ号      j. E-Mail   k. 宿舍   l. 籍贯");
    choice = tolower(getch());

    if (choice < 'a' || choice > 'l')
    {
        return;
    }

    puts("查找内容: (不分大小写)");
    gets(schContent);
    schContent[STR_SIZE - 1] = '\0';

    if (EMPTYSTR(schContent))
    {
        puts("查找内容为空!");
        return;
    }

    puts("查找结果: (显示结果为学号)");
    data = dataHeader;
    id = 0;
    schCount = 0;

    while (data != NULL)
    {
        switch (choice)
        {
        case 'a':
            if (strstrEx(data->stuNum, schContent) != NULL)
            {
                schCount++;
                printf("%06d: %s\n", id, data->stuNum);
            }
            break;
        case 'b':
            SEARCH_DATA(data->name);
            break;
        case 'c':
            SEARCH_DATA(data->stuId);
            break;
        case 'd':
            SEARCH_DATA(data->className);
            break;
        case 'e':
            SEARCH_DATA(data->institute);
            break;
        case 'f':
            SEARCH_DATA(data->major);
            break;
        case 'g':
            if (atoi(schContent) == data->years)
            {
                schCount++;
                printf("%06d: %-20s: %d\n", id, data->stuNum, data->years);
            }
            break;
        case 'h':
            SEARCH_DATA(data->phoneNum);
            break;
        case 'j':
            SEARCH_DATA(data->qqNum);
            break;
        case 'k':
            SEARCH_DATA(data->domitory);
            break;
        case 'l':
            SEARCH_DATA(data->origion);
            break;
        default:
            break;
        }

        if (schCount % 50 == 0 && schCount > 0)
        {
            getch();
        }

        id++;
        data = data->next;
    }

    printf("共查找到%d项, 在主界面用l列出详细数据.\n", schCount);
}




/************
 * modifyData
 * - 修改数据
 */
void modifyData()
{
    STUDATA *data;
    STUDATA *newData;
    char stuNum[STR_SIZE];
    char s_id[STR_SIZE];
    char choice;

    puts("[修改数据]");

    if (!fileOpened)
    {
        puts("未打开文件.");
        return;
    }

    puts("请选择定位方式:");
    puts("a. 学号   b. 编号");
    choice = tolower(getch());

    if (choice < 'a' || choice > 'b')
    {
        return;
    }

    switch (choice)
    {
    case 'a':
        puts("请输入学号:");
        gets(stuNum);
        stuNum[STR_SIZE - 1] = '\0';

        if (EMPTYSTR(stuNum))
        {
            puts("学号为空!");
            return;
        }

        data = getDataAddr(stuNum);

        if (data == NULL)
        {
            puts("未找到学号!");
            return;
        }

        break;
    case 'b':
        puts("请输入编号:");
        gets(s_id);
        s_id[STR_SIZE - 1] = '\0';

        if (EMPTYSTR(s_id))
        {
            puts("编号为空!");
            return;
        }

        data = getDataAddrById(atoi(s_id));

        if (data == NULL)
        {
            puts("未找到编号!");
            return;
        }

        break;
    default:
        break;
    }

    puts("原数据:");
    printData(data);
    puts("------------------------------------------------------------------");
    puts("请输入新数据: (留空保持该项不变)");
    newData = (STUDATA *)malloc(sizeof(STUDATA));
    inputData(newData, INPUT_DATA_MODIFY);

    // 判断是否修改原数据
    MODIFY_DATA(data->stuNum, newData->stuNum);
    MODIFY_DATA(data->name, newData->name);
    MODIFY_DATA(data->stuId, newData->stuId);
    MODIFY_DATA(data->className, newData->className);
    MODIFY_DATA(data->institute, newData->institute);
    MODIFY_DATA(data->major, newData->major);
    if (newData->years != 0)
    {
        data->years = newData->years;
    }
    MODIFY_DATA(data->phoneNum, newData->phoneNum);
    MODIFY_DATA(data->qqNum, newData->qqNum);
    MODIFY_DATA(data->email, newData->email);
    MODIFY_DATA(data->domitory, newData->domitory);
    MODIFY_DATA(data->origion, newData->origion);

    fileModified = TRUE;
    puts("修改完成.");
}




/************
 * deleteData
 * - 删除数据
 */
void deleteData()
{
    STUDATA *data;
    STUDATA *prevData;
    char stuNum[STR_SIZE];
    char s_id[STR_SIZE];
    char choice;

    puts("[删除数据]");

    if (!fileOpened)
    {
        puts("未打开文件.");
        return;
    }

    puts("请选择定位方式:");
    puts("a. 学号   b. 编号");
    choice = tolower(getch());

    if (choice < 'a' || choice > 'b')
    {
        return;
    }

    switch (choice)
    {
    case 'a':
        puts("请输入学号:");
        gets(stuNum);
        stuNum[STR_SIZE - 1] = '\0';

        if (EMPTYSTR(stuNum))
        {
            puts("学号为空!");
            return;
        }

        prevData = getPrevDataAddr(stuNum);
        data = getDataAddr(stuNum);

        if (data == NULL)
        {
            puts("未找到学号!");
            return;
        }

        break;
    case 'b':
        puts("请输入编号:");
        gets(s_id);
        s_id[STR_SIZE - 1] = '\0';

        if (EMPTYSTR(s_id))
        {
            puts("编号为空!");
            return;
        }

        prevData = getPrevDataAddrById(atoi(s_id));
        data = getDataAddrById(atoi(s_id));

        if (data == NULL)
        {
            puts("未找到编号!");
            return;
        }

        break;
    default:
        break;
    }

    // 删除的节点是头
    if (data == dataHeader)
    {
        dataHeader = data->next;
    }
    else
    {
        prevData->next = data->next;

        // 删除的是尾
        if (data == dataTail)
        {
            dataTail = prevData;
        }
    }

    free(data);
    dataCount--;
    fileModified = TRUE;
    puts("已删除.");
}



/**********
 * moveData
 * - 移动数据
 */
void moveData()
{
    STUDATA *srcData;
    STUDATA *destData;
    int moveDest;

    puts("[移动数据]");

    if (!fileOpened)
    {
        puts("未打开文件.");
        return;
    }

    if (dataCount < 2)
    {
        puts("没有足够数据来移动.");
        return;
    }

    srcData = getMoveSrcData();

    if (srcData == NULL)
    {
        return;
    }

    moveDest = getMoveDest();

    if (moveDest < 0)
    {
        return;
    }

    destData = getMoveDestData(moveDest, srcData);

    if (destData == NULL)
    {
        return;
    }

    moveDataTo(moveDest, srcData, destData);
    fileModified = TRUE;
    puts("移动完成.");
}
