﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MainForm
	Inherits System.Windows.Forms.Form

	'Form 重写 Dispose，以清理组件列表。
	<System.Diagnostics.DebuggerNonUserCode()> _
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		Try
			If disposing AndAlso components IsNot Nothing Then
				components.Dispose()
			End If
		Finally
			MyBase.Dispose(disposing)
		End Try
	End Sub

	'Windows 窗体设计器所必需的
	Private components As System.ComponentModel.IContainer

	'注意: 以下过程是 Windows 窗体设计器所必需的
	'可以使用 Windows 窗体设计器修改它。
	'不要使用代码编辑器修改它。
	<System.Diagnostics.DebuggerStepThrough()> _
	Private Sub InitializeComponent()
		Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MainForm))
		Me.Win8_Caption = New System.Windows.Forms.Label
		Me.Win8_Close = New System.Windows.Forms.Label
		Me.Win8_Max = New System.Windows.Forms.Label
		Me.Win8_Mini = New System.Windows.Forms.Label
		Me.IconBox = New System.Windows.Forms.PictureBox
		Me.Win8_Bg = New System.Windows.Forms.Label
		CType(Me.IconBox, System.ComponentModel.ISupportInitialize).BeginInit()
		Me.SuspendLayout()
		'
		'Win8_Caption
		'
		Me.Win8_Caption.BackColor = System.Drawing.Color.LimeGreen
		Me.Win8_Caption.ForeColor = System.Drawing.Color.White
		Me.Win8_Caption.Location = New System.Drawing.Point(24, 0)
		Me.Win8_Caption.Name = "Win8_Caption"
		Me.Win8_Caption.Size = New System.Drawing.Size(260, 24)
		Me.Win8_Caption.TabIndex = 0
		Me.Win8_Caption.Text = "Win8_Caption"
		Me.Win8_Caption.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		'
		'Win8_Close
		'
		Me.Win8_Close.BackColor = System.Drawing.Color.LimeGreen
		Me.Win8_Close.Cursor = System.Windows.Forms.Cursors.Hand
		Me.Win8_Close.FlatStyle = System.Windows.Forms.FlatStyle.Popup
		Me.Win8_Close.Font = New System.Drawing.Font("微软雅黑", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
		Me.Win8_Close.ForeColor = System.Drawing.Color.White
		Me.Win8_Close.Location = New System.Drawing.Point(348, 0)
		Me.Win8_Close.Name = "Win8_Close"
		Me.Win8_Close.Size = New System.Drawing.Size(32, 24)
		Me.Win8_Close.TabIndex = 1
		Me.Win8_Close.Text = "×"
		Me.Win8_Close.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		'
		'Win8_Max
		'
		Me.Win8_Max.BackColor = System.Drawing.Color.LimeGreen
		Me.Win8_Max.Cursor = System.Windows.Forms.Cursors.Hand
		Me.Win8_Max.Font = New System.Drawing.Font("微软雅黑", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
		Me.Win8_Max.ForeColor = System.Drawing.Color.White
		Me.Win8_Max.Location = New System.Drawing.Point(316, 0)
		Me.Win8_Max.Name = "Win8_Max"
		Me.Win8_Max.Size = New System.Drawing.Size(32, 24)
		Me.Win8_Max.TabIndex = 2
		Me.Win8_Max.Text = "□"
		Me.Win8_Max.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		'
		'Win8_Mini
		'
		Me.Win8_Mini.BackColor = System.Drawing.Color.LimeGreen
		Me.Win8_Mini.Cursor = System.Windows.Forms.Cursors.Hand
		Me.Win8_Mini.Font = New System.Drawing.Font("微软雅黑", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
		Me.Win8_Mini.ForeColor = System.Drawing.Color.White
		Me.Win8_Mini.Location = New System.Drawing.Point(284, 0)
		Me.Win8_Mini.Name = "Win8_Mini"
		Me.Win8_Mini.Size = New System.Drawing.Size(32, 24)
		Me.Win8_Mini.TabIndex = 3
		Me.Win8_Mini.Text = "－"
		Me.Win8_Mini.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		'
		'IconBox
		'
		Me.IconBox.Location = New System.Drawing.Point(0, 0)
		Me.IconBox.Name = "IconBox"
		Me.IconBox.Size = New System.Drawing.Size(24, 24)
		Me.IconBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
		Me.IconBox.TabIndex = 4
		Me.IconBox.TabStop = False
		'
		'Win8_Bg
		'
		Me.Win8_Bg.BackColor = System.Drawing.Color.LimeGreen
		Me.Win8_Bg.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me.Win8_Bg.Location = New System.Drawing.Point(0, 350)
		Me.Win8_Bg.Name = "Win8_Bg"
		Me.Win8_Bg.Size = New System.Drawing.Size(380, 376)
		Me.Win8_Bg.TabIndex = 5
		Me.Win8_Bg.Visible = False
		'
		'MainForm
		'
		Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 19.0!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.BackColor = System.Drawing.Color.LimeGreen
		Me.ClientSize = New System.Drawing.Size(380, 400)
		Me.Controls.Add(Me.Win8_Bg)
		Me.Controls.Add(Me.IconBox)
		Me.Controls.Add(Me.Win8_Close)
		Me.Controls.Add(Me.Win8_Max)
		Me.Controls.Add(Me.Win8_Mini)
		Me.Controls.Add(Me.Win8_Caption)
		Me.Font = New System.Drawing.Font("微软雅黑", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
		Me.ForeColor = System.Drawing.Color.White
		Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
		Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
		Me.Location = New System.Drawing.Point(100, 100)
		Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
		Me.Name = "MainForm"
		Me.Padding = New System.Windows.Forms.Padding(1)
		Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
		CType(Me.IconBox, System.ComponentModel.ISupportInitialize).EndInit()
		Me.ResumeLayout(False)

	End Sub
	Friend WithEvents Win8_Caption As System.Windows.Forms.Label
	Friend WithEvents Win8_Close As System.Windows.Forms.Label
	Friend WithEvents Win8_Max As System.Windows.Forms.Label
	Friend WithEvents Win8_Mini As System.Windows.Forms.Label
	Friend WithEvents IconBox As System.Windows.Forms.PictureBox
	Friend WithEvents Win8_Bg As System.Windows.Forms.Label

End Class
