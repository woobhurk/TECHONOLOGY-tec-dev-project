﻿Public Class MainForm
	Dim isMouseDown As Boolean
	Dim Win8CurX, Win8CurY As Integer
	Dim Win8WndX, Win8WndY As Integer

	'******************************************************************
	'主窗口
	'初始化
	Private Sub MainForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
		'-------------------------------->
		IconBox.Image = Me.Icon.ToBitmap
		Win8_Caption.Text = "Win8_Caption"
		isMouseDown = False
		'<--------------------------------
	End Sub

	Private Sub MainForm_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
		'在此处添加事件过程
	End Sub

	'得到焦点，逐渐不透明
	Private Sub MainForm_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Activated
		'-------------------------------->
		While Me.Opacity < 1.0
			Me.Opacity += 0.00002
		End While
		Me.Opacity = 1.0
		'<--------------------------------
	End Sub

	'失去焦点，逐渐透明
	Private Sub MainForm_Deactivate(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Deactivate
		'-------------------------------->
		While Me.Opacity > 0.3
			Me.Opacity -= 0.00002
		End While
		Me.Opacity = 0.3
		'<--------------------------------
	End Sub

	Private Sub MainForm_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Me.MouseDown
		'-------------------------------->
		isMouseDown = True
		Win8CurX = e.X
		Win8CurY = e.Y
		'<--------------------------------
	End Sub

	Private Sub MainForm_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Me.MouseUp
		'-------------------------------->
		isMouseDown = False
		'<--------------------------------
	End Sub

	'光标移动，不支持更改大小
	Private Sub MainForm_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Me.MouseMove
		'If e.X <= 8 Or e.X >= Me.Size.Width - 8 Then
		'Me.Cursor = Cursors.SizeWE
		'ElseIf e.Y >= Me.Size.Height - 8 Then
		'Me.Cursor = Cursors.SizeNS
		'Else
		'Me.Cursor = Cursors.Default
		'End If
		'If isMouseDown Then
		'If e.X <= 8 Then  '光标在左边
		'Me.SetDesktopBounds(Me.Location.X - Win8CurX + e.X, Me.Location.Y, Me.Size.Width + Win8CurX - e.X, Me.Size.Height)	 '注意算法
		'ElseIf e.X >= Me.Size.Width - 8 Then  '在右边
		'Me.SetDesktopBounds(Me.Location.X, Me.Location.Y, Me.Size.Width - Win8CurX + e.X, Me.Size.Height)
		'ElseIf e.Y >= Me.Size.Height - 8 Then  '在下面
		'Me.SetDesktopBounds(Me.Location.X, Me.Location.Y, Me.Size.Width, Me.Size.Height - Win8CurY + e.Y)
		'Else  '光标在显示区域
		'Me.SetDesktopLocation(Me.Location.X - Win8CurX + e.X, Me.Location.Y - Win8CurY + e.Y)
		'End If
		'End If
	End Sub

	'更改大小（最大化），重新调整控件位置
	Private Sub MainForm_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Resize
		'Win8_Close.SetBounds(Me.Size.Width - 8 - Win8_Close.Size.Width - 1, 0, Win8_Close.Size.Width, Win8_Close.Size.Height)
		'Win8_Max.SetBounds(Me.Size.Width - 8 - Win8_Close.Size.Width - 1 - Win8_Max.Size.Width - 1, 0, Win8_Max.Size.Width, Win8_Max.Size.Height)
		'Win8_Mini.SetBounds(Me.Size.Width - 8 - Win8_Close.Size.Width - 1 - Win8_Max.Size.Width - 1 - Win8_Mini.Size.Width - 1, 0, Win8_Mini.Size.Width, Win8_Mini.Size.Height)
		'Win8_Caption.SetBounds(IconBox.Size.Width + 8 + 1, 0, Me.Size.Width - 16 - IconBox.Size.Width - 1 - Win8_Close.Size.Width - 1 - Win8_Max.Size.Width - 1 - Win8_Mini.Size.Width - 1, Win8_Caption.Size.Height)
		Win8_Close.SetBounds(Me.Size.Width - Win8_Close.Size.Width, 0, Win8_Close.Size.Width, Win8_Close.Size.Height)
		Win8_Max.SetBounds(Me.Size.Width - Win8_Close.Size.Width - Win8_Max.Size.Width, 0, Win8_Max.Size.Width, Win8_Max.Size.Height)
		Win8_Mini.SetBounds(Me.Size.Width - Win8_Close.Size.Width - Win8_Max.Size.Width - Win8_Mini.Size.Width, 0, Win8_Mini.Size.Width, Win8_Mini.Size.Height)
		Win8_Caption.SetBounds(IconBox.Size.Width, 0, Me.Size.Width - IconBox.Size.Width - Win8_Close.Size.Width - Win8_Max.Size.Width - Win8_Mini.Size.Width, Win8_Caption.Size.Height)
		Win8_Bg.SetBounds(0, IconBox.Size.Height, Me.Size.Width, Me.Size.Height - IconBox.Size.Height)
	End Sub

	'===============================================================
	'双击，最大化 / 最小化
	'标题栏
	Private Sub Win8_Caption_MouseDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Win8_Caption.MouseDoubleClick
		If Me.WindowState = FormWindowState.Normal Then
			Win8WndX = Me.Location.X
			Win8WndY = Me.Location.Y
			Me.WindowState = FormWindowState.Maximized
		Else
			Me.WindowState = FormWindowState.Normal
			Me.SetDesktopLocation(Win8WndX, Win8WndY)
		End If
	End Sub

	Private Sub Win8_Caption_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Win8_Caption.MouseDown
		isMouseDown = True
		Win8CurX = e.X
		Win8CurY = e.Y
	End Sub

	Private Sub Win8_Caption_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Win8_Caption.MouseUp
		isMouseDown = False
	End Sub

	'移动窗口
	Private Sub Win8_Caption_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Win8_Caption.MouseMove
		Dim CurrentX, CurrentY As Integer

		CurrentX = Me.Location.X - Win8CurX + e.X
		CurrentY = Me.Location.Y - Win8CurY + e.Y
		If CurrentX < 0 Then CurrentX = 0
		If CurrentY < 0 Then CurrentY = 0
		If isMouseDown Then
			Me.SetDesktopLocation(CurrentX, CurrentY)
		End If
	End Sub

	'================================================================
	'关闭按钮
	Private Sub Win8_Close_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Win8_Close.Click
		Application.Exit()
	End Sub

	'光标离开
	Private Sub Win8_Close_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles Win8_Close.MouseLeave
		Win8_Close.BackColor = Color.LimeGreen
	End Sub

	'光标到来
	Private Sub Win8_Close_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Win8_Close.MouseMove
		Win8_Close.BackColor = Color.Crimson
	End Sub

	'================================================================
	'最大化
	Private Sub Win8_Max_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Win8_Max.Click
		If Me.WindowState = FormWindowState.Normal Then
			Win8WndX = Me.Location.X
			Win8WndY = Me.Location.Y
			Me.WindowState = FormWindowState.Maximized
		Else
			Me.WindowState = FormWindowState.Normal
			Me.SetDesktopLocation(Win8WndX, Win8WndY)
		End If
	End Sub

	'光标离开
	Private Sub Win8_Max_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles Win8_Max.MouseLeave
		Win8_Max.BackColor = Color.LimeGreen
	End Sub

	'光标到来
	Private Sub Win8_Max_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Win8_Max.MouseMove
		Win8_Max.BackColor = Color.LightGreen
	End Sub

	'================================================================
	'最小化
	Private Sub Win8_Mini_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Win8_Mini.Click
		Me.WindowState = FormWindowState.Minimized
	End Sub

	'光标离开
	Private Sub Win8_Mini_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles Win8_Mini.MouseLeave
		Win8_Mini.BackColor = Color.LimeGreen
	End Sub

	'光标到来
	Private Sub Win8_Mini_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Win8_Mini.MouseMove
		Win8_Mini.BackColor = Color.LightGreen
	End Sub
End Class
