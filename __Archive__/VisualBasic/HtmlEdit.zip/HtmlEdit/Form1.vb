﻿Public Class MainForm
	Const ID_HTML As Integer = 1
	Const ID_CFG As Integer = 2
	Const CFG_NAME As String = "F:\HtmlEdit.cfg"

	Dim FName As String = "(未命名)"
	Dim FPath As String = ""

	Dim hasSaved As Boolean = False	 '用于判断文件是否存在
	Dim hasChanged As Boolean = False  '用于判断文件是否被修改
	Dim isLoading As Boolean = False  '是否正在加载页面


	'======================================================================================
	Function getName(ByVal PathStr As String) As String
		Return PathStr.Substring(PathStr.LastIndexOf("\") + 1)
	End Function

	Function getDir(ByVal PathStr As String) As String
		Return PathStr.Remove(PathStr.LastIndexOf("\"))
	End Function

	Function ChengeFlash(ByVal PathStr As String) As String
		Return PathStr.Replace("\", "/")
	End Function


	'--------------------------------------------------------------------------------------
	Sub OpenNewFile()
		'FileOpen(ID_HTML, FPath, OpenMode.Binary)
		'Seek(ID_HTML, 1)
		'While Not EOF(ID_HTML)
		'FileGet(ID_HTML, cnt)
		'TextStr += Chr(cnt)
		'End While
		'TBox1.Text = TextStr
		TBox1.Text = (New IO.StreamReader(FPath, System.Text.Encoding.Default)).ReadToEnd
		hasSaved = True
		hasChanged = False
		FName = getName(FPath)
		Tab1.Text = FName
		Me.Text = "HtmlEdit - [" + getDir(FPath) + "]"
	End Sub

	'--------------------------------------------------------------------------------------
	Sub SaveFile()
		Dim tmpSW As IO.StreamWriter

		'FileOpen(ID_HTML, FPath, OpenMode.Output)
		'FilePut(ID_HTML, TBox1.Text)
		'Write(ID_HTML, TBox1.Text)
		tmpSW = New IO.StreamWriter(FPath, False)
		tmpSW.Write(TBox1.Text)
		'FileClose(ID_HTML)
		hasSaved = True
		hasChanged = False
	End Sub

	Sub SaveNewFile()
		If SFDlg.ShowDialog <> Windows.Forms.DialogResult.OK Then Exit Sub
		FPath = SFDlg.FileName
		SaveFile()
		FName = getName(FPath)
		TBox1.Text = FName
		Me.Text = "HtmlEdit - [" + getDir(FPath) + "]"
	End Sub

	'--------------------------------------------------------------------------------------
	'警告用户保存文件
	Function AlertSaveFile() As Microsoft.VisualBasic.MsgBoxResult
		Dim UsrOpt As Microsoft.VisualBasic.MsgBoxResult

		If hasChanged Then
			UsrOpt = MsgBox("文件已经修改，是否保存？", MsgBoxStyle.Exclamation Or MsgBoxStyle.YesNoCancel, "警告")
			If UsrOpt = MsgBoxResult.Yes Then
				If hasSaved Then
					SaveFile()
				Else
					SaveNewFile()
				End If
			End If
		End If
		Return UsrOpt
	End Function

	'--------------------------------------------------------------------------------------
	Sub ExitPro()
		FileOpen(ID_CFG, CFG_NAME, OpenMode.Random)
		FileClose(ID_CFG)
		FileOpen(ID_CFG, CFG_NAME, OpenMode.Output)
		Write(ID_CFG, FPath)
		Write(ID_CFG, Me.Location.X)
		Write(ID_CFG, Me.Location.Y)
		Write(ID_CFG, Me.Width)
		Write(ID_CFG, Me.Height)
		Write(ID_CFG, TBox1.Font.Name)
		Write(ID_CFG, TBox1.Font.Size)
		Write(ID_CFG, TBox1.Font.Italic)
		Write(ID_CFG, TBox1.Font.Bold)
		FileClose(ID_CFG)
	End Sub


	'======================================================================================
	Private Sub MainForm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
		FileOpen(ID_CFG, CFG_NAME, OpenMode.Random)
		FileClose(ID_CFG)
		If FileLen(CFG_NAME) > 0 Then
			FileOpen(ID_CFG, CFG_NAME, OpenMode.Input)
			Input(ID_CFG, FPath)
			Input(ID_CFG, Me.Location.X)
			Input(ID_CFG, Me.Location.Y)
			Input(ID_CFG, Me.Width)
			Input(ID_CFG, Me.Height)
			Input(ID_CFG, TBox1.Font.Name)
			Input(ID_CFG, TBox1.Font.Size)
			Input(ID_CFG, TBox1.Font.Italic)
			Input(ID_CFG, TBox1.Font.Bold)
			FileClose(ID_CFG)
		End If
		Tab1.Text = FName
		TBox1.Dock = DockStyle.Fill
		Web1.Dock = DockStyle.Fill
	End Sub

	Private Sub MainForm_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Resize
		If Me.Height < 250 Or Me.Width < 310 Then
			Me.SetBounds(Me.Location.X, Me.Location.Y, 310, 250)
		End If
		WebSts.SetBounds(0, Me.Height - 85, 67, 21)
		Btn0.SetBounds(Me.Width - 50 * 6 - 62, Me.Height - 85, 45, 25)
		Btn1.SetBounds(Me.Width - 50 * 5 - 62, Me.Height - 85, 45, 25)
		Btn2.SetBounds(Me.Width - 50 * 4 - 62, Me.Height - 85, 45, 25)
		Btn3.SetBounds(Me.Width - 50 * 3 - 62, Me.Height - 85, 45, 25)
		Btn4.SetBounds(Me.Width - 50 * 2 - 62, Me.Height - 85, 45, 25)
		Btn5.SetBounds(Me.Width - 50 * 1 - 62, Me.Height - 85, 45, 25)
		Btn6.SetBounds(Me.Width - 62, Me.Height - 85, 45, 25)
		UrlBox.SetBounds(0, Me.Height - 61, Me.Width - 16, 23)
	End Sub

	Private Sub MainForm_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
		If AlertSaveFile() = MsgBoxResult.Cancel Then Exit Sub
		ExitPro()
		End
	End Sub


	'--------------------------------------------------------------------------------------
	'菜单
	Private Sub 新建ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles 新建ToolStripMenuItem.Click
		If AlertSaveFile() = MsgBoxResult.Cancel Then Exit Sub
		FName = "(未命名)"
		FPath = ""
		Tab1.Text = FName
		TBox1.Text = ""
		hasSaved = False
		hasChanged = False
	End Sub

	Private Sub 打开ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles 打开ToolStripMenuItem.Click
		If AlertSaveFile() = MsgBoxResult.Cancel Then Exit Sub
		If OpenDlg.ShowDialog <> Windows.Forms.DialogResult.OK Then Exit Sub
		FPath = OpenDlg.FileName
		OpenNewFile()
	End Sub

	Private Sub 保存ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles 保存ToolStripMenuItem.Click
		If hasSaved Then
			SaveFile()
		Else
			SaveNewFile()
		End If
	End Sub

	Private Sub 另存为ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles 另存为ToolStripMenuItem.Click
		SaveNewFile()
	End Sub

	Private Sub 退出ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles 退出ToolStripMenuItem.Click
		If AlertSaveFile() = MsgBoxResult.Cancel Then Exit Sub
		ExitPro()
		End
	End Sub


	'--------------------------------------------------------------------------------------
	Private Sub 粘贴ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles 粘贴ToolStripMenuItem.Click
		TBox1.Paste()
	End Sub

	Private Sub 选中所有ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles 选中所有ToolStripMenuItem.Click
		TBox1.SelectAll()
	End Sub


	'--------------------------------------------------------------------------------------
	Private Sub 预览htmlToolStripMenuItem_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles 预览htmlToolStripMenuItem.Click
		Dim HtmlUrl As Uri

		If Not hasSaved Then SaveNewFile()
		If hasChanged Then SaveFile()
		If FPath = "" Then Exit Sub
		HtmlUrl = New Uri("file:///" + ChengeFlash(FPath))
		TabCtrl.SelectTab(ViewPage)
		Web1.Visible = True
		Web1.Navigate(HtmlUrl)
		'ViewPage.Text = Web1.DocumentTitle
	End Sub

	Private Sub 关闭预览ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles 关闭预览ToolStripMenuItem.Click
		Web1.Visible = False
		ViewPage.Text = "预览窗口"
	End Sub


	'--------------------------------------------------------------------------------------
	Private Sub 字体ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles 字体ToolStripMenuItem.Click
		If FontDlg.ShowDialog <> Windows.Forms.DialogResult.OK Then Exit Sub
		TBox1.Font = FontDlg.Font
	End Sub

	Private Sub 字体颜色ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles 字体颜色ToolStripMenuItem.Click
		If ClrDlg.ShowDialog <> Windows.Forms.DialogResult.OK Then Exit Sub
		TBox1.ForeColor = ClrDlg.Color
	End Sub

	Private Sub 背景颜色ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles 背景颜色ToolStripMenuItem.Click
		If ClrDlg.ShowDialog <> Windows.Forms.DialogResult.OK Then Exit Sub
		TBox1.BackColor = ClrDlg.Color
	End Sub


	'--------------------------------------------------------------------------------------
	Private Sub 帮助ToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles 帮助ToolStripMenuItem1.Click
		HelpDlg.Show()
	End Sub

	Private Sub 关于ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles 关于ToolStripMenuItem.Click
		AboutDlg.Show()
	End Sub


	'--------------------------------------------------------------------------------------
	Private Sub TBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TBox1.TextChanged
		hasChanged = True
	End Sub


	'--------------------------------------------------------------------------------------
	'Web浏览器事件
	Private Sub Web1_DocumentCompleted(ByVal sender As Object, ByVal e As System.Windows.Forms.WebBrowserDocumentCompletedEventArgs) Handles Web1.DocumentCompleted
		isLoading = False
		ViewPage.Text = Web1.Site.Name
		MsgBox("")
	End Sub

	Private Sub Web1_NewWindow(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Web1.NewWindow
		'Dim frm As New MainForm

		e.Cancel = True
		isLoading = True
		'frm.Web1.Navigate(sender)
		'frm.Show()
		Web1.Navigate(sender)
	End Sub




	'--------------------------------------------------------------------------------------
	'导航
	Private Sub Btn0_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn0.Click
		Dim HtmlUrl As Uri

		If UrlBox.Text = "" Then Exit Sub
		UrlBox.Text.ToLower()
		If Not UrlBox.Text.StartsWith("http://") Then
			UrlBox.Text = "http://" + UrlBox.Text
		End If
		HtmlUrl = New Uri(UrlBox.Text)
		Web1.Visible = True
		isLoading = True
		Web1.Navigate(HtmlUrl)
	End Sub

	Private Sub Btn1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn1.Click
		Web1.GoBack()
	End Sub

	Private Sub Btn2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn2.Click
		Web1.GoForward()
	End Sub

	Private Sub Btn3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn3.Click
		Web1.GoHome()
	End Sub

	Private Sub Btn4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn4.Click
		isLoading = True
		Web1.Refresh()
	End Sub

	Private Sub Btn5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn5.Click
		Web1.GoSearch()
	End Sub

	Private Sub Btn6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn6.Click
		Web1.Stop()
	End Sub


	'--------------------------------------------------------------------------------------
	'计时器事件
	Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
		Static Dim tmp As Boolean = False

		Info_FChanged.Text = IIf(hasChanged, "已修改", "未修改").ToString
		Info_FSize.Text = "文件大小：" + TBox1.TextLength.ToString + "Bytes"

		If isLoading Then
			WebSts.Text = Web1.StatusText
		Else
			WebSts.Text = ""
		End If

		If TabCtrl.SelectedTab.Equals(Tab1) Then
			Info_FChanged.Visible = True
			Info_FSize.Visible = True
			WebSts.Visible = False
			Btn0.Visible = False
			Btn1.Visible = False
			Btn2.Visible = False
			Btn3.Visible = False
			Btn4.Visible = False
			Btn5.Visible = False
			Btn6.Visible = False
			UrlBox.Visible = False
		ElseIf TabCtrl.SelectedTab.Equals(ViewPage) Then
			Info_FChanged.Visible = False
			Info_FSize.Visible = False
			WebSts.Visible = True
			Btn0.Visible = True
			Btn1.Visible = True
			Btn2.Visible = True
			Btn3.Visible = True
			Btn4.Visible = True
			Btn5.Visible = True
			Btn6.Visible = True
			UrlBox.Visible = True
		End If

		If tmp = hasChanged Then Exit Sub
		If hasChanged Then
			Tab1.Text = FName + "*"
		Else
			Tab1.Text = FName
		End If
		tmp = hasChanged
	End Sub
End Class
