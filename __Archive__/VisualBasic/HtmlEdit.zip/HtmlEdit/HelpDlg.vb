﻿Public Class HelpDlg
	Private Sub HelpDlg_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
		Me.Text = MainForm.Text + " - [帮助]"
	End Sub
End Class