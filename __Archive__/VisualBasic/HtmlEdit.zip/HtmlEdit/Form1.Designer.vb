﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MainForm
	Inherits System.Windows.Forms.Form

	'Form 重写 Dispose，以清理组件列表。
	<System.Diagnostics.DebuggerNonUserCode()> _
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		Try
			If disposing AndAlso components IsNot Nothing Then
				components.Dispose()
			End If
		Finally
			MyBase.Dispose(disposing)
		End Try
	End Sub

	'Windows 窗体设计器所必需的
	Private components As System.ComponentModel.IContainer

	'注意: 以下过程是 Windows 窗体设计器所必需的
	'可以使用 Windows 窗体设计器修改它。
	'不要使用代码编辑器修改它。
	<System.Diagnostics.DebuggerStepThrough()> _
	Private Sub InitializeComponent()
		Me.components = New System.ComponentModel.Container
		Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MainForm))
		Me.TabCtrl = New System.Windows.Forms.TabControl
		Me.Tab1 = New System.Windows.Forms.TabPage
		Me.TBox1 = New System.Windows.Forms.TextBox
		Me.ViewPage = New System.Windows.Forms.TabPage
		Me.Web1 = New System.Windows.Forms.WebBrowser
		Me.Menu1 = New System.Windows.Forms.MenuStrip
		Me.文件ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
		Me.新建ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
		Me.打开ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
		Me.保存ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
		Me.另存为ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
		Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripSeparator
		Me.退出ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
		Me.编辑ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
		Me.粘贴ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
		Me.选中所有ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
		Me.调试ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
		Me.预览htmlToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
		Me.关闭预览ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
		Me.视图ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
		Me.字体ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
		Me.字体颜色ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
		Me.背景颜色ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
		Me.帮助ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
		Me.帮助ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
		Me.关于ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
		Me.Status = New System.Windows.Forms.StatusStrip
		Me.Info_FChanged = New System.Windows.Forms.ToolStripStatusLabel
		Me.Info_FSize = New System.Windows.Forms.ToolStripStatusLabel
		Me.ClrDlg = New System.Windows.Forms.ColorDialog
		Me.FontDlg = New System.Windows.Forms.FontDialog
		Me.OpenDlg = New System.Windows.Forms.OpenFileDialog
		Me.SFDlg = New System.Windows.Forms.SaveFileDialog
		Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
		Me.Btn6 = New System.Windows.Forms.Button
		Me.UrlBox = New System.Windows.Forms.TextBox
		Me.Btn1 = New System.Windows.Forms.Button
		Me.Btn2 = New System.Windows.Forms.Button
		Me.Btn3 = New System.Windows.Forms.Button
		Me.Btn4 = New System.Windows.Forms.Button
		Me.Btn5 = New System.Windows.Forms.Button
		Me.Btn0 = New System.Windows.Forms.Button
		Me.WebSts = New System.Windows.Forms.Label
		Me.TabCtrl.SuspendLayout()
		Me.Tab1.SuspendLayout()
		Me.ViewPage.SuspendLayout()
		Me.Menu1.SuspendLayout()
		Me.Status.SuspendLayout()
		Me.SuspendLayout()
		'
		'TabCtrl
		'
		Me.TabCtrl.Controls.Add(Me.Tab1)
		Me.TabCtrl.Controls.Add(Me.ViewPage)
		Me.TabCtrl.Dock = System.Windows.Forms.DockStyle.Fill
		Me.TabCtrl.Location = New System.Drawing.Point(0, 25)
		Me.TabCtrl.Name = "TabCtrl"
		Me.TabCtrl.SelectedIndex = 0
		Me.TabCtrl.Size = New System.Drawing.Size(706, 447)
		Me.TabCtrl.TabIndex = 0
		'
		'Tab1
		'
		Me.Tab1.Controls.Add(Me.TBox1)
		Me.Tab1.Location = New System.Drawing.Point(4, 22)
		Me.Tab1.Name = "Tab1"
		Me.Tab1.Padding = New System.Windows.Forms.Padding(3)
		Me.Tab1.Size = New System.Drawing.Size(698, 421)
		Me.Tab1.TabIndex = 0
		Me.Tab1.UseVisualStyleBackColor = True
		'
		'TBox1
		'
		Me.TBox1.Location = New System.Drawing.Point(8, 6)
		Me.TBox1.MaxLength = 0
		Me.TBox1.Multiline = True
		Me.TBox1.Name = "TBox1"
		Me.TBox1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
		Me.TBox1.Size = New System.Drawing.Size(285, 384)
		Me.TBox1.TabIndex = 0
		'
		'ViewPage
		'
		Me.ViewPage.Controls.Add(Me.Web1)
		Me.ViewPage.Location = New System.Drawing.Point(4, 22)
		Me.ViewPage.Name = "ViewPage"
		Me.ViewPage.Size = New System.Drawing.Size(698, 421)
		Me.ViewPage.TabIndex = 1
		Me.ViewPage.Text = "预览窗口"
		Me.ViewPage.UseVisualStyleBackColor = True
		'
		'Web1
		'
		Me.Web1.Location = New System.Drawing.Point(3, 36)
		Me.Web1.MinimumSize = New System.Drawing.Size(20, 20)
		Me.Web1.Name = "Web1"
		Me.Web1.ScriptErrorsSuppressed = True
		Me.Web1.Size = New System.Drawing.Size(183, 153)
		Me.Web1.TabIndex = 0
		'
		'Menu1
		'
		Me.Menu1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.文件ToolStripMenuItem, Me.编辑ToolStripMenuItem, Me.调试ToolStripMenuItem, Me.视图ToolStripMenuItem, Me.帮助ToolStripMenuItem})
		Me.Menu1.Location = New System.Drawing.Point(0, 0)
		Me.Menu1.Name = "Menu1"
		Me.Menu1.Size = New System.Drawing.Size(706, 25)
		Me.Menu1.TabIndex = 1
		Me.Menu1.Text = "Menu1"
		'
		'文件ToolStripMenuItem
		'
		Me.文件ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.新建ToolStripMenuItem, Me.打开ToolStripMenuItem, Me.保存ToolStripMenuItem, Me.另存为ToolStripMenuItem, Me.ToolStripMenuItem1, Me.退出ToolStripMenuItem})
		Me.文件ToolStripMenuItem.Name = "文件ToolStripMenuItem"
		Me.文件ToolStripMenuItem.Size = New System.Drawing.Size(58, 21)
		Me.文件ToolStripMenuItem.Text = "文件(&F)"
		'
		'新建ToolStripMenuItem
		'
		Me.新建ToolStripMenuItem.Name = "新建ToolStripMenuItem"
		Me.新建ToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.N), System.Windows.Forms.Keys)
		Me.新建ToolStripMenuItem.Size = New System.Drawing.Size(156, 22)
		Me.新建ToolStripMenuItem.Text = "新建"
		'
		'打开ToolStripMenuItem
		'
		Me.打开ToolStripMenuItem.Name = "打开ToolStripMenuItem"
		Me.打开ToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.O), System.Windows.Forms.Keys)
		Me.打开ToolStripMenuItem.Size = New System.Drawing.Size(156, 22)
		Me.打开ToolStripMenuItem.Text = "打开..."
		'
		'保存ToolStripMenuItem
		'
		Me.保存ToolStripMenuItem.Name = "保存ToolStripMenuItem"
		Me.保存ToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.S), System.Windows.Forms.Keys)
		Me.保存ToolStripMenuItem.Size = New System.Drawing.Size(156, 22)
		Me.保存ToolStripMenuItem.Text = "保存"
		'
		'另存为ToolStripMenuItem
		'
		Me.另存为ToolStripMenuItem.Name = "另存为ToolStripMenuItem"
		Me.另存为ToolStripMenuItem.Size = New System.Drawing.Size(156, 22)
		Me.另存为ToolStripMenuItem.Text = "另存为..."
		'
		'ToolStripMenuItem1
		'
		Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
		Me.ToolStripMenuItem1.Size = New System.Drawing.Size(153, 6)
		'
		'退出ToolStripMenuItem
		'
		Me.退出ToolStripMenuItem.Name = "退出ToolStripMenuItem"
		Me.退出ToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.X), System.Windows.Forms.Keys)
		Me.退出ToolStripMenuItem.Size = New System.Drawing.Size(156, 22)
		Me.退出ToolStripMenuItem.Text = "退出"
		'
		'编辑ToolStripMenuItem
		'
		Me.编辑ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.粘贴ToolStripMenuItem, Me.选中所有ToolStripMenuItem})
		Me.编辑ToolStripMenuItem.Name = "编辑ToolStripMenuItem"
		Me.编辑ToolStripMenuItem.Size = New System.Drawing.Size(59, 21)
		Me.编辑ToolStripMenuItem.Text = "编辑(&E)"
		'
		'粘贴ToolStripMenuItem
		'
		Me.粘贴ToolStripMenuItem.Name = "粘贴ToolStripMenuItem"
		Me.粘贴ToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.V), System.Windows.Forms.Keys)
		Me.粘贴ToolStripMenuItem.Size = New System.Drawing.Size(169, 22)
		Me.粘贴ToolStripMenuItem.Text = "粘贴"
		'
		'选中所有ToolStripMenuItem
		'
		Me.选中所有ToolStripMenuItem.Name = "选中所有ToolStripMenuItem"
		Me.选中所有ToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.A), System.Windows.Forms.Keys)
		Me.选中所有ToolStripMenuItem.Size = New System.Drawing.Size(169, 22)
		Me.选中所有ToolStripMenuItem.Text = "选中所有"
		'
		'调试ToolStripMenuItem
		'
		Me.调试ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.预览htmlToolStripMenuItem, Me.关闭预览ToolStripMenuItem})
		Me.调试ToolStripMenuItem.Name = "调试ToolStripMenuItem"
		Me.调试ToolStripMenuItem.Size = New System.Drawing.Size(61, 21)
		Me.调试ToolStripMenuItem.Text = "调试(&D)"
		'
		'预览htmlToolStripMenuItem
		'
		Me.预览htmlToolStripMenuItem.Name = "预览htmlToolStripMenuItem"
		Me.预览htmlToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F5
		Me.预览htmlToolStripMenuItem.Size = New System.Drawing.Size(146, 22)
		Me.预览htmlToolStripMenuItem.Text = "预览html"
		'
		'关闭预览ToolStripMenuItem
		'
		Me.关闭预览ToolStripMenuItem.Name = "关闭预览ToolStripMenuItem"
		Me.关闭预览ToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F4
		Me.关闭预览ToolStripMenuItem.Size = New System.Drawing.Size(146, 22)
		Me.关闭预览ToolStripMenuItem.Text = "关闭预览"
		'
		'视图ToolStripMenuItem
		'
		Me.视图ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.字体ToolStripMenuItem, Me.字体颜色ToolStripMenuItem, Me.背景颜色ToolStripMenuItem})
		Me.视图ToolStripMenuItem.Name = "视图ToolStripMenuItem"
		Me.视图ToolStripMenuItem.Size = New System.Drawing.Size(60, 21)
		Me.视图ToolStripMenuItem.Text = "视图(&V)"
		'
		'字体ToolStripMenuItem
		'
		Me.字体ToolStripMenuItem.Name = "字体ToolStripMenuItem"
		Me.字体ToolStripMenuItem.Size = New System.Drawing.Size(124, 22)
		Me.字体ToolStripMenuItem.Text = "字体"
		'
		'字体颜色ToolStripMenuItem
		'
		Me.字体颜色ToolStripMenuItem.Name = "字体颜色ToolStripMenuItem"
		Me.字体颜色ToolStripMenuItem.Size = New System.Drawing.Size(124, 22)
		Me.字体颜色ToolStripMenuItem.Text = "字体颜色"
		'
		'背景颜色ToolStripMenuItem
		'
		Me.背景颜色ToolStripMenuItem.Name = "背景颜色ToolStripMenuItem"
		Me.背景颜色ToolStripMenuItem.Size = New System.Drawing.Size(124, 22)
		Me.背景颜色ToolStripMenuItem.Text = "背景颜色"
		'
		'帮助ToolStripMenuItem
		'
		Me.帮助ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.帮助ToolStripMenuItem1, Me.关于ToolStripMenuItem})
		Me.帮助ToolStripMenuItem.Name = "帮助ToolStripMenuItem"
		Me.帮助ToolStripMenuItem.Size = New System.Drawing.Size(61, 21)
		Me.帮助ToolStripMenuItem.Text = "帮助(&H)"
		'
		'帮助ToolStripMenuItem1
		'
		Me.帮助ToolStripMenuItem1.Name = "帮助ToolStripMenuItem1"
		Me.帮助ToolStripMenuItem1.ShortcutKeys = System.Windows.Forms.Keys.F1
		Me.帮助ToolStripMenuItem1.Size = New System.Drawing.Size(121, 22)
		Me.帮助ToolStripMenuItem1.Text = "帮助"
		'
		'关于ToolStripMenuItem
		'
		Me.关于ToolStripMenuItem.Name = "关于ToolStripMenuItem"
		Me.关于ToolStripMenuItem.Size = New System.Drawing.Size(121, 22)
		Me.关于ToolStripMenuItem.Text = "关于(&A)"
		'
		'Status
		'
		Me.Status.AutoSize = False
		Me.Status.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Info_FChanged, Me.Info_FSize})
		Me.Status.Location = New System.Drawing.Point(0, 472)
		Me.Status.Name = "Status"
		Me.Status.Size = New System.Drawing.Size(706, 50)
		Me.Status.TabIndex = 2
		Me.Status.Text = "Status1"
		'
		'Info_FChanged
		'
		Me.Info_FChanged.Name = "Info_FChanged"
		Me.Info_FChanged.Size = New System.Drawing.Size(20, 45)
		Me.Info_FChanged.Text = "   "
		'
		'Info_FSize
		'
		Me.Info_FSize.Name = "Info_FSize"
		Me.Info_FSize.Size = New System.Drawing.Size(20, 45)
		Me.Info_FSize.Text = "   "
		'
		'OpenDlg
		'
		Me.OpenDlg.Filter = "html网页文件(*.htm)|*.htm|html网页文件(*.html)|*.html|所有文件(*.*)|*.*"
		'
		'SFDlg
		'
		Me.SFDlg.DefaultExt = "htm"
		Me.SFDlg.Filter = "html网页文件(*.htm)|*.htm|html网页文件(*.html)|*.html|所有文件(*.*)|*.*"
		'
		'Timer1
		'
		Me.Timer1.Enabled = True
		Me.Timer1.Interval = 40
		'
		'Btn6
		'
		Me.Btn6.BackColor = System.Drawing.Color.DeepPink
		Me.Btn6.Font = New System.Drawing.Font("微软雅黑", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
		Me.Btn6.ForeColor = System.Drawing.Color.Khaki
		Me.Btn6.Location = New System.Drawing.Point(660, 475)
		Me.Btn6.Name = "Btn6"
		Me.Btn6.Size = New System.Drawing.Size(45, 25)
		Me.Btn6.TabIndex = 3
		Me.Btn6.Text = "停止"
		Me.Btn6.UseVisualStyleBackColor = False
		'
		'UrlBox
		'
		Me.UrlBox.BackColor = System.Drawing.Color.Violet
		Me.UrlBox.Font = New System.Drawing.Font("微软雅黑", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
		Me.UrlBox.Location = New System.Drawing.Point(0, 499)
		Me.UrlBox.Name = "UrlBox"
		Me.UrlBox.Size = New System.Drawing.Size(706, 23)
		Me.UrlBox.TabIndex = 4
		'
		'Btn1
		'
		Me.Btn1.BackColor = System.Drawing.Color.HotPink
		Me.Btn1.Font = New System.Drawing.Font("微软雅黑", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
		Me.Btn1.ForeColor = System.Drawing.Color.Khaki
		Me.Btn1.Location = New System.Drawing.Point(410, 475)
		Me.Btn1.Name = "Btn1"
		Me.Btn1.Size = New System.Drawing.Size(45, 25)
		Me.Btn1.TabIndex = 5
		Me.Btn1.Text = "<<"
		Me.Btn1.UseVisualStyleBackColor = False
		'
		'Btn2
		'
		Me.Btn2.BackColor = System.Drawing.Color.HotPink
		Me.Btn2.Font = New System.Drawing.Font("微软雅黑", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
		Me.Btn2.ForeColor = System.Drawing.Color.Khaki
		Me.Btn2.Location = New System.Drawing.Point(460, 475)
		Me.Btn2.Name = "Btn2"
		Me.Btn2.Size = New System.Drawing.Size(45, 25)
		Me.Btn2.TabIndex = 6
		Me.Btn2.Text = ">>"
		Me.Btn2.UseVisualStyleBackColor = False
		'
		'Btn3
		'
		Me.Btn3.BackColor = System.Drawing.Color.HotPink
		Me.Btn3.Font = New System.Drawing.Font("微软雅黑", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
		Me.Btn3.ForeColor = System.Drawing.Color.Khaki
		Me.Btn3.Location = New System.Drawing.Point(510, 475)
		Me.Btn3.Name = "Btn3"
		Me.Btn3.Size = New System.Drawing.Size(45, 25)
		Me.Btn3.TabIndex = 7
		Me.Btn3.Text = "主页"
		Me.Btn3.UseVisualStyleBackColor = False
		'
		'Btn4
		'
		Me.Btn4.BackColor = System.Drawing.Color.HotPink
		Me.Btn4.Font = New System.Drawing.Font("微软雅黑", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
		Me.Btn4.ForeColor = System.Drawing.Color.Khaki
		Me.Btn4.Location = New System.Drawing.Point(560, 475)
		Me.Btn4.Name = "Btn4"
		Me.Btn4.Size = New System.Drawing.Size(45, 25)
		Me.Btn4.TabIndex = 8
		Me.Btn4.Text = "刷新"
		Me.Btn4.UseVisualStyleBackColor = False
		'
		'Btn5
		'
		Me.Btn5.BackColor = System.Drawing.Color.HotPink
		Me.Btn5.Font = New System.Drawing.Font("微软雅黑", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
		Me.Btn5.ForeColor = System.Drawing.Color.Khaki
		Me.Btn5.Location = New System.Drawing.Point(610, 475)
		Me.Btn5.Name = "Btn5"
		Me.Btn5.Size = New System.Drawing.Size(45, 25)
		Me.Btn5.TabIndex = 9
		Me.Btn5.Text = "搜索"
		Me.Btn5.UseVisualStyleBackColor = False
		'
		'Btn0
		'
		Me.Btn0.BackColor = System.Drawing.Color.DeepPink
		Me.Btn0.Font = New System.Drawing.Font("微软雅黑", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
		Me.Btn0.ForeColor = System.Drawing.Color.Khaki
		Me.Btn0.Location = New System.Drawing.Point(360, 475)
		Me.Btn0.Name = "Btn0"
		Me.Btn0.Size = New System.Drawing.Size(45, 25)
		Me.Btn0.TabIndex = 10
		Me.Btn0.Text = "Go"
		Me.Btn0.UseVisualStyleBackColor = False
		'
		'WebSts
		'
		Me.WebSts.AutoSize = True
		Me.WebSts.Font = New System.Drawing.Font("微软雅黑", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
		Me.WebSts.Location = New System.Drawing.Point(0, 475)
		Me.WebSts.Name = "WebSts"
		Me.WebSts.Size = New System.Drawing.Size(67, 21)
		Me.WebSts.TabIndex = 11
		Me.WebSts.Text = "No text"
		'
		'MainForm
		'
		Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.BackColor = System.Drawing.Color.Plum
		Me.ClientSize = New System.Drawing.Size(706, 522)
		Me.Controls.Add(Me.Btn0)
		Me.Controls.Add(Me.Btn5)
		Me.Controls.Add(Me.Btn4)
		Me.Controls.Add(Me.Btn3)
		Me.Controls.Add(Me.Btn2)
		Me.Controls.Add(Me.Btn1)
		Me.Controls.Add(Me.Btn6)
		Me.Controls.Add(Me.WebSts)
		Me.Controls.Add(Me.UrlBox)
		Me.Controls.Add(Me.TabCtrl)
		Me.Controls.Add(Me.Status)
		Me.Controls.Add(Me.Menu1)
		Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
		Me.Name = "MainForm"
		Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
		Me.Text = "HtmlEdit"
		Me.TabCtrl.ResumeLayout(False)
		Me.Tab1.ResumeLayout(False)
		Me.Tab1.PerformLayout()
		Me.ViewPage.ResumeLayout(False)
		Me.Menu1.ResumeLayout(False)
		Me.Menu1.PerformLayout()
		Me.Status.ResumeLayout(False)
		Me.Status.PerformLayout()
		Me.ResumeLayout(False)
		Me.PerformLayout()

	End Sub
	Friend WithEvents TabCtrl As System.Windows.Forms.TabControl
	Friend WithEvents Tab1 As System.Windows.Forms.TabPage
	Friend WithEvents TBox1 As System.Windows.Forms.TextBox
	Friend WithEvents Menu1 As System.Windows.Forms.MenuStrip
	Friend WithEvents Status As System.Windows.Forms.StatusStrip
	Friend WithEvents Info_FSize As System.Windows.Forms.ToolStripStatusLabel
	Friend WithEvents 文件ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents 新建ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents 打开ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents 保存ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents 另存为ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripSeparator
	Friend WithEvents 退出ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents 编辑ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents 视图ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents 字体ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents 字体颜色ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents 背景颜色ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents 帮助ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents 帮助ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents 关于ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents ViewPage As System.Windows.Forms.TabPage
	Friend WithEvents 粘贴ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents 选中所有ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents Web1 As System.Windows.Forms.WebBrowser
	Friend WithEvents ClrDlg As System.Windows.Forms.ColorDialog
	Friend WithEvents FontDlg As System.Windows.Forms.FontDialog
	Friend WithEvents OpenDlg As System.Windows.Forms.OpenFileDialog
	Friend WithEvents SFDlg As System.Windows.Forms.SaveFileDialog
	Friend WithEvents Timer1 As System.Windows.Forms.Timer
	Friend WithEvents 调试ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents 预览htmlToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents 关闭预览ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents Info_FChanged As System.Windows.Forms.ToolStripStatusLabel
	Friend WithEvents Btn6 As System.Windows.Forms.Button
	Friend WithEvents UrlBox As System.Windows.Forms.TextBox
	Friend WithEvents Btn1 As System.Windows.Forms.Button
	Friend WithEvents Btn2 As System.Windows.Forms.Button
	Friend WithEvents Btn3 As System.Windows.Forms.Button
	Friend WithEvents Btn4 As System.Windows.Forms.Button
	Friend WithEvents Btn5 As System.Windows.Forms.Button
	Friend WithEvents Btn0 As System.Windows.Forms.Button
	Friend WithEvents WebSts As System.Windows.Forms.Label

End Class
