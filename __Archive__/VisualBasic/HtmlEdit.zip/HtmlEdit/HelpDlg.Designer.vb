﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class HelpDlg
    Inherits System.Windows.Forms.Form

    'Form 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意: 以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
		Me.HelpText = New System.Windows.Forms.Label
		Me.SuspendLayout()
		'
		'HelpText
		'
		Me.HelpText.BackColor = System.Drawing.Color.LimeGreen
		Me.HelpText.Dock = System.Windows.Forms.DockStyle.Fill
		Me.HelpText.Font = New System.Drawing.Font("微软雅黑", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
		Me.HelpText.ForeColor = System.Drawing.Color.White
		Me.HelpText.Location = New System.Drawing.Point(0, 0)
		Me.HelpText.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
		Me.HelpText.Name = "HelpText"
		Me.HelpText.Size = New System.Drawing.Size(374, 372)
		Me.HelpText.TabIndex = 0
		Me.HelpText.Text = "开始编写html网页文件吧！" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "HtmlEditor是使用内置浏览组件浏览html文件的编辑器。" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "目前HtmlEditor只能显示单色文本，无高亮显示代码功" & _
			"能。编辑功能也十分简陋，没有任何水平，见笑！"
		'
		'HelpDlg
		'
		Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 19.0!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.ClientSize = New System.Drawing.Size(374, 372)
		Me.Controls.Add(Me.HelpText)
		Me.Font = New System.Drawing.Font("微软雅黑", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
		Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
		Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
		Me.MaximizeBox = False
		Me.MinimizeBox = False
		Me.Name = "HelpDlg"
		Me.Opacity = 0.8
		Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
		Me.ResumeLayout(False)

	End Sub
	Friend WithEvents HelpText As System.Windows.Forms.Label
End Class
