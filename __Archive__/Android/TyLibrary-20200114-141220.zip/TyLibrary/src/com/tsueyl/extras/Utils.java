/**
 * Utils
 * Author: Woobhurk
 * Copyright (C) 2015 Tsueyl
 * All rights reserved.
 * *******************************
 * STATIC METHODS
 *   showToast
 *   showDialog
 *   showTraceToast
 *   showTraceDialog
 *   traceToString
 *   traceToString2
 * DYNAMIC METHODS
 * NOTES
 * FREE OF LICENSE
 * *******************************
 * Version: 1.0.0 (20150812 07:46)
 * Change Log:
 *   0. THE FIRST VERSION.
 */

package com.tsueyl.extras;

import android.app.AlertDialog;
import android.content.Context;
import android.widget.Toast;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

public class Utils
{
	public static final int SIZE_TRACESTR = 0x00100000;


	/***********
	 * showToast
	 *   Show a toast in a more convenient way.
	 * Parameter:
	 *   ctx: The Context of the Activity.
	 *   msg: Message.
	 */
	public static void showToast(Context ctx, String msg)
	{
		Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show();
	}


	/************
	 * showDialog
	 *   Show a common dialog in a more convenient way.
	 * Parameter:
	 *   ctx: The Context of the Activity.
	 *   title: Title.
	 *   msg: Message.
	 */
	public static void showDialog(Context ctx, String title, String msg)
	{
		AlertDialog.Builder dlg;

		dlg = new AlertDialog.Builder(ctx);
		dlg.setTitle(title);
		dlg.setMessage(msg);
		dlg.show();
	}


	/****************
	 * showTraceToast
	 *   Show the trace of a Throwable in a Toast.
	 * Parameter:
	 *   ctx: The Context of the Activity.
	 *   e: A Throwable.
	 * Note:
	 *   The toast will last long time.
	 */
	public static void showTraceToast(Context ctx, Throwable e)
	{
		Toast.makeText(ctx, traceToString(e), Toast.LENGTH_LONG).show();
	}


	/*****************
	 * showTraceDialog
	 *   Show the trace of a Throwable in an AlertDialog.
	 * Parameter:
	 *   ctx: The Context of the Activity.
	 *   e: A Throwable.
	 */
	public static void showTraceDialog(Context ctx, Throwable e)
	{
		showDialog(ctx, null, traceToString(e));
	}


	/*************************
	 * traceToString -> String
	 *   Get the trace of a Throwable.
	 * Parameter:
	 *   e: A Throwable.
	 * Return:
	 *   The "converted" result of the Throwable.
	 */
	public static String traceToString(Throwable e)
	{
		StackTraceElement[] steAll;
		String traceStr;

		steAll = e.getStackTrace();
		traceStr = e.toString();
		for (StackTraceElement steElement : steAll)
		{
			traceStr += "\n  at " + steElement.toString();
		}

		return traceStr;
	}


	/**************************
	 * traceToString2 -> String
	 *   Get the trace of a Throwable.
	 * Parameter:
	 *   e: A Throwable.
	 * Return:
	 *   The "converted" result of the Throwable.
	 * Notes:
	 *   The difference between traceToString and traceToString2 is
	 *   that traceToString uses StackTraceElement to get traces
	 *   while traceToString2 uses printStackTrace to get traces and
	 *   stores them in a ByteArrayOutputStream, which means the
	 *   result is more "official" :).
	 */
	public static String traceToString2(Throwable e)
	{
		PrintStream psTrace;
		ByteArrayOutputStream bosTrace;

		// 1MiB for storing trace information.
		bosTrace = new ByteArrayOutputStream(SIZE_TRACESTR);
		psTrace = new PrintStream(bosTrace);
		e.printStackTrace(psTrace);

		return bosTrace.toString();
	}
}

