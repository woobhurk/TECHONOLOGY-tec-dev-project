package com.tsueyl.funcpad;

public class PFuncData
{
	public static final String DEF_EXPX = "pow(sin(t), 3.0)";
	public static final String DEF_EXPY = "2 * cos(t) * t";
	public static final String DEF_RANGESTART = "-pi";
	public static final String DEF_RANGEEND = "2 * e";
	public static final String DEF_RANGEDELTA = "0.1";

	private String pfExpX;
	private String pfExpY;
	private String pfRangeStart;
	private String pfRangeEnd;
	private String pfRangeDelta;


	public PFuncData()
	{
		pfExpX = DEF_EXPX;
		pfExpY = DEF_EXPY;
		pfRangeStart = DEF_RANGESTART;
		pfRangeEnd = DEF_RANGEEND;
		pfRangeDelta = DEF_RANGEDELTA;
	}


	public PFuncData(String expX, String expY, String rangeStart,
			String rangeEnd, String rangeDelta)
	{
		pfExpX = expX;
		pfExpY = expY;
		pfRangeStart = rangeStart;
		pfRangeEnd = rangeEnd;
		pfRangeDelta = rangeDelta;
	}


	public String getExpX()
	{
		return this.pfExpX;
	}


	public String getExpY()
	{
		return this.pfExpY;
	}


	public String getRangeStart()
	{
		return this.pfRangeStart;
	}


	public String getRangeEnd()
	{
		return this.pfRangeEnd;
	}


	public String getRangeDelta()
	{
		return this.pfRangeDelta;
	}


	public void setExpX(String expX)
	{
		this.pfExpX = expX;
	}


	public void setExpY(String expY)
	{
		this.pfExpY = expY;
	}


	public void setRangeStart(String rangeStart)
	{
		this.pfRangeStart = rangeStart;
	}


	public void setRangeEnd(String rangeEnd)
	{
		this.pfRangeEnd = rangeEnd;
	}


	public void setRangeDelta(String rangeDelta)
	{
		this.pfRangeDelta = rangeDelta;
	}
}

