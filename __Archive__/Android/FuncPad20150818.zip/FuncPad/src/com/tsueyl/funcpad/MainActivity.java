/***************
 * Name: FuncPad
 * Author: Woobhurk
 * Copyright (C) 2015 Tsueyl
 * All rights reserved.
 * ********************************
 * Version: 0.1.44 (20150818 14:29)
 * Change Log:
 * - Fixed：
 *   1. FORGETTEN :)
 * - Added:
 *   1. 截图功能
 *   2. 放大镜功能
 *   3. 退出确认功能
 * ********************************
 * Version: 0.1.03 (20150817 16:06)
 * Change Log:
 * - Added:
 *   1. 抗锯齿开关
 * ********************************
 * Version: 0.1.02 (20150817 13:14)
 * Change Log:
 * 0. THE FIRST RELEASE.
 * - Fixed:
 *   1. 缩放图像时不会移动图像
 *   2. 核心绘图函数重构，速度提升1%-_-!
 * - Added:
 *   1. 数据保存功能
 *   2. 显示设置
 *   3. 颜色设置
 */

package com.tsueyl.funcpad;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;
import java.util.ArrayList;
import com.tsueyl.extras.Utils;

public class MainActivity extends Activity
{
	// 默认值
	public static final boolean SHOW_GRID = true;
	public static final boolean SHOW_COORDNUM = true;
	public static final boolean SHOW_ZOOMTOOL = true;
	public static final boolean SHOW_POINTER = true;
	public static final boolean ANTI_ALIAS = true;
	public static final int COLOR_CANVAS = 0xffffffff;
	public static final int COLOR_GRID = 0xffa0a0a0;
	public static final int COLOR_COORD = 0xff000000;
	public static final int COLOR_COORDNUM = 0xff000000;
	public static final int COLOR_FUNC = 0xffa06020;
	public static final int COLOR_POINTER = 0xff503010;

	// Keys
	public static final String NAME_SHAREDPREFERENCES = "funcpad_datas";
	public static final String KEY_SHOWGRID = "key_showgrid";
	public static final String KEY_SHOWCOORDNUM = "key_showcoordnum";
	public static final String KEY_SHOWZOOMTOOL = "key_showzoomtool";
	public static final String KEY_SHOWPOINTER = "key_showpointer";
	public static final String KEY_ANTIALIAS = "key_antialias";
	public static final String KEY_COLORCANVAS = "key_colorcanvas";
	public static final String KEY_COLORGRID = "key_colorgrid";
	public static final String KEY_COLORCOORD = "key_colorcoord";
	public static final String KEY_COLORCOORDNUM = "key_colorcoordnum";
	public static final String KEY_COLORFUNC = "key_colorfunc";
	public static final String KEY_COLORPOINTER = "key_colorpointer";

	public static final int COLORID_CANVAS = 0;
	public static final int COLORID_GRID = 1;
	public static final int COLORID_COORD = 2;
	public static final int COLORID_COORDNUM = 3;
	public static final int COLORID_FUNC = 4;
	public static final int COLORID_POINTER = 5;
	public static final long TIME_EXITDELAY = 1500;

	private View vw_main;
	private View vw_option;

	// Main
	private FuncPadView fpv_funcPad;
	private Button btn_openOption;
	private Button btn_clearAll;
	private Button btn_zoomIn;
	private Button btn_zoomOut;
	private ToggleButton tbtn_showZoomTool;
	private Button btn_takeShot;
	private Button btn_exit;

	// Option
	private EditText et_nfExp;
	private EditText et_nfRangeStart;
	private EditText et_nfRangeEnd;
	private EditText et_nfRangeDelta;
	private Button btn_nfDraw;
	private EditText et_nfEvalX;
	private EditText et_nfEvalFx;
	private Button btn_nfEval;

	private EditText et_pfExpX;
	private EditText et_pfExpY;
	private EditText et_pfRangeStart;
	private EditText et_pfRangeEnd;
	private EditText et_pfRangeDelta;
	private Button btn_pfDraw;
	private EditText et_pfEvalT;
	private EditText et_pfEvalXY;
	private Button btn_pfEval;

	private Button btn_openMain;
	private Button btn_help;
	private Button btn_about;

	// Settings
	private ToggleButton tbtn_showGrid;
	private ToggleButton tbtn_showCoordNum;
	private ToggleButton tbtn_showPointer;
	private ToggleButton tbtn_antiAlias;
	private Button btn_colorCanvas;
	private Button btn_colorGrid;
	private Button btn_colorCoord;
	private Button btn_colorCoordNum;
	private Button btn_colorFunc;
	private Button btn_colorPointer;

	// Gesture detector
	private ScaleGestureDetector sgd_detector;

	// Datas
	private ArrayList<NFuncData> nfDataList;
	private ArrayList<PFuncData> pfDataList;

	// Variables
	private int prevTouchX;
	private int prevTouchY;
	private int origGridSize;
	private boolean showGrid;
	private boolean showCoordNum;
	private boolean showZoomTool;
	private boolean showPointer;
	private boolean antiAlias;
	private int colorCanvas;
	private int colorGrid;
	private int colorCoord;
	private int colorCoordNum;
	private int colorFunc;
	private int colorPointer;
	private boolean needDraw;
	private boolean needMoveFunc;
	private boolean isFirstOpenOption;
	private boolean isMainUI;
	private String rhinoInitCode;
	private long exitTime;


	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);

		LayoutInflater li_inflater;

		getActionBar().hide();
		li_inflater = getLayoutInflater();
		vw_main = li_inflater.inflate(R.layout.main, null);
		vw_option = li_inflater.inflate(R.layout.option, null);
		readPreferences();
		initVar();
		initMainUI();
		initMainWidget();
		drawAllFunc();
	}


	/*********
	 * onPause
	 * - 及时保存数据
	 */
	@Override
	protected void onPause()
	{
		super.onPause();
		savePreferences();
	}


	/***********
	 * onKeyDown
	 * - 处理按键事件，用于防止误退
	 * Notes:
	 * - 如果是选项界面，则切换到主界面；如果是主界面，则判断两次按返回键的间隔
	 * - 时长，如果时长小于TIME_EXITDELAY，则退出，否则显示Toast，Toast显示时长
	 * - 正好等于TIME_EXITDELAY。
	 */
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event)
	{
		// 仅仅处理返回键:)
		if (keyCode != KeyEvent.KEYCODE_BACK)
		{
			return super.onKeyDown(keyCode, event);
		}

		if (!isMainUI)
		{
			switchToMain();
			return false;
		}
		else
		{
			long currentTime = System.currentTimeMillis();

			if (currentTime - exitTime == 0
					|| currentTime - exitTime > TIME_EXITDELAY)
			{
				exitTime = currentTime;
				Toast.makeText(this, "Press BACK again to exit",
						(int)TIME_EXITDELAY).show();
				return false;
			}
			else
			{
				finish();
			}
		}

		// 基本无用了
		return super.onKeyDown(keyCode, event);
	}


	/*****************
	 * readPreferences
	 * - 读取数据
	 */
	private void readPreferences()
	{
		SharedPreferences spReader;

		spReader = getSharedPreferences(NAME_SHAREDPREFERENCES,
				Context.MODE_PRIVATE);

		//Utils.showToast(this, "readPreferences");
		showGrid = spReader.getBoolean(KEY_SHOWGRID, SHOW_GRID);
		showCoordNum = spReader.getBoolean(KEY_SHOWCOORDNUM, SHOW_COORDNUM);
		showZoomTool = spReader.getBoolean(KEY_SHOWZOOMTOOL, SHOW_ZOOMTOOL);
		showPointer = spReader.getBoolean(KEY_SHOWPOINTER, SHOW_POINTER);
		antiAlias = spReader.getBoolean(KEY_ANTIALIAS, ANTI_ALIAS);
		colorCanvas = spReader.getInt(KEY_COLORCANVAS, COLOR_CANVAS);
		colorGrid = spReader.getInt(KEY_COLORGRID, COLOR_GRID);
		colorCoord = spReader.getInt(KEY_COLORCOORD, COLOR_COORD);
		colorCoordNum = spReader.getInt(KEY_COLORCOORDNUM, COLOR_COORDNUM);
		colorFunc = spReader.getInt(KEY_COLORFUNC, COLOR_FUNC);
		colorPointer = spReader.getInt(KEY_COLORPOINTER, COLOR_POINTER);
	}


	/****************
	 * savePeferences
	 * - 储存数据
	 */
	private void savePreferences()
	{
		SharedPreferences.Editor spEdirtor;

		//Utils.showToast(this, "savePreferences");
		spEdirtor = getSharedPreferences(NAME_SHAREDPREFERENCES,
				Context.MODE_PRIVATE).edit();
		spEdirtor.putBoolean(KEY_SHOWGRID, showGrid);
		spEdirtor.putBoolean(KEY_SHOWCOORDNUM, showCoordNum);
		spEdirtor.putBoolean(KEY_SHOWZOOMTOOL, showZoomTool);
		spEdirtor.putBoolean(KEY_SHOWPOINTER, showPointer);
		spEdirtor.putBoolean(KEY_ANTIALIAS, antiAlias);
		spEdirtor.putInt(KEY_COLORCANVAS, colorCanvas);
		spEdirtor.putInt(KEY_COLORGRID, colorGrid);
		spEdirtor.putInt(KEY_COLORCOORD, colorCoord);
		spEdirtor.putInt(KEY_COLORCOORDNUM, colorCoordNum);
		spEdirtor.putInt(KEY_COLORFUNC, colorFunc);
		spEdirtor.putInt(KEY_COLORPOINTER, colorPointer);
		spEdirtor.commit();
	}


	private void initVar()
	{
		nfDataList = new ArrayList<NFuncData>();
		pfDataList = new ArrayList<PFuncData>();
		nfDataList.add(new NFuncData());
		pfDataList.add(new PFuncData());
		needDraw = false;
		//needMoveFunc = false;
		isFirstOpenOption = true;
		isMainUI = true;
		rhinoInitCode = getResources().getString(R.string.code_init_rhino);
		sgd_detector = new ScaleGestureDetector(this, new SGDListener());
	}


	private void initMainUI()
	{
		fpv_funcPad = (FuncPadView)vw_main.findViewById(R.id.fpv_funcPad);
		btn_openOption = (Button)vw_main.findViewById(R.id.btn_openOption);
		btn_clearAll = (Button)vw_main.findViewById(R.id.btn_clearAll);
		btn_zoomIn = (Button)vw_main.findViewById(R.id.btn_zoomIn);
		btn_zoomOut = (Button)vw_main.findViewById(R.id.btn_zoomOut);
		tbtn_showZoomTool = (ToggleButton)vw_main
				.findViewById(R.id.tbtn_showZoomTool);
		btn_takeShot = (Button)vw_main.findViewById(R.id.btn_takeShot);
		btn_exit = (Button)vw_main.findViewById(R.id.btn_exit);

		setContentView(vw_main);
	}


	private void initMainWidget()
	{
		// FuncPad
		fpv_funcPad.setOnTouchListener(new View.OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent e)
			{
				needMoveFunc = true;
				sgd_detector.onTouchEvent(e);

				// 如果是缩放则不移动图像
				if (!needMoveFunc)
				{
					return true;
				}

				switch (e.getAction())
				{
				case MotionEvent.ACTION_DOWN:
					prevTouchX = (int)e.getX();
					prevTouchY = (int)e.getY();
					// 不管是否缩放、是否开启放大镜都要移动触点坐标线
					movePointer(prevTouchX, prevTouchY);
					break;
				case MotionEvent.ACTION_MOVE:
					movePointer((int)e.getX(), (int)e.getY());

					// 如果开启放大镜也不移动图像
					if (!showZoomTool)
					{
						moveFunc((int)e.getX(), (int)e.getY());
					}

					break;
				}

				return true;
			}
		});
		// 初始化画板数据
		fpv_funcPad.setShowGrid(showGrid);
		fpv_funcPad.setShowCoordNum(showCoordNum);
		fpv_funcPad.setShowZoomTool(showZoomTool);
		fpv_funcPad.setShowPointer(showPointer);
		fpv_funcPad.setAntiAlias(antiAlias);
		fpv_funcPad.setCanvasColor(colorCanvas);
		fpv_funcPad.setGridColor(colorGrid);
		fpv_funcPad.setCoordColor(colorCoord);
		fpv_funcPad.setCoordNumColor(colorCoordNum);
		fpv_funcPad.setFuncColor(colorFunc);
		fpv_funcPad.setPointerColor(colorPointer);
		// 打开选项
		btn_openOption.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v)
			{
				switchToOption();
			}
		});
		// 清除所有函数
		btn_clearAll.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v)
			{
				clearAllFunc();
			}
		});
		// 放大
		btn_zoomIn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v)
			{
				zoomFunc(fpv_funcPad.getGridSize()
						+ fpv_funcPad.getGridSizeDelta());
			}
		});
		// 缩小
		btn_zoomOut.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v)
			{
				zoomFunc(fpv_funcPad.getGridSize()
						- fpv_funcPad.getGridSizeDelta());
			}
		});
		// 显示放大镜
		tbtn_showZoomTool.setChecked(showZoomTool);
		tbtn_showZoomTool.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v)
			{
				showZoomTool = ((ToggleButton)v).isChecked();
				fpv_funcPad.setShowZoomTool(showZoomTool);
			}
		});
		// 保存图像
		btn_takeShot.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v)
			{
				takeScreenShot();
			}
		});
		// 退出
		btn_exit.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v)
			{
				finish();
			}
		});
	}


	private void initOptionUI()
	{
		// Normal function
		et_nfExp = (EditText)vw_option.findViewById(R.id.et_nfExp);
		et_nfRangeStart = (EditText)vw_option
				.findViewById(R.id.et_nfRangeStart);
		et_nfRangeEnd = (EditText)vw_option.findViewById(R.id.et_nfRangeEnd);
		et_nfRangeDelta = (EditText)vw_option
				.findViewById(R.id.et_nfRangeDelta);
		btn_nfDraw = (Button)vw_option.findViewById(R.id.btn_nfDraw);
		et_nfEvalX = (EditText)vw_option.findViewById(R.id.et_nfEvalX);
		et_nfEvalFx = (EditText)vw_option.findViewById(R.id.et_nfEvalFx);
		btn_nfEval = (Button)vw_option.findViewById(R.id.btn_nfEval);

		// Parameter function
		et_pfExpX = (EditText)vw_option.findViewById(R.id.et_pfExpX);
		et_pfExpY = (EditText)vw_option.findViewById(R.id.et_pfExpY);
		et_pfRangeStart = (EditText)vw_option
				.findViewById(R.id.et_pfRangeStart);
		et_pfRangeEnd = (EditText)vw_option.findViewById(R.id.et_pfRangeEnd);
		et_pfRangeDelta = (EditText)vw_option
				.findViewById(R.id.et_pfRangeDelta);
		btn_pfDraw = (Button)vw_option.findViewById(R.id.btn_pfDraw);
		et_pfEvalT = (EditText)vw_option.findViewById(R.id.et_pfEvalT);
		et_pfEvalXY = (EditText)vw_option.findViewById(R.id.et_pfEvalXY);
		btn_pfEval = (Button)vw_option.findViewById(R.id.btn_pfEval);

		// Control
		btn_openMain = (Button)vw_option.findViewById(R.id.btn_openMain);
		btn_help = (Button)vw_option.findViewById(R.id.btn_help);
		btn_about = (Button)vw_option.findViewById(R.id.btn_about);

		// Settings
		tbtn_showGrid = (ToggleButton)vw_option
				.findViewById(R.id.tbtn_showGrid);
		tbtn_showCoordNum = (ToggleButton)vw_option
				.findViewById(R.id.tbtn_showCoordNum);
		tbtn_showPointer = (ToggleButton)vw_option
				.findViewById(R.id.tbtn_showPointer);
		tbtn_antiAlias = (ToggleButton)vw_option
				.findViewById(R.id.tbtn_antiAlias);
		btn_colorCanvas = (Button)vw_option.findViewById(R.id.btn_colorCanvas);
		btn_colorGrid = (Button)vw_option.findViewById(R.id.btn_colorGrid);
		btn_colorCoord = (Button)vw_option.findViewById(R.id.btn_colorCoord);
		btn_colorCoordNum = (Button)vw_option
				.findViewById(R.id.btn_colorCoordNum);
		btn_colorFunc = (Button)vw_option.findViewById(R.id.btn_colorFunc);
		btn_colorPointer = (Button)vw_option
				.findViewById(R.id.btn_colorPointer);
	}


	private void initOptionWidget()
	{
		et_nfExp.setText(NFuncData.DEF_EXP);
		et_nfRangeStart.setText(NFuncData.DEF_RANGESTART);
		et_nfRangeEnd.setText(NFuncData.DEF_RANGEEND);
		et_nfRangeDelta.setText(NFuncData.DEF_RANGEDELTA);
		// 画出函数
		btn_nfDraw.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v)
			{
				saveNFunc();

				// 如果函数数据非法则未保存数据，也就不用画出图像
				if (needDraw)
				{
					drawAllFunc();
				}
			}
		});
		// 求函数值
		btn_nfEval.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v)
			{
				evalNFunc();
			}
		});

		et_pfExpX.setText(PFuncData.DEF_EXPX);
		et_pfExpY.setText(PFuncData.DEF_EXPY);
		et_pfRangeStart.setText(PFuncData.DEF_RANGESTART);
		et_pfRangeEnd.setText(PFuncData.DEF_RANGEEND);
		et_pfRangeDelta.setText(PFuncData.DEF_RANGEDELTA);
		// 画出参数方程
		btn_pfDraw.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v)
			{
				savePFunc();

				if (needDraw)
				{
					drawAllFunc();
				}
			}
		});
		// 求参数方程值
		btn_pfEval.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v)
			{
				evalPFunc();
			}
		});

		// Control
		btn_openMain.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v)
			{
				switchToMain();
			}
		});
		btn_help.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v)
			{
				showHelp();
			}
		});
		btn_about.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v)
			{
				showAbout();
			}
		});

		// Settings
		tbtn_showGrid.setChecked(showGrid);
		tbtn_showGrid.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v)
			{
				showGrid = ((ToggleButton)v).isChecked();
				fpv_funcPad.setShowGrid(showGrid);
			}
		});
		tbtn_showCoordNum.setChecked(showCoordNum);
		tbtn_showCoordNum.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v)
			{
				showCoordNum = ((ToggleButton)v).isChecked();
				fpv_funcPad.setShowCoordNum(showCoordNum);
			}
		});
		tbtn_showPointer.setChecked(showPointer);
		tbtn_showPointer.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v)
			{
				showPointer = ((ToggleButton)v).isChecked();
				fpv_funcPad.setShowPointer(showPointer);
			}
		});
		tbtn_antiAlias.setChecked(antiAlias);
		tbtn_antiAlias.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v)
			{
				antiAlias = ((ToggleButton)v).isChecked();
				fpv_funcPad.setAntiAlias(antiAlias);
			}
		});
		// 将按钮文字颜色设置为背景色的反色，以便辨认
		btn_colorCanvas.setTextColor(getNegativeColor(colorCanvas));
		btn_colorCanvas.setBackgroundColor(colorCanvas);
		btn_colorCanvas.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v)
			{
				setColor(COLORID_CANVAS);
			}
		});
		btn_colorGrid.setTextColor(getNegativeColor(colorGrid));
		btn_colorGrid.setBackgroundColor(colorGrid);
		btn_colorGrid.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v)
			{
				setColor(COLORID_GRID);
			}
		});
		btn_colorCoord.setTextColor(getNegativeColor(colorCoord));
		btn_colorCoord.setBackgroundColor(colorCoord);
		btn_colorCoord.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v)
			{
				setColor(COLORID_COORD);
			}
		});
		btn_colorCoordNum.setTextColor(getNegativeColor(colorCoordNum));
		btn_colorCoordNum.setBackgroundColor(colorCoordNum);
		btn_colorCoordNum.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v)
			{
				setColor(COLORID_COORDNUM);
			}
		});
		btn_colorFunc.setTextColor(getNegativeColor(colorFunc));
		btn_colorFunc.setBackgroundColor(colorFunc);
		btn_colorFunc.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v)
			{
				setColor(COLORID_FUNC);
			}
		});
		btn_colorPointer.setTextColor(getNegativeColor(colorPointer));
		btn_colorPointer.setBackgroundColor(colorPointer);
		btn_colorPointer.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v)
			{
				setColor(COLORID_POINTER);
			}
		});
	}


	private void switchToMain()
	{
		setContentView(vw_main);
		isMainUI = true;
	}


	private void switchToOption()
	{
		setContentView(vw_option);
		isMainUI = false;

		if (isFirstOpenOption)
		{
			initOptionUI();
			initOptionWidget();
			isFirstOpenOption = false;
		}
	}


	/*************
	 * drawAllFunc
	 * - 画出所有函数和参数方程图像
	 * Notes:
	 * - 与FuncPadView的drawAllFunc不同。这里将传给fpv_funcPad函数数据。
	 */
	private void drawAllFunc()
	{
		fpv_funcPad.drawAllFunc(nfDataList, pfDataList);
		switchToMain();
	}


	/***********
	 * saveNFunc
	 * - 保存函数数据。会检查范围合法性。
	 */
	private void saveNFunc()
	{
		String nfExp;
		String nfRangeStart;
		String nfRangeEnd;
		String nfRangeDelta;
		float f_nfRangeStart;
		float f_nfRangeEnd;
		float f_nfRangeDelta;
		NFuncData nfData;
		org.mozilla.javascript.Context rhinoCtx;
		org.mozilla.javascript.Scriptable rhinoScope;
		Object result;

		nfExp = et_nfExp.getText().toString();
		nfRangeStart = et_nfRangeStart.getText().toString();
		nfRangeEnd = et_nfRangeEnd.getText().toString();
		nfRangeDelta = et_nfRangeDelta.getText().toString();

		if (nfExp.equals("") || nfRangeStart.equals("")
				|| nfRangeEnd.equals("") || nfRangeDelta.equals(""))
		{
			needDraw = false;
			return;
		}

		rhinoCtx = org.mozilla.javascript.Context.enter();
		rhinoCtx.setOptimizationLevel(-1);

		// 计算范围是否合法
		try
		{
			rhinoScope = rhinoCtx.initStandardObjects();
			rhinoCtx.evaluateString(rhinoScope, rhinoInitCode,
					"saveNFunc.rhinoInitCode", 1, null);
			result = rhinoCtx.evaluateString(rhinoScope, nfRangeStart,
					"saveNFunc.rangeStart", 1, null);
			f_nfRangeStart = Float.parseFloat(rhinoCtx.toString(result));
			result = rhinoCtx.evaluateString(rhinoScope, nfRangeEnd,
					"saveNFunc.rangeEnd", 1, null);
			f_nfRangeEnd = Float.parseFloat(rhinoCtx.toString(result));
			result = rhinoCtx.evaluateString(rhinoScope, nfRangeDelta,
					"saveNFunc.rangeDelta", 1, null);
			f_nfRangeDelta = Float.parseFloat(rhinoCtx.toString(result));
		}
		catch (Exception error)
		{
			Utils.showTraceDialog(this, error);
			needDraw = false;
			return;
		}
		finally
		{
			rhinoCtx.exit();
		}

		if (f_nfRangeEnd < f_nfRangeStart || f_nfRangeDelta <= 0.0f)
		{
			Utils.showDialog(this, null,
					getResources().getString(R.string.invalid_range));
			et_nfRangeStart.requestFocus();
			needDraw = false;
			return;
		}

		nfData = new NFuncData(nfExp, nfRangeStart, nfRangeEnd, nfRangeDelta);
		nfDataList.add(nfData);
		needDraw = true;
	}


	/***********
	 * evalNFunc
	 * - 计算函数值
	 */
	private void evalNFunc()
	{
		String nfExp;
		String nfEvalX;
		String nfEvalFx;
		double d_nfEvalX;
		org.mozilla.javascript.Context rhinoCtx;
		org.mozilla.javascript.Scriptable rhinoScope;
		Object result;

		nfExp = et_nfExp.getText().toString();
		nfEvalX = et_nfEvalX.getText().toString();

		if (nfExp.equals("") || nfEvalX.equals(""))
		{
			return;
		}

		rhinoCtx = org.mozilla.javascript.Context.enter();
		rhinoCtx.setOptimizationLevel(-1);

		try
		{
			rhinoScope = rhinoCtx.initStandardObjects();
			rhinoCtx.evaluateString(rhinoScope, rhinoInitCode,
					"evalNFunc.rhinoInitCode", 1, null);
			result = rhinoCtx.evaluateString(rhinoScope, nfEvalX,
					"evalNFunc.nfEvalX", 1, null);
			nfEvalX = rhinoCtx.toString(result);
			d_nfEvalX = Double.parseDouble(nfEvalX);
			org.mozilla.javascript.ScriptableObject.putProperty(rhinoScope,
					"x", org.mozilla.javascript.Context.javaToJS(d_nfEvalX,
							rhinoScope));
			result = rhinoCtx.evaluateString(rhinoScope, nfExp,
					"evalNFunc.nfExp", 1, null);
			nfEvalFx = rhinoCtx.toString(result);
		}
		catch (Exception error)
		{
			Utils.showTraceDialog(this, error);
			return;
		}
		finally
		{
			rhinoCtx.exit();
		}

		et_nfEvalFx.setText(nfEvalFx);
	}


	private void savePFunc()
	{
		String pfExpX;
		String pfExpY;
		String pfRangeStart;
		String pfRangeEnd;
		String pfRangeDelta;
		float f_pfRangeStart;
		float f_pfRangeEnd;
		float f_pfRangeDelta;
		PFuncData pfData;
		org.mozilla.javascript.Context rhinoCtx;
		org.mozilla.javascript.Scriptable rhinoScope;
		Object result;

		pfExpX = et_pfExpX.getText().toString();
		pfExpY = et_pfExpY.getText().toString();
		pfRangeStart = et_pfRangeStart.getText().toString();
		pfRangeEnd = et_pfRangeEnd.getText().toString();
		pfRangeDelta = et_pfRangeDelta.getText().toString();

		if (pfExpX.equals("") || pfExpY.equals("") || pfRangeStart.equals("")
				|| pfRangeEnd.equals("") || pfRangeDelta.equals(""))
		{
			needDraw = false;
			return;
		}

		rhinoCtx = org.mozilla.javascript.Context.enter();
		rhinoCtx.setOptimizationLevel(-1);

		try
		{
			rhinoScope = rhinoCtx.initStandardObjects();
			rhinoCtx.evaluateString(rhinoScope, rhinoInitCode,
					"savePFunc.rhinoInitCode", 1, null);
			result = rhinoCtx.evaluateString(rhinoScope, pfRangeStart,
					"savePFunc.rangeStart", 1, null);
			f_pfRangeStart = Float.parseFloat(rhinoCtx.toString(result));
			result = rhinoCtx.evaluateString(rhinoScope, pfRangeEnd,
					"savePFunc.rangeEnd", 1, null);
			f_pfRangeEnd = Float.parseFloat(rhinoCtx.toString(result));
			result = rhinoCtx.evaluateString(rhinoScope, pfRangeDelta,
					"savePFunc.rangeDelta", 1, null);
			f_pfRangeDelta = Float.parseFloat(rhinoCtx.toString(result));
		}
		catch (Exception error)
		{
			Utils.showTraceDialog(this, error);
			needDraw = false;
			return;
		}
		finally
		{
			rhinoCtx.exit();
		}

		if (f_pfRangeEnd < f_pfRangeStart || f_pfRangeDelta <= 0.0f)
		{
			Utils.showDialog(this, null,
					getResources().getString(R.string.invalid_range));
			needDraw = false;
			return;
		}

		pfData = new PFuncData(pfExpX, pfExpY, pfRangeStart, pfRangeEnd,
				pfRangeDelta);
		pfDataList.add(pfData);
		needDraw = true;
	}


	private void evalPFunc()
	{
		String pfExpX;
		String pfExpY;
		String pfEvalT;
		String pfEvalX;
		String pfEvalY;
		String pfEvalXY;
		double d_pfEvalT;
		org.mozilla.javascript.Context rhinoCtx;
		org.mozilla.javascript.Scriptable rhinoScope;
		Object result;

		pfExpX = et_pfExpX.getText().toString();
		pfExpY = et_pfExpY.getText().toString();
		pfEvalT = et_pfEvalT.getText().toString();

		if (pfExpX.equals("") || pfExpY.equals("") || pfEvalT.equals(""))
		{
			return;
		}

		rhinoCtx = org.mozilla.javascript.Context.enter();
		rhinoCtx.setOptimizationLevel(-1);

		try
		{
			rhinoScope = rhinoCtx.initStandardObjects();
			rhinoCtx.evaluateString(rhinoScope, rhinoInitCode,
					"evalPFunc.rhinoInitCode", 1, null);
			result = rhinoCtx.evaluateString(rhinoScope, pfEvalT,
					"evalPFunc.pfEvalT", 1, null);
			pfEvalT = rhinoCtx.toString(result);
			d_pfEvalT = Double.parseDouble(pfEvalT);
			org.mozilla.javascript.ScriptableObject.putProperty(rhinoScope,
					"t", org.mozilla.javascript.Context.javaToJS(d_pfEvalT,
							rhinoScope));
			result = rhinoCtx.evaluateString(rhinoScope, pfExpX,
					"evalPFunc.pfExpX", 1, null);
			pfEvalX = rhinoCtx.toString(result);
			result = rhinoCtx.evaluateString(rhinoScope, pfExpY,
					"evalPFunc.pfExpY", 1, null);
			pfEvalY = rhinoCtx.toString(result);
		}
		catch (Exception error)
		{
			Utils.showTraceDialog(this, error);
			return;
		}
		finally
		{
			rhinoCtx.exit();
		}

		//pfEvalXY = "(" + pfEvalX + ", " + pfEvalY + ")";
		pfEvalXY = String.format("(%s, %s)", pfEvalX, pfEvalY);
		et_pfEvalXY.setText(pfEvalXY);
	}


	/**************
	 * clearAllFunc
	 * - 清空函数
	 * Notes:
	 * - 要同时清空MainActivity和fpv_funcPad中的函数数据。
	 */
	private void clearAllFunc()
	{
		nfDataList.clear();
		pfDataList.clear();
		fpv_funcPad.clearAllFunc();
	}


	/**********
	 * moveFunc
	 * - 移动函数图像
	 * Parameters:
	 * - currentTouchX: 当前触点x坐标
	 * - currentTouchY: 当前触点y坐标
	 */
	private void moveFunc(int currentTouchX, int currentTouchY)
	{
		fpv_funcPad.moveFuncBy(currentTouchX - prevTouchX, currentTouchY
				- prevTouchY);
		prevTouchX = currentTouchX;
		prevTouchY = currentTouchY;
	}


	/*************
	 * movePointer
	 * - 移动触点坐标
	 * Parameters:
	 * - pointerX: 新的x坐标
	 * - pointerY: 新的y坐标
	 */
	private void movePointer(int pointerX, int pointerY)
	{
		fpv_funcPad.movePointer(pointerX, pointerY);
	}


	/**********
	 * zoomFunc
	 * - 缩放函数图像
	 * Parameters:
	 * - gridSize: 新的网格大小
	 */
	private void zoomFunc(int gridSize)
	{
		fpv_funcPad.zoomFunc(gridSize);
	}


	/****************
	 * takeScreenShot
	 * - 截屏
	 */
	private void takeScreenShot()
	{
		fpv_funcPad.takeScreenShot();
	}


	/******************
	 * showMoreSettings
	 * - 显示更多设置
	 * Notes:
	 * - 基本上已废弃，因为设置都在option里面了。
	 */
	private void showMoreSettings()
	{
		;
	}


	private void showHelp()
	{
		String helpContent;

		helpContent = getResources().getString(R.string.help_content);
		Utils.showDialog(this, btn_help.getText().toString(), helpContent);
	}


	private void showAbout()
	{
		String aboutContent;

		aboutContent = getResources().getString(R.string.about_content);
		Utils.showDialog(this, btn_about.getText().toString(), aboutContent);
	}


	/**********
	 * setColor
	 * - 设置元素颜色
	 * Parameters:
	 * - colorId: 元素的ID，用于判断是设置哪个元素的颜色
	 */
	private void setColor(int colorId)
	{
		ColorPicker colorPicker;

		colorPicker = new ColorPicker(this, colorId);
		colorPicker.show();
	}


	/******************
	 * getNegativeColor
	 * - 计算反色值
	 * Parameters:
	 * - origColor: 原色值
	 * Return:
	 * - 反色值
	 */
	private int getNegativeColor(int origColor)
	{
		int negativeColor;

		negativeColor = Color.argb(Color.alpha(origColor),
				0xff - Color.red(origColor), 0xff - Color.green(origColor),
				0xff - Color.blue(origColor));

		return negativeColor;
	}




	// 手势监听器，用于缩放函数图像
	private class SGDListener extends
			ScaleGestureDetector.SimpleOnScaleGestureListener
	{
		@Override
		public boolean onScaleBegin(ScaleGestureDetector detector)
		{
			// 缩放开始，保存原始网格大小
			origGridSize = fpv_funcPad.getGridSize();
			// 缩放时，不移动图像
			needMoveFunc = false;
			return super.onScaleBegin(detector);
		}


		@Override
		public boolean onScale(ScaleGestureDetector detector)
		{
			int currentGridSize;

			// 不能直接用gridSize缩放，不然缩放程度会呈指数增长O_O。
			currentGridSize = (int)((float)origGridSize * detector
					.getScaleFactor());
			zoomFunc(currentGridSize);
			needMoveFunc = false;

			return super.onScale(detector);
		}
	}




	// 调色板
	private class ColorPicker extends AlertDialog.Builder implements
			SeekBar.OnSeekBarChangeListener, View.OnClickListener
	{
		private View vw_colorPicker;

		private TextView tv_colorPicker;
		private EditText et_colorR;
		private Button btn_colorMinusR;
		private SeekBar sb_colorR;
		private Button btn_colorAddR;
		private EditText et_colorG;
		private Button btn_colorMinusG;
		private SeekBar sb_colorG;
		private Button btn_colorAddG;
		private EditText et_colorB;
		private Button btn_colorMinusB;
		private SeekBar sb_colorB;
		private Button btn_colorAddB;

		private int colorId;
		private int color;
		private int colorR;
		private int colorG;
		private int colorB;


		public ColorPicker(Context ctx, int _colorId)
		{
			super(ctx);

			LayoutInflater li_colorPicker = getLayoutInflater();
			vw_colorPicker = li_colorPicker
					.inflate(R.layout.color_picker, null);

			this.setView(vw_colorPicker);
			this.setCancelable(false);
			this.setNegativeButton("Cancel",
					new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface p1, int p2)
						{
							// TODO: Implement this method
						}
					});
			this.setPositiveButton("Comfirm",
					new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface p1, int p2)
						{
							setColorById();
						}
					});

			initPickerVar(_colorId);
			initPickerUI();
			initPickerWidget();
		}


		private void initPickerUI()
		{
			tv_colorPicker = (TextView)vw_colorPicker
					.findViewById(R.id.tv_colorPicker);
			// Red
			et_colorR = (EditText)vw_colorPicker.findViewById(R.id.et_colorR);
			btn_colorMinusR = (Button)vw_colorPicker
					.findViewById(R.id.btn_colorMinusR);
			sb_colorR = (SeekBar)vw_colorPicker.findViewById(R.id.sb_colorR);
			btn_colorAddR = (Button)vw_colorPicker
					.findViewById(R.id.btn_colorAddR);
			// Green
			et_colorG = (EditText)vw_colorPicker.findViewById(R.id.et_colorG);
			btn_colorMinusG = (Button)vw_colorPicker
					.findViewById(R.id.btn_colorMinusG);
			sb_colorG = (SeekBar)vw_colorPicker.findViewById(R.id.sb_colorG);
			btn_colorAddG = (Button)vw_colorPicker
					.findViewById(R.id.btn_colorAddG);
			et_colorB = (EditText)vw_colorPicker.findViewById(R.id.et_colorB);
			// Blue
			btn_colorMinusB = (Button)vw_colorPicker
					.findViewById(R.id.btn_colorMinusB);
			sb_colorB = (SeekBar)vw_colorPicker.findViewById(R.id.sb_colorB);
			btn_colorAddB = (Button)vw_colorPicker
					.findViewById(R.id.btn_colorAddB);
		}


		private void initPickerWidget()
		{
			// Red
			tv_colorPicker.setBackgroundColor(color);
			et_colorR.setText("" + colorR);
			btn_colorMinusR.setOnClickListener(this);
			sb_colorR.setProgress(colorR);
			sb_colorR.setOnSeekBarChangeListener(this);
			btn_colorAddR.setOnClickListener(this);
			// Green
			et_colorG.setText("" + colorG);
			btn_colorMinusG.setOnClickListener(this);
			sb_colorG.setProgress(colorG);
			sb_colorG.setOnSeekBarChangeListener(this);
			btn_colorAddG.setOnClickListener(this);
			// Blue
			et_colorB.setText("" + colorB);
			btn_colorMinusB.setOnClickListener(this);
			sb_colorB.setProgress(colorB);
			sb_colorB.setOnSeekBarChangeListener(this);
			btn_colorAddB.setOnClickListener(this);
		}


		private void initPickerVar(int _colorId)
		{
			colorId = _colorId;

			// 判断是选择哪个颜色
			switch (colorId)
			{
			case COLORID_CANVAS:
				color = colorCanvas;
				break;
			case COLORID_GRID:
				color = colorGrid;
				break;
			case COLORID_COORD:
				color = colorCoord;
				break;
			case COLORID_COORDNUM:
				color = colorCoordNum;
				break;
			case COLORID_FUNC:
				color = colorFunc;
				break;
			case COLORID_POINTER:
				color = colorPointer;
				break;
			}

			colorR = Color.red(color);
			colorG = Color.green(color);
			colorB = Color.blue(color);
		}


		/**************
		 * setColorById
		 * - 设置元素颜色
		 * Notes:
		 * - 命名成setColorById是为了防止与MainActivity中的setColor混淆。
		 */
		private void setColorById()
		{
			switch (colorId)
			{
			case COLORID_CANVAS:
				colorCanvas = color;
				fpv_funcPad.setCanvasColor(colorCanvas);
				btn_colorCanvas.setBackgroundColor(colorCanvas);
				break;
			case COLORID_GRID:
				colorGrid = color;
				fpv_funcPad.setGridColor(colorGrid);
				btn_colorGrid.setBackgroundColor(colorGrid);
				break;
			case COLORID_COORD:
				colorCoord = color;
				fpv_funcPad.setCoordColor(colorCoord);
				btn_colorCoord.setBackgroundColor(colorCoord);
				break;
			case COLORID_COORDNUM:
				colorCoordNum = color;
				fpv_funcPad.setCoordNumColor(colorCoordNum);
				btn_colorCoordNum.setBackgroundColor(colorCoordNum);
				break;
			case COLORID_FUNC:
				colorFunc = color;
				fpv_funcPad.setFuncColor(colorFunc);
				btn_colorFunc.setBackgroundColor(colorFunc);
				break;
			case COLORID_POINTER:
				colorPointer = color;
				fpv_funcPad.setPointerColor(colorPointer);
				btn_colorPointer.setBackgroundColor(colorPointer);
				break;
			}
		}


		@Override
		public void onProgressChanged(SeekBar seekBar, int progress,
				boolean fromUser)
		{
			switch (seekBar.getId())
			{
			case R.id.sb_colorR:
				colorR = sb_colorR.getProgress();
				et_colorR.setText("" + colorR);
				break;
			case R.id.sb_colorG:
				colorG = sb_colorG.getProgress();
				et_colorG.setText("" + colorG);
				break;
			case R.id.sb_colorB:
				colorB = sb_colorB.getProgress();
				et_colorB.setText("" + colorB);
				break;
			}

			color = Color.argb(0xff, colorR, colorG, colorB);
			tv_colorPicker.setBackgroundColor(color);
		}


		@Override
		public void onStartTrackingTouch(SeekBar seekBar)
		{
			// TODO Auto-generated method stub

		}


		@Override
		public void onStopTrackingTouch(SeekBar seekBar)
		{
			// TODO Auto-generated method stub

		}


		@Override
		public void onClick(View v)
		{
			switch (v.getId())
			{
			case R.id.btn_colorMinusR:
				if (colorR > 0)
				{
					colorR--;
				}

				sb_colorR.setProgress(colorR);
				break;
			case R.id.btn_colorAddR:
				if (colorR < 0xff)
				{
					colorR++;
				}

				sb_colorR.setProgress(colorR);
				break;
			case R.id.btn_colorMinusG:
				if (colorG > 0)
				{
					colorG--;
				}

				sb_colorG.setProgress(colorG);
				break;
			case R.id.btn_colorAddG:
				if (colorG < 0xff)
				{
					colorG++;
				}

				sb_colorG.setProgress(colorG);
				break;
			case R.id.btn_colorMinusB:
				if (colorB > 0)
				{
					colorB--;
				}

				sb_colorB.setProgress(colorB);
				break;
			case R.id.btn_colorAddB:
				if (colorB < 0xff)
				{
					colorB++;
				}

				sb_colorB.setProgress(colorB);
				break;
			}
		}
	}
}
