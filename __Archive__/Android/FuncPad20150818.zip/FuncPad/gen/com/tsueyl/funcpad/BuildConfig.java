/** Automatically generated file. DO NOT MODIFY */
package com.tsueyl.funcpad;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}