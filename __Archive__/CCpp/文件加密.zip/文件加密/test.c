#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h>
#define NUM_1

void operate(char *inFN, char *outFN, char *password);

int main(int argc, char **argv)
{
	char inFN[100], outFN[100], password[20];
	#ifdef NUM_1
		int maxPrama = 4;
	#elif defined NUM_2
		int maxPrama = 3;
	#endif
	//�������ļ���������ļ���������
	printf("************************************************************\n");
	printf("	�ƣ��塡�ţ������\n");
	printf("	Version:	1.45\n");
	printf("	Author:		Woobhurk.\n");
	printf("	Date:		2012.07\n");
	printf("	All Rights Reserved.\n");
	printf("Look out:\n");
	printf("	This program can also be run in DOS mode.\n");
	printf("	You can input with the following format:\n");
	printf("	[ProgramName] [In_FileName] [Out_FileName] [Password]\n");
	printf("************************************************************\n");
	if(argc != maxPrama)
	{
		printf("Input In_FileName:\n");
		fgets(inFN, 100, stdin);
		inFN[strlen(inFN) - 1] = 0;  //�����Ļ��з�ȥ��
		printf("Input Out_FileName:\n");
		fgets(outFN, 100, stdin);
		outFN[strlen(outFN) - 1] = 0;
		#ifdef NUM_1
			printf("Input password:\n");
			fgets(password, 21, stdin);
			password[strlen(password) - 1] = 0;
		#endif
	}
	else
	{
		strcpy(inFN, argv[1]);
		strcpy(outFN, argv[2]);
		#ifdef NUM_1
			strcpy(password, argv[3]);
		#endif
	}
	operate(inFN, outFN, password);
	printf("OK! Press any key to quit...\n");
    getch();
	return 0;
}

void operate(char *inFN, char *outFN, char *password)
{
	FILE *inFile, *outFile;
	#ifdef NUM_1
		int pswlen = 0, cnt = 0;
	#endif
	int ch;

	inFile = fopen(inFN, "rb");
	if(inFile == NULL)
	{
		printf("'%s': No such file!!\n", inFN);
		getch();
		exit(1);
	}
	outFile = fopen(outFN, "wb");
	if(outFile == NULL)
	{
		printf("Cannot open or create file '%s'!!\n", outFN);
		getch();
		exit(1);
	}
	#ifdef NUM_1
		while(password[pswlen]) pswlen++;
	#endif
	//fwrite(password, pswlen, 1, outFile);
	ch = fgetc(inFile);
	while(!feof(inFile))
	{
		#ifdef NUM_1
			ch ^= password[cnt++ % pswlen]; /*���ܷ���1*/
		#elif defined NUM_2
			ch = ~ch; /*���ܷ���2*/
		#endif
		fputc(ch, outFile);
		ch=fgetc(inFile);
	}
	fclose(inFile);
	fclose(outFile);
}
