#include <stdio.h>
#include <ctype.h>
#include <string.h>

/*************************
�����������֧��
*************************/
//��ȡ�û���ֵ
int getuk(void)
{
	int key = 0;
	key = getch();
	key = tolower(key);
	return key;
}

/*************************
�ļ���������֧��
*************************/
//��ȡ�ļ�����
int lof(FILE *fp)
{
	if(fp == NULL)
	{
		printf("Error!!\n");
		return -1;
	}
	else
	{
		int flong;
		fseek(fp, 0, 2);
		flong = ftell(fp);
		return flong;
	}
}

/**************************
����ת��֧��
**************************/
//16->10
int hex2dec(char *hexStr)
{
	int slong;
	int cnt, tmp = 0;
	slong = strlen(hexStr);
	for(cnt = 0; cnt < slong; cnt++)
	{
		hexStr[cnt] = toupper(hexStr[cnt]);
		if(hexStr[cnt] >= 'A' && hexStr[cnt] <= 'F') tmp = tmp * 16 + hexStr[cnt] - 55;
		else tmp = tmp * 16 + hexStr[cnt] - 48;
	}
	return tmp;
}


//10->16
char *dec2hex(char *hexStr, int decval, int hexlen)
{
	int cnt;
	hexStr[hexlen] = 0;
	for(cnt = hexlen - 1; cnt >= 0; cnt--)
	{
		int tmp;
		tmp = decval % 16;
		if(tmp >= 10 && tmp <= 15)
			hexStr[cnt] = tmp + 55;
		else
			hexStr[cnt] = tmp + 48;
		decval /= 16;
	}
	return hexStr;
}

//10->10�����ӿո�
char *dec2dec(char *decStr, int decval, int declen)
{
	int cnt;
	decStr[declen] = 0;
	for(cnt = declen - 1; cnt >= 0; cnt--)
	{
		decStr[cnt] = decval % 10 + '0';
		decval /= 10;
	}
	return decStr;
}
