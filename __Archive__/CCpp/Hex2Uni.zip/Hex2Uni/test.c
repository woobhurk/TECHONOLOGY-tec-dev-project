/*
=======================================
Hex2Uni
�����У�Hex2Uni �ַ��� �ߵ�λģʽ

ע���ַ��������ϸ��ա�\uxxxx��ģʽ����
ϵͳĬ�ϸߵ�λģʽΪLOW_HIGH
=======================================
*/
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h>
#include <locale.h>
#define LOW_HIGH 1
#define HIGH_LOW 2

void Hex2Uni_1(void);
void Hex2Uni_2(char *);
void Hex2Uni(int);
int Hex2Dec(char *);
void AddZero(char *, int);
void ExchangeBit(char *);

char SrcStr[4096];
char DestStr[4096];
FILE *DataFile;

int main(int argc, char *argv[])
{
	setlocale(LC_CTYPE, "chs");
	if (argc != 3)
	{
		Hex2Uni_1();
	}
	else
	{
		strcpy(SrcStr, argv[1]);
		Hex2Uni_2(argv[2]);
	}
	DataFile = fopen("Unicode.txt", "w");
	fprintf(DataFile, "%s\nԴ�ַ�����%s\n", DestStr, SrcStr);
	fclose(DataFile);
	//getch();
	return 0;
}



void Hex2Uni_1(void)
{
	int BitType;
	
	printf("��ת�����ַ�����\n");
	gets(SrcStr);
	printf("�ߵ�λģʽ����1��λ��ǰ ������λ��ǰ��\n");
	if (getch() == '1')
		BitType = LOW_HIGH;
	else
		BitType = HIGH_LOW;
	Hex2Uni(BitType);
}



void Hex2Uni_2(char *BitType)
{
	int _BitType;
	
	if (!strcmp(BitType, "1"))
		_BitType = LOW_HIGH;
	else
		_BitType = HIGH_LOW;
	Hex2Uni(_BitType);
}



void Hex2Uni(int BitType)
{
	wchar_t WideChar[4096];
	char BitStr[20];
	int CharPos, WideCharPos;
	
	_strlwr(SrcStr);
	for (CharPos = 0, WideCharPos = 0; CharPos < strlen(SrcStr); )
	{
		if (SrcStr[CharPos] == '\\' && SrcStr[CharPos + 1] == 'u')  //Unicode�ַ�
		{
			strncpy(BitStr, SrcStr + CharPos + 2, 4);
			if (BitType == HIGH_LOW) ExchangeBit(BitStr);
			CharPos += 6;  //��\uxxxx��
		}
		else  //Ӣ���ַ�
		{
			BitStr[0] = SrcStr[CharPos];
			BitStr[1] = '\0';
			sprintf(BitStr, "%x", BitStr[0]);
			AddZero(BitStr, 4);
			if (BitType == HIGH_LOW) ExchangeBit(BitStr);
			++CharPos;
		}
		WideChar[WideCharPos++] = Hex2Dec(BitStr);
	}
	sprintf(DestStr, "%S", WideChar);
}



int Hex2Dec(char *HexStr)
{
	char *_HexStr;
	int CharPos;
	int DecVal = 0;
	
	_HexStr = (char *)malloc(strlen(HexStr) + 1);
	strcpy(_HexStr, HexStr);
	_strlwr(_HexStr);
	for (CharPos = 0; CharPos < strlen(_HexStr); CharPos++)
	{
		if (_HexStr[CharPos] >= '0' && _HexStr[CharPos] <= '9')
			DecVal = DecVal * 16 + _HexStr[CharPos] - '0';
		else if (_HexStr[CharPos] >= 'a' && _HexStr[CharPos] <= 'f')
			DecVal = DecVal * 16 + _HexStr[CharPos] - 'a' + 10;
	}
	free(_HexStr);
	return DecVal;
}



//��߲���0
void AddZero(char *SrcStr, int StrLen)
{
	int CharPos;
	char TmpStr[20];
	
	for (CharPos = 0; CharPos < StrLen - strlen(SrcStr); CharPos++)
		TmpStr[CharPos] = '0';
	TmpStr[CharPos] = '\0';
	strcat(TmpStr, SrcStr);
	strcpy(SrcStr, TmpStr);
}



//�����ߵ�λ
void ExchangeBit(char *SrcStr)
{
	int CharPos;
	char TmpChar;
	
	for (CharPos = 0; CharPos < strlen(SrcStr); CharPos += 4)
	{
		TmpChar = SrcStr[CharPos + 2];
		SrcStr[CharPos + 2] = SrcStr[CharPos];
		SrcStr[CharPos] = TmpChar;
		TmpChar = SrcStr[CharPos + 3];
		SrcStr[CharPos + 3] = SrcStr[CharPos + 1];
		SrcStr[CharPos + 1] = TmpChar;
	}
}
