#include <stdio.h>

main()
{
	int ukey=0;
	while(ukey!=0x11b)
	{
		ukey=bioskey(0);
		printf("%x\t",ukey);
	}
	getch();
}
