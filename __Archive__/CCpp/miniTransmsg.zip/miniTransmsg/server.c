#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <conio.h>
#include <errno.h>
#include <winsock2.h>

#define WSA_VERSION 0x0101
#define SOCK_PORT 6666
#define MAX_LINE 5
#define MSG_MAX_SIZE 1024
#define NAME_MAX_SIZE 255
#define NULL_HOSTNAME "NULL"
//#define __ESP_IPADDR

//������ʾ�д����з�������ʹ��
#define __PRIERR puts("  There has been an ERROR in the program."); \
puts("  If you want to continue, press any key."); \
getch()
//�����˳����޷������޷���������ʹ��
#define __MEXIT puts("  You NOW have to QUIT or RESTART."); \
getch(); \
//exit(1)

#ifdef __ESP_IPADDR
	#define CLIENT_IPADDR "192.168.41.1"
	#define GET_CLIENT_IPADDR inet_addr(CLIENT_IPADDR)
#else
	#define GET_CLIENT_IPADDR htonl(INADDR_ANY)
#endif

void getClientIP(char *, char *);
void getClientHost(char *, char *);

int main(void)
{
	WSADATA wData;
	SOCKET sockSrv, sockConn;
	SOCKADDR_IN addrSrv, addrClient;
	int errCode;
	int sin_size;
	char recvMsg[MSG_MAX_SIZE], sendMsg[MSG_MAX_SIZE];
	char hostName[NAME_MAX_SIZE];
	
	//��ʼ��Windows Scoket 1.1
	errCode = WSAStartup(WSA_VERSION, &wData);
	//����
	if (errCode != 0)
	{
		printf("'WSAStartup' ERROR at %d: %d", __LINE__, WSAGetLastError());
		__MEXIT;
	}
	if (HIBYTE(wData.wVersion) != 1 || LOBYTE(wData.wVersion) != 1)
	{
		printf("'wVersion' ERROR at %d.\n", __LINE__);
		WSACleanup();
		__MEXIT;
	}
	
	//�����µ�Scoket��������Ӧ�ͻ�������
	sockSrv = socket(AF_INET, SOCK_STREAM, 0);
	if (sockSrv < 0)
	{
		printf("'socket' ERROR at %d: %d\n", __LINE__, WSAGetLastError()/*errno, strerror(errno)*/);
		__MEXIT;
	}
	
	//��д��������ַ��Ϣ
	addrSrv.sin_family = AF_INET;
	//�˿�Ϊ6000
	addrSrv.sin_port = htons(SOCK_PORT);
	//IP��ַΪINADDR_ANY�����⣩��ע��ʹ��htonl��IP��ַת��Ϊ�����ʽ
	addrSrv.sin_addr.s_addr = GET_CLIENT_IPADDR;
	//addrSrv.sin_addr.s_addr = htonl(INADDR_ANY);  //����addrSrv.sin_addr.S_un.S_addr = ...
	
	//�󶨼����˿�
	if (bind(sockSrv, (SOCKADDR *)&addrSrv, sizeof(SOCKADDR)) < 0)
	{
		printf("'bind' ERROR at %d: %d\n", __LINE__, WSAGetLastError()/*errno, strerror(errno)*/);
		__MEXIT;
	}
	
	//��ʼ������ָ�����ͬʱ������ΪMAX_LINE
	if (listen(sockSrv, MAX_LINE) < 0)
	{
		printf("'listen' ERROR at %d: %d\n", __LINE__, WSAGetLastError()/*errno, strerror(errno)*/);
		__MEXIT;
	}
	puts("Initialization finished.");
	puts("Waiting for client's connection...");
	puts("If client has connected with this server, screen will be cleaned.");
	
	//������������ֱ���ͻ�����������
	sin_size = sizeof(SOCKADDR);
	sockConn = accept(sockSrv, (SOCKADDR *)&addrClient, &sin_size);
	if (sockConn < 0)
	{
		printf("'accept' ERROR at %d: %d\n", __LINE__, WSAGetLastError()/*errno, strerror(errno)*/);
		__MEXIT;
	}
	
	//�洢�ͻ��˵�ַ��inet_ntoa(addrClient.sin_addr)
	puts("Getting client hostname...");
	getClientHost(hostName, inet_ntoa(addrClient.sin_addr));
	
	//��ʼ��ʼ�� & �������Ӻ�ͨ��
	system("cls");
	system("color 06");
	puts("Connected with ***************************************");
	printf("(%s) %s\n", inet_ntoa(addrClient.sin_addr), hostName);
	puts("******************************************************\n");
	while (1)
	{
		//������Ϣ
		system("title TransMsg Server - Recieving");
		if (recv(sockConn, recvMsg, MSG_MAX_SIZE, 0) < 0)
		{
			printf("'recv' ERROR at %d: %d\n", __LINE__, WSAGetLastError()/*errno, strerror(errno)*/);
			__MEXIT;
		}
		printf("\a%s\n", recvMsg);
		
		//��ȡ����
		system("title TransMsg Server - Sending");
label_reinput:
		memset(sendMsg, 0, MSG_MAX_SIZE);
		fgets(sendMsg, MSG_MAX_SIZE, stdin);
		if (strlen(sendMsg) == 1) goto label_reinput;
		sendMsg[strlen(sendMsg) - 1] = '\0';
		snprintf(sendMsg, MSG_MAX_SIZE, "  <SERVER> %s", sendMsg);
		
		//������Ϣ
		if (send(sockConn, sendMsg, strlen(sendMsg) + 1, 0) < 0)
		{
			printf("'send' ERROR at %d: %d\n", __LINE__, WSAGetLastError()/*errno, strerror(errno)*/);
			__MEXIT;
		}
	}
	//ͨѶ�������ر�
	closesocket(sockConn);
	//�ر�����
	closesocket(sockSrv);
	//�ͷ���Դ
	WSACleanup();
	return 0;
}



void getClientIP(char *IPAddr, char *farIPAddr)
{
	if (IPAddr == NULL || farIPAddr == NULL)
	{
		printf("ERROR at %d: IPAddr == NULL || farIPAddr == NULL\n", __LINE__);
		printf("IPAddr = %s\n", NULL_HOSTNAME);
		__PRIERR;
	}
	strcpy(IPAddr, farIPAddr);
}



void getClientHost(char *hostName, char *IPAddr)
{
	HOSTENT *hostEntry;
	
	if (hostName == NULL || IPAddr == NULL)
	{
		printf("ERROR at %d: hostName == NULL || IPAddr == NULL\n", __LINE__);
		__MEXIT;
	}
	
	//���·����ڴ�
	hostEntry = (HOSTENT *)malloc(sizeof(HOSTENT));
	//printf("hostEntry == %p\n", hostEntry);
	if (hostEntry == NULL)
	{
		printf("ERROR at %d: hostEntry == NULL\n", __LINE__);
		//__MEXIT;
		strcpy(hostName, NULL_HOSTNAME);
		__PRIERR;
		return;
	}
	
	//��ʼ��ʼ��
	hostEntry = gethostbyaddr(IPAddr, sizeof(IPAddr), AF_INET);
	if (hostEntry == NULL)
	{
		printf("ERROR at %d: hostEntry == NULL\n", __LINE__);
		printf("'gethostbyaddr' ERROR at %d: %d\n", __LINE__, WSAGetLastError());
		//__MEXIT;
		strcpy(hostName, NULL_HOSTNAME);
		__PRIERR;
		return;
	}
	
	//printf("hostEntry -> h_name == %p\n", hostEntry -> h_name);
	if (hostEntry -> h_name == NULL)
	{
		printf("ERROR at %d: hostEntry -> h_name == NULL\n", __LINE__);
		//__MEXIT;
		strcpy(hostName, NULL_HOSTNAME);
		__PRIERR;
		return;
	}
	//puts(hostEntry -> h_name);
	memset(hostName, 0, NAME_MAX_SIZE);
	//puts("memset OK.");
	strcpy(hostName, hostEntry -> h_name);
	//puts("strcpy OK.");
	//Ŀǰ����free�����������ʹ��gdb����
	//free(hostEntry);
	//puts("free OK.");
}
