#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <conio.h>
#include <errno.h>
#include <winsock2.h>

#define WSA_VERSION 0x0101
#define SOCK_PORT 6666
#define LOCAL_IPADDR "127.0.0.1"  //Localhost
#define MSG_MAX_SIZE 1024
#define NAME_MAX_SIZE 255
#define NULL_HOSTNAME "NULL"

//������ʾ�д����з�������ʹ��
#define __PRIERR puts("  There has been an ERROR in the program."); \
puts("  If you want to continue, press any key."); \
getch()
//�����˳����޷������޷���������ʹ��
#define __MEXIT puts("  You NOW have to QUIT or RESTART."); \
getch(); \
//exit(1)

void getLocalIP(char *);
void getLocalHost(char *, char *);

int main(void)
{
	WSADATA wData;
	SOCKADDR_IN addrClient;
	SOCKET sockClient;
	int errCode;
	char recvMsg[MSG_MAX_SIZE], sendMsg[MSG_MAX_SIZE];
	char IPAddr[NAME_MAX_SIZE], hostName[NAME_MAX_SIZE];
	
	//��ʼ��Windows Socket 1.1
	errCode = WSAStartup(WSA_VERSION, &wData);
	//����
	if (errCode != 0)
	{
		printf("'WSAStartup' ERROR at %d: %d\n", __LINE__, WSAGetLastError());
		__MEXIT;
	}
	if (LOBYTE(wData.wVersion) != 1 || HIBYTE(wData.wVersion) != 1)
	{
		printf("'wVersion' ERROR at %d.\n", __LINE__);
		WSACleanup();
		__MEXIT;
	}
	
	//�����µ�Socket�����ӷ�����
	sockClient = socket(AF_INET, SOCK_STREAM, 0);
	if (sockClient < 0)
	{
		printf("'socket' ERROR at %d: %d\n", __LINE__, WSAGetLastError()/*errno, strerror(errno)*/);
		__MEXIT;
	}
	
	//��ȡ����IP��ַ��������
	puts("Getting IP Address & local hostname...");
	getLocalIP(IPAddr);
	getLocalHost(hostName, IPAddr);
	
	//��д�ͻ��˵�ַ��Ϣ
	addrClient.sin_family = AF_INET;
	//�˿ں�Ϊ6000
	addrClient.sin_port = htons(SOCK_PORT);
	//������IP��ַΪ����IP��ע����inet_addr��IP��ַת��Ϊ�����ʽ
	addrClient.sin_addr.s_addr = inet_addr(IPAddr/*SOCK_ADDR*/);  //����addrClient.sin_addr.S_un.S_addr = ...
	//�������������������
	if (connect(sockClient, (SOCKADDR *)&addrClient, sizeof(SOCKADDR)) < 0)
	{
		printf("'connect' ERROR at %d: %d\n", __LINE__, WSAGetLastError()/*errno, strerror(errno)*/);
		__MEXIT;
	}
	puts("Found SERVER. Connected finished.");
	
	//��ʼ��ʼ�� & ͨ��
	system("cls");
	system("color 06");
	puts("Local IP & Name **************************************");
	printf("(%s) %s\n", IPAddr, hostName);
	puts("******************************************************\n");
	while (1)
	{
		//��ȡ����
		system("title TransMsg Client - Sending");
		memset(sendMsg, 0, MSG_MAX_SIZE);
		fgets(sendMsg, MSG_MAX_SIZE, stdin);
		if (strlen(sendMsg) == 1) continue;
		sendMsg[strlen(sendMsg) - 1] = '\0';
		snprintf(sendMsg, MSG_MAX_SIZE, "  <CLIENT> %s", sendMsg);
		
		//������Ϣ
		if (send(sockClient, sendMsg, strlen(sendMsg) + 1, 0) < 0)
		{
			printf("'send' ERROR at %d: %d\n", __LINE__, WSAGetLastError()/*errno, strerror(errno)*/);
			__MEXIT;
		}
		
		//������Ϣ
		system("title TransMsg Client - Recieving");
		if (recv(sockClient, recvMsg, MSG_MAX_SIZE, 0) < 0)
		{
			printf("'recv' ERROR at %d: %d\n", __LINE__, WSAGetLastError()/*errno, strerror(errno)*/);
			__MEXIT;
		}
		printf("\a%s\n", recvMsg);
	}
	//�رռ���Scoket
	closesocket(sockClient);
	//�ͷ�Windows Scoket DLL�������Դ
	WSACleanup();
	return 0;
}



void getLocalIP(char *IPAddr)
{
	char hostName[NAME_MAX_SIZE];
	HOSTENT *hostEntry;
	
	if (hostName == NULL)
	{
		printf("ERROR at %d: hostName == NULL\n", __LINE__);
		__MEXIT;
	}
	gethostname(hostName, NAME_MAX_SIZE);
	
	hostEntry = gethostbyname(hostName);
	if (hostEntry == NULL)
	{
		printf("ERROR at %d: hostEntry == NULL\n", __LINE__);
		printf("IPAddr = %s\n", LOCAL_IPADDR);
		strcpy(IPAddr, LOCAL_IPADDR);
		__PRIERR;
		return;
	}
	
	if (IPAddr == NULL)
	{
		printf("ERROR at %d: IPAddr == NULL\n", __LINE__);
		__MEXIT;
	}
	//ʹ��sprintf�з���
	snprintf(IPAddr, NAME_MAX_SIZE, "%d.%d.%d.%d",
		(hostEntry -> h_addr_list[0][0] & 0x00ff),
		(hostEntry -> h_addr_list[0][1] & 0x00ff),
		(hostEntry -> h_addr_list[0][2] & 0x00ff),
		(hostEntry -> h_addr_list[0][3] & 0x00ff));
}



void getLocalHost(char *hostName, char *IPAddr)
{
	HOSTENT *hostEntry;
	
	if (hostName == NULL || IPAddr == NULL)
	{
		printf("ERROR at %d: hostName == NULL || IPAddr == NULL\n", __LINE__);
		__MEXIT;
	}
	
	//���·����ڴ�
	hostEntry = (HOSTENT *)malloc(sizeof(HOSTENT));
	//printf("hostEntry == %p\n", hostEntry);
	if (hostEntry == NULL)
	{
		printf("ERROR at %d: hostEntry == NULL\n", __LINE__);
		//__MEXIT;
		strcpy(hostName, NULL_HOSTNAME);
		__PRIERR;
		return;
	}
	
	//��ʼ��ʼ��
	hostEntry = gethostbyaddr(IPAddr, sizeof(IPAddr), AF_INET);
	if (hostEntry == NULL)
	{
		printf("ERROR at %d: hostEntry == NULL\n", __LINE__);
		printf("'gethostbyaddr' ERROR at %d: %d\n", __LINE__, WSAGetLastError());
		//__MEXIT;
		strcpy(hostName, NULL_HOSTNAME);
		__PRIERR;
		return;
	}
	
	//printf("hostEntry -> h_name == %p\n", hostEntry -> h_name);
	if (hostEntry -> h_name == NULL)
	{
		printf("ERROR at %d: hostEntry == NULL\n", __LINE__);
		//__MEXIT;
		strcpy(hostName, NULL_HOSTNAME);
		__PRIERR;
		return;
	}
	//puts(hostEntry -> h_name);
	memset(hostName, 0, NAME_MAX_SIZE);
	//puts("memset OK.");
	strcpy(hostName, hostEntry -> h_name);
	//puts("strcpy OK.");
	//Ŀǰ������free�����������ʹ��gdb����
	//free(hostEntry);
	//puts("free OK.");
	//gethostname(hostName, NAME_MAX_SIZE);
}
