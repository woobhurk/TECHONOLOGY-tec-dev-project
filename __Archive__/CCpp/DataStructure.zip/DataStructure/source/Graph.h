/*
 * Project: DataStructure
 * File: Graph.h
 * Date: 2017-10-10
 * Author: fanch
 */
#ifndef GRAPH_H_
#define GRAPH_H_

class Graph {
public:
    Graph();
    virtual ~Graph();
};

#endif /* GRAPH_H_ */
