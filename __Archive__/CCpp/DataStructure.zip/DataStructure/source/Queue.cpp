/*
 * Project: DataStructure
 * File: Queue.cpp
 * Date: 2017-10-10
 * Author: fanch
 */
#include "Queue.h"

Queue::Queue() {
    // TODO Auto-generated constructor stub

}

Queue::~Queue() {
    // TODO Auto-generated destructor stub
}

