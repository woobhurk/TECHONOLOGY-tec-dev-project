/*
 * Project: DataStructure
 * File: LinkedListNode.cpp
 * Date: 2017-11-21
 * Author: fanch
 */
#include <iostream>
#include "LinkedListNode.h"

template<typename T>
LinkedListNode<T>::LinkedListNode() {
    this->next = NULL;
}

template<typename T>
LinkedListNode<T>::~LinkedListNode() {
}

template<typename T>
void LinkedListNode<T>::setData(T data) {
    this->data = data;
}

template<typename T>
T LinkedListNode<T>::getData() {
    return this->data;
}

template<typename T>
void LinkedListNode<T>::setNext(LinkedListNode<T>* next) {
    this->next = next;
}

template<typename T>
LinkedListNode<T>* LinkedListNode<T>::getNext() {
    return this->next;
}
