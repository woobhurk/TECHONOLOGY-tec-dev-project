/*
 * Project: DataStructure
 * File: Stack.cpp
 * Date: 2017-10-10
 * Author: fanch
 */
#include "Stack.h"

Stack::Stack() {
    // TODO Auto-generated constructor stub

}

Stack::~Stack() {
    // TODO Auto-generated destructor stub
}

