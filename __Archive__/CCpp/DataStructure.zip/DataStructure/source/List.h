/*
 * Project: DataStructure
 * File: List.h
 * Date: 2017-10-10
 * Author: fanch
 */
#ifndef LIST_H_
#define LIST_H_

class List {
public:
    List();
    virtual ~List();
};

#endif /* LIST_H_ */
