/*
 * Project: DataStructure
 * File: LinkedList.h
 * Date: 2017-10-10
 * Author: fanch
 */
#include "LinkedListNode.h"

#ifndef LINKEDLIST_H_
#define LINKEDLIST_H_

template<typename T>
class LinkedList {
public:
    LinkedList();
    virtual ~LinkedList();
    bool insert(LinkedListNode<T>* node);
    bool insertAt(int index, LinkedListNode<T>* node);
    bool deleteAt(int index);
    int getIndex(LinkedListNode<T>* node);
    LinkedListNode<T>* getNodeByIndex(int index);
    int size();
    bool empty();

private:
    LinkedListNode<T>* head;
    LinkedListNode<T>* tail;
};

#endif /* LINKEDLIST_H_ */
