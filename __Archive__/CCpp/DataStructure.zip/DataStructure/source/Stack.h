/*
 * Project: DataStructure
 * File: Stack.h
 * Date: 2017-10-10
 * Author: fanch
 */
#ifndef STACK_H_
#define STACK_H_

class Stack {
public:
    Stack();
    virtual ~Stack();
};

#endif /* STACK_H_ */
