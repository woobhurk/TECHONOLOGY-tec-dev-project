/*
 * Project: DataStructure
 * File: LinkedListNode.h
 * Date: 2017-11-21
 * Author: fanch
 */
#ifndef LINKEDLISTNODE_H_
#define LINKEDLISTNODE_H_

template<typename T>
class LinkedListNode {
public:
    LinkedListNode();
    virtual ~LinkedListNode();
    void setData(T data);
    T getData();
    void setNext(LinkedListNode<T>* next);
    LinkedListNode<T>* getNext();

private:
    T data;
    LinkedListNode<T>* next;
};

#endif /* LINKEDLISTNODE_H_ */
