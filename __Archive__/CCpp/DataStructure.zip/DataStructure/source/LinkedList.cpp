/*
 * Project: DataStructure
 * File: LinkedList.cpp
 * Date: 2017-10-10
 * Author: fanch
 */
#include <iostream>
#include "LinkedList.h"
#include "LinkedListNode.h"

template<typename T>
LinkedList<T>::LinkedList() {
    head = new LinkedListNode<T>();
    tail = head;
}

template<typename T>
LinkedList<T>::~LinkedList() {
}

template<typename T>
bool LinkedList<T>::insert(LinkedListNode<T>* node) {
    bool success;

    if (node == NULL) {
        success = false;
    } else {
        success = true;
    }

    return success;
}

template<typename T>
bool LinkedList<T>::insertAt(int index, LinkedListNode<T>* node) {
    bool success;

    if (index < 0 || index > (this->size() - 1) || node == NULL) {
        success = false;
    } else {
        success = true;
    }

    return success;
}

template<typename T>
bool LinkedList<T>::deleteAt(int index) {
    bool success;

    if (index < 0 || index > (this->size() - 1)) {
        success = false;
    } else {
        success = true;
    }

    return success;
}

template<typename T>
int LinkedList<T>::getIndex(LinkedListNode<T>* node) {
}

template<typename T>
LinkedListNode<T>* LinkedList<T>::getNodeByIndex(int index) {
}

template<typename T>
inline int LinkedList<T>::size() {
}

template<typename T>
bool LinkedList<T>::empty() {
}
