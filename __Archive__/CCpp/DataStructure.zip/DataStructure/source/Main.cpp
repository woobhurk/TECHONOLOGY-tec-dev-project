/*
 * Project: DataStructure
 * File: Main.cpp
 * Date: 2017-10-10
 * Author: fanch
 */
#include <iostream>

int main() {
    return 0;
}
