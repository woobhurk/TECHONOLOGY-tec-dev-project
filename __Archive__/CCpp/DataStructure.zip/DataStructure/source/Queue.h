/*
 * Project: DataStructure
 * File: Queue.h
 * Date: 2017-10-10
 * Author: fanch
 */
#ifndef QUEUE_H_
#define QUEUE_H_

class Queue {
public:
    Queue();
    virtual ~Queue();
};

#endif /* QUEUE_H_ */
