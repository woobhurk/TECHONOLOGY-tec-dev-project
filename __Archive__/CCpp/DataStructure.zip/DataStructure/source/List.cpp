/*
 * Project: DataStructure
 * File: List.cpp
 * Date: 2017-10-10
 * Author: fanch
 */
#include "List.h"

List::List() {
    // TODO Auto-generated constructor stub

}

List::~List() {
    // TODO Auto-generated destructor stub
}

