#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <windows.h>
#include <winsock.h>
#define ICO_MAIN 0
#define EDIT_FN 10
#define EDIT_SI 20
#define EDIT_EN 30
#define EDIT_SF 40
#define BUTTON_ABOUT 50
#define BUTTON_EXIT 60
#define BUTTON_OK 70
//������
#define ERR_NONAME 1  //���ļ���
#define ERR_NOFILE 2  //�ļ�������
#define ERR_OVERFLOW 3  //���
#define ERR_SPACE 4  //�пո�


LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
int CheckErr(void);
void ShowMsg(HDC, int, int);
void export(void);
void GetWidth(void);
void PutLeader(void);
void setdat(void);
void ShowAbout(void);


HWND fnEdit, siEdit, enEdit, sfEdit;
HWND btnOK, btnAbout, btnExit;
FILE *libFile, *bmpFile;
char libFN[100], SaveFolder[100];
int MaxID, StartID, EndID, ExpNum, NowID;
int libFP, bmpFP, width, height, bmpWidth;
int dat0, dat1, dat2, dat3;


int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nShowCmd)
{
	char *cName = TEXT("Window1");
	char *cCaption = TEXT("LibExport V1.0 - L.W.");
	HWND hWnd;
	MSG msg;
	WNDCLASSEX wc;
	
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 0;
	wc.cbSize = sizeof(WNDCLASSEX);
	wc.style = CS_HREDRAW | CS_VREDRAW;
	wc.hbrBackground = CreateSolidBrush(0x00ff8000);
	wc.hIcon = LoadIcon(hInstance, MAKEINTRESOURCE(ICO_MAIN));
	wc.hIconSm = LoadIcon(hInstance, MAKEINTRESOURCE(ICO_MAIN));
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);
	wc.hInstance = hInstance;
	wc.lpfnWndProc = WndProc;
	wc.lpszClassName = cName;
	wc.lpszMenuName = NULL;
	RegisterClassEx(&wc);
	hWnd = CreateWindowEx(WS_EX_CLIENTEDGE, cName, cCaption,WS_CAPTION | WS_MINIMIZEBOX | WS_SYSMENU, CW_USEDEFAULT, CW_USEDEFAULT, 400, 190, NULL, NULL, hInstance, NULL);
	if(hWnd == NULL)
	{
		MessageBox(NULL, TEXT("Cannot create the window!\n"), TEXT("Error"), MB_ICONERROR);
		return 0;
	}
	ShowWindow(hWnd, nShowCmd);
	UpdateWindow(hWnd);
	while(GetMessage(&msg, NULL, 0, 0))
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
	return msg.wParam;
}




LRESULT CALLBACK WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	HDC hDC;
	PAINTSTRUCT ps;
	RECT WndRect;
	int WndWidth, WndHeight;
	static HFONT hFont;
	static LOGFONT lf;
	static int ErrID = ERR_NONAME, EditID;  //����ID����ǰ�༭�����

	switch(msg)
	{
	case WM_CREATE:
		fnEdit = CreateWindow(TEXT("edit"), NULL, WS_CHILD | WS_VISIBLE | WS_BORDER | ES_LEFT | ES_AUTOHSCROLL, 95, 5, 150, 20, hWnd, (HMENU)EDIT_FN, ((LPCREATESTRUCT)lParam) -> hInstance, NULL);
		siEdit = CreateWindow(TEXT("edit"), NULL, WS_CHILD | WS_VISIBLE | WS_BORDER | ES_LEFT | ES_AUTOHSCROLL, 95, 30, 150, 20, hWnd, (HMENU)EDIT_SI, ((LPCREATESTRUCT)lParam) -> hInstance, NULL);
		enEdit = CreateWindow(TEXT("edit"), NULL, WS_CHILD | WS_VISIBLE | WS_BORDER | ES_LEFT | ES_AUTOHSCROLL, 95, 55, 150, 20, hWnd, (HMENU)EDIT_EN, ((LPCREATESTRUCT)lParam) -> hInstance, NULL);
		sfEdit = CreateWindow(TEXT("edit"), NULL, WS_CHILD | WS_VISIBLE | WS_BORDER | ES_LEFT | ES_AUTOHSCROLL, 95, 80, 150, 20, hWnd, (HMENU)EDIT_SF, ((LPCREATESTRUCT)lParam) -> hInstance, NULL);
		btnAbout = CreateWindow(TEXT("button"), TEXT("����"), WS_CHILD | WS_VISIBLE | WS_BORDER, 5, 105, 45, 40, hWnd, (HMENU)BUTTON_ABOUT, ((LPCREATESTRUCT)lParam) -> hInstance, NULL);
		btnExit = CreateWindow(TEXT("button"), TEXT("�˳�"), WS_CHILD | WS_VISIBLE | WS_BORDER, 50, 105, 45, 40, hWnd, (HMENU)BUTTON_EXIT, ((LPCREATESTRUCT)lParam) -> hInstance, NULL);
		btnOK = CreateWindow(TEXT("button"), TEXT("��ʼ����"), WS_CHILD | WS_VISIBLE | WS_BORDER, 95, 105, 150, 40, hWnd, (HMENU)BUTTON_OK, ((LPCREATESTRUCT)lParam) -> hInstance, NULL);

		lf.lfHeight = 20;
		lf.lfWeight = FW_BOLD;
		lstrcpy(lf.lfFaceName, "΢���ź�");
		hFont = CreateFontIndirect(&lf);
		return 0;
	case WM_PAINT:
		hDC = BeginPaint(hWnd, &ps);
		SetBkMode(hDC, TRANSPARENT);
		SetTextColor(hDC, 0x00ffffff);
		SelectObject(hDC, hFont);
		TextOut(hDC, 5, 5, TEXT("LIB�ļ�����"), 11);
		TextOut(hDC, 5, 30, TEXT("��ʼID��"), 8);
		TextOut(hDC, 5, 55, TEXT("����������"), 10);
		TextOut(hDC, 5, 80, TEXT("�����ļ��У�"), 12);
		ErrID = CheckErr();  //������
		ShowMsg(hDC, ErrID, EditID);  //��ʾ������Ϣ��
		EndPaint(hWnd, &ps);
		return 0;
	case WM_LBUTTONDOWN:
		SetFocus(hWnd);
		return 0;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{
		case EDIT_FN:  //һ���ı�༭�����ݣ���ȫ���ػ�
			EditID = 0;
			if(HIWORD(wParam) == EN_UPDATE) InvalidateRect(hWnd, NULL, TRUE);
			break;
		case EDIT_SI:
			EditID = 1;
			if(HIWORD(wParam) == EN_UPDATE) InvalidateRect(hWnd, NULL, TRUE);
			break;
		case EDIT_EN:
			EditID = 2;
			if(HIWORD(wParam) == EN_UPDATE) InvalidateRect(hWnd, NULL, TRUE);
			break;
		case EDIT_SF:
			EditID = 3;
			if(HIWORD(wParam) == EN_UPDATE) InvalidateRect(hWnd, NULL, TRUE);
			break;
		case BUTTON_ABOUT:
			ShowAbout();
			break;
		case BUTTON_EXIT:
			SendMessage(hWnd, WM_CLOSE, 0, 0);
			break;
		case BUTTON_OK:
			if(!ErrID) export();
		}
		return 0;
	case WM_CLOSE:
		;
		int cnt;
		GetWindowRect(hWnd, &WndRect);
		WndWidth = WndRect.right - WndRect.left;
		WndHeight = WndRect.bottom - WndRect.top;
		for(; WndHeight > 0; WndHeight--)
		{
			MoveWindow(hWnd, WndRect.left, WndRect.top, WndWidth, WndHeight, TRUE);
			for(cnt = 0; cnt < 1000000; cnt++) ;  //��ʱ�õ�
		}
		//������return 0;
	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;
	}
	return DefWindowProc(hWnd, msg, wParam, lParam);
}



//������
int CheckErr(void)
{
	char cStartID[10], cExpNum[10];

	GetWindowText(fnEdit, libFN, 99);
	if(strlen(libFN) == 0) return ERR_NONAME;
	if((libFile = fopen(libFN, "rb")) == NULL) return ERR_NOFILE;
	fread(&MaxID, 4, 1, libFile);

	GetWindowText(siEdit, cStartID, 9);
	StartID = atoi(cStartID);
	if(StartID < 1 || StartID > MaxID) return ERR_OVERFLOW;
	--StartID;

	GetWindowText(enEdit, cExpNum, 9);
	ExpNum = atoi(cExpNum);
	EndID = StartID + ExpNum;
	if(EndID < StartID || EndID > MaxID) return ERR_OVERFLOW;
	GetWindowText(sfEdit, SaveFolder, 99);
	if(strchr(SaveFolder, ' ') != NULL) return ERR_SPACE;
	return 0;
}



//��ʾ������Ϣ��
void ShowMsg(HDC hDC, int ErrID, int EditID)
{
	char cTmp[40];

	switch(EditID)
	{
	case 0:  //�ļ���
		if(ErrID == ERR_NONAME)
		{
			SetTextColor(hDC, 0x000080ff);
			TextOut(hDC, 250, 5, TEXT("<-�������ļ���"), 14);
		}
		else if(ErrID == ERR_NOFILE)
		{
			SetTextColor(hDC, 0x000080ff);
			TextOut(hDC, 250, 5, TEXT("<-�ļ�������"), 12);
		}
		else
		{
			SetTextColor(hDC, 0x0000c864);
			TextOut(hDC, 250, 5, TEXT("<-�ļ��Ѵ�"), 12);
			sprintf(cTmp, "<-���%d", MaxID);
			TextOut(hDC, 250, 30, cTmp, strlen(cTmp));
		}
		break;
	case 1:  //��ʼID
		if(ErrID == ERR_OVERFLOW)
		{
			SetTextColor(hDC, 0x000080ff);
			TextOut(hDC, 250, 30, TEXT("<-���"), 6);
		}
		else
		{
			SetTextColor(hDC, 0x0000c864);
			sprintf(cTmp, "<-���%d", MaxID);
			TextOut(hDC, 250, 30, cTmp, strlen(cTmp));
			sprintf(cTmp, "<-���%d��", MaxID - StartID);
			TextOut(hDC, 250, 55, cTmp, strlen(cTmp));
		}
		break;
	case 2:  //��������
		if(ErrID == ERR_OVERFLOW)
		{
			SetTextColor(hDC, 0x000080ff);
			TextOut(hDC, 250, 55, TEXT("<-���"), 6);
		}
		else
		{
			SetTextColor(hDC, 0x0000c864);
			sprintf(cTmp, "<-���%d��", MaxID - StartID);
			TextOut(hDC, 250, 55, cTmp, strlen(cTmp));
		}
		break;
	case 3:  //�����ļ���
		if(ErrID == ERR_SPACE)
		{
			SetTextColor(hDC, 0x000080ff);
			TextOut(hDC, 250, 80, TEXT("<-�����пո�"), 12);
		}
		else
		{
			SetTextColor(hDC, 0x0000c864);
			TextOut(hDC, 250, 80, TEXT("<-�Ϸ�������"), 12);
		}
	}
}



//���������ĺ�����
void export(void)
{
	int baseFP;
	int PicX, PicY;
	int clr, clrR, clrG, clrB;
	char bmpFN[200];

	if(*SaveFolder) CreateDirectory(SaveFolder, NULL);  //���б�Ҫ�����½��ļ���
	if(strstr(libFN, ".lib") != NULL) libFN[strlen(libFN) - 4] = '\0';
	for(NowID = StartID; NowID < EndID; NowID++)
	{
		GetWidth();
		baseFP = libFP;
		if(!*SaveFolder) sprintf(bmpFN, "%s_%d.bmp", libFN, NowID + 1);
		else sprintf(bmpFN, "%s\\\\%s_%d.bmp", SaveFolder, libFN, NowID + 1);
		if((bmpFile = fopen(bmpFN, "wb")) == NULL)
		{
			MessageBox(NULL, "����ĳ��ԭ��LibExport���ò���ֹ��\n�������û�г��������������������Ϣ��", "����", MB_OK | MB_ICONEXCLAMATION);
			return;
		}
		PutLeader();
		for(PicY = height - 1; PicY > -1; PicY--)
		{
			for(PicX = 0; PicX < bmpWidth; PicX++)
			{
				if(PicX < width)
				{
					setdat();
					clr = dat1 << 8 | dat0;
					clrR = clr >> 11 << 3;
					clrG = (clr % 2048) >> 5 << 2;
					clrB = (clr % 32) << 3;
					clr = (clrR << 16) | (clrG << 8) | clrB;
				}
				else
					clr = 0xff00ff;
				fseek(bmpFile, bmpFP, SEEK_SET);
				fwrite(&clr, 4, 1, bmpFile);
				bmpFP += 3;
				libFP = baseFP + (PicX + PicY * width) * 2;
			}
		}
		fclose(bmpFile);
	}
	MessageBox(NULL, "��ϲ��\nͼƬ�ѳɹ�������", "��ʾ", MB_OK);
}



//��ȡͼƬ������
void GetWidth(void)
{
	libFP = NowID * 4 + 4;
	fseek(libFile, libFP, SEEK_SET);
	fread(&libFP, 4, 1, libFile);
	libFP += 4;
	setdat();
	width = dat1 << 8 | dat0;
	height = dat3 << 8 | dat2;
	bmpWidth = width - width % 4 + 4;
	if(width % 4 == 0) bmpWidth -= 4;
	libFP += 12;
}



//����ļ�ͷ
void PutLeader(void)
{
	int puts;

	fseek(bmpFile, 0, SEEK_SET);
	putc('B', bmpFile);
	putc('M', bmpFile);
	puts = bmpWidth * height * 3 + 54;
	fwrite(&puts, 4, 1, bmpFile);
	puts = 0;
	fwrite(&puts, 4, 1, bmpFile);
	puts = 54;
	fwrite(&puts, 4, 1, bmpFile);
	puts = 40;
	fwrite(&puts, 4, 1, bmpFile);
	fwrite(&bmpWidth, 4, 1, bmpFile);
	fwrite(&height, 4, 1, bmpFile);
	puts = 1572864;
	fwrite(&puts, 4, 1, bmpFile);
	puts = 0;
	fwrite(&puts, 4, 1, bmpFile);
	puts = bmpWidth * height * 3;
	fwrite(&puts, 4, 1, bmpFile);
	puts = 0;
	fwrite(&puts, 4, 1, bmpFile);
	fwrite(&puts, 4, 1, bmpFile);
	fwrite(&puts, 4, 1, bmpFile);
	fwrite(&puts, 4, 1, bmpFile);
	bmpFP = 54;
}



//��������
void setdat(void)
{
	fseek(libFile, libFP, SEEK_SET);
	dat0 = fgetc(libFile);
	if(dat0 < 0) dat0 += 256;

	dat1 = fgetc(libFile);
	if(dat1 < 0) dat1 += 256;

	dat2 = fgetc(libFile);
	if(dat2 < 0) dat2 += 256;

	dat3 = fgetc(libFile);
	if(dat3 < 0) dat3 += 256;
}



//����
void ShowAbout(void)
{
	char *AboutText;
	
	AboutText = "\
	��лʹ�� LibExport V1.0��\n\
	����������ڲ�����9588ѧϰ���ϵ�\n\
	����BBasic�ĳ�����ֲ�����ġ�����\n\
	��ѧϰ���������ٶȽ���������ʹ��\n\
	���������ɵ���LIB�ļ����ͼƬ��\n\n\
	��������ܵ�������240 * 320��ͼ\n\
	Ƭ�����Ҽ�������ף��ʹ����죡\n\
	\tCopyright(C)2012 by L.Woobhurk.\n\
	\tAll Rights Reserved.\
	";
	MessageBox(NULL, AboutText, "����", MB_OK | MB_ICONINFORMATION);
}
