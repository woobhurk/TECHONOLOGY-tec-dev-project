#include <stdio.h>
#include <string.h>
#include <windows.h>
#include <winsock.h>
#define ICO_MAIN 0
#define TMR_1 10

#define MARGIN 8
#define CUR_RECT (MARGIN * 2 + 1)
#define STRETCH_INDEX 10
#define DEF_WIDTH (CUR_RECT * STRETCH_INDEX + 200)
#define DEF_HEIGHT (CUR_RECT * STRETCH_INDEX + 78)

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
void DrawCursor(HDC);
void ShowInfo(HDC);

COLORREF PixColor;

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nShowCmd)
{
	char *cName = TEXT("Window1");
	char *cCaption = TEXT("Get Window Color - Lation.Woobhurk");
	HWND hWnd;
	MSG msg;
	WNDCLASSEX wc;

	wc.cbClsExtra = 0;
	wc.cbWndExtra = 0;
	wc.cbSize = sizeof (WNDCLASSEX);
	wc.style = CS_HREDRAW | CS_VREDRAW;
	wc.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	wc.hIcon = LoadIcon(hInstance, MAKEINTRESOURCE(ICO_MAIN));
	wc.hIconSm = LoadIcon(hInstance, MAKEINTRESOURCE(ICO_MAIN));
	wc.hCursor = LoadCursor(NULL, MAKEINTRESOURCE(IDC_ARROW));
	wc.hInstance = hInstance;
	wc.lpfnWndProc = WndProc;
	wc.lpszClassName = cName;
	wc.lpszMenuName = NULL;
	RegisterClassEx(&wc);
	hWnd = CreateWindowEx(WS_EX_CLIENTEDGE, cName, cCaption, WS_CAPTION | WS_VISIBLE | WS_SYSMENU, CW_USEDEFAULT, CW_USEDEFAULT, DEF_WIDTH, DEF_HEIGHT, NULL, NULL, hInstance, NULL);
	if(hWnd == NULL)
	{
		MessageBox(NULL, TEXT("Cannot create a window!\n"), TEXT("Error"), MB_ICONERROR);
		return 0;
	}
	ShowWindow(hWnd, nShowCmd);
	UpdateWindow(hWnd);
	while (GetMessage(&msg, NULL, 0, 0))
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
	return msg.wParam;
}




LRESULT CALLBACK WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	HDC WndDC, DeskDC;
	static HFONT hFont;
	static LOGFONT lf;
	static POINT CurPos;
	static int ScrnWidth, ScrnHeight;
	static BOOL isMouseDown = FALSE;

	switch (msg)
	{
	case WM_CREATE:
		SetTimer(hWnd, TMR_1, 10, NULL);
		ScrnWidth = GetSystemMetrics(SM_CXSCREEN);
		ScrnHeight = GetSystemMetrics(SM_CYSCREEN);
		
		lstrcpy(lf.lfFaceName, TEXT("Times New Roman"));
		lf.lfHeight = 15;
		lf.lfWeight = FW_BOLD;
		hFont = CreateFontIndirect(&lf);
		return 0;
	case WM_LBUTTONDOWN:
		SetCapture(hWnd);
		SetCursor(LoadCursor(NULL, MAKEINTRESOURCE(IDC_CROSS)));
		isMouseDown = TRUE;
		return 0;
	case WM_LBUTTONUP:
		ReleaseCapture();
		isMouseDown = FALSE;
		return 0;
	case WM_KEYDOWN:
		switch (wParam)
		{
		case VK_LEFT:
			if (CurPos.x > 0) SetCursorPos(--CurPos.x, CurPos.y);
			break;
		case VK_RIGHT:
			if (CurPos.x < ScrnWidth - 1) SetCursorPos(++CurPos.x, CurPos.y);
			break;
		case VK_UP:
			if (CurPos.y > 0) SetCursorPos(CurPos.x, --CurPos.y);
			break;
		case VK_DOWN:
			if (CurPos.y < ScrnHeight - 1) SetCursorPos(CurPos.x, ++CurPos.y);
			break;
		}
		return 0;
	case WM_TIMER:
		switch (wParam)
		{
		case TMR_1:
			WndDC = GetDC(hWnd);
			DeskDC = GetDC(NULL);
			SelectObject(WndDC, hFont);
			TextOut(WndDC, 0, CUR_RECT * STRETCH_INDEX, TEXT("�Ӵ�������ק��굽���ȡ��ɫ��"), 30);
			TextOut(WndDC, 0, CUR_RECT * STRETCH_INDEX + 15, TEXT("���ϣ������΢�����õ���ɫ���ҷ�"), 32);
			if (!isMouseDown) break;
			GetCursorPos(&CurPos);
			PixColor = GetPixel(DeskDC, CurPos.x, CurPos.y);
			StretchBlt(WndDC, 0, 0, CUR_RECT * STRETCH_INDEX, CUR_RECT * STRETCH_INDEX, DeskDC, CurPos.x - MARGIN, CurPos.y - MARGIN, MARGIN * 2 + 1, MARGIN * 2 + 1, SRCCOPY);
			DrawCursor(WndDC);
			ShowInfo(WndDC);
			//PreCurPos = CurPos;
			break;
		}
		ReleaseDC(hWnd, WndDC);
		ReleaseDC(NULL, DeskDC);
		return 0;
	case WM_DESTROY:
		DeleteObject(hFont);
		KillTimer(hWnd, TMR_1);
		PostQuitMessage(0);
		return 0;
	}
	return DefWindowProc(hWnd, msg, wParam, lParam);
}



//�ڷŴ��ͼ�л���������λ��
//�㷨���临�ӣ���ʵû��Ҫ
void DrawCursor(HDC hDC)
{
	int CntX, CntY;
	HPEN hPen;
	HBRUSH hBrush;
	COLORREF CurrentColor;
	
	hPen = GetStockObject(NULL_PEN);
	SelectObject(hDC, hPen);
	for (CntX = 0; CntX < CUR_RECT; CntX++)
	{
		if (CntX == MARGIN) continue;  //Ϊ�˲��ظ�����
		CurrentColor = GetPixel(hDC, CntX * STRETCH_INDEX, MARGIN * STRETCH_INDEX);
		hBrush = CreateSolidBrush(CurrentColor ^ 0x00A0A0A0);
		SelectObject(hDC, hBrush);
		Rectangle(hDC, CntX * STRETCH_INDEX - 1, MARGIN * STRETCH_INDEX - 1, (CntX + 1) * STRETCH_INDEX + 1, (MARGIN + 1) * STRETCH_INDEX + 1);  //�������
		DeleteObject(hBrush);
	}
	for (CntY = 0; CntY < CUR_RECT; CntY++)
	{
		CurrentColor = GetPixel(hDC, MARGIN * STRETCH_INDEX, CntY * STRETCH_INDEX);
		hBrush = CreateSolidBrush(CurrentColor ^ 0x00A0A0A0);
		SelectObject(hDC, hBrush);
		Rectangle(hDC, MARGIN * STRETCH_INDEX - 1, CntY * STRETCH_INDEX - 1, (MARGIN + 1) * STRETCH_INDEX + 1, (CntY + 1) * STRETCH_INDEX + 1);
		DeleteObject(hBrush);
	}
	DeleteObject(hPen);
}




void ShowInfo(HDC hDC)
{
	RECT ColorRect;
	HBRUSH hBrush;
	char ColorInfo[50];
	
	ColorRect.left = CUR_RECT * STRETCH_INDEX + 4;
	ColorRect.top = 0;
	ColorRect.right = ColorRect.left + CUR_RECT * STRETCH_INDEX;
	ColorRect.bottom = CUR_RECT / 2 * STRETCH_INDEX;
	hBrush = CreateSolidBrush(PixColor);
	FillRect(hDC, &ColorRect, hBrush);
	DeleteObject(hBrush);
	TextOut(hDC, ColorRect.left, ColorRect.bottom + 4, TEXT("Color info:"), 11);
	sprintf(ColorInfo, "RGB(%ld, %ld, %ld)            ", PixColor % 256, (PixColor % 65536) / 256, PixColor / 65536);
	TextOut(hDC, ColorRect.left, ColorRect.bottom + 19, ColorInfo, strlen(ColorInfo));
	sprintf(ColorInfo, "Hexadecimal: 0x00%-20lx", PixColor);
	TextOut(hDC, ColorRect.left, ColorRect.bottom + 34, ColorInfo, strlen(ColorInfo));
	sprintf(ColorInfo, "Decimal: %-20ld", PixColor);
	TextOut(hDC, ColorRect.left, ColorRect.bottom + 49, ColorInfo, strlen(ColorInfo));
}
