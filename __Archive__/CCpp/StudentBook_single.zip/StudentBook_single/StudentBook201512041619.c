/****************************
 * 学生信息簿.c
 * 版本: 0.1.01 (201512041020)
 * 备注:
 *   tcc上gets如果得到的是空字符串
 *   则会保留'\n'，gcc不会，所以判
 *   断字符串是否为空的方法不一样。
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <conio.h>
#include <ctype.h>
#include <malloc.h>

#define LINUX
//#define TCC

#define TRUE 1
#define FALSE 0
#define INPUT_DATA_ADD 0
#define INPUT_DATA_MODIFY 1
#define MEM_SIZE 100
#define INT_SIZE 4
#define DATA_VERSION 1
#define BOOK_EXT ".sbk"

#ifdef TCC
    // 判断字符串是否为空，因为tcc的gets读入的空字符串的结尾
    // 是'\n'，而gcc的是'\0'
    #define EMPTYSTR(str) (str[0] == '\0' || str[0] == '\n')
    // 用于inputData，将空字符串置'\0'，仅tcc需要
    #define INPUT_DATA(str) \
        if (str[0] == '\n') \
        { \
            str[0] = '\0'; \
        }
#else
    #define EMPTYSTR(str) (str[0] == '\0')
    #define INPUT_DATA
#endif

// 用于searchData，输出符合条件的数据
#define SEARCH_DATA(str) \
    if (strstrEx(str, schContent) != NULL) \
    { \
        schCount++; \
        printf("%s: %s\n", data->stuNum, str); \
    }
// 用于modifyData，判断是否保持原始数据
#define MODIFY_DATA(str, newStr) \
    if (!EMPTYSTR(newStr)) \
    { \
        strcpy(str, newStr); \
    }



typedef short BOOL;
typedef struct _STUDATA {
    char stuNum[MEM_SIZE];  // 学号
    char name[MEM_SIZE];  // 姓名
    char stuId[MEM_SIZE];  // 身份证 
    char className[MEM_SIZE];  // 班级
    char institute[MEM_SIZE];  // 学院
    char major[MEM_SIZE]; // 专业
    int years;  // 学制
    char phoneNum[MEM_SIZE];  // 电话
    char qqNum[MEM_SIZE];  // QQ
    char email[MEM_SIZE];  // E-Mail
    char domitory[MEM_SIZE];  // 宿舍
    char origion[MEM_SIZE];  // 籍贯
    struct _STUDATA *next;
} STUDATA;



void initVars();
void showMenu();
void getOperation();
void newBook();
void openBook();
void saveBook();
void saveBookAs();
void closeBook();
void exitProg();
void clearScreen();
void askToSave();
void listData();
void addData();
void insertData(STUDATA *data);
void searchData();
void modifyData();
void deleteData();
void bookProperty();
void inputData(STUDATA *, int);
void printData(const STUDATA *);
long getFileSize(FILE *);
STUDATA *getPrevDataAddr(const char *);
STUDATA *getDataAddr(const char *);
char *strToUpper(char *);
int strcmpEx(const char *, const char *);
int strncmpEx(const char *, const char *, int);
char *strstrEx(const char *, const char *);



char bookName[MEM_SIZE];
//FILE *bookFile;
long bookSize;
STUDATA *dataHeader;
STUDATA *dataTail;
int dataCount;
BOOL fileOpened;
BOOL fileModified;



int main()
{
    initVars();

    while (TRUE)
    {
        showMenu();
        getOperation();
    }

    return 0;
}




void initVars()
{
    dataHeader = NULL;
    dataTail = NULL;
    dataCount = 0;
    fileOpened = FALSE;
    fileModified = FALSE;
}




void showMenu()
{
    puts("##################################################################");
    puts("#                          学 生 信 息 簿                        #");
    puts("# 文件                                                           #");
    puts("#  n. 新建      o. 打开     s. 保存     S. 另存为      c. 关闭   #");
    puts("#  E. 退出                                                       #");
    puts("# 数据                                                           #");
    puts("#  l. 列出      a. 添加     f. 查找     m. 修改        d. 删除   #");
    puts("#  p. 属性      C. 清屏                                          #");
    puts("##################################################################");

    // 显示打开的文件
    if (fileOpened)
    {
        printf("# <%s>%c\n", bookName, fileModified ? '*' : ' ');
    }

    puts("请选择操作: ");
}




void getOperation()
{
    char op;
    BOOL loop;

    do
    {
        loop = FALSE;
        op = getch();

        switch (op)
        {
        case 'n':
            newBook();
            break;
        case 'o':
            openBook();
            break;
        case 's':
            saveBook();
            break;
        case 'S':
            saveBookAs();
            break;
        case 'c':
            closeBook();
            break;
        case 'E':
            exitProg();
            break;
        case 'l':
            listData();
            break;
        case 'a':
            addData();
            break;
        case 'f':
            searchData();
            break;
        case 'm':
            modifyData();
            break;
        case 'd':
            deleteData();
            break;
        case 'p':
            bookProperty();
            break;
        case 'C':
            clearScreen();
            return;
            break;
        default:
            //return;
            loop = TRUE;
            break;
        }
    }
    while (loop);

    puts("任意键返回...");
    getch();
    puts("\n\n");
}




void newBook()
{
    char newName[MEM_SIZE];
    FILE *bookFile;

    puts("[新建信息簿]");
    printf("文件名: (%s)\n", BOOK_EXT);
    //memset(newName, '\0', MEM_SIZE);
    gets(newName);
    // 留出最后五个字符存放后缀名和'\0'
    newName[MEM_SIZE - 5] = '\0';

    // tcc上gets的结束符为'\n'，而gcc为'\0'
    if (EMPTYSTR(newName))
    //if (strlen(newName) == 0)
    {
        puts("文件名为空!");
        return;
    }

    strcat(newName, BOOK_EXT);

    if ((bookFile = fopen(newName, "rb")) != NULL)
    {
        puts("文件已存在，是否删除原文件? (Y/n)");

        char choice;

        do
        {
            choice = tolower(getch());
        }
        while (choice != 'y' && choice != 'n');

        if (choice == 'n')
        {
            puts("未创建信息簿.");
            return;
        }
    }

    if ((bookFile = fopen(newName, "wb")) == NULL)
    {
        printf("无法打开或创建文件: %s\n", bookName);
        printf("请重试.\n");
        return;
    }

    fclose(bookFile);
    strcpy(bookName, newName);
    dataHeader = NULL;
    dataTail = NULL;
    dataCount = 0;
    fileOpened = TRUE;
    // 假设已修改，将提示保存
    fileModified = TRUE;
    puts("信息簿已创建.");
}




void openBook()
{
    char newName[MEM_SIZE];
    FILE *bookFile;
    STUDATA *data;
    int count;

    puts("[打开信息簿]");

    if (fileOpened && fileModified)
    {
        askToSave();
    }

    printf("文件名: (%s)\n", BOOK_EXT);
    //memset(newName, '\0', MEM_SIZE);
    gets(newName);
    newName[MEM_SIZE - 5] = '\0';

    //printf("------ %d, %d %d %d\n", strlen(newName), newName[0], newName[1], newName[2]);
    if (EMPTYSTR(newName))
    //if (strlen(newName) == 0)
    {
        puts("文件名为空!");
        return;
    }

    strcat(newName, BOOK_EXT);

    if ((bookFile = fopen(newName, "rb")) == NULL)
    {
        printf("无法打开文件: %s\n", newName);
        printf("文件不存在或无法读取!\n");
        return;
    }

    strcpy(bookName, newName);
    bookSize = getFileSize(bookFile);

    if (bookSize < INT_SIZE)
    {
        printf("%ld数据错误!\n", bookSize);
        fclose(bookFile);
        return;
    }

    puts("加载数据中...");
    fread(&dataCount, INT_SIZE, 1, bookFile);

    if (dataCount > 0)
    {
        data = (STUDATA *)malloc(sizeof(STUDATA));
        fread(data, sizeof(STUDATA), 1, bookFile);
        data->next = NULL;
        dataHeader = data;
        count = 1;

        //while (!feof(bookFile))
        while (count < dataCount)
        {
            data->next = (STUDATA *)malloc(sizeof(STUDATA));
            fread(data->next, sizeof(STUDATA), 1, bookFile);
            data = data->next;
            data->next = NULL;
            count++;
        }

        dataTail = data;
    }

    fclose(bookFile);
    fileOpened = TRUE;
    fileModified = FALSE;
    puts("加载完毕.");
}




void saveBook()
{
    FILE *bookFile;
    STUDATA *data;

    puts("[保存信息簿]");

    if (!fileOpened)
    {
        puts("未打开文件.");
        return;
    }

    puts("保存中...");

    if ((bookFile = fopen(bookName, "wb")) == NULL)
    {
        printf("无法保存文件: %s\n", bookName);
        return;
    }

    fwrite(&dataCount, INT_SIZE, 1, bookFile);
    data = dataHeader;

    while (data != NULL)
    {
        fwrite(data, sizeof(STUDATA), 1, bookFile);
        data = data->next;
    }

    fclose(bookFile);
    fileModified = FALSE;
    puts("保存完毕.");
}




void saveBookAs()
{
    char newName[MEM_SIZE];
    FILE *bookFile;

    puts("[信息簿另存为]");

    if (!fileOpened)
    {
        puts("未打开文件.");
        return;
    }

    printf("文件名: (%s)\n", BOOK_EXT);
    //memset(newName, '\0', MEM_SIZE);
    gets(newName);
    newName[MEM_SIZE - 5] = '\0';

    if (EMPTYSTR(newName))
    //if (strlen(newName) == 0)
    {
        puts("文件名为空!");
        return;
    }

    strcat(newName, BOOK_EXT);

    if ((bookFile = fopen(newName, "rb")) != NULL)
    {
        puts("文件已存在，是否删除原文件? (Y/n)");

        char choice;

        do
        {
            choice = tolower(getch());
        }
        while (choice != 'y' && choice != 'n');

        if (choice == 'n')
        {
            puts("未另存信息簿.");
            return;
        }
    }

    if ((bookFile = fopen(newName, "wb")) == NULL)
    {
        printf("无法打开文件: %s\n", newName);
        return;
    }

    fclose(bookFile);
    strcpy(bookName, newName);
    saveBook();
    fileOpened = TRUE;
    fileModified = FALSE;
}




void closeBook()
{
    puts("[关闭信息簿]");

    if (!fileOpened)
    {
        puts("未打开文件.");
        return;
    }

    if (fileModified)
    {
        askToSave();
    }

    fileOpened = FALSE;
    fileModified = FALSE;
}



void exitProg()
{
    puts("[退出程序]");

    if (fileOpened && fileModified)
    {
        askToSave();
    }

    exit(0);
}




void clearScreen()
{
    #ifdef LINUX
        system("clear");
    #else
        system("cls");
    #endif
}




void askToSave()
{
    char choice;

    puts("信息簿未保存, 是否保存? (y/N)");

    do
    {
        choice = tolower(getch());
    }
    while (choice != 'y' && choice != 'n');

    if (choice == 'y')
    {
        saveBook();
    }
}





void listData()
{
    STUDATA *data;
    char stuNum[MEM_SIZE];
    char choice;
    int cnt;
    int pauseCnt;

    puts("[列出数据]");

    if (!fileOpened)
    {
        puts("未打开文件.");
        return;
    }

    puts("a. 列出学号对应数据   b. 列出所有数据   c. 列出所有学号和姓名");
    choice = tolower(getch());

    switch (choice)
    {
    case 'a':
        puts("请输入学号:");
        //memset(stuNum, '\0', MEM_SIZE);
        gets(stuNum);
        stuNum[MEM_SIZE - 1] = '\0';

        if (EMPTYSTR(stuNum))
        {
            puts("学号为空!");
            break;
        }

        data = getDataAddr(stuNum);

        if (data == NULL)
        {
            puts("未找到学号!");
            break;
        }

        printData(data);
        break;
    case 'b':
    case 'c':
        data = dataHeader;
        cnt = 0;
        pauseCnt = (choice == 'b') ? 5 : 40;

        while (data != NULL)
        {
            if (choice == 'b')
            {
                printData(data);
            }
            else
            {
                printf("%s: %s\n", data->stuNum, data->name);
            }

            data = data->next;
            cnt++;

            if (cnt % 5 == pauseCnt && dataCount > pauseCnt)
            {
                puts("任意键继续, e退出...");
                if (tolower(getch()) == 'e')
                {
                    break;
                }
            }
        }

        break;
    default:
        return;
        break;
    }
}




void addData()
{
    STUDATA *newData;

    puts("[添加数据]");

    if (!fileOpened)
    {
        puts("未打开文件.");
        return;
    }

    newData = (STUDATA *)malloc(sizeof(STUDATA));
    //memset(newData, 0, sizeof(STUDATA));
    inputData(newData, INPUT_DATA_ADD);

    // 如果原链表中没有数据则直接增加，否则提示插入位置
    if (dataHeader == NULL)
    {
        dataHeader = newData;
        dataHeader->next = NULL;
        dataTail = dataHeader;
    }
    else
    {
        insertData(newData);
        //dataTail->next = newData;
        //dataTail = newData;
        //dataTail->next = NULL;
    }

    dataCount++;
    fileModified = TRUE;
    puts("数据已添加.");
}




void insertData(STUDATA *newData)
{
    char insPos;
    char stuNum[MEM_SIZE];
    STUDATA *data;

    puts("插入位置:");
    puts("a. 信息簿头   b. 某学号之后   c. 信息簿尾");

    do
    {
        insPos = tolower(getch());
    }
    while (insPos < 'a' || insPos > 'c');

    switch (insPos)
    {
    case 'a':
        newData->next = dataHeader;
        dataHeader = newData;
        break;
    case 'b':
        // 如果数据错误则循环，而不是直接返回，输入的防止信息丢失
        do
        {
            puts("请输入学号:");
            //memset(stuNum, '\0', MEM_SIZE);
            gets(stuNum);
            stuNum[MEM_SIZE - 1] = '\0';

            if (EMPTYSTR(stuNum))
            {
                puts("学号为空!");
                //break;
            }

            data = getDataAddr(stuNum);

            if (data == NULL)
            {
                puts("未找到学号!");
                //break;
            }
        }
        while (EMPTYSTR(stuNum) || data == NULL);

        newData->next = data->next;
        data->next = newData;

        if (data == dataTail)
        {
            dataTail = newData;
            dataTail->next = NULL;
        }

        break;
    case 'c':
        dataTail->next = newData;
        dataTail = newData;
        dataTail->next = NULL;
        break;
    default:
        break;
    }
}




void searchData()
{
    STUDATA *data;
    int schCount;
    char choice;
    char schContent[MEM_SIZE];

    puts("[查找数据]");

    if (!fileOpened)
    {
        puts("未打开文件.");
        return;
    }

    puts("a. 学号   b. 姓名   c. 身份证号  d. 班级     e. 学院   f. 专业");
    puts("g. 学制   h. 电话   i. QQ号      j. E-Mail   k. 宿舍   l. 籍贯");
    data = dataHeader;
    choice = tolower(getch());

    if (choice < 'a' || choice > 'z')
    {
        return;
    }

    puts("查找内容: (不分大小写)");
    //memset(schContent, '\0', MEM_SIZE);
    gets(schContent);
    schContent[MEM_SIZE - 1] = '\0';

    if (EMPTYSTR(schContent))
    {
        puts("查找内容为空!");
        return;
    }

    puts("查找结果: (显示结果为学号)");
    schCount = 0;

    while (data != NULL)
    {
        switch (choice)
        {
        case 'a':
            if (strstrEx(data->stuNum, schContent) != NULL)
            {
                schCount++;
                printf("%s\n", data->stuNum);
            }
            break;
        case 'b':
            /*if (strstrEx(data->name, schContent) != NULL)
            {
                schCount++;
                printf("%s: %s\n", data->stuNum, data->name);
            }*/
            SEARCH_DATA(data->name);
            break;
        case 'c':
            /*if (strstrEx(data->stuId, schContent) != NULL)
            {
                schCount++;
                printf("%s: %s\n", data->stuNum, data->stuId);
            }*/
            SEARCH_DATA(data->stuId);
            break;
        case 'd':
            /*if (strstrEx(data->className, schContent) != NULL)
            {
                schCount++;
                printf("%s: %s\n", data->stuNum, data->className);
            }*/
            SEARCH_DATA(data->className);
            break;
        case 'e':
            /*if (strstrEx(data->institute, schContent) != NULL)
            {
                schCount++;
                printf("%s: %s\n", data->stuNum, data->institute);
            }*/
            SEARCH_DATA(data->institute);
            break;
        case 'f':
            /*if (strstrEx(data->major, schContent) != NULL)
            {
                schCount++;
                printf("%s: %s\n", data->stuNum, data->major);
            }*/
            SEARCH_DATA(data->major);
            break;
        case 'g':
            if (atoi(schContent) == data->years)
            {
                schCount++;
                printf("%s: %d\n", data->stuNum, data->years);
            }
            break;
        case 'h':
            /*if (strstrEx(data->phoneNum, schContent) != NULL)
            {
                schCount++;
                printf("%s: %s\n", data->stuNum, data->phoneNum);
            }*/
            SEARCH_DATA(data->phoneNum);
            break;
        case 'j':
            /*if (strstrEx(data->qqNum, schContent) != NULL)
            {
                schCount++;
                printf("%s: %s\n", data->stuNum, data->qqNum);
            }*/
            SEARCH_DATA(data->qqNum);
            break;
        case 'k':
            /*if (strstrEx(data->domitory, schContent) != NULL)
            {
                schCount++;
                printf("%s: %s\n", data->stuNum, data->domitory);
            }*/
            SEARCH_DATA(data->domitory);
            break;
        case 'l':
            /*if (strstrEx(data->origion, schContent) != NULL)
            {
                schCount++;
                printf("%s: %s\n", data->stuNum, data->origion);
            }*/
            SEARCH_DATA(data->origion);
            break;
        default:
            //return;
            break;
        }

        if (schCount % 50 == 0 && schCount > 0)
        {
            getch();
        }

        data = data->next;
    }

    printf("共查找到%d项, 在主界面用l列出详细数据.\n", schCount);
}




void modifyData()
{
    char stuNum[MEM_SIZE];
    STUDATA *data;
    STUDATA *newData;

    puts("[修改数据]");

    if (!fileOpened)
    {
        puts("未打开文件.");
        return;
    }

    puts("请输入学号:");
    //memset(stuNum, '\0', MEM_SIZE);
    gets(stuNum);
    stuNum[MEM_SIZE - 1] = '\0';

    if (EMPTYSTR(stuNum))
    {
        puts("学号为空!");
        return;
    }

    data = getDataAddr(stuNum);

    if (data == NULL)
    {
        puts("未找到学号!");
        return;
    }

    puts("原数据:");
    printData(data);
    puts("------------------------------------------------------------------");
    //printf("请输入新数据: (输入%s保持该项不变, 学制输入-1)\n", REV_STR);
    puts("请输入新数据: (留空保持该项不变)");
    newData = (STUDATA *)malloc(sizeof(STUDATA));
    //memset(newData, 0, sizeof(STUDATA));
    inputData(newData, INPUT_DATA_MODIFY);

    /*if (strcmp(newData->stuNum, REV_STR))
    {
        strcpy(data->stuNum, newData->stuNum);
    }
    if (strcmp(newData->name, REV_STR))
    {
        strcpy(data->name, newData->name);
    }
    if (strcmp(newData->stuId, REV_STR))
    {
        strcpy(data->stuId, newData->stuId);
    }
    if (strcmp(newData->className, REV_STR))
    {
        strcpy(data->className, newData->className);
    }
    if (strcmp(newData->institute, REV_STR))
    {
        strcpy(data->institute, newData->institute);
    }
    if (strcmp(newData->major, REV_STR))
    {
        strcpy(data->major, newData->major);
    }
    if (newData->years != -1)
    {
        data->years = newData->years;
    }
    if (strcmp(newData->phoneNum, REV_STR))
    {
        strcpy(data->phoneNum, newData->phoneNum);
    }
    if (strcmp(newData->qqNum, REV_STR))
    {
        strcpy(data->qqNum, newData->qqNum);
    }
    if (strcmp(newData->email, REV_STR))
    {
        strcpy(data->email, newData->email);
    }
    if (strcmp(newData->domitory, REV_STR))
    {
        strcpy(data->domitory, newData->domitory);
    }
    if (strcmp(newData->origion, REV_STR))
    {
        strcpy(data->origion, newData->origion);
    }*/
    /*if (!EMPTYSTR(newData->stuNum))
    {
        strcpy(data->stuNum, newData->stuNum);
    }
    if (!EMPTYSTR(newData->name))
    {
        strcpy(data->name, newData->name);
    }
    if (!EMPTYSTR(newData->stuId))
    {
        strcpy(data->stuId, newData->stuId);
    }
    if (!EMPTYSTR(newData->className))
    {
        strcpy(data->className, newData->className);
    }
    if (!EMPTYSTR(newData->institute))
    {
        strcpy(data->institute, newData->institute);
    }
    if (!EMPTYSTR(newData->major))
    {
        strcpy(data->major, newData->major);
    }
    if (newData->years != 0)
    {
        data->years = newData->years;
    }
    if (!EMPTYSTR(newData->phoneNum))
    {
        strcpy(data->phoneNum, newData->phoneNum);
    }
    if (!EMPTYSTR(newData->qqNum))
    {
        strcpy(data->qqNum, newData->qqNum);
    }
    if (!EMPTYSTR(newData->email))
    {
        strcpy(data->email, newData->email);
    }
    if (!EMPTYSTR(newData->domitory))
    {
        strcpy(data->domitory, newData->domitory);
    }
    if (!EMPTYSTR(newData->origion))
    {
        strcpy(data->origion, newData->origion);
    }*/
    MODIFY_DATA(data->stuNum, newData->stuNum);
    MODIFY_DATA(data->name, newData->name);
    MODIFY_DATA(data->stuId, newData->stuId);
    MODIFY_DATA(data->className, newData->className);
    MODIFY_DATA(data->institute, newData->institute);
    MODIFY_DATA(data->major, newData->major);
    if (newData->years != 0)
    {
        data->years = newData->years;
    }
    MODIFY_DATA(data->phoneNum, newData->phoneNum);
    MODIFY_DATA(data->qqNum, newData->qqNum);
    MODIFY_DATA(data->email, newData->email);
    MODIFY_DATA(data->domitory, newData->domitory);
    MODIFY_DATA(data->origion, newData->origion);

    fileModified = TRUE;
    puts("修改完成.");
}




void deleteData()
{
    char stuNum[MEM_SIZE];
    STUDATA *data;
    STUDATA *prevData;

    puts("[删除数据]");

    if (!fileOpened)
    {
        puts("未打开文件.");
        return;
    }

    puts("请输入学号:");
    //memset(stuNum, '\0', MEM_SIZE);
    gets(stuNum);
    stuNum[MEM_SIZE - 1] = '\0';

    if (EMPTYSTR(stuNum))
    {
        puts("学号为空!");
        return;
    }

    prevData = getPrevDataAddr(stuNum);
    data = getDataAddr(stuNum);

    if (data == NULL)
    {
        puts("未找到学号!");
        return;
    }

    // 删除的节点是头
    if (data == dataHeader)
    {
        dataHeader = data->next;
    }
    else
    {
        prevData->next = data->next;

        // 删除的是尾
        if (data == dataTail)
        {
            dataTail = prevData;
            //dataTail->next = NULL;
        }
    }

    free(data);
    dataCount--;
    fileModified = TRUE;
    puts("已删除.");
}




void bookProperty()
{
    long size;
    double d_size;
    char *sizeFmt;
    char *sizeExt;

    puts("[信息簿属性]");

    if (!fileOpened)
    {
        puts("未打开文件.");
        return;
    }

    size = INT_SIZE + sizeof(STUDATA) * dataCount;
    sizeFmt = "文件大小: %.2lf %s\n";

    if (size < 0x400)
    {
        d_size = (double)size;
        sizeFmt = "文件大小: %.0lf %s\n";
        sizeExt = "B";
    }
    else if (size < 0x100000)
    {
        d_size = (double)size / 0x400;
        sizeExt = "KB";
    }
    else
    {
        d_size = (double)size / 0x100000;
        sizeExt = "MB";
    }

    printf("文件名: %s\n", bookName);
    printf(sizeFmt, d_size, sizeExt);
    printf("数据数量: %d\n", dataCount);
}




/***********
 * inputData
 " - 读取信息
 * 参数
 * - data 目标数据
 * - mode 输入模式
 * -   INPUT_DATA_ADD 增加数据，学号不能重复或为空
 * -   INPUT_DATA_ADD 修改数据，学号不能重复
 * 返回
 * - 无
 */
void inputData(STUDATA *data, int mode)
{
    char s_years[MEM_SIZE];
    BOOL loop;

    do
    {
        loop = FALSE;
        printf("学号：  ");
        gets(data->stuNum);

        if (mode == INPUT_DATA_ADD && EMPTYSTR(data->stuNum))
        {
            puts("学号为空!");
            loop = TRUE;
        }
        if (getDataAddr(data->stuNum) != NULL)
        {
            puts("学号已存在!");
            loop = TRUE;
        }
    }
    while (loop);

    data->stuNum[MEM_SIZE - 1] = '\0';
    printf("姓名：  ");
    gets(data->name);
    data->name[MEM_SIZE - 1] = '\0';
    printf("身份证：");
    gets(data->stuId);
    data->stuId[MEM_SIZE - 1] = '\0';
    //strupr(newData->stuId);
    strToUpper(data->stuId);
    printf("班级：  ");
    gets(data->className);
    data->className[MEM_SIZE - 1] = '\0';
    printf("学院：  ");
    gets(data->institute);
    data->institute[MEM_SIZE - 1] = '\0';;
    printf("专业：  ");
    gets(data->major);
    data->major[MEM_SIZE - 1] = '\0';
    printf("学制：  ");
    //memset(s_years, '\0', MEM_SIZE);
    //scanf("%d", &data->years);
    //fflush(stdin);
    // 为了缓冲掉scanf的回车
    //getch();
    gets(s_years);
    s_years[MEM_SIZE - 1] = '\0';
    data->years = atoi(s_years);
    printf("电话：  ");
    gets(data->phoneNum);
    data->phoneNum[MEM_SIZE - 1] = '\0';
    printf("QQ号：  ");
    gets(data->qqNum);
    data->qqNum[MEM_SIZE - 1] = '\0';
    printf("E-Mail：");
    gets(data->email);
    data->email[MEM_SIZE - 1] = '\0';
    printf("宿舍：  ");
    gets(data->domitory);
    data->domitory[MEM_SIZE - 1] = '\0';
    printf("籍贯：  ");
    gets(data->origion);
    data->origion[MEM_SIZE - 1] = '\0';

    #ifdef TCC
        /*if (EMPTYSTR(data->stuNum))
        {
            data->stuNum[0] = '\0';
        }
        if (EMPTYSTR(data->name))
        {
            data->name[0] = '\0';
        }
        if (EMPTYSTR(data->stuId))
        {
            data->stuId[0] = '\0';
        }
        if (EMPTYSTR(data->className))
        {
            data->className[0] = '\0';
        }
        if (EMPTYSTR(data->institute))
        {
            data->institute[0] = '\0';
        }
        if (EMPTYSTR(data->major))
        {
            data->major[0] = '\0';
        }
        if (EMPTYSTR(data->phoneNum))
        {
            data->phoneNum[0] = '\0';
        }
        if (EMPTYSTR(data->qqNum))
        {
            data->qqNum[0] = '\0';
        }
        if (EMPTYSTR(data->email))
        {
            data->email[0] = '\0';
        }
        if (EMPTYSTR(data->domitory))
        {
            data->domitory[0] = '\0';
        }
        if (EMPTYSTR(data->origion))
        {
            data->origion[0] = '\0';
        }*/
        INPUT_DATA(data->stuNum);
        INPUT_DATA(data->name);
        INPUT_DATA(data->stuId);
        INPUT_DATA(data->className);
        INPUT_DATA(data->institute);
        INPUT_DATA(data->major);
        INPUT_DATA(data->phoneNum);
        INPUT_DATA(data->qqNum);
        INPUT_DATA(data->email);
        INPUT_DATA(data->domitory);
        INPUT_DATA(data->origion);
    #endif
}




void printData(const STUDATA *data)
{
    puts("------------------------------------------------------------------");
    printf("学号:   %s\n", data->stuNum);
    printf("姓名:   %s\n", data->name);
    printf("身份证: %s\n", data->stuId);
    printf("班级:   %s\n", data->className);
    printf("学院:   %s\n", data->institute);
    printf("专业:   %s\n", data->major);
    printf("学制:   %d\n", data->years);
    printf("电话:   %s\n", data->phoneNum);
    printf("QQ号:   %s\n", data->qqNum);
    printf("E-Mail: %s\n", data->email);
    printf("宿舍:   %s\n", data->domitory);
    printf("籍贯:   %s\n", data->origion);
}




/******************************
 * getPrevDataAddr -> STUDATA *
 * - 获取符合条件的节点的前一个节点
 * 参数
 * - stuNum 学号
 * 返回
 * - 该节点的地址
 */
STUDATA *getPrevDataAddr(const char *stuNum)
{
    STUDATA *data;
    STUDATA *prevData;

    if (dataHeader == NULL)
    {
        prevData = NULL;
    }

    data = dataHeader;
    prevData = NULL;

    while (data != NULL)
    {
        if (!strncasecmp(stuNum, data->stuNum, strlen(stuNum)))
        {
            break;
        }

        prevData = data;
        data = data->next;
    }

    return prevData;
}




/**************************
 * getDataAddr -> STUDATA *
 * - 获取符合条件的节点
 * 参数
 * - stuNum 学号
 * 返回
 * - 该节点的地址
 */
STUDATA *getDataAddr(const char *stuNum)
{
    STUDATA *data;

    data = dataHeader;

    while (data != NULL)
    {
        if (!strncasecmp(stuNum, data->stuNum, strlen(stuNum)))
        {
            break;
        }

        data = data->next;
    }

    return data;
    //return getPrevDataAddr(stuNum)->next;
}




/*********************
 * getFileSize -> long
 * - 获取文件大小
 * 参数
 * - file 文件
 * 返回
 * - 文件大小
 */
long getFileSize(FILE *file)
{
    long curPos;
    long size;

    // 保存当前指针位置
    curPos = ftell(file);
    fseek(file, 0, SEEK_END);
    size = ftell(file);
    // 恢复文件指针位置
    fseek(file, curPos, SEEK_SET);

    return size;
}




/**********************
 * strToUpper -> char *
 * - 转换字符串为大写
 * 参数
 * - str 目标字符串
 * 返回
 * - 源字符串
 * 备注
 * - 只能转换非常量字符串。
 */
char *strToUpper(char *str)
{
    while (*str != '\0')
    {
        *str = toupper(*str);
        str++;
    }

    return str;
}




/*****************
 * strcmpEx -> int
 * - 比较字符串，不区分大小写
 * 参数
 * - str1, str2 比较的字符串
 " 返回
 * - 比较后的结果
 */
int strcmpEx(const char *str1, const char *str2)
{
    while (tolower(*str1) == tolower(*str2) && *str1 != '\0' && *str2 != '\0')
    {
        str1++;
        str2++;
    }

    return (*str1 - *str2);
}




/******************
 * strncmpEx -> int
 * - 比较字符串，最大长度为maxlen，不区分大小写
 * 参数
 * - str1, str2 比较的字符串
 * - maxlen 比较的最大长度
 * 返回
 * - 比较后的结果
 */
int strncmpEx(const char *str1, const char *str2, int maxlen)
{
    char *tmpStr1;
    char *tmpStr2;
    int slen1;
    int slen2;

    slen1 = strlen(str1);
    slen2 = strlen(str2);
    tmpStr1 = (char *)malloc(slen1);
    tmpStr2 = (char *)malloc(slen2);

    if (maxlen > slen1 || maxlen > slen2)
    {
        maxlen = (slen1 > slen2) ? slen2 : slen1;
    }

    strncpy(tmpStr1, str1, maxlen);
    strncpy(tmpStr2, str2, maxlen);

    return strcmpEx(tmpStr1, tmpStr2);
}




/********************
 * strstrEx -> char *
 * - 查找字符串，不区分大小写
 * 参数
 * - strIn 查找的字符串位置
 *   strBy 要查找的内容
 * 返回
 * - 查找到的地址。
 * 备注
 * - 返回的地址将不可用，只能作为判断是否查找到的依据。
 */
char *strstrEx(const char *strIn, const char *strBy)
{
    char *tmpStrIn;
    char *tmpStrBy;
    char *result;

    tmpStrIn = (char *)malloc(strlen(strIn));
    tmpStrBy = (char *)malloc(strlen(strBy));
    strcpy(tmpStrIn, strIn);
    strcpy(tmpStrBy, strBy);
    strToUpper(tmpStrIn);
    strToUpper(tmpStrBy);
    result = strstr(tmpStrIn, tmpStrBy);
    free(tmpStrIn);
    free(tmpStrBy);

    return result;
}