/****************************
 * ѧ����Ϣ��.c
 * �汾: 0.1.01 (201512041020)
 * ��ע:
 *   tcc��gets����õ����ǿ��ַ���
 *   ��ᱣ��'\n'��gcc���ᣬ������
 *   ���ַ����Ƿ�Ϊ�յķ�����һ����
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <conio.h>
#include <ctype.h>
#include <malloc.h>

#define LINUX
//#define TCC

#define TRUE 1
#define FALSE 0
#define INPUT_DATA_ADD 0
#define INPUT_DATA_MODIFY 1
#define MEM_SIZE 100
#define INT_SIZE 4
#define DATA_VERSION 1
#define BOOK_EXT ".sbk"

#ifdef TCC
    // �ж��ַ����Ƿ�Ϊ�գ���Ϊtcc��gets����Ŀ��ַ����Ľ�β
    // ��'\n'����gcc����'\0'
    #define EMPTYSTR(str) (str[0] == '\0' || str[0] == '\n')
    // ����inputData�������ַ�����'\0'����tcc��Ҫ
    #define INPUT_DATA(str) \
        if (str[0] == '\n') \
        { \
            str[0] = '\0'; \
        }
#else
    #define EMPTYSTR(str) (str[0] == '\0')
    #define INPUT_DATA
#endif

// ����searchData�������������������
#define SEARCH_DATA(str) \
    if (strstrEx(str, schContent) != NULL) \
    { \
        schCount++; \
        printf("%s: %s\n", data->stuNum, str); \
    }
// ����modifyData���ж��Ƿ񱣳�ԭʼ����
#define MODIFY_DATA(str, newStr) \
    if (!EMPTYSTR(newStr)) \
    { \
        strcpy(str, newStr); \
    }



typedef short BOOL;
typedef struct _STUDATA {
    char stuNum[MEM_SIZE];  // ѧ��
    char name[MEM_SIZE];  // ����
    char stuId[MEM_SIZE];  // ����֤ 
    char className[MEM_SIZE];  // �༶
    char institute[MEM_SIZE];  // ѧԺ
    char major[MEM_SIZE]; // רҵ
    int years;  // ѧ��
    char phoneNum[MEM_SIZE];  // �绰
    char qqNum[MEM_SIZE];  // QQ
    char email[MEM_SIZE];  // E-Mail
    char domitory[MEM_SIZE];  // ����
    char origion[MEM_SIZE];  // ����
    struct _STUDATA *next;
} STUDATA;



void initVars();
void showMenu();
void getOperation();
void newBook();
void openBook();
void saveBook();
void saveBookAs();
void closeBook();
void exitProg();
void clearScreen();
void askToSave();
void listData();
void addData();
void insertData(STUDATA *data);
void searchData();
void modifyData();
void deleteData();
void bookProperty();
void inputData(STUDATA *, int);
void printData(const STUDATA *);
long getFileSize(FILE *);
STUDATA *getPrevDataAddr(const char *);
STUDATA *getDataAddr(const char *);
char *strToUpper(char *);
int strcmpEx(const char *, const char *);
int strncmpEx(const char *, const char *, int);
char *strstrEx(const char *, const char *);



char bookName[MEM_SIZE];
//FILE *bookFile;
long bookSize;
STUDATA *dataHeader;
STUDATA *dataTail;
int dataCount;
BOOL fileOpened;
BOOL fileModified;



int main()
{
    initVars();

    while (TRUE)
    {
        showMenu();
        getOperation();
    }

    return 0;
}




void initVars()
{
    dataHeader = NULL;
    dataTail = NULL;
    dataCount = 0;
    fileOpened = FALSE;
    fileModified = FALSE;
}




void showMenu()
{
    puts("##################################################################");
    puts("#                          ѧ �� �� Ϣ ��                        #");
    puts("# �ļ�                                                           #");
    puts("#  n. �½�      o. ��     s. ����     S. ����Ϊ      c. �ر�   #");
    puts("#  E. �˳�                                                       #");
    puts("# ����                                                           #");
    puts("#  l. �г�      a. ����     f. ����     m. �޸�        d. ɾ��   #");
    puts("#  p. ����      C. ����                                          #");
    puts("##################################################################");

    // ��ʾ�򿪵��ļ�
    if (fileOpened)
    {
        printf("# <%s>%c\n", bookName, fileModified ? '*' : ' ');
    }

    puts("��ѡ�����: ");
}




void getOperation()
{
    char op;
    BOOL loop;

    do
    {
        loop = FALSE;
        op = getch();

        switch (op)
        {
        case 'n':
            newBook();
            break;
        case 'o':
            openBook();
            break;
        case 's':
            saveBook();
            break;
        case 'S':
            saveBookAs();
            break;
        case 'c':
            closeBook();
            break;
        case 'E':
            exitProg();
            break;
        case 'l':
            listData();
            break;
        case 'a':
            addData();
            break;
        case 'f':
            searchData();
            break;
        case 'm':
            modifyData();
            break;
        case 'd':
            deleteData();
            break;
        case 'p':
            bookProperty();
            break;
        case 'C':
            clearScreen();
            return;
            break;
        default:
            //return;
            loop = TRUE;
            break;
        }
    }
    while (loop);

    puts("���������...");
    getch();
    puts("\n\n");
}




void newBook()
{
    char newName[MEM_SIZE];
    FILE *bookFile;

    puts("[�½���Ϣ��]");
    printf("�ļ���: (%s)\n", BOOK_EXT);
    //memset(newName, '\0', MEM_SIZE);
    gets(newName);
    // �����������ַ���ź�׺����'\0'
    newName[MEM_SIZE - 5] = '\0';

    // tcc��gets�Ľ�����Ϊ'\n'����gccΪ'\0'
    if (EMPTYSTR(newName))
    //if (strlen(newName) == 0)
    {
        puts("�ļ���Ϊ��!");
        return;
    }

    strcat(newName, BOOK_EXT);

    if ((bookFile = fopen(newName, "rb")) != NULL)
    {
        puts("�ļ��Ѵ��ڣ��Ƿ�ɾ��ԭ�ļ�? (Y/n)");

        char choice;

        do
        {
            choice = tolower(getch());
        }
        while (choice != 'y' && choice != 'n');

        if (choice == 'n')
        {
            puts("δ������Ϣ��.");
            return;
        }
    }

    if ((bookFile = fopen(newName, "wb")) == NULL)
    {
        printf("�޷��򿪻򴴽��ļ�: %s\n", bookName);
        printf("������.\n");
        return;
    }

    fclose(bookFile);
    strcpy(bookName, newName);
    dataHeader = NULL;
    dataTail = NULL;
    dataCount = 0;
    fileOpened = TRUE;
    // �������޸ģ�����ʾ����
    fileModified = TRUE;
    puts("��Ϣ���Ѵ���.");
}




void openBook()
{
    char newName[MEM_SIZE];
    FILE *bookFile;
    STUDATA *data;
    int count;

    puts("[����Ϣ��]");

    if (fileOpened && fileModified)
    {
        askToSave();
    }

    printf("�ļ���: (%s)\n", BOOK_EXT);
    //memset(newName, '\0', MEM_SIZE);
    gets(newName);
    newName[MEM_SIZE - 5] = '\0';

    //printf("------ %d, %d %d %d\n", strlen(newName), newName[0], newName[1], newName[2]);
    if (EMPTYSTR(newName))
    //if (strlen(newName) == 0)
    {
        puts("�ļ���Ϊ��!");
        return;
    }

    strcat(newName, BOOK_EXT);

    if ((bookFile = fopen(newName, "rb")) == NULL)
    {
        printf("�޷����ļ�: %s\n", newName);
        printf("�ļ������ڻ��޷���ȡ!\n");
        return;
    }

    strcpy(bookName, newName);
    bookSize = getFileSize(bookFile);

    if (bookSize < INT_SIZE)
    {
        printf("%ld���ݴ���!\n", bookSize);
        fclose(bookFile);
        return;
    }

    puts("����������...");
    fread(&dataCount, INT_SIZE, 1, bookFile);

    if (dataCount > 0)
    {
        data = (STUDATA *)malloc(sizeof(STUDATA));
        fread(data, sizeof(STUDATA), 1, bookFile);
        data->next = NULL;
        dataHeader = data;
        count = 1;

        //while (!feof(bookFile))
        while (count < dataCount)
        {
            data->next = (STUDATA *)malloc(sizeof(STUDATA));
            fread(data->next, sizeof(STUDATA), 1, bookFile);
            data = data->next;
            data->next = NULL;
            count++;
        }

        dataTail = data;
    }

    fclose(bookFile);
    fileOpened = TRUE;
    fileModified = FALSE;
    puts("�������.");
}




void saveBook()
{
    FILE *bookFile;
    STUDATA *data;

    puts("[������Ϣ��]");

    if (!fileOpened)
    {
        puts("δ���ļ�.");
        return;
    }

    puts("������...");

    if ((bookFile = fopen(bookName, "wb")) == NULL)
    {
        printf("�޷������ļ�: %s\n", bookName);
        return;
    }

    fwrite(&dataCount, INT_SIZE, 1, bookFile);
    data = dataHeader;

    while (data != NULL)
    {
        fwrite(data, sizeof(STUDATA), 1, bookFile);
        data = data->next;
    }

    fclose(bookFile);
    fileModified = FALSE;
    puts("�������.");
}




void saveBookAs()
{
    char newName[MEM_SIZE];
    FILE *bookFile;

    puts("[��Ϣ������Ϊ]");

    if (!fileOpened)
    {
        puts("δ���ļ�.");
        return;
    }

    printf("�ļ���: (%s)\n", BOOK_EXT);
    //memset(newName, '\0', MEM_SIZE);
    gets(newName);
    newName[MEM_SIZE - 5] = '\0';

    if (EMPTYSTR(newName))
    //if (strlen(newName) == 0)
    {
        puts("�ļ���Ϊ��!");
        return;
    }

    strcat(newName, BOOK_EXT);

    if ((bookFile = fopen(newName, "rb")) != NULL)
    {
        puts("�ļ��Ѵ��ڣ��Ƿ�ɾ��ԭ�ļ�? (Y/n)");

        char choice;

        do
        {
            choice = tolower(getch());
        }
        while (choice != 'y' && choice != 'n');

        if (choice == 'n')
        {
            puts("δ������Ϣ��.");
            return;
        }
    }

    if ((bookFile = fopen(newName, "wb")) == NULL)
    {
        printf("�޷����ļ�: %s\n", newName);
        return;
    }

    fclose(bookFile);
    strcpy(bookName, newName);
    saveBook();
    fileOpened = TRUE;
    fileModified = FALSE;
}




void closeBook()
{
    puts("[�ر���Ϣ��]");

    if (!fileOpened)
    {
        puts("δ���ļ�.");
        return;
    }

    if (fileModified)
    {
        askToSave();
    }

    fileOpened = FALSE;
    fileModified = FALSE;
}



void exitProg()
{
    puts("[�˳�����]");

    if (fileOpened && fileModified)
    {
        askToSave();
    }

    exit(0);
}




void clearScreen()
{
    #ifdef LINUX
        system("clear");
    #else
        system("cls");
    #endif
}




void askToSave()
{
    char choice;

    puts("��Ϣ��δ����, �Ƿ񱣴�? (y/N)");

    do
    {
        choice = tolower(getch());
    }
    while (choice != 'y' && choice != 'n');

    if (choice == 'y')
    {
        saveBook();
    }
}





void listData()
{
    STUDATA *data;
    char stuNum[MEM_SIZE];
    char choice;
    int cnt;
    int pauseCnt;

    puts("[�г�����]");

    if (!fileOpened)
    {
        puts("δ���ļ�.");
        return;
    }

    puts("a. �г�ѧ�Ŷ�Ӧ����   b. �г���������   c. �г�����ѧ�ź�����");
    choice = tolower(getch());

    switch (choice)
    {
    case 'a':
        puts("������ѧ��:");
        //memset(stuNum, '\0', MEM_SIZE);
        gets(stuNum);
        stuNum[MEM_SIZE - 1] = '\0';

        if (EMPTYSTR(stuNum))
        {
            puts("ѧ��Ϊ��!");
            break;
        }

        data = getDataAddr(stuNum);

        if (data == NULL)
        {
            puts("δ�ҵ�ѧ��!");
            break;
        }

        printData(data);
        break;
    case 'b':
    case 'c':
        data = dataHeader;
        cnt = 0;
        pauseCnt = (choice == 'b') ? 5 : 40;

        while (data != NULL)
        {
            if (choice == 'b')
            {
                printData(data);
            }
            else
            {
                printf("%s: %s\n", data->stuNum, data->name);
            }

            data = data->next;
            cnt++;

            if (cnt % 5 == pauseCnt && dataCount > pauseCnt)
            {
                puts("���������, e�˳�...");
                if (tolower(getch()) == 'e')
                {
                    break;
                }
            }
        }

        break;
    default:
        return;
        break;
    }
}




void addData()
{
    STUDATA *newData;

    puts("[��������]");

    if (!fileOpened)
    {
        puts("δ���ļ�.");
        return;
    }

    newData = (STUDATA *)malloc(sizeof(STUDATA));
    //memset(newData, 0, sizeof(STUDATA));
    inputData(newData, INPUT_DATA_ADD);

    // ���ԭ������û��������ֱ�����ӣ�������ʾ����λ��
    if (dataHeader == NULL)
    {
        dataHeader = newData;
        dataHeader->next = NULL;
        dataTail = dataHeader;
    }
    else
    {
        insertData(newData);
        //dataTail->next = newData;
        //dataTail = newData;
        //dataTail->next = NULL;
    }

    dataCount++;
    fileModified = TRUE;
    puts("����������.");
}




void insertData(STUDATA *newData)
{
    char insPos;
    char stuNum[MEM_SIZE];
    STUDATA *data;

    puts("����λ��:");
    puts("a. ��Ϣ��ͷ   b. ĳѧ��֮��   c. ��Ϣ��β");

    do
    {
        insPos = tolower(getch());
    }
    while (insPos < 'a' || insPos > 'c');

    switch (insPos)
    {
    case 'a':
        newData->next = dataHeader;
        dataHeader = newData;
        break;
    case 'b':
        // ������ݴ�����ѭ����������ֱ�ӷ��أ�����ķ�ֹ��Ϣ��ʧ
        do
        {
            puts("������ѧ��:");
            //memset(stuNum, '\0', MEM_SIZE);
            gets(stuNum);
            stuNum[MEM_SIZE - 1] = '\0';

            if (EMPTYSTR(stuNum))
            {
                puts("ѧ��Ϊ��!");
                //break;
            }

            data = getDataAddr(stuNum);

            if (data == NULL)
            {
                puts("δ�ҵ�ѧ��!");
                //break;
            }
        }
        while (EMPTYSTR(stuNum) || data == NULL);

        newData->next = data->next;
        data->next = newData;

        if (data == dataTail)
        {
            dataTail = newData;
            dataTail->next = NULL;
        }

        break;
    case 'c':
        dataTail->next = newData;
        dataTail = newData;
        dataTail->next = NULL;
        break;
    default:
        break;
    }
}




void searchData()
{
    STUDATA *data;
    int schCount;
    char choice;
    char schContent[MEM_SIZE];

    puts("[��������]");

    if (!fileOpened)
    {
        puts("δ���ļ�.");
        return;
    }

    puts("a. ѧ��   b. ����   c. ����֤��  d. �༶     e. ѧԺ   f. רҵ");
    puts("g. ѧ��   h. �绰   i. QQ��      j. E-Mail   k. ����   l. ����");
    data = dataHeader;
    choice = tolower(getch());

    if (choice < 'a' || choice > 'z')
    {
        return;
    }

    puts("��������: (���ִ�Сд)");
    //memset(schContent, '\0', MEM_SIZE);
    gets(schContent);
    schContent[MEM_SIZE - 1] = '\0';

    if (EMPTYSTR(schContent))
    {
        puts("��������Ϊ��!");
        return;
    }

    puts("���ҽ��: (��ʾ���Ϊѧ��)");
    schCount = 0;

    while (data != NULL)
    {
        switch (choice)
        {
        case 'a':
            if (strstrEx(data->stuNum, schContent) != NULL)
            {
                schCount++;
                printf("%s\n", data->stuNum);
            }
            break;
        case 'b':
            /*if (strstrEx(data->name, schContent) != NULL)
            {
                schCount++;
                printf("%s: %s\n", data->stuNum, data->name);
            }*/
            SEARCH_DATA(data->name);
            break;
        case 'c':
            /*if (strstrEx(data->stuId, schContent) != NULL)
            {
                schCount++;
                printf("%s: %s\n", data->stuNum, data->stuId);
            }*/
            SEARCH_DATA(data->stuId);
            break;
        case 'd':
            /*if (strstrEx(data->className, schContent) != NULL)
            {
                schCount++;
                printf("%s: %s\n", data->stuNum, data->className);
            }*/
            SEARCH_DATA(data->className);
            break;
        case 'e':
            /*if (strstrEx(data->institute, schContent) != NULL)
            {
                schCount++;
                printf("%s: %s\n", data->stuNum, data->institute);
            }*/
            SEARCH_DATA(data->institute);
            break;
        case 'f':
            /*if (strstrEx(data->major, schContent) != NULL)
            {
                schCount++;
                printf("%s: %s\n", data->stuNum, data->major);
            }*/
            SEARCH_DATA(data->major);
            break;
        case 'g':
            if (atoi(schContent) == data->years)
            {
                schCount++;
                printf("%s: %d\n", data->stuNum, data->years);
            }
            break;
        case 'h':
            /*if (strstrEx(data->phoneNum, schContent) != NULL)
            {
                schCount++;
                printf("%s: %s\n", data->stuNum, data->phoneNum);
            }*/
            SEARCH_DATA(data->phoneNum);
            break;
        case 'j':
            /*if (strstrEx(data->qqNum, schContent) != NULL)
            {
                schCount++;
                printf("%s: %s\n", data->stuNum, data->qqNum);
            }*/
            SEARCH_DATA(data->qqNum);
            break;
        case 'k':
            /*if (strstrEx(data->domitory, schContent) != NULL)
            {
                schCount++;
                printf("%s: %s\n", data->stuNum, data->domitory);
            }*/
            SEARCH_DATA(data->domitory);
            break;
        case 'l':
            /*if (strstrEx(data->origion, schContent) != NULL)
            {
                schCount++;
                printf("%s: %s\n", data->stuNum, data->origion);
            }*/
            SEARCH_DATA(data->origion);
            break;
        default:
            //return;
            break;
        }

        if (schCount % 50 == 0 && schCount > 0)
        {
            getch();
        }

        data = data->next;
    }

    printf("�����ҵ�%d��, ����������l�г���ϸ����.\n", schCount);
}




void modifyData()
{
    char stuNum[MEM_SIZE];
    STUDATA *data;
    STUDATA *newData;

    puts("[�޸�����]");

    if (!fileOpened)
    {
        puts("δ���ļ�.");
        return;
    }

    puts("������ѧ��:");
    //memset(stuNum, '\0', MEM_SIZE);
    gets(stuNum);
    stuNum[MEM_SIZE - 1] = '\0';

    if (EMPTYSTR(stuNum))
    {
        puts("ѧ��Ϊ��!");
        return;
    }

    data = getDataAddr(stuNum);

    if (data == NULL)
    {
        puts("δ�ҵ�ѧ��!");
        return;
    }

    puts("ԭ����:");
    printData(data);
    puts("------------------------------------------------------------------");
    //printf("������������: (����%s���ָ����, ѧ������-1)\n", REV_STR);
    puts("������������: (���ձ��ָ����)");
    newData = (STUDATA *)malloc(sizeof(STUDATA));
    //memset(newData, 0, sizeof(STUDATA));
    inputData(newData, INPUT_DATA_MODIFY);

    /*if (strcmp(newData->stuNum, REV_STR))
    {
        strcpy(data->stuNum, newData->stuNum);
    }
    if (strcmp(newData->name, REV_STR))
    {
        strcpy(data->name, newData->name);
    }
    if (strcmp(newData->stuId, REV_STR))
    {
        strcpy(data->stuId, newData->stuId);
    }
    if (strcmp(newData->className, REV_STR))
    {
        strcpy(data->className, newData->className);
    }
    if (strcmp(newData->institute, REV_STR))
    {
        strcpy(data->institute, newData->institute);
    }
    if (strcmp(newData->major, REV_STR))
    {
        strcpy(data->major, newData->major);
    }
    if (newData->years != -1)
    {
        data->years = newData->years;
    }
    if (strcmp(newData->phoneNum, REV_STR))
    {
        strcpy(data->phoneNum, newData->phoneNum);
    }
    if (strcmp(newData->qqNum, REV_STR))
    {
        strcpy(data->qqNum, newData->qqNum);
    }
    if (strcmp(newData->email, REV_STR))
    {
        strcpy(data->email, newData->email);
    }
    if (strcmp(newData->domitory, REV_STR))
    {
        strcpy(data->domitory, newData->domitory);
    }
    if (strcmp(newData->origion, REV_STR))
    {
        strcpy(data->origion, newData->origion);
    }*/
    /*if (!EMPTYSTR(newData->stuNum))
    {
        strcpy(data->stuNum, newData->stuNum);
    }
    if (!EMPTYSTR(newData->name))
    {
        strcpy(data->name, newData->name);
    }
    if (!EMPTYSTR(newData->stuId))
    {
        strcpy(data->stuId, newData->stuId);
    }
    if (!EMPTYSTR(newData->className))
    {
        strcpy(data->className, newData->className);
    }
    if (!EMPTYSTR(newData->institute))
    {
        strcpy(data->institute, newData->institute);
    }
    if (!EMPTYSTR(newData->major))
    {
        strcpy(data->major, newData->major);
    }
    if (newData->years != 0)
    {
        data->years = newData->years;
    }
    if (!EMPTYSTR(newData->phoneNum))
    {
        strcpy(data->phoneNum, newData->phoneNum);
    }
    if (!EMPTYSTR(newData->qqNum))
    {
        strcpy(data->qqNum, newData->qqNum);
    }
    if (!EMPTYSTR(newData->email))
    {
        strcpy(data->email, newData->email);
    }
    if (!EMPTYSTR(newData->domitory))
    {
        strcpy(data->domitory, newData->domitory);
    }
    if (!EMPTYSTR(newData->origion))
    {
        strcpy(data->origion, newData->origion);
    }*/
    MODIFY_DATA(data->stuNum, newData->stuNum);
    MODIFY_DATA(data->name, newData->name);
    MODIFY_DATA(data->stuId, newData->stuId);
    MODIFY_DATA(data->className, newData->className);
    MODIFY_DATA(data->institute, newData->institute);
    MODIFY_DATA(data->major, newData->major);
    if (newData->years != 0)
    {
        data->years = newData->years;
    }
    MODIFY_DATA(data->phoneNum, newData->phoneNum);
    MODIFY_DATA(data->qqNum, newData->qqNum);
    MODIFY_DATA(data->email, newData->email);
    MODIFY_DATA(data->domitory, newData->domitory);
    MODIFY_DATA(data->origion, newData->origion);

    fileModified = TRUE;
    puts("�޸����.");
}




void deleteData()
{
    char stuNum[MEM_SIZE];
    STUDATA *data;
    STUDATA *prevData;

    puts("[ɾ������]");

    if (!fileOpened)
    {
        puts("δ���ļ�.");
        return;
    }

    puts("������ѧ��:");
    //memset(stuNum, '\0', MEM_SIZE);
    gets(stuNum);
    stuNum[MEM_SIZE - 1] = '\0';

    if (EMPTYSTR(stuNum))
    {
        puts("ѧ��Ϊ��!");
        return;
    }

    prevData = getPrevDataAddr(stuNum);
    data = getDataAddr(stuNum);

    if (data == NULL)
    {
        puts("δ�ҵ�ѧ��!");
        return;
    }

    // ɾ���Ľڵ���ͷ
    if (data == dataHeader)
    {
        dataHeader = data->next;
    }
    else
    {
        prevData->next = data->next;

        // ɾ������β
        if (data == dataTail)
        {
            dataTail = prevData;
            //dataTail->next = NULL;
        }
    }

    free(data);
    dataCount--;
    fileModified = TRUE;
    puts("��ɾ��.");
}




void bookProperty()
{
    long size;
    double d_size;
    char *sizeFmt;
    char *sizeExt;

    puts("[��Ϣ������]");

    if (!fileOpened)
    {
        puts("δ���ļ�.");
        return;
    }

    size = INT_SIZE + sizeof(STUDATA) * dataCount;
    sizeFmt = "�ļ���С: %.2lf %s\n";

    if (size < 0x400)
    {
        d_size = (double)size;
        sizeFmt = "�ļ���С: %.0lf %s\n";
        sizeExt = "B";
    }
    else if (size < 0x100000)
    {
        d_size = (double)size / 0x400;
        sizeExt = "KB";
    }
    else
    {
        d_size = (double)size / 0x100000;
        sizeExt = "MB";
    }

    printf("�ļ���: %s\n", bookName);
    printf(sizeFmt, d_size, sizeExt);
    printf("��������: %d\n", dataCount);
}




/***********
 * inputData
 " - ��ȡ��Ϣ
 * ����
 * - data Ŀ������
 * - mode ����ģʽ
 * -   INPUT_DATA_ADD �������ݣ�ѧ�Ų����ظ���Ϊ��
 * -   INPUT_DATA_ADD �޸����ݣ�ѧ�Ų����ظ�
 * ����
 * - ��
 */
void inputData(STUDATA *data, int mode)
{
    char s_years[MEM_SIZE];
    BOOL loop;

    do
    {
        loop = FALSE;
        printf("ѧ�ţ�  ");
        gets(data->stuNum);

        if (mode == INPUT_DATA_ADD && EMPTYSTR(data->stuNum))
        {
            puts("ѧ��Ϊ��!");
            loop = TRUE;
        }
        if (getDataAddr(data->stuNum) != NULL)
        {
            puts("ѧ���Ѵ���!");
            loop = TRUE;
        }
    }
    while (loop);

    data->stuNum[MEM_SIZE - 1] = '\0';
    printf("������  ");
    gets(data->name);
    data->name[MEM_SIZE - 1] = '\0';
    printf("����֤��");
    gets(data->stuId);
    data->stuId[MEM_SIZE - 1] = '\0';
    //strupr(newData->stuId);
    strToUpper(data->stuId);
    printf("�༶��  ");
    gets(data->className);
    data->className[MEM_SIZE - 1] = '\0';
    printf("ѧԺ��  ");
    gets(data->institute);
    data->institute[MEM_SIZE - 1] = '\0';;
    printf("רҵ��  ");
    gets(data->major);
    data->major[MEM_SIZE - 1] = '\0';
    printf("ѧ�ƣ�  ");
    //memset(s_years, '\0', MEM_SIZE);
    //scanf("%d", &data->years);
    //fflush(stdin);
    // Ϊ�˻����scanf�Ļس�
    //getch();
    gets(s_years);
    s_years[MEM_SIZE - 1] = '\0';
    data->years = atoi(s_years);
    printf("�绰��  ");
    gets(data->phoneNum);
    data->phoneNum[MEM_SIZE - 1] = '\0';
    printf("QQ�ţ�  ");
    gets(data->qqNum);
    data->qqNum[MEM_SIZE - 1] = '\0';
    printf("E-Mail��");
    gets(data->email);
    data->email[MEM_SIZE - 1] = '\0';
    printf("���᣺  ");
    gets(data->domitory);
    data->domitory[MEM_SIZE - 1] = '\0';
    printf("���᣺  ");
    gets(data->origion);
    data->origion[MEM_SIZE - 1] = '\0';

    #ifdef TCC
        /*if (EMPTYSTR(data->stuNum))
        {
            data->stuNum[0] = '\0';
        }
        if (EMPTYSTR(data->name))
        {
            data->name[0] = '\0';
        }
        if (EMPTYSTR(data->stuId))
        {
            data->stuId[0] = '\0';
        }
        if (EMPTYSTR(data->className))
        {
            data->className[0] = '\0';
        }
        if (EMPTYSTR(data->institute))
        {
            data->institute[0] = '\0';
        }
        if (EMPTYSTR(data->major))
        {
            data->major[0] = '\0';
        }
        if (EMPTYSTR(data->phoneNum))
        {
            data->phoneNum[0] = '\0';
        }
        if (EMPTYSTR(data->qqNum))
        {
            data->qqNum[0] = '\0';
        }
        if (EMPTYSTR(data->email))
        {
            data->email[0] = '\0';
        }
        if (EMPTYSTR(data->domitory))
        {
            data->domitory[0] = '\0';
        }
        if (EMPTYSTR(data->origion))
        {
            data->origion[0] = '\0';
        }*/
        INPUT_DATA(data->stuNum);
        INPUT_DATA(data->name);
        INPUT_DATA(data->stuId);
        INPUT_DATA(data->className);
        INPUT_DATA(data->institute);
        INPUT_DATA(data->major);
        INPUT_DATA(data->phoneNum);
        INPUT_DATA(data->qqNum);
        INPUT_DATA(data->email);
        INPUT_DATA(data->domitory);
        INPUT_DATA(data->origion);
    #endif
}




void printData(const STUDATA *data)
{
    puts("------------------------------------------------------------------");
    printf("ѧ��:   %s\n", data->stuNum);
    printf("����:   %s\n", data->name);
    printf("����֤: %s\n", data->stuId);
    printf("�༶:   %s\n", data->className);
    printf("ѧԺ:   %s\n", data->institute);
    printf("רҵ:   %s\n", data->major);
    printf("ѧ��:   %d\n", data->years);
    printf("�绰:   %s\n", data->phoneNum);
    printf("QQ��:   %s\n", data->qqNum);
    printf("E-Mail: %s\n", data->email);
    printf("����:   %s\n", data->domitory);
    printf("����:   %s\n", data->origion);
}




/******************************
 * getPrevDataAddr -> STUDATA *
 * - ��ȡ���������Ľڵ��ǰһ���ڵ�
 * ����
 * - stuNum ѧ��
 * ����
 * - �ýڵ�ĵ�ַ
 */
STUDATA *getPrevDataAddr(const char *stuNum)
{
    STUDATA *data;
    STUDATA *prevData;

    if (dataHeader == NULL)
    {
        prevData = NULL;
    }

    data = dataHeader;
    prevData = NULL;

    while (data != NULL)
    {
        if (!strncasecmp(stuNum, data->stuNum, strlen(stuNum)))
        {
            break;
        }

        prevData = data;
        data = data->next;
    }

    return prevData;
}




/**************************
 * getDataAddr -> STUDATA *
 * - ��ȡ���������Ľڵ�
 * ����
 * - stuNum ѧ��
 * ����
 * - �ýڵ�ĵ�ַ
 */
STUDATA *getDataAddr(const char *stuNum)
{
    STUDATA *data;

    data = dataHeader;

    while (data != NULL)
    {
        if (!strncasecmp(stuNum, data->stuNum, strlen(stuNum)))
        {
            break;
        }

        data = data->next;
    }

    return data;
    //return getPrevDataAddr(stuNum)->next;
}




/*********************
 * getFileSize -> long
 * - ��ȡ�ļ���С
 * ����
 * - file �ļ�
 * ����
 * - �ļ���С
 */
long getFileSize(FILE *file)
{
    long curPos;
    long size;

    // ���浱ǰָ��λ��
    curPos = ftell(file);
    fseek(file, 0, SEEK_END);
    size = ftell(file);
    // �ָ��ļ�ָ��λ��
    fseek(file, curPos, SEEK_SET);

    return size;
}




/**********************
 * strToUpper -> char *
 * - ת���ַ���Ϊ��д
 * ����
 * - str Ŀ���ַ���
 * ����
 * - Դ�ַ���
 * ��ע
 * - ֻ��ת���ǳ����ַ�����
 */
char *strToUpper(char *str)
{
    while (*str != '\0')
    {
        *str = toupper(*str);
        str++;
    }

    return str;
}




/*****************
 * strcmpEx -> int
 * - �Ƚ��ַ����������ִ�Сд
 * ����
 * - str1, str2 �Ƚϵ��ַ���
 " ����
 * - �ȽϺ�Ľ��
 */
int strcmpEx(const char *str1, const char *str2)
{
    while (tolower(*str1) == tolower(*str2) && *str1 != '\0' && *str2 != '\0')
    {
        str1++;
        str2++;
    }

    return (*str1 - *str2);
}




/******************
 * strncmpEx -> int
 * - �Ƚ��ַ�������󳤶�Ϊmaxlen�������ִ�Сд
 * ����
 * - str1, str2 �Ƚϵ��ַ���
 * - maxlen �Ƚϵ���󳤶�
 * ����
 * - �ȽϺ�Ľ��
 */
int strncmpEx(const char *str1, const char *str2, int maxlen)
{
    char *tmpStr1;
    char *tmpStr2;
    int slen1;
    int slen2;

    slen1 = strlen(str1);
    slen2 = strlen(str2);
    tmpStr1 = (char *)malloc(slen1);
    tmpStr2 = (char *)malloc(slen2);

    if (maxlen > slen1 || maxlen > slen2)
    {
        maxlen = (slen1 > slen2) ? slen2 : slen1;
    }

    strncpy(tmpStr1, str1, maxlen);
    strncpy(tmpStr2, str2, maxlen);

    return strcmpEx(tmpStr1, tmpStr2);
}




/********************
 * strstrEx -> char *
 * - �����ַ����������ִ�Сд
 * ����
 * - strIn ���ҵ��ַ���λ��
 *   strBy Ҫ���ҵ�����
 * ����
 * - ���ҵ��ĵ�ַ��
 * ��ע
 * - ���صĵ�ַ�������ã�ֻ����Ϊ�ж��Ƿ���ҵ������ݡ�
 */
char *strstrEx(const char *strIn, const char *strBy)
{
    char *tmpStrIn;
    char *tmpStrBy;
    char *result;

    tmpStrIn = (char *)malloc(strlen(strIn));
    tmpStrBy = (char *)malloc(strlen(strBy));
    strcpy(tmpStrIn, strIn);
    strcpy(tmpStrBy, strBy);
    strToUpper(tmpStrIn);
    strToUpper(tmpStrBy);
    result = strstr(tmpStrIn, tmpStrBy);
    free(tmpStrIn);
    free(tmpStrBy);

    return result;
}