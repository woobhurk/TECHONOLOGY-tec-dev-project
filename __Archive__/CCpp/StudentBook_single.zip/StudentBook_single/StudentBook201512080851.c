/****************************
 * 学生信息簿.c
 * --------------------------
 * 版本: 0.2.90 (201512080851)
 * 修改:
 *   1. 优化代码结构。
 * 备注:
 *   粗略测试版本。
 * --------------------------
 * 版本: 0.2.88 (201512080824)
 * 修改:
 *   1. 增加数据移动功能。
 * --------------------------
 * 版本: 0.2.52 (201512071347)
 * 修改:
 *   1. 修正查找数据的错误。
 * --------------------------
 * 版本: 0.2.30 (201512071055)
 * 修改:
 *   1. 修正修改数据的问题。
 *   2. 修正查找数据的问题。
 *   3. 修正字符串比较函数的问题。
 * --------------------------
 * 版本: 0.2.24 (201512070024)
 * 修改:
 *   1. 修正学号搜索问题。
 *   2. 增加通过编号修改功能。
 * 备注:
     未完整测试版本。
 * --------------------------
 * 版本: 0.2.00 (201512061917)
 * 修改:
 *   1. 用宏代替判断。
 *   2. 增加编译环境判断。
 *   3. 提高函数和语法对编译器的兼容性。
 *   4. 支持搜索不区分大小写。
 *   5. 支持指定插入位置。
 * --------------------------
 * 版本: 0.1.01 (201512041020)
 * 修改:
 *   0. 首个较完整版本。
 * 备注:
 *   tcc上gets如果得到的是空字符串则会保留'\n'，gcc不
 *   会，所以判断字符串是否为空的方法不一样。
 */
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <ctype.h>
#include <string.h>
#include <malloc.h>

#define LINUX
//#define TCC

#define TRUE 1
#define FALSE 0
#define INPUT_DATA_ADD 0
#define INPUT_DATA_MODIFY 1
#define STR_SIZE 100
#define INT_SIZE 4
#define BOOK_EXT ".sbk"

#ifdef TCC
    // 判断字符串是否为空，因为tcc的gets读入的空字符串的结尾是'\n'，而gcc的是'\0'
    #define EMPTYSTR(str) (str[0] == '\0' || str[0] == '\n')
    // 用于inputData，将空字符串置'\0'，仅tcc需要
    #define INPUT_DATA(str) \
        if (str[0] == '\n') \
        { \
            str[0] = '\0'; \
        }
#else
    #define EMPTYSTR(str) (str[0] == '\0')
    #define INPUT_DATA(str)
#endif

// 用于searchData，输出符合条件的数据
#define SEARCH_DATA(str) \
    if (strstrEx(str, schContent) != NULL) \
    { \
        schCount++; \
        printf("%06d: %-20s: %s\n", id, data->stuNum, str); \
    }
// 用于modifyData，判断是否保持原始数据
#define MODIFY_DATA(str, newStr) \
    if (!EMPTYSTR(newStr)) \
    { \
        strcpy(str, newStr); \
    }



typedef short BOOL;
typedef struct _STUDATA {
    char stuNum[STR_SIZE];  // 学号
    char name[STR_SIZE];  // 姓名
    char stuId[STR_SIZE];  // 身份证 
    char className[STR_SIZE];  // 班级
    char institute[STR_SIZE];  // 学院
    char major[STR_SIZE]; // 专业
    int years;  // 学制
    char phoneNum[STR_SIZE];  // 电话
    char qqNum[STR_SIZE];  // QQ
    char email[STR_SIZE];  // E-Mail
    char domitory[STR_SIZE];  // 宿舍
    char origion[STR_SIZE];  // 籍贯
    struct _STUDATA *next;
} STUDATA;



void initVars();
void showMenu();
void getOperation();
void newBook();
void openBook();
void saveBook();
void saveBookAs();
void closeBook();
void exitProg();
void clearScreen();
void askToSave();
void listData();
void addData();
void addDataTo(STUDATA *);
void searchData();
void modifyData();
void deleteData();
void moveData();
void moveDataTo(STUDATA *);
void bookProperty();
void inputData(STUDATA *, int);
void printData(const STUDATA *);
long getFileSize(FILE *);
STUDATA *getPrevDataAddr(const char *);
STUDATA *getDataAddr(const char *);
STUDATA *getPrevDataAddrById(int);
STUDATA *getDataAddrById(int);
char *strToUpper(char *);
int strcmpEx(const char *, const char *);
int strncmpEx(const char *, const char *, int);
char *strstrEx(const char *, const char *);



char bookName[STR_SIZE];
STUDATA *dataHeader;
STUDATA *dataTail;
int dataCount;
BOOL fileOpened;
BOOL fileModified;



int main()
{
    initVars();

    while (TRUE)
    {
        showMenu();
        getOperation();
    }

    return 0;
}




void initVars()
{
    dataHeader = NULL;
    dataTail = NULL;
    dataCount = 0;
    fileOpened = FALSE;
    fileModified = FALSE;
}




void showMenu()
{
    //printf("---- %d, %d, %d, %d\n", strncmpEx("abc", "aBCD", 3), strncmpEx("ab", "aBCdEf", 3), strncmp("ef", "eGf", 10), strncmpEx("ancGs", "Anc", 20));
    puts("##################################################################");
    puts("#                          学 生 信 息 簿                        #");
    puts("# 文件                                                           #");
    puts("#  n. 新建      o. 打开     s. 保存     S. 另存为      c. 关闭   #");
    puts("#  E. 退出                                                       #");
    puts("# 数据                                                           #");
    puts("#  l. 列出      a. 添加     f. 查找     m. 修改        d. 删除   #");
    puts("#  v. 移动      p. 属性     C. 清屏                              #");
    puts("##################################################################");

    // 显示打开的文件
    if (fileOpened)
    {
        printf("# <%s>%c\n", bookName, fileModified ? '*' : ' ');
    }

    puts("请选择操作: ");
}




void getOperation()
{
    char op;
    BOOL loop;

    do
    {
        loop = FALSE;
        op = getch();

        switch (op)
        {
        case 'n':
            newBook();
            break;
        case 'o':
            openBook();
            break;
        case 's':
            saveBook();
            break;
        case 'S':
            saveBookAs();
            break;
        case 'c':
            closeBook();
            break;
        case 'E':
            exitProg();
            break;
        case 'l':
            listData();
            break;
        case 'a':
            addData();
            break;
        case 'f':
            searchData();
            break;
        case 'm':
            modifyData();
            break;
        case 'd':
            deleteData();
            break;
        case 'v':
            moveData();
            break;
        case 'p':
            bookProperty();
            break;
        case 'C':
            clearScreen();
            return;
            break;
        default:
            //return;
            loop = TRUE;
            break;
        }
    }
    while (loop);

    puts("任意键返回...");
    getch();
    puts("\n\n");
}




void newBook()
{
    char newName[STR_SIZE];
    FILE *bookFile;
    char choice;

    puts("[新建信息簿]");

    if (fileOpened && fileModified)
    {
        askToSave();
    }

    printf("文件名: (%s)\n", BOOK_EXT);
    gets(newName);
    // 留出最后五个字符存放后缀名和'\0'
    newName[STR_SIZE - 5] = '\0';

    if (EMPTYSTR(newName))
    {
        puts("文件名为空!");
        return;
    }

    strcat(newName, BOOK_EXT);

    if ((bookFile = fopen(newName, "rb")) != NULL)
    {
        puts("文件已存在，是否删除原文件? (Y/n)");

        do
        {
            choice = tolower(getch());
        }
        while (choice != 'y' && choice != 'n');

        if (choice == 'n')
        {
            puts("未创建信息簿.");
            return;
        }
    }

    if ((bookFile = fopen(newName, "wb")) == NULL)
    {
        printf("无法打开或创建文件: %s\n", bookName);
        printf("请重试.\n");
        return;
    }

    fclose(bookFile);
    strcpy(bookName, newName);
    dataHeader = NULL;
    dataTail = NULL;
    dataCount = 0;
    fileOpened = TRUE;
    // 假设已修改，将提示保存
    fileModified = TRUE;
    puts("信息簿已创建.");
}




void openBook()
{
    char newName[STR_SIZE];
    FILE *bookFile;
    long bookSize;
    STUDATA *data;
    int count;

    puts("[打开信息簿]");

    if (fileOpened && fileModified)
    {
        askToSave();
    }

    printf("文件名: (%s)\n", BOOK_EXT);
    gets(newName);
    newName[STR_SIZE - 5] = '\0';

    //printf("------ %d, %d %d %d\n", strlen(newName), newName[0], newName[1], newName[2]);
    if (EMPTYSTR(newName))
    {
        puts("文件名为空!");
        return;
    }

    strcat(newName, BOOK_EXT);

    if ((bookFile = fopen(newName, "rb")) == NULL)
    {
        printf("无法打开文件: %s\n", newName);
        printf("文件不存在或无法读取!\n");
        return;
    }

    strcpy(bookName, newName);
    bookSize = getFileSize(bookFile);

    if (bookSize < INT_SIZE)
    {
        printf("%ld数据错误!\n", bookSize);
        fclose(bookFile);
        return;
    }

    puts("加载数据中...");
    fread(&dataCount, INT_SIZE, 1, bookFile);

    if (dataCount > 0)
    {
        data = (STUDATA *)malloc(sizeof(STUDATA));
        fread(data, sizeof(STUDATA), 1, bookFile);
        data->next = NULL;
        dataHeader = data;
        count = 1;

        // 用feof的话读取的数据会出错
        //while (!feof(bookFile))
        while (count < dataCount)
        {
            data->next = (STUDATA *)malloc(sizeof(STUDATA));
            fread(data->next, sizeof(STUDATA), 1, bookFile);
            data = data->next;
            data->next = NULL;
            count++;
        }

        dataTail = data;
    }

    fclose(bookFile);
    fileOpened = TRUE;
    fileModified = FALSE;
    puts("加载完毕.");
}




void saveBook()
{
    FILE *bookFile;
    STUDATA *data;

    puts("[保存信息簿]");

    if (!fileOpened)
    {
        puts("未打开文件.");
        return;
    }

    puts("保存中...");

    if ((bookFile = fopen(bookName, "wb")) == NULL)
    {
        printf("无法保存文件: %s\n", bookName);
        return;
    }

    fwrite(&dataCount, INT_SIZE, 1, bookFile);
    data = dataHeader;

    while (data != NULL)
    {
        fwrite(data, sizeof(STUDATA), 1, bookFile);
        data = data->next;
    }

    fclose(bookFile);
    fileModified = FALSE;
    puts("保存完毕.");
}




void saveBookAs()
{
    char newName[STR_SIZE];
    FILE *bookFile;
    char choice;

    puts("[信息簿另存为]");

    if (!fileOpened)
    {
        puts("未打开文件.");
        return;
    }

    printf("文件名: (%s)\n", BOOK_EXT);
    gets(newName);
    newName[STR_SIZE - 5] = '\0';

    if (EMPTYSTR(newName))
    {
        puts("文件名为空!");
        return;
    }

    strcat(newName, BOOK_EXT);

    if ((bookFile = fopen(newName, "rb")) != NULL)
    {
        puts("文件已存在，是否删除原文件? (Y/n)");

        do
        {
            choice = tolower(getch());
        }
        while (choice != 'y' && choice != 'n');

        if (choice == 'n')
        {
            puts("未另存信息簿.");
            return;
        }
    }

    if ((bookFile = fopen(newName, "wb")) == NULL)
    {
        printf("无法打开文件: %s\n", newName);
        return;
    }

    fclose(bookFile);
    strcpy(bookName, newName);
    saveBook();
    fileOpened = TRUE;
    fileModified = FALSE;
}




void closeBook()
{
    puts("[关闭信息簿]");

    if (!fileOpened)
    {
        puts("未打开文件.");
        return;
    }

    if (fileModified)
    {
        askToSave();
    }

    fileOpened = FALSE;
    fileModified = FALSE;
    puts("文件已关闭.");
}



void exitProg()
{
    puts("[退出程序]");

    if (fileOpened && fileModified)
    {
        askToSave();
    }

    exit(0);
}




void clearScreen()
{
    #ifdef LINUX
        system("clear");
    #else
        system("cls");
    #endif
}




void askToSave()
{
    char choice;

    puts("信息簿未保存, 是否保存? (y/N)");

    do
    {
        choice = tolower(getch());
    }
    while (choice != 'y' && choice != 'n');

    if (choice == 'y')
    {
        saveBook();
    }
}





void listData()
{
    STUDATA *data;
    char stuNum[STR_SIZE];
    char s_id[STR_SIZE];
    char choice;
    int cnt;
    int pauseCnt;

    puts("[列出数据]");

    if (!fileOpened)
    {
        puts("未打开文件.");
        return;
    }

    puts("a. 列出学号对应数据     b. 列出编号对应数据");
    puts("c. 列出所有学号和姓名   d. 列出所有数据(可能较多)");
    choice = tolower(getch());

    if (choice < 'a' || choice > 'd')
    {
        return;
    }

    switch (choice)
    {
    case 'a':
        puts("请输入学号:");
        gets(stuNum);
        stuNum[STR_SIZE - 1] = '\0';

        if (EMPTYSTR(stuNum))
        {
            puts("学号为空!");
            break;
        }

        data = getDataAddr(stuNum);

        if (data == NULL)
        {
            puts("未找到学号!");
            break;
        }

        printData(data);
        break;
    case 'b':
        puts("请输入编号:");
        gets(s_id);
        s_id[STR_SIZE - 1] = '\0';

        if (EMPTYSTR(s_id))
        {
            puts("编号为空!");
            break;
        }

        data = getDataAddrById(atoi(s_id));

        if (data == NULL)
        {
            puts("未找到编号!");
            break;
        }

        printData(data);
        break;
    case 'c':
    case 'd':
        data = dataHeader;
        cnt = 0;
        pauseCnt = (choice == 'c') ? 40 : 5;

        while (data != NULL)
        {
            if (choice == 'c')
            {
                printf("%06d: %-20s: %s\n", cnt, data->stuNum, data->name);
            }
            else
            {
                printData(data);
            }

            data = data->next;
            cnt++;

            if (cnt % pauseCnt == 0 && dataCount > pauseCnt)
            {
                puts("任意键继续, e退出...");

                if (tolower(getch()) == 'e')
                {
                    break;
                }
            }
        }

        break;
    default:
        break;
    }
}




void addData()
{
    STUDATA *newData;

    puts("[添加数据]");

    if (!fileOpened)
    {
        puts("未打开文件.");
        return;
    }

    newData = (STUDATA *)malloc(sizeof(STUDATA));
    inputData(newData, INPUT_DATA_ADD);

    // 如果原链表中没有数据则直接增加，否则提示插入位置
    if (dataHeader == NULL)
    {
        dataHeader = newData;
        dataHeader->next = NULL;
        dataTail = dataHeader;
    }
    else
    {
        addDataTo(newData);
    }

    dataCount++;
    fileModified = TRUE;
}




void addDataTo(STUDATA *newData)
{
    char stuNum[STR_SIZE];
    char s_id[STR_SIZE];
    STUDATA *data;
    BOOL loop;
    char choice;

    puts("添加位置:");
    puts("a. 信息簿头   b. 某学号之后   c. 某编号之后   d. 信息簿尾");

    do
    {
        choice = tolower(getch());
    }
    while (choice < 'a' || choice > 'd');

    switch (choice)
    {
    case 'a':
        newData->next = dataHeader;
        dataHeader = newData;
        break;
    case 'b':
        // 如果数据错误则循环，而不是直接返回，输入的防止信息丢失
        do
        {
            loop = FALSE;
            puts("请输入学号:");
            gets(stuNum);
            stuNum[STR_SIZE - 1] = '\0';

            if (EMPTYSTR(stuNum))
            {
                puts("学号为空!");
                loop = TRUE;
            }

            data = getDataAddr(stuNum);

            if (data == NULL)
            {
                puts("未找到学号!");
                loop = TRUE;
            }
        }
        while (loop);

        newData->next = data->next;
        data->next = newData;

        if (data == dataTail)
        {
            dataTail = newData;
            dataTail->next = NULL;
        }

        break;
    case 'c':
        // 如果数据错误则循环，而不是直接返回，输入的防止信息丢失
        do
        {
            loop = FALSE;
            puts("请输入编号:");
            gets(s_id);
            s_id[STR_SIZE - 1] = '\0';

            if (EMPTYSTR(s_id))
            {
                puts("编号为空!");
                loop = TRUE;
            }

            data = getDataAddrById(atoi(s_id));

            if (data == NULL)
            {
                puts("未找到编号!");
                loop = TRUE;
            }
        }
        while (loop);

        newData->next = data->next;
        data->next = newData;

        if (data == dataTail)
        {
            dataTail = newData;
            dataTail->next = NULL;
        }

        break;
    case 'd':
        dataTail->next = newData;
        dataTail = newData;
        dataTail->next = NULL;
        break;
    default:
        break;
    }

    puts("数据已添加.");
}




void searchData()
{
    STUDATA *data;
    int schCount;
    int id;
    char choice;
    char schContent[STR_SIZE];

    puts("[查找数据]");

    if (!fileOpened)
    {
        puts("未打开文件.");
        return;
    }

    puts("a. 学号   b. 姓名   c. 身份证号  d. 班级     e. 学院   f. 专业");
    puts("g. 学制   h. 电话   i. QQ号      j. E-Mail   k. 宿舍   l. 籍贯");
    choice = tolower(getch());

    if (choice < 'a' || choice > 'l')
    {
        return;
    }

    puts("查找内容: (不分大小写)");
    gets(schContent);
    schContent[STR_SIZE - 1] = '\0';

    if (EMPTYSTR(schContent))
    {
        puts("查找内容为空!");
        return;
    }

    puts("查找结果: (显示结果为学号)");
    data = dataHeader;
    id = 0;
    schCount = 0;

    while (data != NULL)
    {
        switch (choice)
        {
        case 'a':
            if (strstrEx(data->stuNum, schContent) != NULL)
            {
                schCount++;
                printf("%06d: %s\n", id, data->stuNum);
            }
            break;
        case 'b':
            SEARCH_DATA(data->name);
            break;
        case 'c':
            SEARCH_DATA(data->stuId);
            break;
        case 'd':
            SEARCH_DATA(data->className);
            break;
        case 'e':
            SEARCH_DATA(data->institute);
            break;
        case 'f':
            SEARCH_DATA(data->major);
            break;
        case 'g':
            if (atoi(schContent) == data->years)
            {
                schCount++;
                printf("%06d: %-20s: %d\n", id, data->stuNum, data->years);
            }
            break;
        case 'h':
            SEARCH_DATA(data->phoneNum);
            break;
        case 'j':
            SEARCH_DATA(data->qqNum);
            break;
        case 'k':
            SEARCH_DATA(data->domitory);
            break;
        case 'l':
            SEARCH_DATA(data->origion);
            break;
        default:
            break;
        }

        if (schCount % 50 == 0 && schCount > 0)
        {
            getch();
        }

        id++;
        data = data->next;
    }

    printf("共查找到%d项, 在主界面用l列出详细数据.\n", schCount);
}




void modifyData()
{
    STUDATA *data;
    STUDATA *newData;
    char stuNum[STR_SIZE];
    char s_id[STR_SIZE];
    char choice;

    puts("[修改数据]");

    if (!fileOpened)
    {
        puts("未打开文件.");
        return;
    }

    puts("请选择定位方式:");
    puts("a. 学号   b. 编号");
    choice = tolower(getch());

    if (choice < 'a' || choice > 'b')
    {
        return;
    }

    switch (choice)
    {
    case 'a':
        puts("请输入学号:");
        gets(stuNum);
        stuNum[STR_SIZE - 1] = '\0';

        if (EMPTYSTR(stuNum))
        {
            puts("学号为空!");
            return;
        }

        data = getDataAddr(stuNum);

        if (data == NULL)
        {
            puts("未找到学号!");
            return;
        }

        break;
    case 'b':
        puts("请输入编号:");
        gets(s_id);
        s_id[STR_SIZE - 1] = '\0';

        if (EMPTYSTR(s_id))
        {
            puts("编号为空!");
            return;
        }

        data = getDataAddrById(atoi(s_id));

        if (data == NULL)
        {
            puts("未找到编号!");
            return;
        }

        break;
    default:
        break;
    }

    puts("原数据:");
    printData(data);
    puts("------------------------------------------------------------------");
    puts("请输入新数据: (留空保持该项不变)");
    newData = (STUDATA *)malloc(sizeof(STUDATA));
    inputData(newData, INPUT_DATA_MODIFY);

    // 判断是否修改原数据
    MODIFY_DATA(data->stuNum, newData->stuNum);
    MODIFY_DATA(data->name, newData->name);
    MODIFY_DATA(data->stuId, newData->stuId);
    MODIFY_DATA(data->className, newData->className);
    MODIFY_DATA(data->institute, newData->institute);
    MODIFY_DATA(data->major, newData->major);
    if (newData->years != 0)
    {
        data->years = newData->years;
    }
    MODIFY_DATA(data->phoneNum, newData->phoneNum);
    MODIFY_DATA(data->qqNum, newData->qqNum);
    MODIFY_DATA(data->email, newData->email);
    MODIFY_DATA(data->domitory, newData->domitory);
    MODIFY_DATA(data->origion, newData->origion);

    fileModified = TRUE;
    puts("修改完成.");
}




void deleteData()
{
    STUDATA *data;
    STUDATA *prevData;
    char stuNum[STR_SIZE];
    char s_id[STR_SIZE];
    char choice;

    puts("[删除数据]");

    if (!fileOpened)
    {
        puts("未打开文件.");
        return;
    }

    puts("请选择定位方式:");
    puts("a. 学号   b. 编号");
    choice = tolower(getch());

    if (choice < 'a' || choice > 'b')
    {
        return;
    }

    switch (choice)
    {
    case 'a':
        puts("请输入学号:");
        gets(stuNum);
        stuNum[STR_SIZE - 1] = '\0';

        if (EMPTYSTR(stuNum))
        {
            puts("学号为空!");
            return;
        }

        prevData = getPrevDataAddr(stuNum);
        data = getDataAddr(stuNum);

        if (data == NULL)
        {
            puts("未找到学号!");
            return;
        }

        break;
    case 'b':
        puts("请输入编号:");
        gets(s_id);
        s_id[STR_SIZE - 1] = '\0';

        if (EMPTYSTR(s_id))
        {
            puts("编号为空!");
            return;
        }

        prevData = getPrevDataAddrById(atoi(s_id));
        data = getDataAddrById(atoi(s_id));

        if (data == NULL)
        {
            puts("未找到编号!");
            return;
        }

        break;
    default:
        break;
    }

    // 删除的节点是头
    if (data == dataHeader)
    {
        dataHeader = data->next;
    }
    else
    {
        prevData->next = data->next;

        // 删除的是尾
        if (data == dataTail)
        {
            dataTail = prevData;
        }
    }

    free(data);
    dataCount--;
    fileModified = TRUE;
    puts("已删除.");
}




void moveData()
{
    STUDATA *srcData;
    char stuNum[STR_SIZE];
    char s_id[STR_SIZE];
    char choice;

    puts("[移动数据]");

    if (!fileOpened)
    {
        puts("未打开文件.");
        return;
    }

    if (dataCount < 2)
    {
        puts("没有足够数据来移动.");
        return;
    }

    puts("请选择定位方式:");
    puts("a. 学号   b. 编号");
    choice = tolower(getch());

    if (choice < 'a' || choice > 'b')
    {
        return;
    }

    switch (choice)
    {
    case 'a':
        puts("请输入学号:");
        gets(stuNum);
        stuNum[STR_SIZE - 1] = '\0';

        if (EMPTYSTR(stuNum))
        {
            puts("学号为空!");
            return;
        }

        srcData = getDataAddr(stuNum);

        if (srcData == NULL)
        {
            puts("未找到学号!");
            return;
        }

        break;
    case 'b':
        puts("请输入编号:");
        gets(s_id);
        s_id[STR_SIZE - 1] = '\0';

        if (EMPTYSTR(s_id))
        {
            puts("编号为空!");
            return;
        }

        srcData = getDataAddrById(atoi(s_id));

        if (srcData == NULL)
        {
            puts("未找到编号!");
            return;
        }

        break;
    default:
        break;
    }

    moveDataTo(srcData);
    fileModified = TRUE;
}




void moveDataTo(STUDATA *srcData)
{
    STUDATA *srcPrevData;
    STUDATA *destData;
    STUDATA *tailPrevData;
    //char stuNum[STR_SIZE];
    //char s_id[STR_SIZE];
    char numStr[STR_SIZE];
    char *promptPrefix;
    char choice;

    puts("移动到:");
    puts("a. 信息簿头   b. 某学号之后   c. 某编号之后   d. 信息簿尾");
    choice = tolower(getch());

    if (choice < 'a' || choice > 'd')
    {
        return;
    }

    srcPrevData = getPrevDataAddr(srcData->stuNum);
    tailPrevData =getPrevDataAddr(dataTail->stuNum);

    switch (choice)
    {
    case 'a':
        if (srcData == dataHeader)
        {
            puts("目标位置与原位置相同.");
            return;
        }
        else if (srcData == dataTail)
        {
            dataTail = tailPrevData;
            dataTail->next = NULL;
        }
        else
        {
            srcPrevData->next = srcData->next;
        }

        srcData->next = dataHeader;
        dataHeader = srcData;
        break;
    case 'b':
    case 'c':
        promptPrefix = (choice == 'b') ? "学号" : "编号";
        printf("请输入%s:\n", promptPrefix);
        gets(numStr);
        numStr[STR_SIZE - 1] = '\0';

        if (EMPTYSTR(numStr))
        {
            printf("%s为空!\n", promptPrefix);
            return;
        }

        destData = (choice == 'b') ? getDataAddr(numStr) : getDataAddrById(atoi(numStr));

        if (destData == NULL)
        {
            printf("%s不存在!\n", promptPrefix);
            return;
        }

        if (srcData == destData)
        {
            puts("目标位置与原位置相同.");
            return;
        }

        if (srcData == dataHeader)
        {
            // 移动头
            dataHeader = srcData->next;

            if (destData == dataTail)
            {
                // 头移动到尾
                dataTail->next = srcData;
                dataTail = srcData;
                dataTail->next = NULL;
            }
            else
            {
                // 头移动到中间
                srcData->next = destData->next;
                destData->next = srcData;
            }
        }
        else if (srcData == dataTail)
        {
            // 移动尾
            dataTail = tailPrevData;
            dataTail->next = NULL;

            if (destData == dataHeader)
            {
                // 尾移动到头
                srcData->next = dataHeader;
                dataHeader = srcData;
            }
            else
            {
                // 尾移动到中间
                srcData->next = destData->next;
                destData->next = srcData;
            }
        }
        else
        {
            // 移动中间
            srcPrevData->next = srcData->next;

            if (destData == dataHeader)
            {
                // 中间移动到头
                srcData->next = dataHeader;
                dataHeader = srcData;
            }
            else if (destData == dataTail)
            {
                // 中间移动到尾
                dataTail->next = srcData;
                dataTail = srcData;
                dataTail->next = NULL;
            }
            else
            {
                // 中间移动到中间
                srcData->next = destData->next;
                destData->next = srcData;
            }
        }

        break;
    case 'd':
        if (srcData == dataHeader)
        {
            dataHeader = srcData->next;
        }
        else if (srcData == dataTail)
        {
            puts("目标位置与原位置相同.");
            return;
        }
        else
        {
            srcPrevData->next = srcData->next;
        }

        dataTail->next = srcData;
        dataTail = srcData;
        dataTail->next = NULL;
        break;
    default:
        break;
    }

    puts("移动完成.");
}




void bookProperty()
{
    long size;
    double d_size;
    char *sizeFmt;
    char *sizeExt;

    puts("[信息簿属性]");

    if (!fileOpened)
    {
        puts("未打开文件.");
        return;
    }

    size = INT_SIZE + sizeof(STUDATA) * dataCount;
    sizeFmt = "文件大小: %.2lf %s\n";

    if (size < 0x400)
    {
        d_size = (double)size;
        sizeFmt = "文件大小: %.0lf %s\n";
        sizeExt = "B";
    }
    else if (size < 0x100000)
    {
        d_size = (double)size / 0x400;
        sizeExt = "KB";
    }
    else
    {
        d_size = (double)size / 0x100000;
        sizeExt = "MB";
    }

    printf("文件名: %s\n", bookName);
    printf(sizeFmt, d_size, sizeExt);
    printf("数据数量: %d\n", dataCount);
}




/***********
 * inputData
 " - 读取信息
 * 参数
 * - data 目标数据
 * - mode 输入模式
 * -   INPUT_DATA_ADD 增加数据，学号不能重复或为空
 * -   INPUT_DATA_ADD 修改数据，学号不能重复
 * 返回
 * - 无
 */
void inputData(STUDATA *data, int mode)
{
    char s_years[STR_SIZE];
    BOOL loop;

    do
    {
        loop = FALSE;
        printf("学号：  ");
        gets(data->stuNum);

        if (mode == INPUT_DATA_ADD && EMPTYSTR(data->stuNum))
        {
            puts("学号为空!");
            loop = TRUE;
            continue;
        }
        if (!EMPTYSTR(data->stuNum) && getDataAddr(data->stuNum) != NULL)
        {
            puts("学号已存在!");
            loop = TRUE;
            continue;
        }
    }
    while (loop);

    data->stuNum[STR_SIZE - 1] = '\0';
    printf("姓名：  ");
    gets(data->name);
    data->name[STR_SIZE - 1] = '\0';
    printf("身份证：");
    gets(data->stuId);
    data->stuId[STR_SIZE - 1] = '\0';
    strToUpper(data->stuId);
    printf("班级：  ");
    gets(data->className);
    data->className[STR_SIZE - 1] = '\0';
    printf("学院：  ");
    gets(data->institute);
    data->institute[STR_SIZE - 1] = '\0';;
    printf("专业：  ");
    gets(data->major);
    data->major[STR_SIZE - 1] = '\0';
    printf("学制：  ");
    gets(s_years);
    s_years[STR_SIZE - 1] = '\0';
    data->years = atoi(s_years);
    printf("电话：  ");
    gets(data->phoneNum);
    data->phoneNum[STR_SIZE - 1] = '\0';
    printf("QQ号：  ");
    gets(data->qqNum);
    data->qqNum[STR_SIZE - 1] = '\0';
    printf("E-Mail：");
    gets(data->email);
    data->email[STR_SIZE - 1] = '\0';
    printf("宿舍：  ");
    gets(data->domitory);
    data->domitory[STR_SIZE - 1] = '\0';
    printf("籍贯：  ");
    gets(data->origion);
    data->origion[STR_SIZE - 1] = '\0';

    #ifdef TCC
        INPUT_DATA(data->stuNum);
        INPUT_DATA(data->name);
        INPUT_DATA(data->stuId);
        INPUT_DATA(data->className);
        INPUT_DATA(data->institute);
        INPUT_DATA(data->major);
        INPUT_DATA(data->phoneNum);
        INPUT_DATA(data->qqNum);
        INPUT_DATA(data->email);
        INPUT_DATA(data->domitory);
        INPUT_DATA(data->origion);
    #endif
}




void printData(const STUDATA *data)
{
    puts("------------------------------------------------------------------");
    printf("学号:   %s\n", data->stuNum);
    printf("姓名:   %s\n", data->name);
    printf("身份证: %s\n", data->stuId);
    printf("班级:   %s\n", data->className);
    printf("学院:   %s\n", data->institute);
    printf("专业:   %s\n", data->major);
    printf("学制:   %d\n", data->years);
    printf("电话:   %s\n", data->phoneNum);
    printf("QQ号:   %s\n", data->qqNum);
    printf("E-Mail: %s\n", data->email);
    printf("宿舍:   %s\n", data->domitory);
    printf("籍贯:   %s\n", data->origion);
}




/******************************
 * getPrevDataAddr -> STUDATA *
 * - 通过学号查找前一个节点的地址
 * 参数
 * - stuNum 学号
 * 返回
 * - 该节点的地址
 */
STUDATA *getPrevDataAddr(const char *stuNum)
{
    STUDATA *data;
    STUDATA *prevData;

    prevData = dataHeader;
    data = dataHeader;

    while (data != NULL && strncmpEx(stuNum, data->stuNum, strlen(stuNum)) != 0)
    {
        prevData = data;
        data = data->next;
    }

    return prevData;
}




/**************************
 * getDataAddr -> STUDATA *
 * - 通过学号查找节点地址
 * 参数
 * - stuNum 学号
 * 返回
 * - 该节点的地址
 */
STUDATA *getDataAddr(const char *stuNum)
{
    STUDATA *data;

    data = dataHeader;

    while (data != NULL && strncmpEx(stuNum, data->stuNum, strlen(stuNum)) != 0)
    {
        data = data->next;
    }

    return data;
}




/**********************************
 * getPrevDataAddrById -> STUDATA *
 * - 通过内部编号查找前一个节点的地址
 * 参数
 * - id 内部编号
 * 返回
 * - 该节点的地址
 */
STUDATA *getPrevDataAddrById(int id)
{
    STUDATA *prevData;
    STUDATA *data;
    int curId;

    prevData = dataHeader;
    data = dataHeader;
    curId = 0;

    while (data != NULL && curId != id)
    {
        curId++;
        prevData = data;
        data = data->next;
    }

    return prevData;
}




/******************************
 * getDataAddrById -> STUDATA *
 * - 通过内部编号查找节点的地址
 * 参数
 * - id 内部编号
 * 返回
 * - 该节点地址
 */
STUDATA *getDataAddrById(int id)
{
    STUDATA *data;
    int curId;

    data = dataHeader;
    curId = 0;

    while (data != NULL && curId != id)
    {
        curId++;
        data = data->next;
    }

    return data;
}




/*********************
 * getFileSize -> long
 * - 获取文件大小
 * 参数
 * - file 文件
 * 返回
 * - 文件大小
 */
long getFileSize(FILE *file)
{
    long curPos;
    long size;

    // 保存当前指针位置
    curPos = ftell(file);
    fseek(file, 0, SEEK_END);
    size = ftell(file);
    // 恢复文件指针位置
    fseek(file, curPos, SEEK_SET);

    return size;
}




/**********************
 * strToUpper -> char *
 * - 转换字符串为大写
 * 参数
 * - str 目标字符串
 * 返回
 * - 源字符串
 * 备注
 * - 不能转换常量字符串。
 */
char *strToUpper(char *str)
{
    while (*str != '\0')
    {
        *str = toupper(*str);
        str++;
    }

    return str;
}




/*****************
 * strcmpEx -> int
 * - 比较字符串，不区分大小写
 * 参数
 * - str1, str2 比较的字符串
 " 返回
 * - 比较后的结果
 */
int strcmpEx(const char *str1, const char *str2)
{
    while (tolower(*str1) == tolower(*str2) && *str1 != '\0' && *str2 != '\0')
    {
        str1++;
        str2++;
    }

    return (*str1 - *str2);
}




/******************
 * strncmpEx -> int
 * - 比较字符串，最大长度为n，不区分大小写
 * 参数
 * - str1, str2 比较的字符串
 * - n 比较的最大长度
 * 返回
 * - 比较后的结果
 */
int strncmpEx(const char *str1, const char *str2, int n)
{
    while (--n >= 0 && tolower(*str1) == tolower(*str2) && *str1 != '\0' && *str2 != '\0')
    {
        str1++;
        str2++;
    }

    return (n < 0 || *str1 == '\0' || *str2 == '\0') ? 0 : (*str1 - *str2);
}
/*int _strncmpEx(const char *str1, const char *str2, int n)
{
    char *tmpStr1;
    char *tmpStr2;
    int slen1;
    int slen2;

    slen1 = strlen(str1);
    slen2 = strlen(str2);
    tmpStr1 = (char *)malloc(slen1);
    tmpStr2 = (char *)malloc(slen2);

    if (n > slen1 || n > slen2)
    {
        //n = (slen1 > slen2) ? slen2 : slen1;
        n = slen1;
    }

    strncpy(tmpStr1, str1, n);
    strncpy(tmpStr2, str2, n);

    return strcmpEx(tmpStr1, tmpStr2);
}*/




/********************
 * strstrEx -> char *
 * - 查找字符串，不区分大小写
 * 参数
 * - strIn 查找的字符串位置
 *   strBy 要查找的内容
 * 返回
 * - 查找到的地址。
 * 备注
 * - 返回的地址将不可用，只能作为判断是否查找到的依据。
 */
char *strstrEx(const char *strIn, const char *strBy)
{
    char *tmpStrIn;
    char *tmpStrBy;
    char *result;

    tmpStrIn = (char *)malloc(strlen(strIn) + 1);
    tmpStrBy = (char *)malloc(strlen(strBy) + 1);
    strcpy(tmpStrIn, strIn);
    strcpy(tmpStrBy, strBy);
    strToUpper(tmpStrIn);
    strToUpper(tmpStrBy);
    result = strstr(tmpStrIn, tmpStrBy);
    free(tmpStrIn);
    free(tmpStrBy);

    return result;
}
