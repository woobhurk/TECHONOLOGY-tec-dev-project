#ifndef DATA_MOVE_H
#define DATA_MOVE_H

#include "types.h"


void moveData();
STUDATA *getMoveSrcData();
int getMoveDest();
STUDATA *getMoveDestData(int, STUDATA *);
void moveDataTo(int, STUDATA *, STUDATA *);
#endif /* data_move.h */
