/********
 * data.c
 * �����ݽ��в�����
 */

#include <stdio.h>
//#include <conio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <malloc.h>
#include "data.h"
#include "data_add.h"
#include "data_move.h"
#include "data_get.h"
#include "data_io.h"
#include "utils.h"
#include "types.h"
#include "const.h"
#include "global.h"


/**********
 * listData
 * - �г�����
 */
void listData()
{
    STUDATA *data;
    char stuNum[STR_SIZE];
    char s_id[STR_SIZE];
    char choice;
    int cnt;
    int pauseCnt;

    puts("[�г�����]");

    if (!fileOpened)
    {
        puts("δ���ļ�.");
        return;
    }

    puts("a. �г�ѧ�Ŷ�Ӧ����     b. �г���Ŷ�Ӧ����");
    puts("c. �г�����ѧ�ź�����   d. �г���������(���ܽ϶�)");
    choice = tolower(getch());

    if (choice < 'a' || choice > 'd')
    {
        return;
    }

    switch (choice)
    {
    case 'a':
        puts("������ѧ��:");
        gets(stuNum);
        stuNum[STR_SIZE - 1] = '\0';

        if (EMPTYSTR(stuNum))
        {
            puts("ѧ��Ϊ��!");
            break;
        }

        data = getDataAddr(stuNum);

        if (data == NULL)
        {
            puts("δ�ҵ�ѧ��!");
            break;
        }

        printData(data);
        break;
    case 'b':
        puts("��������:");
        gets(s_id);
        s_id[STR_SIZE - 1] = '\0';

        if (EMPTYSTR(s_id))
        {
            puts("���Ϊ��!");
            break;
        }

        data = getDataAddrById(atoi(s_id));

        if (data == NULL)
        {
            puts("δ�ҵ����!");
            break;
        }

        printData(data);
        break;
    case 'c':
    case 'd':
        data = dataHeader;
        cnt = 0;
        pauseCnt = (choice == 'c') ? 40 : 5;

        while (data != NULL)
        {
            if (choice == 'c')
            {
                printf("%06d: %-20s: %s\n", cnt, data->stuNum, data->name);
            }
            else
            {
                printData(data);
            }

            data = data->next;
            cnt++;

            if (cnt % pauseCnt == 0 && dataCount > pauseCnt)
            {
                puts("���������, e�˳�...");

                if (tolower(getch()) == 'e')
                {
                    break;
                }
            }
        }

        break;
    default:
        break;
    }
}




/************
 * addData
 * - ��������
 */
void addData()
{
    STUDATA *newData;
    STUDATA *destData;
    int addDest;

    puts("[��������]");

    if (!fileOpened)
    {
        puts("δ���ļ�.");
        return;
    }

    newData = (STUDATA *)malloc(sizeof(STUDATA));
    inputData(newData, INPUT_DATA_ADD);

    // ���ԭ������û��������ֱ�����ӣ�������ʾ����λ��
    if (dataHeader == NULL)
    {
        addDataTo(ADD_DATA_HEADER, newData, NULL);
    }
    else
    {
        addDest = getAddDest();
        destData = getAddDestData(addDest);
        addDataTo(addDest, newData, destData);
    }

    dataCount++;
    fileModified = TRUE;
    puts("����������.");
}




/************
 * searchData
 * - ��������
 */
void searchData()
{
    STUDATA *data;
    int schCount;
    int id;
    char choice;
    char schContent[STR_SIZE];

    puts("[��������]");

    if (!fileOpened)
    {
        puts("δ���ļ�.");
        return;
    }

    puts("a. ѧ��   b. ����   c. ����֤��  d. �༶     e. ѧԺ   f. רҵ");
    puts("g. ѧ��   h. �绰   i. QQ��      j. E-Mail   k. ����   l. ����");
    choice = tolower(getch());

    if (choice < 'a' || choice > 'l')
    {
        return;
    }

    puts("��������: (���ִ�Сд)");
    gets(schContent);
    schContent[STR_SIZE - 1] = '\0';

    if (EMPTYSTR(schContent))
    {
        puts("��������Ϊ��!");
        return;
    }

    puts("���ҽ��: (��ʾ���Ϊѧ��)");
    data = dataHeader;
    id = 0;
    schCount = 0;

    while (data != NULL)
    {
        switch (choice)
        {
        case 'a':
            if (strstrEx(data->stuNum, schContent) != NULL)
            {
                schCount++;
                printf("%06d: %s\n", id, data->stuNum);
            }
            break;
        case 'b':
            SEARCH_DATA(data->name);
            break;
        case 'c':
            SEARCH_DATA(data->stuId);
            break;
        case 'd':
            SEARCH_DATA(data->className);
            break;
        case 'e':
            SEARCH_DATA(data->institute);
            break;
        case 'f':
            SEARCH_DATA(data->major);
            break;
        case 'g':
            if (atoi(schContent) == data->years)
            {
                schCount++;
                printf("%06d: %-20s: %d\n", id, data->stuNum, data->years);
            }
            break;
        case 'h':
            SEARCH_DATA(data->phoneNum);
            break;
        case 'j':
            SEARCH_DATA(data->qqNum);
            break;
        case 'k':
            SEARCH_DATA(data->domitory);
            break;
        case 'l':
            SEARCH_DATA(data->origion);
            break;
        default:
            break;
        }

        if (schCount % 50 == 0 && schCount > 0)
        {
            getch();
        }

        id++;
        data = data->next;
    }

    printf("�����ҵ�%d��, ����������l�г���ϸ����.\n", schCount);
}




/************
 * modifyData
 * - �޸�����
 */
void modifyData()
{
    STUDATA *data;
    STUDATA *newData;
    char stuNum[STR_SIZE];
    char s_id[STR_SIZE];
    char choice;

    puts("[�޸�����]");

    if (!fileOpened)
    {
        puts("δ���ļ�.");
        return;
    }

    puts("��ѡ��λ��ʽ:");
    puts("a. ѧ��   b. ���");
    choice = tolower(getch());

    if (choice < 'a' || choice > 'b')
    {
        return;
    }

    switch (choice)
    {
    case 'a':
        puts("������ѧ��:");
        gets(stuNum);
        stuNum[STR_SIZE - 1] = '\0';

        if (EMPTYSTR(stuNum))
        {
            puts("ѧ��Ϊ��!");
            return;
        }

        data = getDataAddr(stuNum);

        if (data == NULL)
        {
            puts("δ�ҵ�ѧ��!");
            return;
        }

        break;
    case 'b':
        puts("��������:");
        gets(s_id);
        s_id[STR_SIZE - 1] = '\0';

        if (EMPTYSTR(s_id))
        {
            puts("���Ϊ��!");
            return;
        }

        data = getDataAddrById(atoi(s_id));

        if (data == NULL)
        {
            puts("δ�ҵ����!");
            return;
        }

        break;
    default:
        break;
    }

    puts("ԭ����:");
    printData(data);
    puts("------------------------------------------------------------------");
    puts("������������: (���ձ��ָ����)");
    newData = (STUDATA *)malloc(sizeof(STUDATA));
    inputData(newData, INPUT_DATA_MODIFY);

    // �ж��Ƿ��޸�ԭ����
    MODIFY_DATA(data->stuNum, newData->stuNum);
    MODIFY_DATA(data->name, newData->name);
    MODIFY_DATA(data->stuId, newData->stuId);
    MODIFY_DATA(data->className, newData->className);
    MODIFY_DATA(data->institute, newData->institute);
    MODIFY_DATA(data->major, newData->major);
    if (newData->years != 0)
    {
        data->years = newData->years;
    }
    MODIFY_DATA(data->phoneNum, newData->phoneNum);
    MODIFY_DATA(data->qqNum, newData->qqNum);
    MODIFY_DATA(data->email, newData->email);
    MODIFY_DATA(data->domitory, newData->domitory);
    MODIFY_DATA(data->origion, newData->origion);

    fileModified = TRUE;
    puts("�޸����.");
}




/************
 * deleteData
 * - ɾ������
 */
void deleteData()
{
    STUDATA *data;
    STUDATA *prevData;
    char stuNum[STR_SIZE];
    char s_id[STR_SIZE];
    char choice;

    puts("[ɾ������]");

    if (!fileOpened)
    {
        puts("δ���ļ�.");
        return;
    }

    puts("��ѡ��λ��ʽ:");
    puts("a. ѧ��   b. ���");
    choice = tolower(getch());

    if (choice < 'a' || choice > 'b')
    {
        return;
    }

    switch (choice)
    {
    case 'a':
        puts("������ѧ��:");
        gets(stuNum);
        stuNum[STR_SIZE - 1] = '\0';

        if (EMPTYSTR(stuNum))
        {
            puts("ѧ��Ϊ��!");
            return;
        }

        prevData = getPrevDataAddr(stuNum);
        data = getDataAddr(stuNum);

        if (data == NULL)
        {
            puts("δ�ҵ�ѧ��!");
            return;
        }

        break;
    case 'b':
        puts("��������:");
        gets(s_id);
        s_id[STR_SIZE - 1] = '\0';

        if (EMPTYSTR(s_id))
        {
            puts("���Ϊ��!");
            return;
        }

        prevData = getPrevDataAddrById(atoi(s_id));
        data = getDataAddrById(atoi(s_id));

        if (data == NULL)
        {
            puts("δ�ҵ����!");
            return;
        }

        break;
    default:
        break;
    }

    // ɾ���Ľڵ���ͷ
    if (data == dataHeader)
    {
        dataHeader = data->next;
    }
    else
    {
        prevData->next = data->next;

        // ɾ������β
        if (data == dataTail)
        {
            dataTail = prevData;
        }
    }

    free(data);
    dataCount--;
    fileModified = TRUE;
    puts("��ɾ��.");
}



/**********
 * moveData
 * - �ƶ�����
 */
void moveData()
{
    STUDATA *srcData;
    STUDATA *destData;
    int moveDest;

    puts("[�ƶ�����]");

    if (!fileOpened)
    {
        puts("δ���ļ�.");
        return;
    }

    if (dataCount < 2)
    {
        puts("û���㹻�������ƶ�.");
        return;
    }

    srcData = getMoveSrcData();

    if (srcData == NULL)
    {
        return;
    }

    moveDest = getMoveDest();

    if (moveDest < 0)
    {
        return;
    }

    destData = getMoveDestData(moveDest, srcData);

    if (destData == NULL)
    {
        return;
    }

    moveDataTo(moveDest, srcData, destData);
    fileModified = TRUE;
    puts("�ƶ����.");
}
