#ifndef MAIN_H
#define MAIN_H


void initVars();
void showMenu();
void getOperation();
void exitProg();
void clearScreen();
#endif /* main.h */
