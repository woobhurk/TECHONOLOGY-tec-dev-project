/********
 * main.c
 * ����������������
 */

#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <ctype.h>
#include "main.h"
#include "book.h"
#include "data.h"
#include "types.h"
#include "const.h"
#include "global.h"


char bookName[STR_SIZE];
STUDATA *dataHeader;
STUDATA *dataTail;
int dataCount;
BOOL fileOpened;
BOOL fileModified;


int main()
{
    initVars();

    while (TRUE)
    {
        showMenu();
        getOperation();
    }

    return 0;
}




/**********
 * initVars
 * - ��ʼ������
 */
void initVars()
{
    dataHeader = NULL;
    dataTail = NULL;
    dataCount = 0;
    fileOpened = FALSE;
    fileModified = FALSE;
}




/**********
 * showMenu
 * - ��ʾ�˵�
 */
void showMenu()
{
    //printf("---- %d, %d, %d, %d\n", strncmpEx("abc", "aBCD", 3), strncmpEx("ab", "aBCdEf", 3), strncmp("ef", "eGf", 10), strncmpEx("ancGs", "Anc", 20));
    puts("##################################################################");
    puts("#                          ѧ �� �� Ϣ ��                        #");
    puts("# �ļ�                                                           #");
    puts("#  n. �½�      o. ��     s. ����     S. ����Ϊ      c. �ر�   #");
    puts("#  E. �˳�                                                       #");
    puts("# ����                                                           #");
    puts("#  l. �г�      a. ����     f. ����     m. �޸�        d. ɾ��   #");
    puts("#  v. �ƶ�      p. ����     C. ����                              #");
    puts("##################################################################");

    // ��ʾ�򿪵��ļ�
    if (fileOpened)
    {
        printf("# <%s>%c\n", bookName, fileModified ? '*' : ' ');
    }

    puts("��ѡ�����: ");
}




/**************
 * getOperation
 * - ��ȡ�û�����
 */
void getOperation()
{
    char op;
    BOOL loop;

    do
    {
        loop = FALSE;
        op = getch();

        switch (op)
        {
        case 'n':
            newBook();
            break;
        case 'o':
            openBook();
            break;
        case 's':
            saveBook();
            break;
        case 'S':
            saveBookAs();
            break;
        case 'c':
            closeBook();
            break;
        case 'E':
            exitProg();
            break;
        case 'l':
            listData();
            break;
        case 'a':
            addData();
            break;
        case 'f':
            searchData();
            break;
        case 'm':
            modifyData();
            break;
        case 'd':
            deleteData();
            break;
        case 'v':
            moveData();
            break;
        case 'p':
            bookProperty();
            break;
        case 'C':
            clearScreen();
            return;
            break;
        default:
            loop = TRUE;
            break;
        }
    }
    while (loop);

    puts("���������...");
    getch();
    puts("\n\n");
}




/**********
 * exitProg
 * - �˳�����
 */
void exitProg()
{
    puts("[�˳�����]");

    if (fileOpened && fileModified)
    {
        askToSave();
    }

    exit(0);
}




/*************
 * clearScreen
 * - ����
 */
void clearScreen()
{
    #ifdef LINUX
        system("clear");
    #else
        system("cls");
    #endif
}
