#ifndef DATA_GET_H
#define DATA_GET_H

#include "types.h"


STUDATA *getPrevDataAddr(const char *);
STUDATA *getDataAddr(const char *);
STUDATA *getPrevDataAddrById(int);
STUDATA *getDataAddrById(int);
#endif /* data_get.h */
