#encoding = utf-8
'''TCP Server

实验中……
'''

import socket

HOST = "";
PORT = 8888;

sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM);
try:
    sock.bind((HOST, PORT));
except socket.error as errexp:
    print("bind error: ", errexp);
    exit(1);
sock.listen(10);
newconn, newaddr = sock.accept();

# Server端先接收数据后发送。
while True:
    recvdata = newconn.recv(4096);
    # 将byte转换为str。
    print("$ " + recvdata.decode());
    senddata = input("#>> ");
    try:
        # Python3中需要将str转换为byte才能发送。
        newconn.sendall(senddata.encode());
    except socket.error as errexp:
        print("send error: ", errexp);
        exit(2);

newconn.close();
sock.close();
