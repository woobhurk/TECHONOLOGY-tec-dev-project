#encoding = utf-8
'''UDP Client

实验中……
'''

import socket

HOST = "localhost";
PORT = 8888;

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM);

while True:
    try:
        senddata = input("$$$ ");
        sock.sendto(senddata.encode(), (HOST, PORT));
        recvdata, newaddr = sock.recvfrom(4096);
        #print("newaddr: ", newaddr);
        print("# " + recvdata.decode());
    except socket.error as errexp:
        print("errexp: ", errexp);
        exit(1);

sock.close();
