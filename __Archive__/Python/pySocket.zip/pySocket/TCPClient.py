#encoding = utf-8
'''TCP Client

实验中……
'''

import socket

HOST = "localhost";
PORT = 8888;

try:
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM);
except socket.error as errexp:
    print("create socket error: ", errexp);
    exit(1);
sock.connect((HOST, PORT));

# Client端先发送数据后接收。
while True:
    senddata = input("$>> ");
    try:
        # Python3中需要将str转换为byte才能发送。
        sock.sendall(senddata.encode());
    except socket.error as errexp:
        print("send error: ", errexp);
        exit(2);
    recvdata = sock.recv(4096);
    # 将byte转换为str。
    print("# " + recvdata.decode());

sock.close();
