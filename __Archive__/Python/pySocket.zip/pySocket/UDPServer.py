#encoding = utf-8
'''UDP Server

实验中……
'''

import socket

HOST = "";
PORT = 8888;

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM);
sock.bind((HOST, PORT));

while True:
    try:
        recvdata, newaddr = sock.recvfrom(4096);
        #print("newaddr: ", newaddr);
        print("$ " + recvdata.decode());
        senddata = input("### ");
        sock.sendto(senddata.encode(), newaddr);
    except socket.error as errexp:
        print("errexp: ", errexp);
        exit(1);

sock.close();
