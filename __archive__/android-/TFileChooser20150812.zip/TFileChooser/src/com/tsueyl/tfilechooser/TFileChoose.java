package com.tsueyl.tfilechooser;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.os.Environment;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TableRow.LayoutParams;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;

public class TFileChoose
{
	private Context _ctx;
	private View _ctnView;
	private PopupWindow _wndChooser;
	private Dialog _dlgChooser;
	private LinearLayout _layFileList;
	private ListView _lvFileList;
	private ArrayAdapter _aaFileList;

	private String _filePath;
	private String _fileDir;


	TFileChoose(Activity actv)
	{
		_ctx = actv.getApplicationContext();
		_ctnView = actv.getCurrentFocus();
	}



	// Public methods
	public String chooseFile()
	{
		String fileDir;

		if (Environment.getExternalStorageState().equals(Environment.MEDIA_UNMOUNTED))
		{
			fileDir = "/";
		}
		else
		{
			fileDir = Environment.getExternalStorageDirectory().getPath();
		}

		return chooseFile(fileDir);
	}

	public String chooseFile(String fileDir)
	{
		if (fileDir == null)
		{
			return null;
		}

		_fileDir = fileDir;
		_showChooser();

		return _filePath;
	}



	// Private methods
	private void _showChooser()
	{
		ArrayList<String> fileList;
		String[] fileListContents;
		Button btnCancel;

		_dlgChooser = new Dialog(_ctx);
		//_wndChooser = new PopupWindow();
		_layFileList = new LinearLayout(_ctx);
		_lvFileList = new ListView(_ctx);
		_aaFileList = new ArrayAdapter(_ctx, android.R.layout.simple_list_item_1);
		btnCancel = new Button(_ctx);

		//_wndChooser.setWindowLayoutMode(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
		//_wndChooser.setOutsideTouchable(false);
		//_wndChooser.setContentView(_layFileList);

		fileList = _getFileList(_fileDir);
		fileListContents = new String[fileList.size()];
		_aaFileList.addAll(_getFileList(_fileDir).toArray(fileListContents));
		/*_aaFileList.addAll(_arrayToString(_getFileList(_fileDir)));*/
		_lvFileList.setAdapter(_aaFileList);
		_lvFileList.setOnItemClickListener(new AdapterView.OnItemClickListener(){
			@Override
			public void onItemClick(AdapterView<?> av, View v, int pos, long id)
			{
				String dirName;
				File dir;

				dirName = (String) _aaFileList.getItem(pos);
				dir = new File(dirName);

				if (dir.isDirectory())
				{
					_fileDir += dirName;
				}
				else
				{
					_dlgChooser.dismiss();
					_filePath = _fileDir + dirName;
				}

				_updateFileList();
			}
		});

		btnCancel.setText("Cancel");
		btnCancel.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
		btnCancel.setOnClickListener(new View.OnClickListener(){
			@Override
			public void onClick(View v)
			{
				_dlgChooser.dismiss();
				_filePath = null;
			}
		});

		_layFileList.addView(_lvFileList);
		_layFileList.addView(btnCancel);
		_dlgChooser.setCancelable(false);
		_dlgChooser.setContentView(_layFileList);
		_dlgChooser.show();
		//_wndChooser.showAtLocation(_ctnView, Gravity.LEFT | Gravity.TOP, 0, 0);
	}


	private void _updateFileList()
	{
		ArrayList<String> fileList;
		String[] fileListContents;

		fileList = _getFileList(_fileDir);
		fileListContents = new String[fileList.size()];
		_aaFileList.clear();
		_aaFileList.addAll(_getFileList(_fileDir).toArray(fileListContents));
		_lvFileList.setAdapter(_aaFileList);
	}

	private ArrayList<String> _getFileList(String fileDir)
	{
		ArrayList<String> fileList;
		File fFileDir;

		//Toast.makeText(_ctx, "1111111111111", Toast.LENGTH_LONG).show();
		fileList = new ArrayList<String>();
		//Toast.makeText(_ctx, "2222222222222", Toast.LENGTH_LONG).show();
		fFileDir = new File(fileDir);
		//Toast.makeText(_ctx, "3333333333333", Toast.LENGTH_LONG).show();

		if (!fFileDir.isDirectory())
		{
			return null;
		}

		for (File dir : fFileDir.listFiles())
		{
			if (dir.isDirectory())
			{
				fileList.add(dir.getName());
			}
		}
		for (File file : fFileDir.listFiles())
		{
			if (file.isFile())
			{
				fileList.add(file.getName());
			}
		}

		return fileList;
	}


	private String[] _arrayToString(ArrayList<String> arrayList)
	{
		String[] stringList;

		stringList = new String[arrayList.size()];
		for (int i = 0; i < arrayList.size(); i++)
		{
			stringList[i] = arrayList.get(i);
		}

		return stringList;
	}
}

