/**
 * TFileChooser
 * Author: Woobhurk
 * Copyright (C) 2015 Tsueyl
 * All rights reserved.
 * *******************************
 * SDK VERSION
 *   <uses-sdk android:minSdkVersion="8" android:targetSdkVersion="21" />
 * PERMISSION
 *   <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" />
 * FREE OF LICENSE
 * *******************************
 * INTENT KEYS
 *   KEY_FILEPATH -> String
 *     The returned path of selected directory file.
 *     Return an empty string if calceled.
 *     Cause a NullPointerException if exit Activity directly.
 *   KEY_FILEDIR -> String
 *     The start path of a directory.
 *     Can be a file, but the file list will be empty.
 * *******************************
 * Version: 1.0.1 (20150812 09:51)
 * Change Log:
 * 1. Now can choose a directory.
 * *******************************
 * Version: 1.0.0 (20150812 07:35)
 * Change Log:
 *   0. THE FIRST VERSION.
 */

package com.tsueyl.tfilechooser;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TableRow.LayoutParams;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;

public class TFileChooser extends Activity
{
	public static final String KEY_FILEDIR = "KEY_FILEDIR";
	public static final String KEY_FILEPATH = "KEY_FILEPATH";
	public static final String DIR_ROOT = "/";
	public static final String DIR_EMPTY = "";
	public static final String DIR_PARENT = "DIR_PARENT";
	public static final String PREFIX_DIR = "■ ";
	public static final String PREFIX_FILE = "□ ";
	public static final String TEXT_BTNUPDIR = "▲";
	public static final String TEXT_BTNSELECT = "√";
	public static final String TEXT_BTNCALCEL = "╳";
	public static final float SIZE_TEXT = 18.0f;
	public static final int SIZE_BTNHEIGHT = 44;

	private TextView _tvFileDir;
	private LinearLayout _layFileList;
	private LinearLayout _layOptionBar;
	private ListView _lvFileList;
	private ArrayAdapter<String> _aaFileList;

	private String _filePath;
	private String _fileDir;


	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		Intent fileChooserIntent;

		super.onCreate(savedInstanceState);

		fileChooserIntent = getIntent();
		_fileDir = fileChooserIntent.getExtras().getString(KEY_FILEDIR);
		chooseFile();
		//fileChooserIntent.putExtra("KEY_filePath", "/sdcard/*");
		//fileChooserIntent.setClass(this,
		//MainActivity.class);
		//startActivity(fileChooserIntent);
		//finish();
	}


	/*@Override
	 protected void onPause()
	 {
	 Intent result;
	 super.onPause();
	 result = new Intent();
	 result.putExtra(KEY_FILEPATH, _filePath);
	 setResult(RESULT_OK, result);
	 showToast("onPause");
	 }*/

	/************
	 * chooseFile
	 *   Main method.
	 */
	private void chooseFile()
	{
		if (_fileDir.equals(DIR_EMPTY) || !(new File(_fileDir)).exists())
		{
			if (Environment.getExternalStorageState().equals(Environment.MEDIA_UNMOUNTED))
			{
				_fileDir = DIR_ROOT;
			}
			else
			{
				_fileDir = Environment.getExternalStorageDirectory().getPath();
			}
		}

		_filePath = DIR_EMPTY;
		setupChooser();
	}


	/**************
	 * setupChooser
	 *   Initialize widgets and UI and show the chooser.
	 */
	private void setupChooser()
	{
		Button btnUpDir;
		Button btnSelect;
		Button btnCancel;
		LayoutParams lpButton;
		LayoutParams lpFileList;

		_tvFileDir = new TextView(this);
		_layFileList = new LinearLayout(this);
		_layOptionBar = new LinearLayout(this);
		btnUpDir = new Button(this);
		btnSelect = new Button(this);
		btnCancel = new Button(this);
		_lvFileList = new ListView(this);
		_aaFileList = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1);

		_tvFileDir.setText(_fileDir);
		_tvFileDir.setTextSize(SIZE_TEXT);
		_tvFileDir.setTypeface(Typeface.DEFAULT_BOLD);
		_tvFileDir.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, SIZE_BTNHEIGHT / 2));

		lpButton = new LayoutParams(LayoutParams.MATCH_PARENT, SIZE_BTNHEIGHT);
		lpButton.weight = 1.0f;
		lpFileList = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);

		btnUpDir.setText(TEXT_BTNUPDIR);
		btnUpDir.setTextSize(SIZE_TEXT);
		btnUpDir.setTypeface(Typeface.DEFAULT_BOLD);
		btnUpDir.setLayoutParams(lpButton);
		btnUpDir.setOnClickListener(new View.OnClickListener(){
				@Override
				public void onClick(View v)
				{
					updateFileList(DIR_PARENT);
				}
			});
		btnSelect.setText(TEXT_BTNSELECT);
		btnSelect.setTextSize(SIZE_TEXT);
		btnSelect.setTypeface(Typeface.DEFAULT_BOLD);
		btnSelect.setLayoutParams(lpButton);
		btnSelect.setOnClickListener(new View.OnClickListener(){
				@Override
				public void onClick(View v)
				{
					_filePath = _fileDir;
					exitChooser();
				}
			});
		btnCancel.setText(TEXT_BTNCALCEL);
		btnCancel.setTextSize(SIZE_TEXT);
		btnCancel.setTypeface(Typeface.DEFAULT_BOLD);
		btnCancel.setLayoutParams(lpButton);
		btnCancel.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v)
				{
					exitChooser();
				}
			});

		_aaFileList.addAll(getFileList(_fileDir));
		_lvFileList.setAdapter(_aaFileList);
		_lvFileList.setFastScrollEnabled(true);
		_lvFileList.setLeft(0);
		_lvFileList.setLayoutParams(lpFileList);
		_lvFileList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
				@Override
				public void onItemClick(AdapterView<?> av, View v, int pos, long id)
				{
					String dirName;

					dirName = (String) av.getItemAtPosition(pos);
					updateFileList(dirName.substring(PREFIX_DIR.length()));
				}
			});

		_layOptionBar.setOrientation(LinearLayout.HORIZONTAL);
		_layFileList.setOrientation(LinearLayout.VERTICAL);
		_layOptionBar.addView(btnUpDir);
		_layOptionBar.addView(btnSelect);
		_layOptionBar.addView(btnCancel);
		_layFileList.addView(_tvFileDir);
		_layFileList.addView(_layOptionBar);
		_layFileList.addView(_lvFileList);
		setContentView(_layFileList);
	}


	/*************
	 * exitChooser
	 *   Exit and return result.
	 */
	private void exitChooser()
	{
		Intent result;

		result = new Intent();
		result.putExtra(KEY_FILEPATH, _filePath);
		setResult(RESULT_OK, result);
		finish();
	}


	/****************
	 * updateFileList
	 *   Update the ListView.
	 * Parameter:
	 *   dirName: The selected file.
	 * Notes:
	 *   If dirNames is DIR_PARENT, then current directory will be
	 *   changed to its parent.
	 */
	private void updateFileList(String dirName)
	{
		File dir;

		if (dirName.equals(DIR_PARENT))
		{
			_fileDir = _fileDir.substring(0, _fileDir.lastIndexOf(File.separator));

			if (_fileDir.equals(DIR_EMPTY))
			{
				_fileDir = DIR_ROOT;
			}
		}
		else
		{
			_fileDir += _fileDir.equals(DIR_ROOT) ? dirName : (File.separator + dirName);
		}

		dir = new File(_fileDir);

		if (!dir.isDirectory())
		{
			_filePath = _fileDir;
			exitChooser();
		}

		_aaFileList.clear();
		_aaFileList.addAll(getFileList(_fileDir));
		_lvFileList.setAdapter(_aaFileList);
		_tvFileDir.setText(_fileDir);
	}


	/*************************
	 * getFileList -> String[]
	 *   Get all files and directories in a directory.
	 * Parameter:
	 *   The destination directory.
	 * Return:
	 *   A list of result.
	 */
	private String[] getFileList(String currentDir)
	{
		File fCurrentDir;
		File[] fSubDirs;
		String[] fileList;
		String[] tempDirs;
		String[] tempFiles;
		int cntDir;
		int cntFile;

		fCurrentDir = new File(currentDir);
		fSubDirs = fCurrentDir.listFiles();

		/*if (!fFileDir.isDirectory())
		 {
		 return null;
		 }*/
		// No files in this directory.
		if (fSubDirs == null)
		{
			fileList = new String[0];
			return fileList;
		}

		tempDirs = new String[fSubDirs.length];
		tempFiles = new String[fSubDirs.length];
		fileList = new String[fSubDirs.length];

		cntDir = 0;
		cntFile = 0;
		for (File dir : fSubDirs)
		{
			if (dir.isDirectory())
			{
				tempDirs[cntDir++] = PREFIX_DIR + dir.getName();
			}
			else
			{
				tempFiles[cntFile++] = PREFIX_FILE + dir.getName();
			}
		}

		Arrays.sort(tempDirs, new TFileComparator());
		Arrays.sort(tempFiles, new TFileComparator());

		cntFile = 0;
		for (String s : tempDirs)
		{
			if (s != null)
			{
				fileList[cntFile++] = s;
			}
		}
		for (String s : tempFiles)
		{
			if (s != null)
			{
				fileList[cntFile++] = s;
			}
		}

		return fileList;
	}


	private String[] getFileList2(String currentDir)
	{
		ArrayList<String> aFileList;
		File fCurrentDir;
		File[] fSubDirs;
		String[] fileList;
		String[] fileListContents;
		String[] tempDirs;
		String[] tempFiles;
		int cntDir;
		int cntFile;

		aFileList = new ArrayList<String>();
		aFileList.add(DIR_PARENT);
		fCurrentDir = new File(currentDir);
		fSubDirs = fCurrentDir.listFiles();

		/*if (!fFileDir.isDirectory())
		 {
		 return null;
		 }*/
		if (fSubDirs == null)
		{
			fileList = new String[1];
			fileList[0] = DIR_PARENT;
			return fileList;
		}

		tempDirs = new String[fSubDirs.length];
		tempFiles = new String[fSubDirs.length];
		fileList = new String[fSubDirs.length + 1];

		cntDir = 0;
		cntFile = 0;
		for (File dir : fSubDirs)
		{
			if (dir.isDirectory())
			{
				//fileList.add(dir.getName());
				tempDirs[cntDir++] = dir.getName();
			}
			else
			{
				tempFiles[cntFile++] = dir.getName();
			}
		}

		Arrays.sort(tempDirs, new TFileComparator());
		Arrays.sort(tempFiles, new TFileComparator());
		//fileList = new String[fSubDirs.length];
		fileList[0] = DIR_PARENT;

		cntFile = 1;
		for (String s : tempDirs)
		{
			if (s != null)
			{
				//aFileList.add(s);
				fileList[cntFile++] = s;
			}
		}
		for (String s : tempFiles)
		{
			if (s != null)
			{
				//aFileList.add(s);
				fileList[cntFile++] = s;
			}
		}

		//fileListContents = new String[fSubDirs.length];
		//fileList = aFileList.toArray(fileListContents);

		return fileList;
	}


	private ArrayAdapter<String> getFileList3(String currentDir)
	{
		ArrayAdapter<String> fileList;
		File fCurrentDir;
		File[] fSubDirs;
		String[] tempFiles;
		String[] tempDirs;
		int cntDir;
		int cntFile;

		fileList = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1);
		fCurrentDir = new File(currentDir);
		fSubDirs = fCurrentDir.listFiles();
		fileList.add(DIR_PARENT);

		/*if (!fFileDir.isDirectory())
		 {
		 return null;
		 }*/

		if (fSubDirs == null)
		{
			return fileList;
		}

		tempDirs = new String[fSubDirs.length];
		tempFiles = new String[fSubDirs.length];

		cntDir = 0;
		cntFile = 0;
		for (File dir : fSubDirs)
		{
			if (dir.isDirectory())
			{
				//fileList.add(dir.getName());
				tempDirs[cntDir++] = dir.getName();
			}
			else
			{
				tempFiles[cntFile++] = dir.getName();
			}
		}
		Arrays.sort(tempDirs, new TFileComparator());
		Arrays.sort(tempFiles, new TFileComparator());
		fileList.addAll(tempDirs);
		fileList.addAll(tempFiles);

		/*for (String s : temp)
		 {
		 fileList.add(s);
		 }
		 cnt = 0;
		 for (File file : fSubDirs)
		 {
		 if (file.isFile())
		 {
		 fileList.add(file.getName());
		 temp[cnt++] = file.getName();
		 }
		 }
		 Arrays.sort(temp, new TFileComparator());
		 for (String s : temp)
		 {
		 fileList.add(s);
		 }*/

		return fileList;
	}


	private void showToast(String msg)
	{
		Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
	}

	/*private String[] arrayToString(ArrayList<String> arrayList)
	 {
	 String[] stringList;

	 stringList = new String[arrayList.size()];
	 for (int i = 0; i < arrayList.size(); i++)
	 {
	 stringList[i] = arrayList.get(i);
	 }

	 return stringList;
	 }*/
}




/**
 * TFileComparator
 *   An implemention of Comparator.
 */
class TFileComparator implements Comparator<String>
{
	@Override
	public int compare(String s1, String s2)
	{
		if (s1 == null && s2 == null)
		{
			return 0;
		}
		// Put null to last.
		else if (s1 == null)
		{
			return s2.length();
		}
		else if (s2 == null)
		{
			return -s1.length();
		}
		else
		{
			return s1.compareTo(s2);
		}
	}

	/*@Override
	 public int compare(String s1, String s2)
	 {
	 byte[] bytesS1;
	 byte[] bytesS2;
	 int strLength;
	 int cnt;

	 s1.compareTo(s2);
	 if (s1 == null && s2 == null)
	 {
	 return 0;
	 }
	 else if (s1 == null)
	 {
	 return s2.length();
	 }
	 else if (s2 == null)
	 {
	 return -s1.length();
	 }

	 if (s1.equals(s2))
	 {
	 return 0;
	 }

	 bytesS1 = s1.getBytes();
	 bytesS2 = s2.getBytes();

	 strLength = Math.min(bytesS1.length, bytesS2.length);
	 for (cnt = 0; cnt < strLength; cnt++)
	 {
	 if (bytesS1[cnt] != bytesS2[cnt])
	 {
	 break;
	 }
	 }

	 /*if (cnt == bytesS1.length && cnt == bytesS2.length)
	 {
	 return 0;
	 }
	 if (cnt == bytesS1.length || cnt == bytesS2.length)
	 {
	 return (bytesS1.length - bytesS2.length);
	 }
	 else
	 {
	 return (bytesS1[cnt] - bytesS2[cnt]);
	 }
	 }*/
}

