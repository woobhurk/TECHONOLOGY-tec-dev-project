/**
 * This is just a demo.
 */

package com.tsueyl.tfilechooser;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import com.tsueyl.extras.Utils;

public class MainActivity extends Activity
{
	public static final String KEY_FILEDIR = "KEY_FILEDIR";
	public static final String KEY_FILEPATH = "KEY_FILEPATH";
	public static final String DIR_ROOT = "/";
	public static final int ID_FILECHOOSER = 0x00000001;

	private Button btnFileChooser;
	private String _filePath;


    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState)
	{
		Intent fileChooserIntent;

        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

		btnFileChooser = (Button) findViewById(R.id.btnFileChooser);
		btnFileChooser.setOnClickListener(new View.OnClickListener(){
				@Override
				public void onClick(View v)
				{
					Intent fileChooserIntent;

					fileChooserIntent = new Intent();
					fileChooserIntent.putExtra(KEY_FILEDIR, "/sdcard");
					fileChooserIntent.setClass(MainActivity.this, TFileChooser.class);
					//startActivity(fileChooserIntent);
					startActivityForResult(fileChooserIntent, ID_FILECHOOSER);
				}
			});
		fileChooserIntent = new Intent();
		fileChooserIntent.putExtra(KEY_FILEDIR, DIR_ROOT);
		fileChooserIntent.setClass(MainActivity.this, TFileChooser.class);
		//startActivity(fileChooserIntent);
		startActivityForResult(fileChooserIntent, ID_FILECHOOSER);
    }

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data)
	{
		super.onActivityResult(requestCode, resultCode, data);

		try
		{
			_filePath = data.getExtras().getString(KEY_FILEPATH);
		}
		catch (Exception e)
		{
			//Utils.showDialog(this, "0", null);
			//Utils.showDialog(this, "1", Utils.traceToString(e));
			//Utils.showDialog(this, "2", Utils.traceToString2(e));
			Utils.showTraceToast(this, e);
			Utils.showTraceDialog(this, e);
		}
		Utils.showToast(this, _filePath);
		//Toast.makeText(MainActivity.this, _filePath, Toast.LENGTH_LONG).show();
	}
}

