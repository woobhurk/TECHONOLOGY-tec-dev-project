package com.tsueyl.fonts;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;
import android.widget.Toast;
import com.tsueyl.extras.Utils;

public class MainActivity extends Activity
{
    public static final int DEF_FONT_INDEX = 19;
    public static final int DEF_FONT_SIZE = 64;
    public static final int DEF_DLGFONT_SIZE = 32;
    public static final String DEF_CONTENT = "永";
    public static final int COLOR_DIVIDER = 0xff808080;
    public static final long EXIT_DELAY = 1500;

    private View vwMain;
    private View vwFonts;
    private Button btnChangeFont;
    private Button btnConvFont;
    private Button btnViewFont;
    private Button btnClearFont;
    private EditText etFontSize;
    private EditText etContext;
    //private Button btnExit;
    private LinearLayout layFonts;
    private Button btnFontsBack;
    private Button btnFontsClear;

    private boolean isMainUI;
    private boolean fontsInited;
    private Typeface[] tfFonts;
    private String[] fontNames;
    private String[] fontFiles;
    private int fontIndex;
    private long prevExitTime;


    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState)
	{
        LayoutInflater liInflater;

        super.onCreate(savedInstanceState);
        //getActionBar().hide();
        liInflater = getLayoutInflater();
        vwMain = liInflater.inflate(R.layout.main, null);
        vwFonts = liInflater.inflate(R.layout.fonts, null);
        initVars();
        initMainUI();
        initMainWidgets();
        initFontsUI();
        initFontsWidgets();
        switchToMain();
    }


    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event)
    {
        // TODO: Implement this method
        if (keyCode != KeyEvent.KEYCODE_BACK)
        {
            return super.onKeyDown(keyCode, event);
        }

        if (!isMainUI)
        {
            switchToMain();
            //Utils.showToast(this, "Press BACK again to exit");
        }
        else
        {
            long curExitTime = System.currentTimeMillis();

            if (curExitTime - prevExitTime == 0 || curExitTime - prevExitTime > EXIT_DELAY)
            {
                prevExitTime = curExitTime;
                Toast.makeText(this, "Press [BACK] again to exit", (int)EXIT_DELAY).show();
                return false;
            }
            else
            {
                finish();
            }
        }

        return true;
    }




    public void initVars()
    {
        Resources res;
        int cnt;

        isMainUI = true;
        fontsInited = false;
        res = getResources();
        fontNames = res.getStringArray(R.array.font_names);
        fontFiles = res.getStringArray(R.array.font_files);
        tfFonts = new Typeface[fontNames.length];

        for (cnt = 0; cnt < tfFonts.length; cnt++)
        {
            tfFonts[cnt] = Typeface.createFromAsset(getAssets(), fontFiles[cnt]);
        }

        fontIndex = DEF_FONT_INDEX;
        prevExitTime = System.currentTimeMillis();
    }




    public void initMainUI()
    {
        btnChangeFont = (Button)vwMain.findViewById(R.id.btnChangeFont);
        btnConvFont = (Button)vwMain.findViewById(R.id.btnConvFont);
        btnViewFont = (Button)vwMain.findViewById(R.id.btnViewFont);
        btnClearFont = (Button)vwMain.findViewById(R.id.btnClearFont);
        etFontSize = (EditText)vwMain.findViewById(R.id.etFontSize);
        etContext = (EditText)vwMain.findViewById(R.id.etContent);
    }




    public void initMainWidgets()
    {
        btnChangeFont.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                // TODO: Implement this method
                changeFont();
            }
        });
        btnChangeFont.setText(fontNames[fontIndex]);
        btnChangeFont.setTypeface(getTypefaceByIndex(fontIndex));

        btnConvFont.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                // TODO: Implement this method
                if (!checkArgs())
                {
                    return;
                }

                convertFont();
                addFontDivider();
                switchToFonts();
            }
        });

        btnViewFont.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                // TODO: Implement this method
                switchToFonts();
            }
        });

        btnClearFont.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                // TODO: Implement this method
                clearFont();
            }
        });

        etFontSize.setText("" + DEF_FONT_SIZE);
        etContext.setText(DEF_CONTENT);
        etContext.requestFocus();
    }




    public void initFontsUI()
    {
        layFonts = (LinearLayout)vwFonts.findViewById(R.id.layFonts);
        btnFontsBack = (Button)vwFonts.findViewById(R.id.btnFontsBack);
        btnFontsClear = (Button)vwFonts.findViewById(R.id.btnFontsClear);
    }




    public void initFontsWidgets()
    {
        btnFontsBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                // TODO: Implement this method
                switchToMain();
            }
        });

        btnFontsClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                // TODO: Implement this method
                clearFont();
            }
        });
    }




    public void switchToMain()
    {
        setContentView(vwMain);
        isMainUI = true;
    }




    public void switchToFonts()
    {
        /*if (!fontsInited)
        {
            initFontsUI();
            initFontsWidgets();
            fontsInited = true;
        }*/

        setContentView(vwFonts);
        isMainUI = false;
    }




    public void changeFont()
    {
        /*fontIndex = ++fontIndex % fontNames.length;
        btnChangeFont.setText(fontNames[fontIndex]);
        btnChangeFont.setTypeface(getTypefaceByIndex(fontIndex));*/
        FontsDialog fdDialog;

        fdDialog = new FontsDialog(this, getAssets(), getLayoutInflater());
        fdDialog.chooseFont();
    }




    public void convertFont()
    {
        String size;
        String content;
        FontsTextView ftvFontChar;

        size = etFontSize.getText().toString();
        content = etContext.getText().toString();

        if (size.equals("") || Integer.parseInt(size) <= 0)
        {
            etFontSize.setText("" + DEF_FONT_SIZE);
        }

        layFonts = (LinearLayout)vwFonts.findViewById(R.id.layFonts);
        ftvFontChar = new FontsTextView(this, getAssets(), getLayoutInflater(), tfFonts);
        ftvFontChar.setText(content);
        ftvFontChar.setTextSize(Float.parseFloat(size));
        ftvFontChar.setTypefaceByIndex(fontIndex);
        ftvFontChar.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v)
            {
                // TODO: Implement this method
                deleteFont((FontsTextView)v);
                return true;
            }
        });

        layFonts.addView(ftvFontChar);
    }




    public void clearFont()
    {
        layFonts.removeAllViews();
    }




    public boolean checkArgs()
    {
        String content;
        boolean isLeagel;

        content = etContext.getText().toString();

        if (content.equals(""))
        {
            Utils.showToast(MainActivity.this, "请输入内容");
            isLeagel = false;
        }
        else
        {
            isLeagel = true;
        }

        return isLeagel;
    }




    public void addFontDivider()
    {
        View vwDivider;
        LayoutParams lpDivider;

        vwDivider = new View(this);
        lpDivider = new LayoutParams(LayoutParams.MATCH_PARENT, 10);
        vwDivider.setLayoutParams(lpDivider);
        vwDivider.setBackgroundColor(COLOR_DIVIDER);
        layFonts.addView(vwDivider);
    }




    public void deleteFont(FontsTextView ftv)
    {
        int index;
        int count;

        count = layFonts.getChildCount();
        for (index = 0; index < count; index++)
        {
            if (layFonts.getChildAt(index).equals(ftv))
            {
                break;
            }
        }

        layFonts.removeView(ftv);
        layFonts.removeViewAt(index);
        //Utils.showToast(this, "Item deleted.");
    }




    public int getTypefaceIndex(String name)
    {
        int index;

        index = 0;

        for (String fontName : fontNames)
        {
            if (fontName.equals(name))
            {
                break;
            }

            index++;
        }

        return index;
    }




    public Typeface getTypefaceByIndex(int index)
    {
        return tfFonts[index];
        //return Typeface.createFromAsset(getAssets(), fontFiles[fontIndex]);
    }




    public Typeface getTypefaceByName(String name)
    {
        return getTypefaceByIndex(getTypefaceIndex(name));
    }



    public void setTypefaceByIndex(int index)
    {
        fontIndex = index;
        btnChangeFont.setText(fontNames[fontIndex]);
        btnChangeFont.setTypeface(getTypefaceByIndex(fontIndex));
    }




    private class FontsDialog extends AlertDialog.Builder
    {
        private Context mCtx;
        private AssetManager mAmManager;
        private LayoutInflater mLiInflater;
        private View mVwDialog;
        private TextView tvFontName;
        private LinearLayout mLayFontList;
        private AlertDialog mDlgFont;

        public FontsDialog(Context ctx, AssetManager manager, LayoutInflater inflater)
        {
            super(ctx);
            mCtx = ctx;
            mAmManager = manager;
            mLiInflater = inflater;
            mVwDialog = mLiInflater.inflate(R.layout.fonts_dialog, null);
            initVars();
            initDialogUI();
            initDialogWidgets();
        }




        public void initVars()
        {
            ;
        }




        public void initDialogUI()
        {
            tvFontName = (TextView)mVwDialog.findViewById(R.id.tvFontName);
            mLayFontList = (LinearLayout)mVwDialog.findViewById(R.id.layFontList);
        }




        public void initDialogWidgets()
        {
            TextView tvFontList;
            Button btnFontList;

            this.setPositiveButton("Close", null);
            tvFontName.setText(fontNames[fontIndex]);

            for (String fontName : fontNames)
            {
                tvFontList = new TextView(mCtx);
                btnFontList = new Button(mCtx);
                tvFontList.setText(fontName);
                tvFontList.setTextSize((float)(DEF_DLGFONT_SIZE / 2));
                tvFontList.setGravity(Gravity.CENTER);
                btnFontList.setText(fontName);
                btnFontList.setTextSize((float)DEF_DLGFONT_SIZE);
                btnFontList.setTypeface(getTypefaceByName(fontName));
                btnFontList.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v)
                    {
                        // TODO: Implement this method
                        Button btn;
                        int index;

                        btn = (Button)v;
                        tvFontName.setText(btn.getText());
                        index = getTypefaceIndex(btn.getText().toString());
                        setTypefaceByIndex(index);
                    }
                });

                mLayFontList.addView(tvFontList);
                mLayFontList.addView(btnFontList);
            }
        }




        public void chooseFont()
        {
            setView(mVwDialog);
            mDlgFont = show();
        }
    }
}

