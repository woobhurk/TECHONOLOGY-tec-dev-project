package com.tsueyl.fonts;

import android.app.AlertDialog;
import android.content.Context;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.tsueyl.extras.Utils;

public class FontsTextView extends TextView
{
    public static final int DEF_DLGFONT_SIZE = 32;
    public static final int DEF_COLOR_FONT = 0xff404040;
    public static final int DEF_COLOR_FONTBG = 0xffffffff;

    private Context mCtx;
    private AssetManager mAmManager;
    private LayoutInflater mLiInflater;
    private Typeface[] tfFonts;
    private String[] fontNames;
    private String[] fontFiles;
    private int fontIndex;
    private int colorFont;
    private int colorFontBg;
    private boolean isOnScale;
    private DisplayMetrics dm;
    private ScaleGestureDetector SGD;


    public FontsTextView(Context ctx, AssetManager manager, LayoutInflater inflater, Typeface[] fonts)
    {
        super(ctx);
        mCtx = ctx;
        mAmManager = manager;
        mLiInflater = inflater;
        tfFonts = fonts;
        initVars();
        initWidgets();
    }




    @Override
    public boolean onTouchEvent(MotionEvent event)
    {
        SGD.onTouchEvent(event);

        //return true;
        return super.onTouchEvent(event);
    }




    public void initVars()
    {
        Resources res;

        res = mCtx.getResources();
        fontNames = res.getStringArray(R.array.font_names);
        fontFiles = res.getStringArray(R.array.font_files);
        colorFont = DEF_COLOR_FONT;
        colorFontBg = DEF_COLOR_FONTBG;
        isOnScale = false;
        dm = mCtx.getResources().getDisplayMetrics();
        SGD = new ScaleGestureDetector(mCtx, new SGDListener());
    }



    public void initWidgets()
    {
        //LayoutParams lpFonts;

        //lpFonts = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        //this.setLayoutParams(lpFonts);
        //this.setPadding(5, 0, 5, 0);
        this.setTextColor(colorFont);
        this.setBackgroundColor(colorFontBg);
        this.setGravity(Gravity.CENTER);
        this.setLongClickable(true);
        this.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                // TODO: Implement this method
                changeFont();
            }
        });
    }




    public void changeFont()
    {
        FontsDialog fdDialog;

        fdDialog = new FontsDialog(mCtx, mAmManager, mLiInflater);
        fdDialog.chooseFont();
    }




    public int getTypefaceIndex(String name)
    {
        int index;

        index = 0;

        for (String fontName : fontNames)
        {
            if (fontName.equals(name))
            {
                break;
            }

            index++;
        }

        return index;
    }




    public Typeface getTypefaceByIndex(int index)
    {
        return tfFonts[index];
    }




    public Typeface getTypefaceByName(String name)
    {
        return getTypefaceByIndex(getTypefaceIndex(name));
    }




    public void setTypefaceByIndex(int index)
    {
        fontIndex = index;
        setTypeface(getTypefaceByIndex(index));
    }




    private class FontsDialog extends AlertDialog.Builder
    {
        private Context mCtx;
        private AssetManager mAmManager;
        private LayoutInflater mLiInflater;
        private AlertDialog mDlgFont;
        private View mVwDialog;
        private View mVwChangeContent;
        private TextView tvFontName;
        private LinearLayout mLayFontList;
        private EditText etChangeContent;
        private Button btnChangeContent;
        private EditText etChangeSize;
        private Button btnChangeSize;

        public FontsDialog(Context ctx, AssetManager manager, LayoutInflater inflater)
        {
            super(ctx);
            mCtx = ctx;
            mAmManager = manager;
            mLiInflater = inflater;
            mVwDialog = mLiInflater.inflate(R.layout.fonts_dialog, null);
            mVwChangeContent = mLiInflater.inflate(R.layout.change_content, null);
            initVars();
            initDialogUI();
            initDialogWidgets();
        }



        public void initVars()
        {
            ;
        }



        public void initDialogUI()
        {
            tvFontName = (TextView)mVwDialog.findViewById(R.id.tvFontName);
            mLayFontList = (LinearLayout)mVwDialog.findViewById(R.id.layFontList);
            etChangeContent = (EditText)mVwChangeContent.findViewById(R.id.etChangeContent);
            btnChangeContent = (Button)mVwChangeContent.findViewById(R.id.btnChangeContent);
            etChangeSize = (EditText)mVwChangeContent.findViewById(R.id.etChangeSize);
            btnChangeSize = (Button)mVwChangeContent.findViewById(R.id.btnChangeSize);
        }



        public void initDialogWidgets()
        {
            TextView tvFontList;
            Button btnFontList;

            this.setPositiveButton("Close", null);
            tvFontName.setText(fontNames[fontIndex]);
            mLayFontList.addView(mVwChangeContent);

            for (String fontName : fontNames)
            {
                tvFontList = new TextView(mCtx);
                btnFontList = new Button(mCtx);
                tvFontList.setText(fontName);
                tvFontList.setTextSize((float)(DEF_DLGFONT_SIZE / 2));
                tvFontList.setGravity(Gravity.CENTER);
                btnFontList.setText(fontName);
                btnFontList.setTextSize((float)DEF_DLGFONT_SIZE);
                btnFontList.setTypeface(getTypefaceByName(fontName));
                btnFontList.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v)
                    {
                        // TODO: Implement this method
                        Button btn;
                        int index;

                        btn = (Button)v;
                        tvFontName.setText(btn.getText());
                        index = getTypefaceIndex(btn.getText().toString());
                        setTypefaceByIndex(index);
                    }
                });

                mLayFontList.addView(tvFontList);
                mLayFontList.addView(btnFontList);
            }

            etChangeContent.setText(getText());

            btnChangeContent.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v)
                {
                    changeFontContent();
                }
            });

            // getTextSize得到的是经过缩放的大小
            etChangeSize.setText("" + (int)(getTextSize() / dm.scaledDensity));

            btnChangeSize.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v)
                {
                    changeFontSize();
                }
            });
        }



        public void chooseFont()
        {
            setView(mVwDialog);
            mDlgFont = show();
        }



        public void changeFontContent()
        {
            String content;

            content = etChangeContent.getText().toString();

            if (content.equals(""))
            {
                Utils.showToast(mCtx, "请输入内容");
                return;
            }

            setText(etChangeContent.getText().toString());
        }



        private void changeFontSize()
        {
            String size;

            size = etChangeSize.getText().toString();

            if (size.equals("") || Integer.parseInt(size) <= 0)
            {
                return;
            }

            setTextSize(Float.parseFloat(size));
        }
    }




    private class SGDListener extends ScaleGestureDetector.SimpleOnScaleGestureListener
    {
        private float curScaleFactor;
        private float fontSize;


        @Override
        public boolean onScaleBegin(ScaleGestureDetector detector)
        {
            isOnScale = true;
            fontSize = getTextSize() / dm.scaledDensity;
            return super.onScaleBegin(detector);
            //return true;
        }



        @Override
        public boolean onScale(ScaleGestureDetector detector)
        {
            curScaleFactor = detector.getScaleFactor();
            setTextSize(fontSize * curScaleFactor);
            return super.onScale(detector);
            //return true;
        }



        @Override
        public void onScaleEnd(ScaleGestureDetector detector)
        {
            isOnScale = false;
            super.onScaleEnd(detector);
        }
    }
}

