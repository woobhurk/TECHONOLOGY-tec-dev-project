﻿Imports System.Drawing.Graphics

Public Class MainForm
	Const BW_COLOR As Short = 2
	Const CHROME_COLOR As Short = 1

	Const NONE As Short = -1  '无棋子
	Const BLACK As Short = 0  '黑棋/气
	Const WHITE As Short = 1  '白棋/气
	Const COMMQI As Short = 2  '公共气

	Const START_POS As Integer = 20


	Dim ChessNum As Short = BLACK  '下子方
	Dim ChessMode As Short = BW_COLOR  '颜色模式
	Dim BoardWid As Integer
	Dim StrIdx As Integer  '单格大小
	Dim Chess(19, 19), ChessQi(19, 19) As Short	 '棋子，气眼
	Dim hasChecked(19, 19) As Boolean  '是否已检查
	Dim isSglClr As Boolean = False	 '是否单方下
	Dim isShowQi As Boolean = False
	Dim isPickOut As Boolean = False  '是否提子模式

	Dim canDrawBoard As Boolean = True
	Dim canDrawChess As Boolean = False
	Dim canDrawQi As Boolean = False
	Dim DrawPen As Pen
	Dim DrawObj As Graphics


	'===============================================================================
	'绘出棋盘
	Sub DrawBoard()
		Dim LineX, LineY As Integer

		Me.Refresh()
		For LineX = 0 To 18	'绘出网格
			If LineX = 0 Or LineX = 18 Then
				DrawPen.Width = 2
			Else
				DrawPen.Width = 1
			End If
			LineY = LineX
			DrawObj.DrawLine(DrawPen, LineX * StrIdx + START_POS, START_POS, LineX * StrIdx + START_POS, BoardWid + START_POS)
			DrawObj.DrawLine(DrawPen, START_POS, LineY * StrIdx + START_POS, BoardWid + START_POS, LineY * StrIdx + START_POS)
		Next

		For LineY = 0 To 3	'绘出星位
			For LineX = 0 To 3
				DrawObj.DrawRectangle(New Pen(Color.Black, 2), LineX * StrIdx * 6 + StrIdx * 3 + START_POS - 1, LineY * StrIdx * 6 + StrIdx * 3 + START_POS - 1, 3, 3)
			Next
		Next
	End Sub


	'-----------------------------------------------------------------------
	'绘出棋子
	Sub DrawAllChess()
		Dim TmpX, TmpY As Short

		For TmpY = 0 To 18
			For TmpX = 0 To 18
				If Chess(TmpX, TmpY) <> NONE Then Call DrawOneChess(Chess(TmpX, TmpY), TmpX, TmpY)
			Next
		Next
	End Sub

	Sub DrawOneChess(ByVal ChessClr As Integer, ByVal ChessX As Integer, ByVal ChessY As Integer)
		Dim TmpWid As Short
		Dim TmpPen As Pen

		If ChessClr = BLACK Then
			TmpPen = New Pen(Color.Black, CInt(StrIdx / 2))
			'是否一色棋
			If ChessMode = CHROME_COLOR Then TmpPen.Color = Color.White
		Else
			TmpPen = New Pen(Color.White, CInt(StrIdx / 2))
		End If
		TmpWid = CShort(StrIdx / 2)	 '本来是StrIdx，但是因为画笔宽度，故 / 2
		ChessX = ChessX * StrIdx + START_POS - CInt(StrIdx / 2) + CInt(StrIdx / 4) + 1	'笔宽StrIdx / 2，所以笔的横坐标左边有StrIdx / 4的宽度  '+1是因为要使棋子宽度比格子小2px
		ChessY = ChessY * StrIdx + START_POS - CInt(StrIdx / 2) + CInt(StrIdx / 4) + 1
		DrawObj.DrawEllipse(TmpPen, ChessX, ChessY, TmpWid, TmpWid)
	End Sub


	'-------------------------------------------------------------------------------
	'绘出气眼 Qi = 气
	Sub DrawAllQi()
		Dim TmpX, TmpY As Short

		For TmpY = 0 To 18
			For TmpX = 0 To 18
				If ChessQi(TmpX, TmpY) <> NONE Then Call DrawOneQi(ChessQi(TmpX, TmpY), TmpX, TmpY)
			Next
		Next
	End Sub

	Sub DrawOneQi(ByVal QiClr As Short, ByVal QiX As Short, ByVal QiY As Short)
		Dim QiWid As Short
		Dim TmpPen As Pen

		If QiClr = BLACK Then
			TmpPen = New Pen(Color.Black)
			'是否一色棋
			If ChessMode = CHROME_COLOR Then TmpPen.Color = Color.White
		ElseIf QiClr = WHITE Then
			TmpPen = New Pen(Color.White)
		Else
			TmpPen = New Pen(Color.Crimson)	 '公共气
		End If

		QiWid = CShort(StrIdx / 6)	'气的宽度
		QiX = CShort(QiX * StrIdx + START_POS)
		QiY = CShort(QiY * StrIdx + START_POS)
		DrawObj.DrawLine(TmpPen, QiX - QiWid, QiY - QiWid, QiX + QiWid, QiY + QiWid)  '气：交叉线
		DrawObj.DrawLine(TmpPen, QiX + QiWid, QiY - QiWid, QiX - QiWid, QiY + QiWid)
	End Sub


	'-------------------------------------------------------------------------------
	'放入棋子
	Sub PutChess(ByVal MouseX As Integer, ByVal MouseY As Integer)
		MouseX = CInt((MouseX - START_POS) / StrIdx)	'对齐棋子位置
		MouseY = CInt((MouseY - START_POS) / StrIdx)
		If isPickOut Then
			Chess(MouseX, MouseY) = NONE
			canDrawBoard = True
		Else
			'Recheck()
			If Chess(MouseX, MouseY) <> NONE Then Exit Sub
			Chess(MouseX, MouseY) = ChessNum
			Recheck()
			'如果下子后无气，则再次判断
			If CountOneQi(ChessNum, CShort(MouseX), CShort(MouseY)) = 0 Then
				'去除异色棋子后判断
				If ChessNum = BLACK Then
					DelClrChess(WHITE)
				ElseIf ChessNum = WHITE Then
					DelClrChess(BLACK)
				End If
				Recheck()
				'还是无气，取消放入，跳出判断
				If CountOneQi(ChessNum, CShort(MouseX), CShort(MouseY)) = 0 Then
					Chess(MouseX, MouseY) = NONE
					GoTo End_If
				End If
				'这里只有放入了棋子才会执行
				If isSglClr Then GoTo End_If
				ChessNum = CShort(IIf(ChessNum = BLACK, WHITE, BLACK))
				If ChessMode = BW_COLOR Then BWBtn.Text = CStr(IIf(ChessNum = BLACK, "黑 / 白棋", "白 / 黑棋"))
			Else  '下子后仍有气
				'Recheck()
				CountAllQi()
				If isSglClr Then GoTo End_If
				ChessNum = CShort(IIf(ChessNum = BLACK, WHITE, BLACK))
				If ChessMode = BW_COLOR Then BWBtn.Text = CStr(IIf(ChessNum = BLACK, "黑 / 白棋", "白 / 黑棋"))
			End If
		End If
End_If:
		InfoLab.Text = "黑棋" + CountChess(BLACK).ToString + "，白棋" + CountChess(WHITE).ToString
		canDrawChess = True
		canDrawQi = isShowQi
	End Sub


	'-------------------------------------------------------------------------------
	'删除无气的棋子
	Sub DelDiedChess(ByVal ChessClr As Short, ByVal ChessX As Short, ByVal ChessY As Short)
		Dim TmpX, TmpY As Short

		Chess(ChessX, ChessY) = NONE
		TmpX = CShort(ChessX - 1)
		If TmpX >= 0 Then
			If Chess(TmpX, ChessY) = ChessClr Then
				Chess(TmpX, ChessY) = NONE
				DelDiedChess(ChessClr, TmpX, ChessY)
			End If
		End If
		TmpX = CShort(ChessX + 1)
		If TmpX <= 18 Then
			If Chess(TmpX, ChessY) = ChessClr Then
				Chess(TmpX, ChessY) = NONE
				DelDiedChess(ChessClr, TmpX, ChessY)
			End If
		End If
		TmpY = CShort(ChessY - 1)
		If TmpY >= 0 Then
			If Chess(ChessX, TmpY) = ChessClr Then
				Chess(ChessX, TmpY) = NONE
				DelDiedChess(ChessClr, ChessX, TmpY)
			End If
		End If
		TmpY = CShort(ChessY + 1)
		If TmpY <= 18 Then
			If Chess(ChessX, TmpY) = ChessClr Then
				Chess(ChessX, TmpY) = NONE
				DelDiedChess(ChessClr, ChessX, TmpY)
			End If
		End If
		PutAllQi()
	End Sub

	'删除特定颜色棋子
	Sub DelClrChess(ByVal ChessClr As Short)
		Dim hasDel As Boolean = False
		Dim TmpX, TmpY As Short

		For TmpY = 0 To 18
			For TmpX = 0 To 18
				Recheck()
				If Chess(TmpX, TmpY) <> ChessClr Or Chess(TmpX, TmpY) = NONE Then Continue For
				If CountOneQi(ChessClr, TmpX, TmpY) > 0 Then Continue For
				DelDiedChess(ChessClr, TmpX, TmpY)
				hasDel = True
			Next
		Next
		'若删除了棋子则重绘
		If Not hasDel Then Exit Sub
		canDrawBoard = True
		canDrawChess = True
		canDrawQi = isShowQi
	End Sub


	'-------------------------------------------------------------------------------
	'计算某颜色棋子个数
	Function CountChess(ByVal ChessNum As Short) As Short
		Dim cnt As Short
		Dim TmpX, TmpY As Short

		For TmpY = 0 To 18
			For TmpX = 0 To 18
				If Chess(TmpX, TmpY) = ChessNum Then cnt += CShort(1)
			Next
		Next
		Return cnt
	End Function


	'-------------------------------------------------------------------------------
	'储存气眼信息
	Sub PutAllQi()
		Dim QiX, QiY, TmpX, TmpY As Short

		For TmpY = 0 To 18
			For TmpX = 0 To 18
				ChessQi(TmpX, TmpY) = NONE
			Next
		Next

		For QiY = 0 To 18
			For QiX = 0 To 18
				If Chess(QiX, QiY) = NONE Then Continue For
				TmpX = CShort(QiX - 1) '左
				If TmpX >= 0 Then
					If Chess(TmpX, QiY) = NONE Then ChessQi(TmpX, QiY) = CShort(IIf(ChessQi(TmpX, QiY) = NONE Or ChessQi(TmpX, QiY) = Chess(QiX, QiY), Chess(QiX, QiY), COMMQI))
				End If
				TmpX = CShort(QiX + 1) '右
				If TmpX <= 18 Then
					If Chess(TmpX, QiY) = NONE Then ChessQi(TmpX, QiY) = CShort(IIf(ChessQi(TmpX, QiY) = NONE Or ChessQi(TmpX, QiY) = Chess(QiX, QiY), Chess(QiX, QiY), COMMQI))
				End If
				TmpY = CShort(QiY - 1) '上
				If TmpY >= 0 Then
					If Chess(QiX, TmpY) = NONE Then ChessQi(QiX, TmpY) = CShort(IIf(ChessQi(QiX, TmpY) = NONE Or ChessQi(QiX, TmpY) = Chess(QiX, QiY), Chess(QiX, QiY), COMMQI))
				End If
				TmpY = CShort(QiY + 1) '下
				If TmpY <= 18 Then
					If Chess(QiX, TmpY) = NONE Then ChessQi(QiX, TmpY) = CShort(IIf(ChessQi(QiX, TmpY) = NONE Or ChessQi(QiX, TmpY) = Chess(QiX, QiY), Chess(QiX, QiY), COMMQI))
				End If
			Next
		Next
	End Sub


	'-------------------------------------------------------------------------------
	'计算所有棋子的气，并删除无气之棋，调用此函数前可不用Recheck()
	Sub CountAllQi()
		Dim TmpX, TmpY As Short
		Dim hasDel As Boolean = False

		For TmpY = 0 To 18
			For TmpX = 0 To 18
				Recheck()
				If Chess(TmpX, TmpY) = NONE Then Continue For
				If CountOneQi(Chess(TmpX, TmpY), TmpX, TmpY) = 0 Then
					DelDiedChess(Chess(TmpX, TmpY), TmpX, TmpY)
					hasDel = True
				End If
			Next
		Next
		If Not hasDel Then Exit Sub
		canDrawBoard = True
		canDrawChess = True
		canDrawQi = isShowQi
	End Sub

	'调用此函数前必须调用Recheck()
	Function CountOneQi(ByVal ChessClr As Short, ByVal ChessX As Short, ByVal ChessY As Short) As Short
		Dim cnt As Short = 0
		Dim TmpX, TmpY As Short

		If ChessClr = NONE Then Exit Function
		hasChecked(ChessX, ChessY) = True
		TmpX = CShort(ChessX - 1)
		If TmpX >= 0 Then
			If Not hasChecked(TmpX, ChessY) Then
				'hasChecked(TmpX, ChessY) = True
				If Chess(TmpX, ChessY) = NONE Then
					cnt += CShort(1)
				ElseIf Chess(TmpX, ChessY) = ChessClr Then
					cnt += CountOneQi(ChessClr, TmpX, ChessY)
				End If
			End If
		End If
		TmpX = CShort(ChessX + 1)
		If TmpX <= 18 Then
			If Not hasChecked(TmpX, ChessY) Then
				hasChecked(TmpX, ChessY) = True
				If Chess(TmpX, ChessY) = NONE Then
					cnt += CShort(1)
				ElseIf Chess(TmpX, ChessY) = ChessClr Then
					cnt += CountOneQi(ChessClr, TmpX, ChessY)
				End If
			End If
		End If
		TmpY = CShort(ChessY - 1)
		If TmpY >= 0 Then
			If Not hasChecked(ChessX, TmpY) Then
				hasChecked(ChessX, TmpY) = True
				If Chess(ChessX, TmpY) = NONE Then
					cnt += CShort(1)
				ElseIf Chess(ChessX, TmpY) = ChessClr Then
					cnt += CountOneQi(ChessClr, ChessX, TmpY)
				End If
			End If
		End If
		TmpY = CShort(ChessY + 1)
		If TmpY <= 18 Then
			If Not hasChecked(ChessX, TmpY) Then
				hasChecked(ChessX, TmpY) = True
				If Chess(ChessX, TmpY) = NONE Then
					cnt += CShort(1)
				ElseIf Chess(ChessX, TmpY) = ChessClr Then
					cnt += CountOneQi(ChessClr, ChessX, TmpY)
				End If
			End If
		End If
		Return cnt
	End Function


	'-------------------------------------------------------------------------------
	'清除检查信息
	Sub Recheck()
		Dim TmpX, TmpY As Short

		For TmpY = 0 To 18
			For TmpX = 0 To 18
				hasChecked(TmpX, TmpY) = False
			Next
		Next
	End Sub


	'===============================================================================
	Private Sub MainForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
		Dim TmpX, TmpY As Short

		For TmpY = 0 To 18 Step 1
			For TmpX = 0 To 18 Step 1
				Chess(TmpX, TmpY) = NONE
				ChessQi(TmpX, TmpY) = NONE
				hasChecked(TmpX, TmpY) = False
			Next
		Next
		DrawPen = New Pen(Color.Black, 1)
		DrawObj = CreateGraphics()
	End Sub


	'窗口大小改变
	Private Sub MainForm_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Resize
		If Me.Height > 100 Then
			Me.Height = Me.Width + START_POS * 2 + BWBtn.Height
			BoardWid = Me.Width - START_POS * 2
			StrIdx = CInt(BoardWid / 18)
			canDrawBoard = True
			canDrawChess = True
			canDrawQi = isShowQi
			BWBtn.SetBounds(0, Me.Height - 30 - 20, 70, 20)
			ChmBtn.SetBounds(70, Me.Height - 30 - 20, 70, 20)
			BBtn.SetBounds(140, Me.Height - 30 - 20, 70, 20)
			WBtn.SetBounds(210, Me.Height - 30 - 20, 70, 20)
			POBtn.SetBounds(280, Me.Height - 30 - 20, 70, 20)
			SQBtn.SetBounds(350, Me.Height - 30 - 20, 70, 20)
			ClrBtn.SetBounds(420, Me.Height - 30 - 20, 70, 20)
		End If
	End Sub


	'窗口移过头，重画
	Private Sub MainForm_Move(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Move
		If Me.Location.X < 0 Or Me.Location.X > Screen.PrimaryScreen.WorkingArea.Right - Me.Width Or Me.Location.Y < 0 Or Me.Location.Y > Screen.PrimaryScreen.WorkingArea.Bottom - Me.Width Then
			canDrawBoard = True
			canDrawChess = True
			canDrawQi = isShowQi
		End If
	End Sub


	'鼠标点击 / 下棋
	Private Sub MainForm_MouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Me.MouseClick
		If e.X < START_POS Or e.X > BoardWid + START_POS Or e.Y < START_POS Or e.Y > BoardWid + START_POS Then Exit Sub
		PutChess(e.X, e.Y)
	End Sub

	'=========================================================================
	Private Sub DrawTimer_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DrawTimer.Tick
		If canDrawBoard Then
			Call DrawBoard()
			canDrawBoard = False
		End If
		If canDrawChess Then
			Call DrawAllChess()
			canDrawChess = False
		End If
		If isShowQi And canDrawQi Then
			Call PutAllQi()
			Call DrawAllQi()
			'绘出一次则无效，防止重复绘
			canDrawQi = False
		End If
	End Sub

	'==========================================================================
	'按钮事件
	Private Sub BWBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BWBtn.Click
		'MsgBox("传统的棋子显示方式，" + Chr(10) + _
		'"适用于初学或中上水平的棋手。")
		BWBtn.BackColor = Color.DarkGreen
		ChmBtn.BackColor = Color.ForestGreen
		BBtn.BackColor = Color.ForestGreen
		WBtn.BackColor = Color.ForestGreen
		POBtn.BackColor = Color.ForestGreen
		InfoLab.Visible = True

		ChessMode = BW_COLOR
		'正常切换落子方
		If isSglClr Then
			ChessNum = CShort(IIf(ChessNum = BLACK, WHITE, BLACK))
			isSglClr = False
		End If
		BWBtn.Text = CStr(IIf(ChessNum = BLACK, "黑 / 白棋", "白 / 黑棋"))
		isPickOut = False
		canDrawBoard = True
		canDrawChess = True
		canDrawQi = isShowQi
	End Sub

	Private Sub ChmBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ChmBtn.Click
		'MsgBox("使用一色棋可增强记忆力，" + Chr(10) + _
		'"长期训练可大大提高算路，" + Chr(10) + _
		'"能力达到一定水平方可驾驭。")
		BWBtn.BackColor = Color.ForestGreen
		ChmBtn.BackColor = Color.DarkGreen
		BBtn.BackColor = Color.ForestGreen
		WBtn.BackColor = Color.ForestGreen
		POBtn.BackColor = Color.ForestGreen
		InfoLab.Visible = False

		ChessMode = CHROME_COLOR
		If isSglClr Then
			ChessNum = CShort(IIf(ChessNum = BLACK, WHITE, BLACK))
			isSglClr = False
		End If
		isPickOut = False
		canDrawBoard = True
		canDrawChess = True
		canDrawQi = isShowQi
	End Sub

	Private Sub BBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BBtn.Click
		'BWBtn.BackColor = Color.ForestGreen  '不改变模式按钮颜色，以防误按
		'ChmBtn.BackColor = Color.ForestGreen
		BBtn.BackColor = Color.DarkGreen
		WBtn.BackColor = Color.ForestGreen
		POBtn.BackColor = Color.ForestGreen

		ChessNum = BLACK
		isSglClr = True
		isPickOut = False
	End Sub

	Private Sub WBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles WBtn.Click
		'BWBtn.BackColor = Color.ForestGreen
		'ChmBtn.BackColor = Color.ForestGreen
		BBtn.BackColor = Color.ForestGreen
		WBtn.BackColor = Color.DarkGreen
		POBtn.BackColor = Color.ForestGreen

		ChessNum = WHITE
		isSglClr = True
		isPickOut = False
	End Sub

	Private Sub POBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles POBtn.Click
		'BWBtn.BackColor = Color.ForestGreen
		'ChmBtn.BackColor = Color.ForestGreen
		BBtn.BackColor = Color.ForestGreen
		WBtn.BackColor = Color.ForestGreen
		POBtn.BackColor = Color.DarkGreen

		isPickOut = True
	End Sub

	Private Sub SQBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SQBtn.Click
		isShowQi = Not isShowQi
		SQBtn.Text = IIf(isShowQi, "隐藏气眼", "显示气眼").ToString
		canDrawBoard = True
		canDrawChess = True
		canDrawQi = isShowQi  '必须重新绘出气眼
	End Sub

	Private Sub ClrBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClrBtn.Click
		Dim TmpX, TmpY As Short

		If MsgBox("您确定要将棋盘上的棋子全部清除并重新开始？", MsgBoxStyle.Question Or MsgBoxStyle.YesNo, "Warning - [" + Me.Text + "]") = MsgBoxResult.No Then Exit Sub

		For TmpY = 0 To 18 Step 1
			For TmpX = 0 To 18 Step 1
				Chess(TmpX, TmpY) = NONE
				ChessQi(TmpX, TmpY) = NONE
				hasChecked(TmpX, TmpY) = False
			Next
		Next

		'BWBtn.BackColor = Color.DarkGreen
		BWBtn.Text = "黑 / 白棋"
		'ChmBtn.BackColor = Color.ForestGreen
		BBtn.BackColor = Color.ForestGreen
		WBtn.BackColor = Color.ForestGreen
		POBtn.BackColor = Color.ForestGreen
		InfoLab.Text = "黑棋0，白棋0"

		ChessNum = BLACK
		isSglClr = False
		isPickOut = False
		canDrawBoard = True
		canDrawChess = True
	End Sub
End Class
