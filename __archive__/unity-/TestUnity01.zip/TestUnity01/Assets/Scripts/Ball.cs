﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ball : MonoBehaviour
{
    // Use this for initialization
    private  void Start()
    {
        this.GetComponent<Rigidbody>().velocity = new Vector3(0.0f, 5.0f, -8.0f);
    }

    // Update is called once per frame
    private  void Update()
    {
    }

    private void OnBecameInvisible()
    {
        Destroy(this.gameObject);
    }
}
