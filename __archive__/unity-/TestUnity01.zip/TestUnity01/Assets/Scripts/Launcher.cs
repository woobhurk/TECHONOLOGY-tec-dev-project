﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Launcher : MonoBehaviour
{
    public GameObject ballPrefab;

    // Use this for initialization
    private  void Start()
    {
    }

    // Update is called once per frame
    private  void Update()
    {
        if (Input.GetMouseButtonDown(1))
        {
            Instantiate(this.ballPrefab);
        }
    }
}
