﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Cube : MonoBehaviour
{
    private float jumpSpeed = 10.0f;
    private bool isLanding = false;

    // Use this for initialization
    private  void Start()
    {
    }

    // Update is called once per frame
    private  void Update()
    {
        if (isLanding)
        {
            if (Input.GetMouseButtonDown(0))
            {
                this.GetComponent<Rigidbody>().velocity = Vector3.up * this.jumpSpeed;
                isLanding = false;
            }
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Floor"))
        {
            this.isLanding = true;
        }
    }
}
