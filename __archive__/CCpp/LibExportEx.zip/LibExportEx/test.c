#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <string.h>

void export(void);
void GetWidth(void);
void PutLeader(void);
void setdat(void);

FILE *libFile, *bmpFile;
char libFN[100], bmpFN[200];
int MaxID, StartID, EndID, ExpNum, NowID;
int libFP, bmpFP, width, height, bmpWidth;
int dat0, dat1, dat2, dat3;

int main(void)
{
	char cTmp[10];

	InputName:
	printf("LIB Filename: ");
	gets(libFN);
	libFN[99] = '\0';
	if((libFile = fopen(libFN, "rb")) == NULL)
	{
		printf("No such file '%s'!\n", libFN);
		getch();
		system("cls");
		goto InputName;
	}
	fread(&MaxID, 4, 1, libFile);

	printf("\n������ʼID�����%d����", MaxID);
	gets(cTmp);
	cTmp[9] = '\0';
	StartID = atoi(cTmp);
	if(StartID < 1) StartID = 1;
	else if(StartID > MaxID) StartID = MaxID;
	--StartID;

	printf("\n�������������%d����", MaxID - StartID);
	gets(cTmp);
	cTmp[9] = '\0';
	ExpNum = atoi(cTmp);
	if((EndID = StartID + ExpNum) < StartID) EndID = StartID;

	export();
	getch();
	return 0;
}



//���������ĺ�����
void export(void)
{
	int baseFP;
	int PicX, PicY;
	int clr, clrR, clrG, clrB;
	char bmpFN[200];

	system("@MD LibExport>NUL");
	if(strstr(libFN, ".lib") != NULL) libFN[strlen(libFN) - 4] = '\0';
	for(NowID = StartID; NowID < EndID; NowID++)
	{
		GetWidth();
		baseFP = libFP;
		sprintf(bmpFN, "LibExport\\\\%s_%d.bmp", libFN, NowID + 1);
		if((bmpFile = fopen(bmpFN, "wb")) == NULL)
		{
			printf("ִ�� 'export' ����ʱ������\n");
			return;
		}
		PutLeader();
		for(PicY = height - 1; PicY > -1; PicY--)
		{
			for(PicX = 0; PicX < bmpWidth; PicX++)
			{
				if(PicX < width)
				{
					setdat();
					clr = dat1 << 8 | dat0;
					clrR = clr >> 11 << 3;
					clrG = (clr % 2048) >> 5 << 2;
					clrB = (clr % 32) << 3;
					clr = (clrR << 16) | (clrG << 8) | clrB;
				}
				else
					clr = 0xff00ff;
				fseek(bmpFile, bmpFP, SEEK_SET);
				fwrite(&clr, 4, 1, bmpFile);
				bmpFP += 3;
				libFP = baseFP + (PicX + PicY * width) * 2;
			}
		}
		fclose(bmpFile);
	}
	printf("\nLIB�ļ��Ѿ��ɹ�������\n�������ڱ�Ŀ¼�µ�LibExport�¡�\n");
}



//��ȡͼƬ������
void GetWidth(void)
{
	libFP = NowID * 4 + 4;
	fseek(libFile, libFP, SEEK_SET);
	fread(&libFP, 4, 1, libFile);
	libFP += 4;
	setdat();
	width = dat1 << 8 | dat0;
	height = dat3 << 8 | dat2;
	bmpWidth = width - width % 4 + 4;
	if(width % 4 == 0) bmpWidth -= 4;
	libFP += 12;
}



//����ļ�ͷ
void PutLeader(void)
{
	int puts;

	fseek(bmpFile, 0, SEEK_SET);
	putc('B', bmpFile);
	putc('M', bmpFile);
	puts = bmpWidth * height * 3 + 54;
	fwrite(&puts, 4, 1, bmpFile);
	puts = 0;
	fwrite(&puts, 4, 1, bmpFile);
	puts = 54;
	fwrite(&puts, 4, 1, bmpFile);
	puts = 40;
	fwrite(&puts, 4, 1, bmpFile);
	fwrite(&bmpWidth, 4, 1, bmpFile);
	fwrite(&height, 4, 1, bmpFile);
	puts = 1572864;
	fwrite(&puts, 4, 1, bmpFile);
	puts = 0;
	fwrite(&puts, 4, 1, bmpFile);
	puts = bmpWidth * height * 3;
	fwrite(&puts, 4, 1, bmpFile);
	puts = 0;
	fwrite(&puts, 4, 1, bmpFile);
	fwrite(&puts, 4, 1, bmpFile);
	fwrite(&puts, 4, 1, bmpFile);
	fwrite(&puts, 4, 1, bmpFile);
	bmpFP = 54;
}



//��������
void setdat(void)
{
	fseek(libFile, libFP, SEEK_SET);
	dat0 = fgetc(libFile);
	if(dat0 < 0) dat0 += 256;

	dat1 = fgetc(libFile);
	if(dat1 < 0) dat1 += 256;

	dat2 = fgetc(libFile);
	if(dat2 < 0) dat2 += 256;

	dat3 = fgetc(libFile);
	if(dat3 < 0) dat3 += 256;
}
