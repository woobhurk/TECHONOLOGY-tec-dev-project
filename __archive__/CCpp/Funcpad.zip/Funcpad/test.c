#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include <windows.h>
#include <winsock.h>
#define ICO_MAIN 0
#define TXT_MAIN 10
#define BUTTON_OK 20
#define BUTTON_CLEAR 30
#define BUTTON_ABOUT 40
#define PIC_OK 50
#define PIC_CLEAR 60
#define PIC_ABOUT 70

#define LSIZE 60
#define DEF_WIDTH 860
#define DEF_HEIGHT 600
#define MAXSIZE 25
#define SYN_X 'x'
#define SYN_ADD '+'
#define SYN_SUB '-'
#define SYN_PWR '^'
#define SYN_DOT '.'
#define SE_UNKNOWN -1
#define SE_SYNTAX -2

#define CLEANERRORFUNC \
int y1, y2;\
BOOL isErr1 = FALSE, isErr2 = FALSE;\
y1 = OYPos - 1;\
y2 = OYPos + 1;\
while(y1 > -1 || y2 < height)\
{\
	if(PointPos[y1].x == 0) isErr1 = TRUE;\
	if(PointPos[y2].x == 0) isErr2 = TRUE;\
	--y1;\
	++y2;\
}\
if(isErr1 || isErr2)\
{\
	HPEN hPen;\
	hPen = CreatePen(PS_SOLID, 2, 0x00ffffff);\
	SelectObject(hDC, hPen);\
	MoveToEx(hDC, OXPos, 0, NULL);\
	LineTo(hDC, OXPos, height);\
	DeleteObject(hPen);\
}

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
void DrawLine(HDC);
void DrawMouseLine(HDC, int, int);
void EditExp(char *, const char *, int);
int CheckExp(const char *);
void ShowError(HDC, int);
int DivExp(const char *, char (*)[MAXSIZE]);
BOOL isNum(const char *);
BOOL isPowerFunc(const char *);
double GetHand(const char *);
double GetPower(double, const char *);
double CountVal(double, const char *);
int DrawFunc(HDC, const char *, char (*)[MAXSIZE]);
void CleanErrorFunc(HDC);
void ShowAbout(void);

int width, height;
int OXPos = DEF_WIDTH / 2, OYPos = DEF_HEIGHT / 2;  //ԭ�����Ļ����
int LineSize = LSIZE;  //��λ��
POINT PointPos[1024];

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nShowCmd)
{
	char *cName = TEXT("Window1");
	char *cCaption = TEXT("��������V8.47Beta - L.W.");
	HWND hWnd;
	MSG msg;
	WNDCLASSEX wc;

	wc.cbClsExtra = 0;
	wc.cbWndExtra = 0;
	wc.cbSize = sizeof(WNDCLASSEX);
	wc.style = CS_HREDRAW | CS_VREDRAW;
	wc.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	wc.hIcon = LoadIcon(hInstance, MAKEINTRESOURCE(ICO_MAIN));
	wc.hIconSm = LoadIcon(hInstance, MAKEINTRESOURCE(ICO_MAIN));
	wc.hCursor = LoadCursor(NULL, IDC_CROSS);
	wc.hInstance = hInstance;
	wc.lpfnWndProc = WndProc;
	wc.lpszClassName = cName;
	wc.lpszMenuName = NULL;
	RegisterClassEx(&wc);
	hWnd = CreateWindowEx(WS_EX_CLIENTEDGE, cName, cCaption, WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT, DEF_WIDTH, DEF_HEIGHT, NULL, NULL, hInstance, NULL);
	if(hWnd == NULL)
	{
		MessageBox(NULL, TEXT("Cannot create the window!\n"), TEXT("Error"), MB_ICONERROR);
		return 0;
	}
	ShowWindow(hWnd, nShowCmd);
	UpdateWindow(hWnd);
	while(GetMessage(&msg, NULL, 0, 0))
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
	return msg.wParam;
}



LRESULT CALLBACK WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	static char ExpStr[50][MAXSIZE * MAXSIZE], SubStr[MAXSIZE][MAXSIZE];
	static int ExpNum = 0;
	static int NowMouseX = DEF_WIDTH + 1, NowMouseY = DEF_HEIGHT + 1, LastMouseX, LastMouseY;
	static BOOL MouseDown = FALSE;
	static HWND hEdit, hBtnOK, hBtnClr, hBtnAbt;
	static HBITMAP hBitmap[3];
	static BITMAP bitmap[3];
	static HDC hDC, hDCMem;
	static HFONT hFont;
	static LOGFONT lf;
	PAINTSTRUCT ps;
	LPDRAWITEMSTRUCT pdis;
	int cnt;

	switch(msg)
	{
	case WM_CREATE:
		hEdit = CreateWindow(TEXT("edit"), "2 ^ x", WS_CHILD | WS_VISIBLE | WS_BORDER | ES_LEFT | ES_AUTOHSCROLL | ES_LOWERCASE, 32, 0, 160, 20, hWnd, (HMENU)TXT_MAIN, ((LPCREATESTRUCT)lParam) -> hInstance, NULL);
		hBtnOK = CreateWindow(TEXT("button"), "- OK -", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON | BS_OWNERDRAW, 202, 0, 50, 20, hWnd, (HMENU)BUTTON_OK, ((LPCREATESTRUCT)lParam) -> hInstance, NULL);
		hBtnClr = CreateWindow(TEXT("button"), "- Clear -", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON | BS_OWNERDRAW, 257, 0, 70, 20, hWnd, (HMENU)BUTTON_CLEAR, ((LPCREATESTRUCT)lParam) -> hInstance, NULL);
		hBtnAbt = CreateWindow(TEXT("button"), "- About -", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON | BS_OWNERDRAW, 332, 0, 70, 20, hWnd, (HMENU)BUTTON_ABOUT, ((LPCREATESTRUCT)lParam) -> hInstance, NULL);

		strcpy(ExpStr[0], "2^x");
		lf.lfHeight = 16;  //��������
		lf.lfWeight = FW_BOLD;
		lstrcpy(lf.lfFaceName, "Times New Roman");
		hFont = CreateFontIndirect(&lf);

		hBitmap[0] = LoadBitmap(((LPCREATESTRUCT)lParam) -> hInstance, MAKEINTRESOURCE(PIC_OK));
		GetObject(hBitmap[0], sizeof(BITMAP), &bitmap[0]);
		hBitmap[1] = LoadBitmap(((LPCREATESTRUCT)lParam) -> hInstance, MAKEINTRESOURCE(PIC_CLEAR));
		GetObject(hBitmap[1], sizeof(BITMAP), &bitmap[1]);
		hBitmap[2] = LoadBitmap(((LPCREATESTRUCT)lParam) -> hInstance, MAKEINTRESOURCE(PIC_ABOUT));
		GetObject(hBitmap[2], sizeof(BITMAP), &bitmap[2]);
		SendMessage(hWnd, WM_PAINT, 0, 0);  //�Ƚ�hDC������Чֵ���ٻ����ť��
		return 0;
	case WM_SIZE:
		width = LOWORD(lParam);
		height = HIWORD(lParam);
		return 0;
	case WM_PAINT:
		hDC = BeginPaint(hWnd, &ps);
		SetBkMode(hDC, TRANSPARENT);
		SelectObject(hDC, hFont);
		for(cnt = 0; cnt <= ExpNum; cnt++) if(DrawFunc(hDC, ExpStr[cnt], SubStr)) --ExpNum;  //��һ����ͼ���������ʽ�Ƿ��򲻼���
		DrawLine(hDC);
		DrawMouseLine(hDC, NowMouseX, NowMouseY);
		EndPaint(hWnd, &ps);
		return 0;
	case WM_MOUSEMOVE:  //ԭ������λ��ͬ���仯
		if(!MouseDown) return 0;
		int XMin, YMin, XMax, YMax;

		XMin = OXPos + LineSize - 8;  //֮����Ҫ��ʵ�ʷ�Χ��������Ϊ����ƶ�ʱ���ܾ�ȷ����ͼʾ��Χ�ڡ�
		XMax = XMin + 16;
		YMin = OYPos - 8;
		YMax = YMin + 16;
		NowMouseX = LOWORD(lParam);  //ȡ��Ŀǰ���λ��
		NowMouseY = HIWORD(lParam);
		if(LastMouseX < XMin || LastMouseX > XMax || LastMouseY < YMin || LastMouseY > YMax)
		{
			OXPos += (NowMouseX - LastMouseX);  //ʹԭ��ͬ���ƶ�
			OYPos += (NowMouseY - LastMouseY);
		}
		else
		{
			LineSize += (NowMouseX - LastMouseX);
			if(LineSize < 8) LineSize = 8;
		}
		LastMouseX = NowMouseX;
		LastMouseY = NowMouseY;
		InvalidateRect(hWnd, NULL, TRUE);
		UpdateWindow(hWnd);
		return 0;
	case WM_MOUSEWHEEL:
		if((short)HIWORD(wParam) > 0) LineSize += 20;
		else if((short)HIWORD(wParam) < 0) LineSize -= 20;
		if(LineSize < 8) LineSize = 8;
		InvalidateRect(hWnd, NULL, TRUE);
		UpdateWindow(hWnd);
		return 0;
	case WM_LBUTTONDOWN:
		LastMouseX = LOWORD(lParam);
		LastMouseY = HIWORD(lParam);
		MouseDown = TRUE;
		SetFocus(hWnd);
		return 0;
	case WM_LBUTTONUP:
		MouseDown = FALSE;
		return 0;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{
		case BUTTON_OK:
			GetWindowText(hEdit, ExpStr[++ExpNum], MAXSIZE * MAXSIZE);
			if(*ExpStr[ExpNum] == '\0') return 0;
			if(!strcmp(ExpStr[ExpNum], ExpStr[ExpNum - 1]))
			{
				--ExpNum;
				return 0;
			}
			EditExp(ExpStr[ExpNum], ExpStr[ExpNum], sizeof(ExpStr));
			InvalidateRect(hWnd, NULL, TRUE);  //ʹ�����滭������Ч��������ͼ��ʾ
			SetFocus(hWnd);
			break;
		case BUTTON_CLEAR:
			ExpNum = -1;
			InvalidateRect(hWnd, NULL, TRUE);
		UpdateWindow(hWnd);
			SetFocus(hWnd);
			break;
		case BUTTON_ABOUT:
			ShowAbout();
			SetFocus(hWnd);
			break;
		}
		return 0;
	case WM_KEYDOWN:
		switch(wParam)
		{
		case VK_LEFT:
			if(MouseDown) NowMouseX -= 1;  //����ͬʱ��ס����򻺶�������ꡣ
			else OXPos += LSIZE - 1;
			break;
		case VK_RIGHT:
			if(MouseDown) NowMouseX += 1;
			else OXPos -= LSIZE - 1;
			break;
		case VK_UP:
			if(MouseDown) NowMouseY -= 1;
			else OYPos += LSIZE - 1;
			break;
		case VK_DOWN:
			if(MouseDown) NowMouseY += 1;
			else OYPos -= LSIZE - 1;
			break;
		}
		InvalidateRect(hWnd, NULL, TRUE);
		UpdateWindow(hWnd);
		return 0;
	case WM_DRAWITEM:
		pdis = (LPDRAWITEMSTRUCT)lParam;
		hDCMem = CreateCompatibleDC(hDC);
		switch(pdis -> CtlID)  //�жϻ����Ǹ���ť
		{
		case BUTTON_OK:
			SelectObject(hDCMem, hBitmap[0]);
			BitBlt(hDC, pdis -> rcItem.left, pdis -> rcItem.top, bitmap[0].bmWidth, bitmap[0].bmHeight, hDCMem, 0, 0, SRCCOPY);
			break;
		case BUTTON_CLEAR:
			SelectObject(hDCMem, hBitmap[1]);
			BitBlt(hDC, pdis -> rcItem.left, pdis -> rcItem.top, bitmap[1].bmWidth, bitmap[1].bmHeight, hDCMem, 0, 0, SRCCOPY);
			break;
		case BUTTON_ABOUT:
			SelectObject(hDCMem, hBitmap[2]);
			BitBlt(hDC, pdis -> rcItem.left, pdis -> rcItem.top, bitmap[2].bmWidth, bitmap[2].bmHeight, hDCMem, 0, 0, SRCCOPY);
			break;
		}
		DeleteDC(hDCMem);
		return 0;
	case WM_CLOSE:  //�رմ�����Ч
		;  //��ʵ�����⣬ֻ��������ֹ�����������á�
		RECT WindowRect;
		double cnt = width / height;
		GetWindowRect(hWnd, &WindowRect);
		while(width > 120)
		{
			MoveWindow(hWnd, WindowRect.left, WindowRect.top, width, (int)width / cnt, TRUE);
			width -= 1;
		}
	case WM_DESTROY:
		DeleteObject(hBitmap[0]);
		DeleteObject(hBitmap[1]);
		DeleteObject(hBitmap[2]);
		PostQuitMessage(0);
		return 0;
	}
	return DefWindowProc(hWnd, msg, wParam, lParam);
}



//����ƽ��ֱ������ϵ
void DrawLine(HDC hDC)
{
	int x, y;
	int XMax, YMax;
	int XPos, YPos;
	static HPEN hPen1, hPen2;
	char tmpchr[4] = {'\0', '\0', '\0', '\0'};

	hPen1 = CreatePen(PS_SOLID, 1, 0x00000000);  //����ϵ����
	hPen2 = CreatePen(PS_SOLID, 1, 0x00ffc8f0);  //���񻭱�
	SelectObject(hDC, hPen1);
	Rectangle(hDC, OXPos + LineSize - 4, OYPos - 4, OXPos + LineSize + 4, OYPos + 4);  //�����λ�����ƿ�֮����Ҫ���Ȼ������Ϊ�������亯��������������Ḳ�ǵ���
	MoveToEx(hDC, 0, OYPos, NULL);  //����x��y��
	LineTo(hDC, width, OYPos);
	MoveToEx(hDC, OXPos, 0, NULL);
	LineTo(hDC, OXPos, height);
	MoveToEx(hDC, OXPos - 3, 6, NULL);  //������ͷ
	LineTo(hDC, OXPos, 0);
	LineTo(hDC, OXPos + 4, 7);
	MoveToEx(hDC, width - 6, OYPos - 3, NULL);
	LineTo(hDC, width, OYPos);
	LineTo(hDC, width - 7, OYPos + 4);

	XMax = (OXPos > width - OXPos) ? OXPos * 2 : width;  //�ж�y���ı߸����������߸�������ȡ 2 * OXPos������ȡwidth��
	for(x = OXPos + LineSize; x <= XMax; x += LineSize)  //���x��̶�
	{
		SelectObject(hDC, hPen2);
		MoveToEx(hDC, x, 0, NULL);
		LineTo(hDC, x, height);
		MoveToEx(hDC, OXPos * 2 - x, 0, NULL);
		LineTo(hDC, OXPos * 2 - x, height);

		SelectObject(hDC, hPen1);
		MoveToEx(hDC, x, OYPos - 3, NULL);
		LineTo(hDC, x, OYPos);
		MoveToEx(hDC, OXPos * 2 - x, OYPos - 3, NULL);  //�ȼ���x = OXPos - (x - OXPos);
		LineTo(hDC, OXPos * 2 - x, OYPos);

		if((x - OXPos) / LineSize % 2 == 0)  //���㵱ǰ�̶�
		{
			if(OYPos < 0) YPos = 0;
			else if(OYPos > height) YPos = height - 16;
			else YPos = OYPos + 2;
			itoa((x - OXPos) / LineSize, tmpchr, 10);
			TextOut(hDC, x - 6, YPos, tmpchr, strlen(tmpchr));
			itoa((OXPos - x) / LineSize, tmpchr, 10);  //ȡ��ǰ�̶��෴��
			TextOut(hDC, OXPos * 2 - x - 6, YPos, tmpchr, strlen(tmpchr));
		}
	}
	YMax = (OYPos > height - OYPos) ? OYPos * 2 : height;
	for(y = OYPos + LineSize; y <= YMax; y += LineSize)  //���y��̶�
	{
		SelectObject(hDC, hPen2);
		MoveToEx(hDC, 0, y, NULL);
		LineTo(hDC, width, y);
		MoveToEx(hDC, 0, OYPos * 2 - y, NULL);
		LineTo(hDC, width, OYPos * 2 - y);

		SelectObject(hDC, hPen1);
		MoveToEx(hDC, OXPos + 3, y, NULL);
		LineTo(hDC, OXPos, y);
		MoveToEx(hDC, OXPos + 3, OYPos * 2 - y, NULL);
		LineTo(hDC, OXPos, OYPos * 2 - y);

		if((y - OYPos) / LineSize % 2 == 0)
		{
			if(OXPos < 0) XPos = 0;
			else if(OXPos > width) XPos = width - 16;
			else XPos = OXPos - 24;
			itoa((OYPos - y) / LineSize, tmpchr, 10);
			TextOut(hDC, XPos, y - 8, tmpchr, strlen(tmpchr));
			itoa((y - OYPos) / LineSize, tmpchr, 10);
			TextOut(hDC, XPos, OYPos * 2 - y - 8, tmpchr, strlen(tmpchr));
		}
	}
	TextOut(hDC, OXPos - 12, 16, "y", 1);  //��ʾx��O��y
	TextOut(hDC, width - 12, OYPos, "x", 1);
	TextOut(hDC, OXPos - 12, OYPos, "O", 1);
	TextOut(hDC, 0, 0, "f(x) =", 6);  //��ʾ��������ʽͷ

	DeleteObject(hPen1);
	DeleteObject(hPen2);
}



//���������������ֱ�ߣ�����û��- -.
void DrawMouseLine(HDC hDC, int NowMouseX, int NowMouseY)
{
	double x, y;
	char pos[32];
	HPEN hPen;

	hPen = CreatePen(PS_SOLID, 1, 0x00ff8000);
	SelectObject(hDC, hPen);
	MoveToEx(hDC, NowMouseX, 0, NULL);
	LineTo(hDC, NowMouseX, height);
	MoveToEx(hDC, 0, NowMouseY, NULL);
	LineTo(hDC, width, NowMouseY);
	x = (double)(NowMouseX - OXPos) / LineSize;
	y = (double)(OYPos - NowMouseY) / LineSize;
	sprintf(pos, "(%lf, %lf)", x, y);
	TextOut(hDC, NowMouseX, NowMouseY, pos, strlen(pos));

	DeleteObject(hPen);
}



//������ʽ�еĿո�ȫ��ȥ��
void EditExp(char *outstr, const char *instr, int maxcount)
{
	int pos1 = 0, pos2 = 0;

	while(instr[pos1])
	{
		if(pos2 >= maxcount - 1) return;  //����1�ֽ����洢'\0'�ֽ�
		if(instr[pos1] != ' ') outstr[pos2++] = instr[pos1];
		++pos1;
	}
	outstr[pos2] = '\0';
}



//������ʽ�Ƿ�������޷�����
int CheckExp(const char *ExpStr)
{
	int cnt = 0, cnt2 = 1;

	for(; ExpStr[cnt] && ExpStr[cnt2]; cnt++, cnt2++)
	{
		switch(ExpStr[cnt])
		{
		case SYN_X:
			if(ExpStr[cnt2] != SYN_ADD && ExpStr[cnt2] != SYN_SUB && ExpStr[cnt2] != SYN_PWR) return SE_SYNTAX;
			break;
		case SYN_ADD: case SYN_SUB:
			if(ExpStr[cnt2] != SYN_X && !isdigit(ExpStr[cnt2])) return SE_SYNTAX;
			break;
		case SYN_PWR:
			if(ExpStr[cnt2] != SYN_X && ExpStr[cnt2] != SYN_ADD && ExpStr[cnt2] != SYN_SUB && !isdigit(ExpStr[cnt2])) return SE_SYNTAX;
			break;
		case SYN_DOT:
			if(!isdigit(ExpStr[cnt2])) return SE_SYNTAX;
			break;
		case '0': case '1': case '2': case '3': case '4':
		case '5': case '6': case '7': case '8': case '9':
			if(ExpStr[cnt2] != SYN_X && ExpStr[cnt2] != SYN_ADD && ExpStr[cnt2] != SYN_SUB && ExpStr[cnt2] != SYN_PWR && ExpStr[cnt2] != SYN_DOT && !isdigit(ExpStr[cnt2])) return SE_SYNTAX;
			break;
		default:
			return SE_UNKNOWN;
		}
	}
	return 0;
}



//��ʾ������Ϣ
void ShowError(HDC hDC, int ErrorCode)
{
	char *ErrorText;

	switch(ErrorCode)
	{
	case SE_UNKNOWN:
		ErrorText = "Unknown syntax or alpha!!";
		break;
	case SE_SYNTAX:
		ErrorText = "Syntax error!!";
		break;
	}
	TextOut(hDC, 25, 20, ErrorText, strlen(ErrorText));
}



//������ʽ��ÿһ��ı���ʽ�洢�������Ӿ���
int DivExp(const char *ExpStr, char (*SubStr)[MAXSIZE])
{
	int cnt = 0;
	int pos1 = 0, pos2 = 0;

	while(ExpStr[cnt])
	{
		switch(ExpStr[cnt])
		{
		case SYN_X:
			SubStr[pos1][pos2++] = SYN_X;
			break;
		case SYN_ADD: case SYN_SUB:
			if(ExpStr[cnt - 1] == SYN_PWR || cnt == 0)  //����ӺŻ����ǰ�治���ݣ����ֵ���һ���Ӿ丳ֵ��
				SubStr[pos1][pos2++] = ExpStr[cnt];
			else
			{
				SubStr[pos1++][pos2] = '\0';  //ȥ����һ���Ӿ�ķǷ��ַ���
				SubStr[pos1][0] = ExpStr[cnt];
				pos2 = 1;
			}
			break;
		case SYN_PWR:
			SubStr[pos1][pos2++] = SYN_PWR;
			break;
		case SYN_DOT:
			SubStr[pos1][pos2++] = SYN_DOT;
			break;
		case '0': case '1': case '2': case '3': case '4':
		case '5': case '6': case '7': case '8': case '9':
			SubStr[pos1][pos2++] = ExpStr[cnt];
			break;
		}
		++cnt;
	}
	SubStr[pos1++][pos2] = '\0';  //��SubStr���һ��Ԫ�ص����һ���ַ����㡣
	return pos1;
}



//�ж��ַ����Ƿ�Ϊ���ֻ򸡵���
BOOL isNum(const char *SubStr)
{
	int cnt = 0;

	while(SubStr[cnt])
	{
		if(SubStr[cnt] != SYN_ADD && SubStr[cnt] != SYN_SUB && SubStr[cnt] != SYN_DOT && !isdigit(SubStr[cnt])) return FALSE;
		++cnt;
	}
	return TRUE;
}



//�ж��Ӿ��Ƿ�Ϊָ������
BOOL isPowerFunc(const char *SubStr)
{
	char *PowerPos, *XPos;
	char tmpStr[MAXSIZE];
	PowerPos = strchr(SubStr, SYN_PWR);
	XPos = strchr(SubStr, SYN_PWR);
	strcpy(tmpStr, SubStr);
	if(PowerPos != NULL) tmpStr[PowerPos - SubStr] = '\0';
	else return FALSE;
	if(!isNum(tmpStr)) return FALSE;
	return TRUE;
}



//��ȡϵ��
double GetHand(const char *SubStr)
{
	int cnt = 0, cnt2 = 0;
	char hand[MAXSIZE];

	while(SubStr[cnt] != SYN_X && SubStr[cnt] != SYN_PWR && SubStr[cnt]) hand[cnt2++] = SubStr[cnt++];
	hand[cnt2] = '\0';
	if(!strcmp(hand, "+") || *hand == '\0') return 1.0;
	else if(!strcmp(hand, "-")) return -1.0;
	else return atof(hand);
}



//��ȡָ��
double GetPower(double XPos, const char *SubStr)
{
	char *PowerPos, power[MAXSIZE];

	if((PowerPos = strchr(SubStr, SYN_PWR)) == NULL) return 1.0;
	strcpy(power, PowerPos + 1);
	if(!isPowerFunc(SubStr))
	{
		/*if(!strcmp(power, "+")) return 1.0;
		else if(!strcmp(power, "-")) return -1.0;
		else return atof(power);*/
		return atof(power);
	}
	else
	{
		if(isNum(power)) return atof(power);
		power[strlen(power) - 1] = '\0';
		if(*power == '\0') return XPos;
		return atof(power) * XPos;
	}
}



//���㵥��ʽ��ֵ
double CountVal(double x, const char *SubStr)
{
	double XPos;
	double SubPower, SubHand;

	if(isNum(SubStr)) return atof(SubStr) * LineSize;
	XPos = (x - OXPos) / LineSize;  //��Ļ����ת��Ϊ����ϵ���꣬x����Ļ���꣬XPos������ϵ���ꡣ
	SubHand = GetHand(SubStr);
	SubPower = GetPower(XPos, SubStr);
	if(!isPowerFunc(SubStr))
	{
		XPos = pow(XPos, SubPower);
		x = XPos * SubHand * LineSize;
	}
	else
	{
		x = pow(SubHand, SubPower) * LineSize;
	}
	return x;
}



//�������ͼ��
int DrawFunc(HDC hDC, const char *ExpStr, char (*SubStr)[MAXSIZE])
{
	int XPos, max;
	int ErrorCode;
	double y;
	static HPEN hPen;
	int cnt;

	ErrorCode = CheckExp(ExpStr);
	if(ErrorCode)
	{
		ShowError(hDC, ErrorCode);
		return -1;
	}
	max = DivExp(ExpStr, SubStr);
	for(XPos = 0; XPos < width; XPos++)
	{
		y = 0.0;
		cnt = 0;
		while(cnt < max) y += CountVal((double)XPos, SubStr[cnt++]);
		PointPos[XPos].x = XPos;
		PointPos[XPos].y = OYPos - y;  //��ֱ������ϵ����ת��Ϊ��Ļ���ꡣ
	}
	hPen = CreatePen(PS_SOLID, 2, 0x00f000f0);
	SelectObject(hDC, hPen);
	Polyline(hDC, PointPos, width);
	DeleteObject(hPen);
	//CleanErrorFunc(hDC);
	CLEANERRORFUNC;
	return 0;
}



//��� x = 0 ����ֱ��
void CleanErrorFunc(HDC hDC)
{
	int y1, y2;
	BOOL isErr1 = FALSE, isErr2 = FALSE;
	y1 = OYPos - 1;
	y2 = OYPos + 1;
	while(y1 > -1 || y2 < height)
	{
		if(PointPos[y1].x == 0) isErr1 = TRUE;
		if(PointPos[y2].x == 0) isErr2 = TRUE;
		--y1;
		++y2;
	}
	if(isErr1 || isErr2)
	{
		HPEN hPen;
		hPen = CreatePen(PS_SOLID, 2, 0x00ffffff);
		SelectObject(hDC, hPen);
		MoveToEx(hDC, OXPos, 0, NULL);
		LineTo(hDC, OXPos, height);
		DeleteObject(hPen);
	}
}



//��ʾ��������
void ShowAbout(void)
{
	char *HelpText;
	HelpText ="\
	�ǳ���л��ʹ���������\n\n\
	���������������ڻ������������ͼ�񣬱��������ܡ�\n\
	����ʼ��Ĭ�ϻ������ y = 2 ^ x ��ͼ��\n\
	������Ȼ�ܻ�������ͼ�񣬵�ͼ����״�����ο���������\n\
	ȫ�������Ͼ��������������ݴ������ܲ�����һ����\n\
	�ܡ�\n\
	ллʹ�á�\n\
	\t\t\t\t��һ��2����\n\
	\t\t\t\t�ⱦ�� ����\n\
	Version: V8.47 Beta\n\
	Copyright(C)LationWorkgroup 2012.\n\
	All rights reserved.";
	MessageBox(NULL, HelpText, "- About -", MB_ICONINFORMATION | MB_OK);
}
