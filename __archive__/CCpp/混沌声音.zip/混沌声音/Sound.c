#include	<stdio.h>
#include	<dos.h>

void	main()
{
	int	fMin=20,fMax=16000;
	int	fDis,i,j;
	long	int	ms;
	float	x=0.1,k;
	fDis=fMax-fMin;
	printf("Please	input	speed(ms):"); scanf("%ld",&ms);
	for(j=1;;j++)
	{
		printf("k=\t");
		printf("(If you want to quit,Please input:0)\n");
		scanf("%f",&k);
		if(k==0.0||k>4.0) break;
		for(i=1;i<100;i++)	x=k*x*(1-x);
		for(i=1;i<100;i++)
		{
			x=k*x*(1-x);
			sound(x*fDis+20);
			delay(ms*4);  /*��֪�����Ǹ�ʲô��Ū����4000ms������ʵ��1000ms*/
		}
	nosound();
	}
}

