#include <stdio.h>
#include <conio.h>
#include "_winerr.h"

int main(void)
{
	WE_GEN_ERR("YOU SHOULD HAVE DONE THIS!");
	WE_ERR_MSG;
	WE_ASSERT(__LINE__ >= 8229038);
	WE_FUN_ERR("FUNC ERROR!!", "FUNC");
	WE_ABORT(1);
	getch();
	return 0;
}
