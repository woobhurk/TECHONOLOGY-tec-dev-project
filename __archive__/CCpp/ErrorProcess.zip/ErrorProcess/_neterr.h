/*
This file includeing some general error-out macros.
Header:	_neterr.h
Author:	Woobhurk
Date:	2013.08.10
Note:
	NE - Network Error
*/
#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <winsock2.h>

#define ERRBUF_SIZE 1024

char errBuf[ERRBUF_SIZE];

//Show general errors��ʾ�������
#define NE_GEN_ERR(_ERR_MSG) \
	snprintf(errBuf, ERRBUF_SIZE, \
		"ERROR at %d:\n  - %s", \
		__LINE__, _ERR_MSG); \
	MessageBox(NULL, errBuf, TEXT("ERROR"), MB_OK)
//Show functional errors��ʾ��������
#define NE_FUN_ERR(_ERR_MSG, _FUN_NAME) \
	snprintf(errBuf, ERRBUF_SIZE, \
		"ERROR at %d:\n  - %s\n  - Function<%s> ERROR: %d", \
		__LINE__, _ERR_MSG, _FUN_NAME, WSAGetLastError()); \
	MessageBox(NULL, errBuf, TEXT("ERROR"), MB_OK)
//Show error messages��ʾ���󾯸�
#define NE_ERR_MSG \
	MessageBox(NULL, \
		TEXT("There has been an ERROR in the program.\nIf you want to continue, press 'OK'."), \
		TEXT("ERROR"), MB_OK)
//Abort�жϳ���
#define NE_ABORT(_ERR_CODE) \
	MessageBox(NULL, \
		TEXT("You now have to QUIT or RESTART."), \
		TEXT("ERROR"), MB_OK); \
	exit(_ERR_CODE)
//Assert
#define NE_ASSERT(_EXPRES) \
	if (!(_EXPRES)) \
	{ \
		snprintf(errBuf, ERRBUF_SIZE, \
			"WARNING at %d:\nExpression FAILED:\n  - %s", \
			__LINE__, #_EXPRES); \
		MessageBox(NULL, errBuf, TEXT("WARNING"), MB_OK); \
	} \
	NULL
