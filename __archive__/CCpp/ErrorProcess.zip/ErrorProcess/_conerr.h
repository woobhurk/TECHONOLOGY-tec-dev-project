/*
This file includeing some general error-out macros.
Header:	_conerr.h
Author:	Woobhurk
Date:	2013.08.10
Note:
	CE - Concole Error
*/
#include <stdlib.h>
#include <conio.h>

//Show general errors��ʾ�������
#define CE_GEN_ERR(_ERR_MSG) \
	printf("> ERROR at %d:\n", __LINE__); \
	printf("  - %s\n", _ERR_MSG)
//Show functional errors��ʾ��������
#define CE_FUN_ERR(_ERR_MSG, _FUN_NAME) \
	printf("> ERROR at %d:\n", __LINE__); \
	printf("  - %s\n", _ERR_MSG); \
	printf("  - Function<%s> ERROR.\n", _FUN_NAME)
//Show error messages��ʾ���󾯸�
#define CE_ERR_MSG \
	puts("> There has been an ERROR in the program."); \
	puts("> If you want to continue, press any key."); \
	getch()
//Abort�жϳ���
#define CE_ABORT(_ERR_CODE) \
	puts("> You now have to QUIT or RESTART."); \
	getch(); \
	exit(_ERR_CODE)
//Assert
#define CE_ASSERT(_EXPRS) \
	if (!(_EXPRS)) \
	{ \
		printf("> WARNING at %d:\n", __LINE__); \
		puts("> Expression FAILED:"); \
		printf("  - %s\n", #_EXPRS); \
		getch(); \
	} \
	NULL
