﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意: 以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
		Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
		Me.TextBox1 = New System.Windows.Forms.TextBox
		Me.Label1 = New System.Windows.Forms.Label
		Me.Label2 = New System.Windows.Forms.Label
		Me.TextBox2 = New System.Windows.Forms.TextBox
		Me.Button1 = New System.Windows.Forms.Button
		Me.TabCtrl = New System.Windows.Forms.TabControl
		Me.TabPage1 = New System.Windows.Forms.TabPage
		Me.CheckBox4 = New System.Windows.Forms.CheckBox
		Me.CheckBox3 = New System.Windows.Forms.CheckBox
		Me.CheckBox2 = New System.Windows.Forms.CheckBox
		Me.CheckBox1 = New System.Windows.Forms.CheckBox
		Me.TabPage2 = New System.Windows.Forms.TabPage
		Me.CheckBox5 = New System.Windows.Forms.CheckBox
		Me.CheckBox6 = New System.Windows.Forms.CheckBox
		Me.Button2 = New System.Windows.Forms.Button
		Me.TextBox3 = New System.Windows.Forms.TextBox
		Me.Label4 = New System.Windows.Forms.Label
		Me.TextBox4 = New System.Windows.Forms.TextBox
		Me.Label3 = New System.Windows.Forms.Label
		Me.TabCtrl.SuspendLayout()
		Me.TabPage1.SuspendLayout()
		Me.TabPage2.SuspendLayout()
		Me.SuspendLayout()
		'
		'TextBox1
		'
		Me.TextBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(160, Byte), Integer))
		Me.TextBox1.Font = New System.Drawing.Font("Lucida Console", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.TextBox1.Location = New System.Drawing.Point(3, 30)
		Me.TextBox1.MaxLength = 0
		Me.TextBox1.Name = "TextBox1"
		Me.TextBox1.Size = New System.Drawing.Size(469, 23)
		Me.TextBox1.TabIndex = 0
		Me.TextBox1.TabStop = False
		'
		'Label1
		'
		Me.Label1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(0, Byte), Integer))
		Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me.Label1.Font = New System.Drawing.Font("微软雅黑", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
		Me.Label1.Location = New System.Drawing.Point(3, 3)
		Me.Label1.Name = "Label1"
		Me.Label1.Size = New System.Drawing.Size(469, 24)
		Me.Label1.TabIndex = 1
		Me.Label1.Text = "要转换的字符串"
		Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		'
		'Label2
		'
		Me.Label2.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(0, Byte), Integer))
		Me.Label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me.Label2.Font = New System.Drawing.Font("微软雅黑", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
		Me.Label2.Location = New System.Drawing.Point(3, 56)
		Me.Label2.Name = "Label2"
		Me.Label2.Size = New System.Drawing.Size(469, 24)
		Me.Label2.TabIndex = 2
		Me.Label2.Text = "输出窗口"
		Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		'
		'TextBox2
		'
		Me.TextBox2.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(160, Byte), Integer))
		Me.TextBox2.Cursor = System.Windows.Forms.Cursors.Default
		Me.TextBox2.Font = New System.Drawing.Font("Lucida Console", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.TextBox2.Location = New System.Drawing.Point(3, 83)
		Me.TextBox2.MaxLength = 0
		Me.TextBox2.Multiline = True
		Me.TextBox2.Name = "TextBox2"
		Me.TextBox2.ReadOnly = True
		Me.TextBox2.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
		Me.TextBox2.Size = New System.Drawing.Size(469, 150)
		Me.TextBox2.TabIndex = 3
		Me.TextBox2.TabStop = False
		'
		'Button1
		'
		Me.Button1.BackColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(0, Byte), Integer))
		Me.Button1.Font = New System.Drawing.Font("微软雅黑", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
		Me.Button1.Location = New System.Drawing.Point(339, 239)
		Me.Button1.Name = "Button1"
		Me.Button1.Size = New System.Drawing.Size(133, 46)
		Me.Button1.TabIndex = 6
		Me.Button1.TabStop = False
		Me.Button1.Text = "开始转换"
		Me.Button1.UseVisualStyleBackColor = False
		'
		'TabCtrl
		'
		Me.TabCtrl.Controls.Add(Me.TabPage1)
		Me.TabCtrl.Controls.Add(Me.TabPage2)
		Me.TabCtrl.Dock = System.Windows.Forms.DockStyle.Fill
		Me.TabCtrl.Font = New System.Drawing.Font("微软雅黑", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
		Me.TabCtrl.Location = New System.Drawing.Point(0, 0)
		Me.TabCtrl.Name = "TabCtrl"
		Me.TabCtrl.SelectedIndex = 0
		Me.TabCtrl.Size = New System.Drawing.Size(483, 337)
		Me.TabCtrl.TabIndex = 7
		Me.TabCtrl.TabStop = False
		'
		'TabPage1
		'
		Me.TabPage1.Controls.Add(Me.CheckBox4)
		Me.TabPage1.Controls.Add(Me.CheckBox3)
		Me.TabPage1.Controls.Add(Me.CheckBox2)
		Me.TabPage1.Controls.Add(Me.CheckBox1)
		Me.TabPage1.Controls.Add(Me.Label1)
		Me.TabPage1.Controls.Add(Me.Button1)
		Me.TabPage1.Controls.Add(Me.TextBox1)
		Me.TabPage1.Controls.Add(Me.Label2)
		Me.TabPage1.Controls.Add(Me.TextBox2)
		Me.TabPage1.Font = New System.Drawing.Font("微软雅黑", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
		Me.TabPage1.Location = New System.Drawing.Point(4, 28)
		Me.TabPage1.Name = "TabPage1"
		Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
		Me.TabPage1.Size = New System.Drawing.Size(475, 305)
		Me.TabPage1.TabIndex = 0
		Me.TabPage1.Text = "Uni2Hex"
		Me.TabPage1.UseVisualStyleBackColor = True
		'
		'CheckBox4
		'
		Me.CheckBox4.AutoSize = True
		Me.CheckBox4.Location = New System.Drawing.Point(115, 262)
		Me.CheckBox4.Name = "CheckBox4"
		Me.CheckBox4.Size = New System.Drawing.Size(80, 23)
		Me.CheckBox4.TabIndex = 10
		Me.CheckBox4.Text = "高位在前"
		Me.CheckBox4.UseVisualStyleBackColor = True
		'
		'CheckBox3
		'
		Me.CheckBox3.AutoSize = True
		Me.CheckBox3.Location = New System.Drawing.Point(3, 262)
		Me.CheckBox3.Name = "CheckBox3"
		Me.CheckBox3.Size = New System.Drawing.Size(80, 23)
		Me.CheckBox3.TabIndex = 9
		Me.CheckBox3.Text = "低位在前"
		Me.CheckBox3.UseVisualStyleBackColor = True
		'
		'CheckBox2
		'
		Me.CheckBox2.AutoSize = True
		Me.CheckBox2.Location = New System.Drawing.Point(115, 239)
		Me.CheckBox2.Name = "CheckBox2"
		Me.CheckBox2.Size = New System.Drawing.Size(80, 23)
		Me.CheckBox2.TabIndex = 8
		Me.CheckBox2.Text = "全部转换"
		Me.CheckBox2.UseVisualStyleBackColor = True
		'
		'CheckBox1
		'
		Me.CheckBox1.AutoSize = True
		Me.CheckBox1.Location = New System.Drawing.Point(3, 239)
		Me.CheckBox1.Name = "CheckBox1"
		Me.CheckBox1.Size = New System.Drawing.Size(106, 23)
		Me.CheckBox1.TabIndex = 7
		Me.CheckBox1.Text = "保留英文字符"
		Me.CheckBox1.UseVisualStyleBackColor = True
		'
		'TabPage2
		'
		Me.TabPage2.Controls.Add(Me.CheckBox5)
		Me.TabPage2.Controls.Add(Me.CheckBox6)
		Me.TabPage2.Controls.Add(Me.Button2)
		Me.TabPage2.Controls.Add(Me.TextBox3)
		Me.TabPage2.Controls.Add(Me.Label4)
		Me.TabPage2.Controls.Add(Me.TextBox4)
		Me.TabPage2.Controls.Add(Me.Label3)
		Me.TabPage2.Font = New System.Drawing.Font("微软雅黑", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
		Me.TabPage2.Location = New System.Drawing.Point(4, 28)
		Me.TabPage2.Name = "TabPage2"
		Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
		Me.TabPage2.Size = New System.Drawing.Size(475, 305)
		Me.TabPage2.TabIndex = 1
		Me.TabPage2.Text = "Hex2Uni"
		Me.TabPage2.UseVisualStyleBackColor = True
		'
		'CheckBox5
		'
		Me.CheckBox5.AutoSize = True
		Me.CheckBox5.Location = New System.Drawing.Point(3, 262)
		Me.CheckBox5.Name = "CheckBox5"
		Me.CheckBox5.Size = New System.Drawing.Size(80, 23)
		Me.CheckBox5.TabIndex = 12
		Me.CheckBox5.Text = "低位在前"
		Me.CheckBox5.UseVisualStyleBackColor = True
		'
		'CheckBox6
		'
		Me.CheckBox6.AutoSize = True
		Me.CheckBox6.Location = New System.Drawing.Point(115, 262)
		Me.CheckBox6.Name = "CheckBox6"
		Me.CheckBox6.Size = New System.Drawing.Size(80, 23)
		Me.CheckBox6.TabIndex = 11
		Me.CheckBox6.Text = "高位在前"
		Me.CheckBox6.UseVisualStyleBackColor = True
		'
		'Button2
		'
		Me.Button2.BackColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(0, Byte), Integer))
		Me.Button2.Font = New System.Drawing.Font("微软雅黑", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
		Me.Button2.Location = New System.Drawing.Point(339, 239)
		Me.Button2.Name = "Button2"
		Me.Button2.Size = New System.Drawing.Size(133, 46)
		Me.Button2.TabIndex = 7
		Me.Button2.TabStop = False
		Me.Button2.Text = "开始转换"
		Me.Button2.UseVisualStyleBackColor = False
		'
		'TextBox3
		'
		Me.TextBox3.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(160, Byte), Integer))
		Me.TextBox3.Font = New System.Drawing.Font("Lucida Console", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.TextBox3.Location = New System.Drawing.Point(3, 30)
		Me.TextBox3.MaxLength = 0
		Me.TextBox3.Name = "TextBox3"
		Me.TextBox3.Size = New System.Drawing.Size(469, 23)
		Me.TextBox3.TabIndex = 4
		Me.TextBox3.TabStop = False
		'
		'Label4
		'
		Me.Label4.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(0, Byte), Integer))
		Me.Label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me.Label4.Font = New System.Drawing.Font("微软雅黑", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
		Me.Label4.Location = New System.Drawing.Point(3, 56)
		Me.Label4.Name = "Label4"
		Me.Label4.Size = New System.Drawing.Size(469, 24)
		Me.Label4.TabIndex = 5
		Me.Label4.Text = "输出窗口"
		Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		'
		'TextBox4
		'
		Me.TextBox4.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(160, Byte), Integer))
		Me.TextBox4.Cursor = System.Windows.Forms.Cursors.Default
		Me.TextBox4.Font = New System.Drawing.Font("Lucida Console", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.TextBox4.Location = New System.Drawing.Point(3, 83)
		Me.TextBox4.MaxLength = 0
		Me.TextBox4.Multiline = True
		Me.TextBox4.Name = "TextBox4"
		Me.TextBox4.ReadOnly = True
		Me.TextBox4.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
		Me.TextBox4.Size = New System.Drawing.Size(469, 150)
		Me.TextBox4.TabIndex = 6
		Me.TextBox4.TabStop = False
		'
		'Label3
		'
		Me.Label3.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(0, Byte), Integer))
		Me.Label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me.Label3.Font = New System.Drawing.Font("微软雅黑", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
		Me.Label3.Location = New System.Drawing.Point(3, 3)
		Me.Label3.Name = "Label3"
		Me.Label3.Size = New System.Drawing.Size(469, 24)
		Me.Label3.TabIndex = 2
		Me.Label3.Text = "要转换的字符串"
		Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		'
		'Form1
		'
		Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.ClientSize = New System.Drawing.Size(483, 337)
		Me.Controls.Add(Me.TabCtrl)
		Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
		Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
		Me.MaximizeBox = False
		Me.Name = "Form1"
		Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
		Me.Text = "Unicode编码查看 - Lation.Woobhurk"
		Me.TopMost = True
		Me.TabCtrl.ResumeLayout(False)
		Me.TabPage1.ResumeLayout(False)
		Me.TabPage1.PerformLayout()
		Me.TabPage2.ResumeLayout(False)
		Me.TabPage2.PerformLayout()
		Me.ResumeLayout(False)

	End Sub
	Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
	Friend WithEvents Label1 As System.Windows.Forms.Label
	Friend WithEvents Label2 As System.Windows.Forms.Label
	Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
	Friend WithEvents Button1 As System.Windows.Forms.Button
	Friend WithEvents TabCtrl As System.Windows.Forms.TabControl
	Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
	Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
	Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
	Friend WithEvents Label4 As System.Windows.Forms.Label
	Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
	Friend WithEvents Label3 As System.Windows.Forms.Label
	Friend WithEvents Button2 As System.Windows.Forms.Button
	Friend WithEvents CheckBox2 As System.Windows.Forms.CheckBox
	Friend WithEvents CheckBox1 As System.Windows.Forms.CheckBox
	Friend WithEvents CheckBox4 As System.Windows.Forms.CheckBox
	Friend WithEvents CheckBox3 As System.Windows.Forms.CheckBox
	Friend WithEvents CheckBox5 As System.Windows.Forms.CheckBox
	Friend WithEvents CheckBox6 As System.Windows.Forms.CheckBox

End Class
