﻿Public Class Form1
	Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
		CheckBox1.Checked = True
		CheckBox3.Checked = True
		CheckBox5.Checked = True
	End Sub

	'得到焦点，逐渐不透明
	Private Sub Form1_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Activated
		While Me.Opacity < 1.0
			Me.Opacity += 0.00002
		End While
		Me.Opacity = 1.0
	End Sub

	'失去焦点，逐渐透明
	Private Sub Form1_Deactivate(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Deactivate
		While Me.Opacity > 0.3
			Me.Opacity -= 0.00002
		End While
		Me.Opacity = 0.3
	End Sub

	Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
		If TextBox1.Text = "" Then
			MsgBox("请输入要转换的字符串！", MsgBoxStyle.Exclamation, "Unicode编码查看 - 错误")
			Exit Sub
		End If
		If Not CheckBox1.Checked And Not CheckBox2.Checked And Not CheckBox3.Checked And Not CheckBox4.Checked Then
			MsgBox("请选择转换模式！", MsgBoxStyle.Exclamation, "Unicode编码查看 - 错误")
			Exit Sub
		End If
		If CheckBox1.Checked Then
			If CheckBox3.Checked Then
				Shell(Application.StartupPath + "\Uni2Hex " + Chr(34) + TextBox1.Text + Chr(34) + " 1 1", AppWinStyle.Hide, True)	 '加上引号
			ElseIf CheckBox4.Checked Then
				Shell(Application.StartupPath + "\Uni2Hex " + Chr(34) + TextBox1.Text + Chr(34) + " 1 2", AppWinStyle.Hide, True)
			End If
		ElseIf CheckBox2.Checked Then
			If CheckBox3.Checked Then
				Shell(Application.StartupPath + "\Uni2Hex " + Chr(34) + TextBox1.Text + Chr(34) + " 2 1", AppWinStyle.Hide, True)	 '加上引号
			ElseIf CheckBox4.Checked Then
				Shell(Application.StartupPath + "\Uni2Hex " + Chr(34) + TextBox1.Text + Chr(34) + " 2 2", AppWinStyle.Hide, True)
			End If
		End If
			FileOpen(1, Application.StartupPath + "\Unicode.txt", OpenMode.Input)
			Input(1, TextBox2.Text)
			FileClose(1)
			'Kill(Application.StartupPath + "\Unicode.txt")
	End Sub

	'当选中模式改变后，立即让对应的CheckBox选中
	Private Sub CheckBox1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox1.CheckedChanged
		CheckBox2.Checked = Not CheckBox1.Checked
	End Sub

	Private Sub CheckBox2_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CheckBox2.CheckedChanged
		CheckBox1.Checked = Not CheckBox2.Checked
	End Sub

	Private Sub CheckBox3_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CheckBox3.CheckedChanged
		CheckBox4.Checked = Not CheckBox3.Checked
	End Sub

	Private Sub CheckBox4_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CheckBox4.CheckedChanged
		CheckBox3.Checked = Not CheckBox4.Checked
	End Sub


	'=========================================================================
	'=========================================================================
	Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
		If TextBox3.Text = "" Then
			MsgBox("请输入要转换的字符串！", MsgBoxStyle.Exclamation, "Unicode编码查看 - 错误")
			Exit Sub
		End If
		If Not CheckBox5.Checked And Not CheckBox6.Checked Then
			MsgBox("请选择高低位模式！", MsgBoxStyle.Exclamation, "Unicode编码查看 - 错误")
			Exit Sub
		End If
		If CheckBox5.Checked Then
			Shell(Application.StartupPath + "\Hex2Uni " + Chr(34) + TextBox3.Text + Chr(34) + " 1", AppWinStyle.Hide, True)	 '加上引号
		ElseIf CheckBox6.Checked Then
			Shell(Application.StartupPath + "\Hex2Uni " + Chr(34) + TextBox3.Text + Chr(34) + " 2", AppWinStyle.Hide, True)
		End If
		FileOpen(1, Application.StartupPath + "\Unicode.txt", OpenMode.Input)
		Input(1, TextBox4.Text)
		FileClose(1)
		'Kill(Application.StartupPath + "\Unicode.txt")
	End Sub

	Private Sub CheckBox5_CheckStateChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CheckBox5.CheckStateChanged
		CheckBox6.Checked = Not CheckBox5.Checked
	End Sub

	Private Sub CheckBox6_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CheckBox6.CheckedChanged
		CheckBox5.Checked = Not CheckBox6.Checked
	End Sub
End Class
