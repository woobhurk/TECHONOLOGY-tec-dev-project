﻿Public NotInheritable Class DetailBox
	'Public Const DEBUG_ON As Boolean = False


	'得到焦点，逐渐不透明
	Private Sub DetailBox_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Activated
		While Me.Opacity < 1.0
			'If DEBUG_ON Then
			Me.Opacity += 0.00002
			'Else
			'Me.Opacity += 0.000002
			'End If
		End While
		Me.Opacity = 1.0
	End Sub

	'失去焦点，逐渐透明
	Private Sub DetailBox_Deactivate(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Deactivate
		While Me.Opacity > 0.3
			'If DEBUG_ON Then
			Me.Opacity -= 0.00002
			'Else
			'Me.Opacity -= 0.000002
			'End If
		End While
		Me.Opacity = 0.3
	End Sub

	'得到焦点，不透明
	'Private Sub DetailBox_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.GotFocus
	'Me.Opacity = 1.0
	'End Sub

	'失去焦点，透明
	'Private Sub DetailBox_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.LostFocus
	'Me.Opacity = 0.3
	'End Sub

	'关闭
	Private Sub OKBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OKBtn.Click
		Me.Close()
	End Sub
End Class
