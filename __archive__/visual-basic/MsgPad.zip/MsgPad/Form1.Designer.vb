﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意: 以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
		Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
		Me.Label1 = New System.Windows.Forms.Label
		Me.Label2 = New System.Windows.Forms.Label
		Me.TextBox2 = New System.Windows.Forms.TextBox
		Me.SaveBtn = New System.Windows.Forms.Button
		Me.DelBtn = New System.Windows.Forms.Button
		Me.PadBox = New System.Windows.Forms.ListBox
		Me.TextBox1 = New System.Windows.Forms.TextBox
		Me.ClrBtn = New System.Windows.Forms.Button
		Me.SuspendLayout()
		'
		'Label1
		'
		Me.Label1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(0, Byte), Integer))
		Me.Label1.Font = New System.Drawing.Font("微软雅黑", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
		Me.Label1.Location = New System.Drawing.Point(12, 9)
		Me.Label1.Name = "Label1"
		Me.Label1.Size = New System.Drawing.Size(634, 19)
		Me.Label1.TabIndex = 1
		Me.Label1.Text = "最近的留言 - 点击查看详细"
		Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		'
		'Label2
		'
		Me.Label2.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(0, Byte), Integer))
		Me.Label2.Font = New System.Drawing.Font("微软雅黑", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
		Me.Label2.Location = New System.Drawing.Point(12, 366)
		Me.Label2.Name = "Label2"
		Me.Label2.Size = New System.Drawing.Size(634, 19)
		Me.Label2.TabIndex = 2
		Me.Label2.Text = "新建的留言 - 上方输入标题,下方输入留言"
		Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		'
		'TextBox2
		'
		Me.TextBox2.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(160, Byte), Integer))
		Me.TextBox2.Font = New System.Drawing.Font("微软雅黑", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.TextBox2.Location = New System.Drawing.Point(12, 407)
		Me.TextBox2.MaxLength = 0
		Me.TextBox2.Multiline = True
		Me.TextBox2.Name = "TextBox2"
		Me.TextBox2.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
		Me.TextBox2.Size = New System.Drawing.Size(634, 195)
		Me.TextBox2.TabIndex = 3
		Me.TextBox2.TabStop = False
		'
		'SaveBtn
		'
		Me.SaveBtn.BackColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(0, Byte), Integer))
		Me.SaveBtn.Font = New System.Drawing.Font("微软雅黑", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
		Me.SaveBtn.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(128, Byte), Integer))
		Me.SaveBtn.Location = New System.Drawing.Point(12, 604)
		Me.SaveBtn.Name = "SaveBtn"
		Me.SaveBtn.Size = New System.Drawing.Size(82, 34)
		Me.SaveBtn.TabIndex = 4
		Me.SaveBtn.TabStop = False
		Me.SaveBtn.Text = "存储留言"
		Me.SaveBtn.UseVisualStyleBackColor = False
		'
		'DelBtn
		'
		Me.DelBtn.BackColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(0, Byte), Integer))
		Me.DelBtn.Enabled = False
		Me.DelBtn.Font = New System.Drawing.Font("微软雅黑", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
		Me.DelBtn.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(128, Byte), Integer))
		Me.DelBtn.Location = New System.Drawing.Point(100, 604)
		Me.DelBtn.Name = "DelBtn"
		Me.DelBtn.Size = New System.Drawing.Size(100, 34)
		Me.DelBtn.TabIndex = 5
		Me.DelBtn.TabStop = False
		Me.DelBtn.Text = "删除该留言"
		Me.DelBtn.UseVisualStyleBackColor = False
		'
		'PadBox
		'
		Me.PadBox.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(160, Byte), Integer))
		Me.PadBox.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.PadBox.Font = New System.Drawing.Font("微软雅黑", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
		Me.PadBox.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(128, Byte), Integer))
		Me.PadBox.FormattingEnabled = True
		Me.PadBox.ItemHeight = 21
		Me.PadBox.Location = New System.Drawing.Point(12, 29)
		Me.PadBox.Name = "PadBox"
		Me.PadBox.Size = New System.Drawing.Size(634, 336)
		Me.PadBox.TabIndex = 6
		Me.PadBox.TabStop = False
		'
		'TextBox1
		'
		Me.TextBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(160, Byte), Integer))
		Me.TextBox1.Font = New System.Drawing.Font("Lucida Console", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.TextBox1.Location = New System.Drawing.Point(12, 386)
		Me.TextBox1.MaxLength = 23
		Me.TextBox1.Name = "TextBox1"
		Me.TextBox1.Size = New System.Drawing.Size(634, 20)
		Me.TextBox1.TabIndex = 7
		Me.TextBox1.TabStop = False
		'
		'ClrBtn
		'
		Me.ClrBtn.BackColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(0, Byte), Integer))
		Me.ClrBtn.Enabled = False
		Me.ClrBtn.Font = New System.Drawing.Font("微软雅黑", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
		Me.ClrBtn.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(128, Byte), Integer))
		Me.ClrBtn.Location = New System.Drawing.Point(206, 604)
		Me.ClrBtn.Name = "ClrBtn"
		Me.ClrBtn.Size = New System.Drawing.Size(83, 34)
		Me.ClrBtn.TabIndex = 8
		Me.ClrBtn.TabStop = False
		Me.ClrBtn.Text = "清除留言"
		Me.ClrBtn.UseVisualStyleBackColor = False
		'
		'Form1
		'
		Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.AutoScroll = True
		Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
		Me.ClientSize = New System.Drawing.Size(658, 650)
		Me.Controls.Add(Me.ClrBtn)
		Me.Controls.Add(Me.TextBox1)
		Me.Controls.Add(Me.PadBox)
		Me.Controls.Add(Me.DelBtn)
		Me.Controls.Add(Me.SaveBtn)
		Me.Controls.Add(Me.TextBox2)
		Me.Controls.Add(Me.Label2)
		Me.Controls.Add(Me.Label1)
		Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
		Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
		Me.MaximizeBox = False
		Me.Name = "Form1"
		Me.Opacity = 0.9
		Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
		Me.Text = "留言板 - Lation.Woobhurk"
		Me.TopMost = True
		Me.ResumeLayout(False)
		Me.PerformLayout()

	End Sub
	Friend WithEvents Label1 As System.Windows.Forms.Label
	Friend WithEvents Label2 As System.Windows.Forms.Label
	Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
	Friend WithEvents SaveBtn As System.Windows.Forms.Button
	Private WithEvents DelBtn As System.Windows.Forms.Button
	Friend WithEvents PadBox As System.Windows.Forms.ListBox
	Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
	Friend WithEvents ClrBtn As System.Windows.Forms.Button

End Class
