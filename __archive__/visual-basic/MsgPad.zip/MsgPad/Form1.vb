﻿Public Class Form1
	Dim PadIdx As Integer = -1
	Dim DataFile As String

	'Public Const DEBUG_ON As Boolean = True


	'======================================================================
	'======================================================================
	'获取留言板标题
	Function GetPadTitle(ByVal Str As String) As String
		Dim Title As String

		Title = Mid(Str, 1, Str.IndexOf("\\"))
		GetPadTitle = Title
	End Function

	'获取留言板内容
	Function GetPadContext(ByVal str As String) As String
		Dim Context As String

		Context = Mid(str, str.IndexOf("\\") + 3, str.LastIndexOf("\\") - str.IndexOf("\\") - 2)
		GetPadContext = Context
	End Function

	'获取留言板时间
	Function GetPadTime(ByVal Str As String) As String
		Dim Time As String

		Time = Mid(Str, Str.LastIndexOf("\\") + 3)
		GetPadTime = Time
	End Function

	'储存数据
	Sub SavePad()
		Dim cnt As Integer

		FileOpen(1, DataFile, OpenMode.Output)
		If PadBox.Items.Count > 0 Then
			For cnt = 0 To PadBox.Items.Count - 1
				WriteLine(1, PadBox.Items(cnt).ToString)
			Next
		End If
		FileClose(1)
		'加密
		Shell(Application.StartupPath + "\encrypter MPData.mpd MPData.tmp 123456", AppWinStyle.Hide, True)
		Kill(DataFile)
		Rename(Application.StartupPath + "\MPData.tmp", DataFile)
		'加密完毕
	End Sub

	'读取数据
	Sub LoadPad()
		Dim cnt As Integer
		Dim Context As String

		'防错，如果没有MPData.mpd文件则创建
		FileOpen(1, DataFile, OpenMode.Random)
		If LOF(1) <= 0 Then
			FileClose(1)
			Exit Sub
		End If
		FileClose(1)
		'解密
		Shell(Application.StartupPath + "\encrypter MPData.mpd MPData.tmp 123456", AppWinStyle.Hide, True)
		Kill(DataFile)
		Rename(Application.StartupPath + "\MPData.tmp", DataFile)
		'加密完毕
		FileOpen(1, DataFile, OpenMode.Input)
		While Not EOF(1)
			Input(1, Context)
			PadBox.Items.Add(Context)
			cnt += 1
		End While
		ClrBtn.Enabled = True
		FileClose(1)
	End Sub


	'===========================================================================
	'===========================================================================
	Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
		DataFile = Application.StartupPath + "\MPData.mpd"
		Call LoadPad()
		MsgBox("欢迎使用留言板！", MsgBoxStyle.Information, "留言板 - Lation.Woobhurk")
	End Sub

	'得到焦点，逐渐不透明
	Private Sub Form1_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Activated
		While Me.Opacity < 1.0
			'If DEBUG_ON Then
			Me.Opacity += 0.00002
			'Else
			'Me.Opacity += 0.000002
			'End If
		End While
		Me.Opacity = 1.0
	End Sub

	'失去焦点，逐渐透明
	Private Sub Form1_Deactivate(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Deactivate
		While Me.Opacity > 0.3
			'If DEBUG_ON Then
			Me.Opacity -= 0.00002
			'Else
			'Me.Opacity -= 0.000002
			'End If
		End While
		Me.Opacity = 0.3
	End Sub

	'得到焦点，不透明
	'Private Sub Form1_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.GotFocus
	'Me.Opacity = 1.0
	'End Sub

	'失去焦点，透明
	'Private Sub Form1_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.LostFocus
	'Me.Opacity = 0.3
	'End Sub

	'关闭，储存数据
	Private Sub Form1_FormClosed(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
		Call SavePad()
	End Sub

	'点击，详情
	Private Sub PadBox_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles PadBox.Click
		If PadIdx = PadBox.SelectedIndex And PadIdx <> -1 Then
			DetailBox.Label1.Text = GetPadTitle(PadBox.Items(PadIdx).ToString)
			DetailBox.TextBox1.Text = GetPadContext(PadBox.Items(PadIdx).ToString)
			DetailBox.Label2.Text = GetPadTime(PadBox.Items(PadIdx).ToString)
			DetailBox.Show()
		Else
			PadIdx = PadBox.SelectedIndex
			If PadIdx <> -1 Then DelBtn.Enabled = True
		End If
	End Sub

	'添加留言
	Private Sub SaveBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveBtn.Click
		If TextBox1.Text <> "" And TextBox2.Text <> "" Then
			If TextBox1.Text.Contains("\") Then
				MsgBox("标题不能含有'\'！", MsgBoxStyle.Exclamation, "留言板 - 错误")
			Else
				PadBox.Items.Add(TextBox1.Text + "\\" + TextBox2.Text + "\\" + Now().ToString)
				ClrBtn.Enabled = True
			End If
		Else
			MsgBox("标题栏及内容栏必须输入内容！", MsgBoxStyle.Exclamation, "留言板 - 错误")
		End If
	End Sub

	'删除留言
	Private Sub DelBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DelBtn.Click
		If PadIdx <> -1 Then
			PadBox.Items.RemoveAt(PadIdx)
			'PadBox.Refresh()
			If PadBox.Items.Count > PadIdx Then
				PadBox.SetSelected(PadIdx, True)
			Else
				PadIdx = -1
				PadBox.ClearSelected()
				DelBtn.Enabled = False
			End If
		End If
		If PadBox.Items.Count = 0 Then
			DelBtn.Enabled = False
			ClrBtn.Enabled = False
		End If
	End Sub

	'清除留言
	Private Sub ClrBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ClrBtn.Click
		If MsgBox("确认要清除所有留言？", MsgBoxStyle.YesNo, "留言板 - 确认") = MsgBoxResult.Yes Then
			PadBox.Items.Clear()
		End If
	End Sub
End Class
