package tyfanch.electivehelper.view.vo;

public class OnlineCourseVoConst {
    private OnlineCourseVoConst() {}

    public static final String NAME = "onlineCourseVo";
}
