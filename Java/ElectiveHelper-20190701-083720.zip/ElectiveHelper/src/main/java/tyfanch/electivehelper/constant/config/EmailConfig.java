package tyfanch.electivehelper.constant.config;

public class EmailConfig {
    private EmailConfig() {}

    public static final String EMAIL_HOST = "localhost";
    public static final String EMAIL_AUTH = "true";
    public static final String EMAIL_USER = "tyfanch";
    public static final String EMAIL_PASSWORD = "abcabc";
    public static final String EMAIL_SUBJECT = "Activation";
    public static final String EMAIL_SENDER = "tyfanch@tyfanch.com";
    public static final String EMAIL_RECEIVER = "receiver@tyfanch.com";
}
