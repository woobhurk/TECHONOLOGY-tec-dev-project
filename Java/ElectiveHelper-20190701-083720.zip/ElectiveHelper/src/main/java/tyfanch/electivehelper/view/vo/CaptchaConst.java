package tyfanch.electivehelper.view.vo;

public class CaptchaConst {
    protected CaptchaConst() {}

    public static final String NAME = "captcha";
    public static final int CAPTCHA_LENGTH = 4;
    public static final int CAPTCHA_WIDTH = 160;
    public static final int CAPTCHA_HEIGHT = 40;
}
