package tyfanch.electivehelper.bean;

public class ClassroomConst {
    private ClassroomConst() {}

    public static final String NAME = "classroom";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_BUILDING = "building";
    public static final String COLUMN_ROOM = "room";
}
