package tyfanch.electivehelper.service.user;

/**
 * 用户处理业务
 */
public interface UserBizService {
}
