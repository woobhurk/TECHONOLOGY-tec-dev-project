package tyfanch.electivehelper.view.vo;

public class CourseVoConst {
    private CourseVoConst() {}

    public static final String NAME = "courseVo";
}
