package tyfanch.electivehelper.bean;

public class TeacherConst extends UniUserConst {
    private TeacherConst() {}

    public static final String NAME = "teacher";
}
