package tyfanch.electivehelper.view.vo;

public class UserVoConst {
    protected UserVoConst() {}

    public static final String NAME = "userVo";
}
