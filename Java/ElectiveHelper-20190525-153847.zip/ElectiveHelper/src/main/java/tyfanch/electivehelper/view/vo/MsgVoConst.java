package tyfanch.electivehelper.view.vo;

public class MsgVoConst {
    private MsgVoConst() {}

    public static final String NAME = "msgVo";
}
