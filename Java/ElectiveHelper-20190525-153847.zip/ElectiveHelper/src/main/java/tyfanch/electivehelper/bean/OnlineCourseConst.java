package tyfanch.electivehelper.bean;

public class OnlineCourseConst {
    private OnlineCourseConst() {}

    public static final String NAME = "onlineCourse";
}
