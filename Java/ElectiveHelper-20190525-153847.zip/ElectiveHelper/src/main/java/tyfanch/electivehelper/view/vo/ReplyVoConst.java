package tyfanch.electivehelper.view.vo;

public class ReplyVoConst {
    private ReplyVoConst() {}

    public static final String NAME = "replyVo";
}
