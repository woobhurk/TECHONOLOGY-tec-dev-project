package tyfanch.electivehelper.servlet;

import javax.servlet.annotation.WebServlet;

@WebServlet(name = "UserTypeServlet", urlPatterns = {"/UserType"})
public class UserTypeServlet extends CommonServlet {
}
