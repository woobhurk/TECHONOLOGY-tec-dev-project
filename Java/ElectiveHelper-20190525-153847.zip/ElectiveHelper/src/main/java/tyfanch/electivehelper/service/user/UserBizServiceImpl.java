package tyfanch.electivehelper.service.user;

public class UserBizServiceImpl implements UserBizService {
}
