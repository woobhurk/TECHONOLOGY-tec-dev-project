package tyfanch.electivehelper.dao.classroom;

import java.util.List;

public interface ClassroomDao {
    List findAll();
}
