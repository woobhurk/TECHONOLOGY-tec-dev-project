package tyfanch.electivehelper.bean;

import java.io.Serializable;

public class Student extends UniUser implements Serializable {
}
