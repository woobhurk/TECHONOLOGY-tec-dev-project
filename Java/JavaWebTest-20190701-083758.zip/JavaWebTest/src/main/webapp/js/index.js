init();

function init() {
    var btnTest = document.getElementById("btnTest");
    var spanTest = document.getElementById("spanTest");

    btnTest.addEventListener("click", getResponseFromServer);
}

function getResponseFromServer(event) {
    alert("hello");
    event.target.innerText = "OK";
}
