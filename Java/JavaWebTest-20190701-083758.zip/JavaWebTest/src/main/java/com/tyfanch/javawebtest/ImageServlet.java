package com.tyfanch.javawebtest;

import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.IOException;

/**
 * @author tyfanch
 */
@WebServlet(name = "Image", urlPatterns = {"/Image"})
public class ImageServlet extends HttpServlet {
    public static final int FONT_SIZE = 48;
    public static final int IMAGE_HEIGHT = FONT_SIZE * 5 / 4;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        ServletOutputStream outputStream;
        BufferedImage bufferedImage;
        Graphics graphics;
        String paramStr = request.getParameter("str");
        String attriStr = (String) request.getAttribute("str");
        String imageStr;

        if (paramStr != null && attriStr != null) {
            imageStr = paramStr + ", " + attriStr;
        } else if (paramStr == null && attriStr != null) {
            imageStr = attriStr;
        } else if (paramStr != null && attriStr == null) {
            imageStr = paramStr;
        } else {
            imageStr = "This is a demo str";
        }

        try {
            System.out.println("imageStr = " + imageStr);

            response.reset();
            response.setContentType("image/jpeg");
            outputStream = response.getOutputStream();
            bufferedImage = new BufferedImage(FONT_SIZE * imageStr.length(), IMAGE_HEIGHT, BufferedImage.TYPE_INT_RGB);
            graphics = bufferedImage.getGraphics();
            graphics.setColor(Color.DARK_GRAY);
            graphics.fillRect(0, 0, FONT_SIZE * imageStr.length(), IMAGE_HEIGHT);
            graphics.setColor(Color.WHITE);
            graphics.setFont(new Font("Consolas", Font.BOLD, FONT_SIZE));

            for (int i = 0; i < imageStr.length(); i++) {
                graphics.drawString("" + imageStr.charAt(i), FONT_SIZE * i + (IMAGE_HEIGHT - FONT_SIZE) / 2, FONT_SIZE);
                graphics.drawLine(FONT_SIZE * i, 0, FONT_SIZE * i, IMAGE_HEIGHT);
            }

            ImageIO.write(bufferedImage, "jpeg", outputStream);
            outputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}
