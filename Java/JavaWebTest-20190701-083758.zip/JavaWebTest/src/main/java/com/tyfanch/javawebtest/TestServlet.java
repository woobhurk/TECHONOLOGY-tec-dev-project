package com.tyfanch.javawebtest;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * @author tyfanch
 */
@WebServlet(name = "Test", urlPatterns = {"/Test"})
public class TestServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            PrintWriter printWriter = response.getWriter();
            response.setContentType("text/html");
            printWriter.println("<!DOCTYPE html><html><head><title>TestServlet</title></head>");
            printWriter.println("<body>");
            RequestDispatcher indexPageDispatcher = request.getRequestDispatcher("index.jsp");
            RequestDispatcher imageDispatcher = request.getRequestDispatcher("ImageServlet");
            indexPageDispatcher.include(request, response);
            imageDispatcher.include(request, response);
            printWriter.println("</body></html>");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}
