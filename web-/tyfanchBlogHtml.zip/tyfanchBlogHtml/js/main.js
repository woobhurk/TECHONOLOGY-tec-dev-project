// Constant
CARD_MAX_HEIGHT = 400;



// Hook
window.onload = function () {
    onLoadEvent();
};



// Function
function onLoadEvent() {
    initHtmlView();
    addNavBarMenuListener();
    addAnchorListener();
}

function initHtmlView() {
    var cards = document.getElementsByClassName("card");

    for (var i = 0; i < cards.length; i++) {
        var articleNode = cards[i].getElementsByTagName("article")[0];
        var imgNode = cards[i].getElementsByTagName("img")[0];

        if (articleNode.offsetHeight < CARD_MAX_HEIGHT) {
            imgNode.style.display = "none";
        }
    }
}

function addNavBarMenuListener() {
    // document.getElementById("navPiano").addEventListener("click", function (event) {
    //     document.getElementById("content").innerHTML = "";
    // });
}

function addAnchorListener() {
    var cards = document.getElementsByClassName("card");

    for (var i = 0; i < cards.length; i++) {
        cards[i].addEventListener('click', anchorListener);
    }
}

function anchorListener(event) {
    var node = event.target;
    var articleNode;
    var imgNode;

    while (node.nodeName != "A") {
        node = node.parentNode;
    }

    articleNode = node.getElementsByTagName("article")[0];
    imgNode = node.getElementsByTagName("img")[0];

    if (articleNode.style.maxHeight != "none") {
        articleNode.style.maxHeight = "none";
        imgNode.src = "./img/icon_expand_less_white.png";
    } else {
        articleNode.style.maxHeight = CARD_MAX_HEIGHT + "px";
        imgNode.src = "./img/icon_expand_white.png";
    }
}
